﻿
SET NOCOUNT ON

PRINT 'Loading PurgeInventory values...'

GO

MERGE
INTO [Admin].[PurgeInventory] AS tgt
USING (
	  SELECT
		  c.TABLE_NAME AS [Table]
	  FROM INFORMATION_SCHEMA.[COLUMNS] AS c
	  WHERE c.COLUMN_NAME = 'DateKey'
	  AND c.TABLE_SCHEMA = 'Inventory'
) AS src
ON src.[Table] = tgt.[Table]
WHEN NOT MATCHED BY TARGET
	THEN INSERT( [Table] )
		VALUES (src.[Table])
WHEN NOT MATCHED BY SOURCE
	THEN DELETE
WHEN MATCHED AND tgt.[Table] IN ('Databases','DiskSpace') AND tgt.[Retention] IS NULL
 THEN UPDATE SET [Retention] = 180
;

GO
