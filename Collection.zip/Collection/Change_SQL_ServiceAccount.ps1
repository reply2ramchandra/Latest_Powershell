﻿#Change SQL Server Service and Agent Account and Password
<#
##for one server
 $TargetServer='TPATWSQLCU02'
$services=Get-DbaService $TargetServer | Where-Object { $_.StartName -eq “NT Service\MSSQLSERVER” -OR $_.StartName -eq “NT Service\SQLSERVERAGENT” }  | Select-Object ServiceName,State
foreach($service in $services.ServiceName)
{$service.Change($null,$null,$null,$null,$null,$null,”HPS\svc_TPAPWMSSQL”,”n3wSTr0ngPw”)
if ($service.State -eq “Running”) {Restart-Service $service}}
svc_hpssql      	gm5jcNukn_ 
svc_datalinksql m#7K991Cb! 
x3lYNUm8

                

#>
# Get-DbaService -ComputerName $TargetServer | Where-Object { $_.StartName -eq "NT Service\MSSQL`$SQL04" }  | Out-GridView -Passthru | Update-DbaServiceAccount -ServiceCredential $cred
# Get-DbaService -ComputerName $TargetServer | Where-Object { $_.StartName -eq “NT Service\SQLAgent`$TEST” }  | Out-GridView -Passthru | Update-DbaServiceAccount -ServiceCredential $cred
 
#for Named instance use escape character ` after $ symbol
 Import-Module dbatools -EA SilentlyContinue 
 $TargetServer='TPAPWSQLDL005'
 Get-DbaService -ComputerName $TargetServer
 $cred = Get-Credential hps\svc_datalinksql
 Get-DbaService -ComputerName $TargetServer | Where-Object { $_.StartName -eq "NT Service\MSSQLSERVER" }  | Out-GridView -Passthru | Update-DbaServiceAccount -ServiceCredential $cred
 Get-DbaService -ComputerName $TargetServer | Where-Object { $_.StartName -eq “NT Service\SQLSERVERAGENT”}  | Out-GridView -Passthru | Update-DbaServiceAccount -ServiceCredential $cred
 Get-DbaService -ComputerName $TargetServer
