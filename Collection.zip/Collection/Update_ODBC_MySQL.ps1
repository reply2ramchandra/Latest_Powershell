﻿#Update MySQL ODBC
$server='tpapwdwsql004'
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& msiexec /quiet /passive /qn /i C:\tmp\mysql\mysql-connector-odbc-9.3.0-winx64.msi IACCEPTMYSQLCONNECTORODBCLICENSETERMS=YES"
}

