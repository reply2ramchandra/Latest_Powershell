﻿#connect the server and run
#C:\Program Files (x86)\Microsoft Visual Studio\Installer\InstallCleanup.exe -f