USE [master]
GO

/****** Object:  StoredProcedure [dbo].[SearchAllTables]    Script Date: 11/13/2022 1:43:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




--- EXEC SearchAllTables 'keycode'

CREATE PROC [dbo].[SearchAllTables]
(
   @SearchStr nvarchar(100)
)
AS
BEGIN

CREATE TABLE #Results (ColumnName nvarchar(370), ColumnValue nvarchar(3630))

   SET NOCOUNT ON

   DECLARE @TableName nvarchar(256), @ColumnName nvarchar(128), @SearchStr2 nvarchar(110)
   SET  @TableName = ''
   SET @SearchStr2 = QUOTENAME('%' + @SearchStr + '%','''')

   WHILE @TableName IS NOT NULL
   BEGIN
      SET @ColumnName = ''
      SET @TableName = 
      (
         SELECT MIN(QUOTENAME(TABLE_SCHEMA) + '.' + QUOTENAME(TABLE_NAME))
         FROM    INFORMATION_SCHEMA.TABLES
         WHERE       TABLE_TYPE = 'BASE TABLE'
            AND   QUOTENAME(TABLE_SCHEMA) + '.' + QUOTENAME(TABLE_NAME) > @TableName
            AND   OBJECTPROPERTY(
                  OBJECT_ID(
                     QUOTENAME(TABLE_SCHEMA) + '.' + QUOTENAME(TABLE_NAME)
                      ), 'IsMSShipped'
                         ) = 0
      )

      WHILE (@TableName IS NOT NULL) AND (@ColumnName IS NOT NULL)
      BEGIN
         SET @ColumnName =
         (
            SELECT MIN(QUOTENAME(COLUMN_NAME))
            FROM    INFORMATION_SCHEMA.COLUMNS
            WHERE       TABLE_SCHEMA   = PARSENAME(@TableName, 2)
               AND   TABLE_NAME   = PARSENAME(@TableName, 1)
               AND   DATA_TYPE IN ('char', 'varchar', 'nchar', 'nvarchar')
               AND   QUOTENAME(COLUMN_NAME) > @ColumnName
         )
   
         IF @ColumnName IS NOT NULL
         BEGIN
            INSERT INTO #Results
            EXEC
            (
               'SELECT ''' + @TableName + '.' + @ColumnName + ''', LEFT(' + @ColumnName + ', 3630) 
               FROM ' + @TableName + ' (NOLOCK) ' +
               ' WHERE ' + @ColumnName + ' LIKE ' + @SearchStr2
            )
         END
      END   
   END

   SELECT ColumnName, ColumnValue FROM #Results
END


GO

/****** Object:  StoredProcedure [dbo].[sp_DBA_Restore_Logic]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_DBA_Restore_Logic]
@db_name sysname

AS

SET NOCOUNT ON


/*****************************************************************************/
/* This script can be run for SQL 2005, 2008 Non-R2 and 2008 R2 Environments */
/*****************************************************************************/

/* Declare Variables */
DECLARE 
@restore_to_datetime datetime--, 
--@db_name sysname

/*************************************************************************/
/* Change <Database Name> to desired database and execute against Master */
/*************************************************************************/

--select @db_name = N'DBA_Repository'

select @restore_to_datetime = GETDATE()

declare @server_name nvarchar(512)
set @server_name = cast(serverproperty(N'Servername') as nvarchar(512))
                  
DECLARE 
@first_full_backupset_id            INTEGER,
@first_full_backup_startdate        DATETIME,
@count_entries                      INTEGER,
@in_restore_plan                    BIT,
@last_backupset_type                CHAR(1),
@last_backupset_id                  INTEGER,
@last_backupset_family_guid         UNIQUEIDENTIFIER,
@last_backupset_diff_base_guid      UNIQUEIDENTIFIER,
@last_backupset_recovery_fork_guid  UNIQUEIDENTIFIER,
@full_backupset_id                  INTEGER,
@full_backupset_start_date          DATETIME,
@full_backupset_recovery_fork_guid  UNIQUEIDENTIFIER,
@loop_var                           BIT,
@loop_backup_set_id                 INTEGER,
@loop_start_date                    DATETIME,
      @count_unique_fork_guid             INTEGER,
@t1_backup_set_id                   INTEGER,
@t1_type                            CHAR(1),
@t1_backup_start_date               DATETIME,
@t1_first_recovery_fork_guid        UNIQUEIDENTIFIER,
@t1_last_recovery_fork_guid         UNIQUEIDENTIFIER,
@t1_first_lsn                       NUMERIC(25, 0),
@t1_last_lsn                        NUMERIC(25, 0),
@t1_checkpoint_lsn                  NUMERIC(25, 0),
@t1_database_backup_lsn             NUMERIC(25, 0),
@t1_fork_point_lsn                  NUMERIC(25, 0),
@t1_backup_set_uuid                 UNIQUEIDENTIFIER,
@t1_database_guid                   UNIQUEIDENTIFIER,
@t1_diff_base_guid                  UNIQUEIDENTIFIER,
@t2_backup_set_id                   INTEGER,
@t2_type                            CHAR(1),
@t2_backup_start_date               DATETIME,
@t2_first_recovery_fork_guid        UNIQUEIDENTIFIER,
@t2_last_recovery_fork_guid         UNIQUEIDENTIFIER,
@t2_first_lsn                       NUMERIC(25, 0),
@t2_last_lsn                        NUMERIC(25, 0),
@t2_checkpoint_lsn                  NUMERIC(25, 0),
@t2_database_backup_lsn             NUMERIC(25, 0),
@t2_fork_point_lsn                  NUMERIC(25, 0),
@t2_backup_set_uuid                 UNIQUEIDENTIFIER,
@t2_database_guid                   UNIQUEIDENTIFIER,
@t2_diff_base_guid                  UNIQUEIDENTIFIER
    
CREATE TABLE #backupset(
backup_set_id                       INTEGER          NOT NULL,
is_in_restore_plan                  BIT              NOT NULL,
backup_start_date                   DATETIME         NOT NULL,
type                                CHAR(1)          NOT NULL,
database_name                       NVARCHAR(256)    NOT NULL,
database_guid                       UNIQUEIDENTIFIER ,
family_guid                         UNIQUEIDENTIFIER ,
first_recovery_fork_guid            UNIQUEIDENTIFIER ,
last_recovery_fork_guid             UNIQUEIDENTIFIER ,
first_lsn                           NUMERIC(25, 0)   , 
last_lsn                            NUMERIC(25, 0)   ,
checkpoint_lsn                      NUMERIC(25, 0)   ,
database_backup_lsn                 NUMERIC(25, 0)   ,
fork_point_lsn                      NUMERIC(25, 0)   ,
restore_till_lsn                    NUMERIC(25, 0)   ,
backup_set_uuid                     UNIQUEIDENTIFIER ,
differential_base_guid              UNIQUEIDENTIFIER
)
/**********************************************************************/
/* Identify the first                                                 */
/**********************************************************************/
SELECT @first_full_backupset_id = backupset_outer.backup_set_id
      ,@first_full_backup_startdate = backupset_outer.backup_start_date
FROM msdb.dbo.backupset backupset_outer
WHERE backupset_outer.database_name = @db_name
   AND backupset_outer.server_name = @server_name
   AND backupset_outer.type = 'D' -- Full Database Backup   
   AND backupset_outer.backup_start_date = (  SELECT MAX(backupset_inner.backup_start_date)
                                              FROM msdb.dbo.backupset backupset_inner
                                              WHERE backupset_inner.database_name = backupset_outer.database_name
                                                     AND backupset_inner.server_name = @server_name
                                                     AND backupset_inner.type = backupset_outer.type 
                                                     AND backupset_inner.backup_start_date <= @restore_to_datetime
                                                     AND backupset_inner.is_copy_only = 0 )
   AND backupset_outer.is_copy_only = 0
/*******************************************************************************************/
/* Find the first full database backup needed in the restore plan and store its attributes */
/* in #backupset work table                                                                */ 
/*******************************************************************************************/
INSERT #backupset(
   backup_set_id             
  ,is_in_restore_plan        
  ,backup_start_date         
  ,type                      
  ,database_name
  ,last_recovery_fork_guid
)
SELECT backup_set_id             
      ,1                   --  The full database backup is always needed for the restore plan
      ,backup_start_date         
      ,type                      
      ,database_name
      ,last_recovery_fork_guid
FROM msdb.dbo.backupset
WHERE msdb.dbo.backupset.backup_set_id = @first_full_backupset_id
AND msdb.dbo.backupset.server_name = @server_name

/***************************************************************/
/* Find the log and differential backups that occurred after   */
/* the full backup and store them in #backupset work table     */ 
/***************************************************************/
INSERT #backupset(
   backup_set_id
  ,is_in_restore_plan 
  ,backup_start_date         
  ,type                      
  ,database_name
  ,last_recovery_fork_guid
)
SELECT backup_set_id             
      ,0
      ,backup_start_date         
      ,type                      
      ,database_name
      ,last_recovery_fork_guid
FROM msdb.dbo.backupset
WHERE msdb.dbo.backupset.database_name = @db_name
   AND msdb.dbo.backupset.server_name = @server_name
   AND msdb.dbo.backupset.type IN ('I', 'L')  -- Differential, Log backups
   AND msdb.dbo.backupset.backup_start_date >=  @first_full_backup_startdate
   
/**********************************************************************************/
/* identify and mark the backup logs that need to be included in the restore plan */
/**********************************************************************************/
UPDATE #backupset  
   SET is_in_restore_plan = 1
WHERE #backupset.type = 'I'
   AND #backupset.backup_start_date = ( SELECT MAX(backupset_inner.backup_start_date)
                                        FROM #backupset backupset_inner
                                        WHERE backupset_inner.type = #backupset.type
                                        AND backupset_inner.backup_start_date <= @restore_to_datetime)
  
/**************************************************************************************/
/* Log backups that occurred after the different are always part of the restore plan. */
/**************************************************************************************/
UPDATE #backupset  
   SET is_in_restore_plan = 1
WHERE #backupset.type = 'L'
   AND #backupset.backup_start_date <= @restore_to_datetime
  AND #backupset.backup_start_date >= (SELECT backupset_inner.backup_start_date
                                        FROM #backupset backupset_inner
                                        WHERE backupset_inner.type = 'I'
                                           AND backupset_inner.is_in_restore_plan = 1)
                                           
/**************************************************************************************/
/* If @restore_to_datetime is greater than the last startdate of the last log backup, */
/* include the next log backup in the restore plan                                    */
/**************************************************************************************/
UPDATE #backupset  
   SET is_in_restore_plan = 1
WHERE #backupset.type = 'L'
   AND #backupset.backup_start_date = (SELECT MIN(backupset_inner.backup_start_date)
                                       FROM #backupset backupset_inner
                                       WHERE backupset_inner.type = 'L'
                                          AND backupset_inner.backup_start_date > @restore_to_datetime
                                          AND backupset_inner.is_in_restore_plan = 0)
                                           
/**************************************************************************************/
/* If there are no differential backups, all log backups that occurred after the full */
/* backup are needed in the restore plan.                                             */
/**************************************************************************************/
UPDATE #backupset  
   SET is_in_restore_plan = 1
WHERE #backupset.type = 'L'
   AND #backupset.backup_start_date <= @restore_to_datetime
   AND NOT EXISTS(SELECT *
                  FROM #backupset backupset_inner
                  WHERE backupset_inner.type = 'I')
                   
/**************************************************************************************/
/* The above plan is based on backup_start_date which fails in case when the DB is    */
/* restored to a previous state i.e forked. In which case we need to base it on lsn   */
/* numbers. This forking condition can be checked by matching the                     */
/* last_recovery_fork_guid of the backupset if it doesn't match, we need to change    */
/* the plan.                                                                          */
/**************************************************************************************/

SELECT @count_unique_fork_guid = COUNT( DISTINCT last_recovery_fork_guid )
  FROM #backupset

IF @count_unique_fork_guid > 1
BEGIN

DELETE 
FROM #backupset
/**************************************************************************************/
/* First we look for a T-Log backup taken after the given point-in-time to get the    */
/* tail log, that can be used to restore to the exact point-in-time.                  */
/**************************************************************************************/

INSERT #backupset(
      backup_set_id,
      is_in_restore_plan,
      backup_start_date,
      type,
      database_name,
      database_guid,
      family_guid,
      first_recovery_fork_guid,
      last_recovery_fork_guid,
      first_lsn,
      last_lsn,
      checkpoint_lsn,
      database_backup_lsn,
      fork_point_lsn,
      backup_set_uuid,
      differential_base_guid
)
SELECT TOP(1)
      backup_set_id,
      1,
      backup_start_date,
      type,
      database_name,
      database_guid,
      family_guid,
      first_recovery_fork_guid,
      last_recovery_fork_guid,
      first_lsn,
      last_lsn,
      checkpoint_lsn,
      database_backup_lsn,
      fork_point_lsn,
      backup_set_uuid,
      differential_base_guid
                 
FROM msdb.dbo.backupset
WHERE msdb.dbo.backupset.database_name = @db_name
   AND msdb.dbo.backupset.type IN ('D', 'L')
   AND msdb.dbo.backupset.backup_start_date >= @restore_to_datetime
ORDER BY msdb.dbo.backupset.backup_start_date ASC,
              msdb.dbo.backupset.last_lsn ASC                                          
                                              
SELECT @last_backupset_type = bset.type
FROM #backupset as bset

IF @last_backupset_type = 'D' --Full
BEGIN 
      DELETE FROM #backupset
END

/**********************************************************************/
/* If no T-Log backup exits for after the time T, get the last backup */
/**********************************************************************/                                          

SELECT @count_entries = COUNT(bset.backup_set_id)
FROM #backupset as bset

IF @count_entries < 1
BEGIN

      INSERT #backupset(
            backup_set_id,
            is_in_restore_plan,
            backup_start_date,
            type,
            database_name,
            database_guid,
            family_guid,
            first_recovery_fork_guid,
            last_recovery_fork_guid,
            first_lsn,
            last_lsn,
            checkpoint_lsn,
            database_backup_lsn,
            fork_point_lsn,
            backup_set_uuid,
            differential_base_guid
)
      SELECT TOP(1)
            backup_set_id,
            1,
            backup_start_date,
            type,
            database_name,
            database_guid,
            family_guid,
            first_recovery_fork_guid,
            last_recovery_fork_guid,
            first_lsn,
            last_lsn,
            checkpoint_lsn,
            database_backup_lsn,
            fork_point_lsn,
            backup_set_uuid,
            differential_base_guid
      FROM msdb.dbo.backupset
      WHERE msdb.dbo.backupset.database_name = @db_name
        AND msdb.dbo.backupset.backup_start_date <= @restore_to_datetime
        ORDER BY msdb.dbo.backupset.backup_start_date DESC,
            msdb.dbo.backupset.last_lsn DESC 
            
END

SELECT @last_backupset_type = bset.type,
         @last_backupset_id = bset.backup_set_id,
         @last_backupset_family_guid = bset.family_guid,
         @last_backupset_diff_base_guid = bset.differential_base_guid,
         @last_backupset_recovery_fork_guid = bset.last_recovery_fork_guid       
FROM #backupset as bset
  
/**************************************************************************************/
/* If the selected backup is Full ('D') return.                                       */
/**************************************************************************************/

IF (@last_backupset_type = 'D')
BEGIN
      GOTO done
END 

/**************************************************************************************/
/* If the selected backup is Differential('I'),select the Diff-base backup(Full) also */
/**************************************************************************************/
IF (@last_backupset_type = 'I')
BEGIN
      
      INSERT #backupset(
                  backup_set_id,
                  is_in_restore_plan,
                  backup_start_date,
                  type,
                  database_name,
                  database_guid,
                  family_guid,
                  first_recovery_fork_guid,
                  last_recovery_fork_guid,
                  first_lsn,
                  last_lsn,
                  checkpoint_lsn,
                  database_backup_lsn,
                  fork_point_lsn,
                  backup_set_uuid,
                  differential_base_guid
            )
            SELECT TOP(1)
                  backup_set_id,
                  1,
                  backup_start_date,
                  type,
                  database_name,
                  database_guid,
                  family_guid,
                  first_recovery_fork_guid,
                  last_recovery_fork_guid,
                  first_lsn,
                  last_lsn,
                  checkpoint_lsn,
                  database_backup_lsn,
                  fork_point_lsn,
                  backup_set_uuid,
                  differential_base_guid
            FROM msdb.dbo.backupset
            WHERE msdb.dbo.backupset.backup_set_uuid = @last_backupset_diff_base_guid
              AND msdb.dbo.backupset.family_guid = @last_backupset_family_guid
      GOTO done
END

SELECT @t1_type = bset.type,
         @t1_backup_set_id = bset.backup_set_id,
         @t1_backup_set_uuid = bset.backup_set_uuid,
         @t1_backup_start_date = bset.backup_start_date,
         @t1_diff_base_guid = bset.differential_base_guid,
         @t1_last_recovery_fork_guid = bset.last_recovery_fork_guid,
         @t1_first_recovery_fork_guid = bset.first_recovery_fork_guid,
         @t1_database_guid = bset.database_guid,
         @t1_first_lsn = bset.first_lsn,
         @t1_last_lsn = bset.last_lsn,
         @t1_checkpoint_lsn = bset.checkpoint_lsn,
         @t1_database_backup_lsn = bset.database_backup_lsn,
         @t1_fork_point_lsn = bset.fork_point_lsn        
 FROM #backupset as bset

SET @loop_backup_set_id = @t1_backup_set_id
SET @loop_start_date = @t1_backup_start_date

/**************************************************************************************/
/* This Loop iterates thru the backup with the same family_guid in reverse order and  */
/* constructs the T-Log chain, until it finds the compatible Diff or Backup           */
/**************************************************************************************/
SET @loop_var = 1  
WHILE ( @loop_var = 1 )
BEGIN
      
      SELECT TOP(1)
            @t2_backup_set_id = backup_set_id,
            @t2_backup_set_uuid = backup_set_uuid,
            @t2_backup_start_date = backup_start_date,
            @t2_type = type,
            @t2_first_recovery_fork_guid = first_recovery_fork_guid,
            @t2_last_recovery_fork_guid= last_recovery_fork_guid,
            @t2_database_guid = database_guid,
            @t2_first_lsn = first_lsn,
            @t2_last_lsn = last_lsn,
            @t2_checkpoint_lsn = checkpoint_lsn,
            @t2_database_backup_lsn = database_backup_lsn,
            @t2_fork_point_lsn= fork_point_lsn,
            @t2_diff_base_guid = differential_base_guid           
      FROM msdb.dbo.backupset
      WHERE msdb.dbo.backupset.family_guid = @last_backupset_family_guid
        AND msdb.dbo.backupset.backup_start_date <= @loop_start_date
        AND msdb.dbo.backupset.backup_set_id < @loop_backup_set_id
        ORDER BY msdb.dbo.backupset.backup_start_date DESC,
            msdb.dbo.backupset.last_lsn DESC, 
            msdb.dbo.backupset.backup_set_id DESC 
            
      IF( @t2_backup_set_id IS NULL OR @t2_backup_set_id = @loop_backup_set_id) 
      BEGIN
            GOTO done
      END 
      
      IF( @t1_fork_point_lsn IS NULL )
      BEGIN
      
            IF (@t2_type = 'D' AND @t2_database_guid = @t1_database_guid 
 AND @t2_first_lsn = @t1_first_lsn 
 AND @t2_last_recovery_fork_guid = @t1_first_recovery_fork_guid )
            BEGIN
                  GOTO AddFullBackup
            END
            
            IF (@t2_type = 'I' AND @t2_database_guid = @t1_database_guid 
 AND  @t2_last_recovery_fork_guid = @t1_first_recovery_fork_guid )
            BEGIN 
                  GOTO AddDiffBackup
            END         
            
            IF (@t2_type = 'L' AND @t2_last_recovery_fork_guid = @t1_first_recovery_fork_guid 
 AND @t2_last_lsn = @t1_first_lsn)
            BEGIN
                  INSERT #backupset(
                        backup_set_id,
                        is_in_restore_plan,
                        backup_start_date,
                        type,
                        database_name,
                        database_guid,
                        family_guid,
                        first_recovery_fork_guid,
                        last_recovery_fork_guid,
                        first_lsn,
                        last_lsn,
                        checkpoint_lsn,
                        database_backup_lsn,
                        fork_point_lsn,
                        backup_set_uuid,
                        differential_base_guid
                  )
                  SELECT TOP(1)
                        backup_set_id,
                        1,
                        backup_start_date,
                        type,
                        database_name,
                        database_guid,
                        family_guid,
                        first_recovery_fork_guid,
                        last_recovery_fork_guid,
                        first_lsn,
                        last_lsn,
                        checkpoint_lsn,
                        database_backup_lsn,
                        fork_point_lsn,
                        backup_set_uuid,
                        differential_base_guid

                  FROM msdb.dbo.backupset
                  WHERE msdb.dbo.backupset.backup_set_id = @t2_backup_set_id  
                  
                  SET   @t1_type = @t2_type
                  SET   @t1_backup_set_id = @t2_backup_set_id
                  SET   @t1_backup_set_uuid = @t2_backup_set_uuid
                  SET   @t1_backup_start_date = @t2_backup_start_date
                  SET   @t1_diff_base_guid = @t2_diff_base_guid
                  SET   @t1_last_recovery_fork_guid = @t2_last_recovery_fork_guid
                  SET   @t1_first_recovery_fork_guid = @t2_first_recovery_fork_guid
                  SET   @t1_database_guid = @t2_database_guid
                  SET   @t1_first_lsn = @t2_first_lsn
                  SET   @t1_last_lsn = @t2_last_lsn
                  SET   @t1_checkpoint_lsn = @t2_checkpoint_lsn
                  SET   @t1_database_backup_lsn = @t2_database_backup_lsn
                  SET   @t1_fork_point_lsn = @t2_fork_point_lsn      
                  
            END
      
      END
      ELSE
      BEGIN

            IF (@t2_type = 'D' AND ((@t2_last_recovery_fork_guid = @t1_first_recovery_fork_guid 
 AND @t2_last_lsn <= @t1_fork_point_lsn) 
                               OR  @t2_last_recovery_fork_guid = @t1_last_recovery_fork_guid 
 AND @t2_last_lsn > @t1_fork_point_lsn 
 AND @t2_last_lsn < @t1_last_lsn))
            BEGIN
                  GOTO AddFullBackup
            END
            
            IF (@t2_type = 'I' 
                  AND ((@t2_last_recovery_fork_guid = @t1_first_recovery_fork_guid 
AND @t2_last_lsn <= @t1_fork_point_lsn) 
OR @t2_last_recovery_fork_guid = @t1_last_recovery_fork_guid 
AND @t2_last_lsn > @t1_fork_point_lsn AND @t2_last_lsn < @t1_last_lsn))
            BEGIN
                  GOTO AddDiffBackup
            END
            
            IF (@t2_type = 'L' AND @t2_last_recovery_fork_guid = @t1_first_recovery_fork_guid 
 AND @t2_last_lsn = @t1_first_lsn)
            BEGIN
                  INSERT #backupset(
                        backup_set_id,
                        is_in_restore_plan,
                        backup_start_date,
                        type,
                        database_name,
                        database_guid,
                        family_guid,
                        first_recovery_fork_guid,
                        last_recovery_fork_guid,
                        first_lsn,
                        last_lsn,
                        checkpoint_lsn,
                        database_backup_lsn,
                        fork_point_lsn,
                        backup_set_uuid,
                        differential_base_guid
                  )
                  SELECT TOP(1)
                        backup_set_id,
                        1,
                        backup_start_date,
                        type,
                        database_name,
                        database_guid,
                        family_guid,
                        first_recovery_fork_guid,
                        last_recovery_fork_guid,
                        first_lsn,
                        last_lsn,
                        checkpoint_lsn,
                        database_backup_lsn,
                        fork_point_lsn,
                        backup_set_uuid,
                        differential_base_guid

                  FROM msdb.dbo.backupset
                  WHERE msdb.dbo.backupset.backup_set_id = @t2_backup_set_id  
                  
                  SET   @t1_type = @t2_type
                  SET   @t1_backup_set_id = @t2_backup_set_id
                  SET   @t1_backup_set_uuid = @t2_backup_set_uuid
                  SET   @t1_backup_start_date = @t2_backup_start_date
                  SET   @t1_diff_base_guid = @t2_diff_base_guid
                  SET   @t1_last_recovery_fork_guid = @t2_last_recovery_fork_guid
                  SET   @t1_first_recovery_fork_guid = @t2_first_recovery_fork_guid
                  SET   @t1_database_guid = @t2_database_guid
                  SET   @t1_first_lsn = @t2_first_lsn
                  SET   @t1_last_lsn = @t2_last_lsn
                  SET   @t1_checkpoint_lsn = @t2_checkpoint_lsn
                  SET   @t1_database_backup_lsn = @t2_database_backup_lsn
                  SET   @t1_fork_point_lsn = @t2_fork_point_lsn      
                  
            END
      END
      
      SET @loop_backup_set_id = @t2_backup_set_id
      SET @loop_start_date = @t2_backup_start_date
      
END

AddFullBackup:
INSERT #backupset(
      backup_set_id,
      is_in_restore_plan,
      backup_start_date,
      type,
      database_name,
      database_guid,
      family_guid,
      first_recovery_fork_guid,
      last_recovery_fork_guid,
      first_lsn,
      last_lsn,
      checkpoint_lsn,
      database_backup_lsn,
      fork_point_lsn,
      backup_set_uuid,
      differential_base_guid
)
SELECT TOP(1)
      backup_set_id,
      1,
      backup_start_date,
      type,
      database_name,
      database_guid,
      family_guid,
      first_recovery_fork_guid,
      last_recovery_fork_guid,
      first_lsn,
      last_lsn,
      checkpoint_lsn,
      database_backup_lsn,
      fork_point_lsn,
      backup_set_uuid,
      differential_base_guid
FROM msdb.dbo.backupset
WHERE msdb.dbo.backupset.backup_set_id = @t2_backup_set_id  
GOTO done

AddDiffBackup:    
INSERT #backupset(
      backup_set_id,
      is_in_restore_plan,
      backup_start_date,
      type,
      database_name,
      database_guid,
      family_guid,
      first_recovery_fork_guid,
      last_recovery_fork_guid,
      first_lsn,
      last_lsn,
      checkpoint_lsn,
      database_backup_lsn,
      fork_point_lsn,
      backup_set_uuid,
      differential_base_guid
)
SELECT TOP(1)
      backup_set_id,
      1,
      backup_start_date,
      type,
      database_name,
      database_guid,
      family_guid,
      first_recovery_fork_guid,
      last_recovery_fork_guid,
      first_lsn,
      last_lsn,
      checkpoint_lsn,
      database_backup_lsn,
      fork_point_lsn,
      backup_set_uuid,
      differential_base_guid
FROM msdb.dbo.backupset
WHERE msdb.dbo.backupset.backup_set_id = @t2_backup_set_id

INSERT #backupset(
      backup_set_id,
      is_in_restore_plan,
      backup_start_date,
      type,
      database_name,
      database_guid,
      family_guid,
      first_recovery_fork_guid,
      last_recovery_fork_guid,
      first_lsn,
      last_lsn,
      checkpoint_lsn,
      database_backup_lsn,
      fork_point_lsn,
      backup_set_uuid,
      differential_base_guid
)
SELECT TOP(1)
      backup_set_id,
      1,
      backup_start_date,
      type,
      database_name,
      database_guid,
      family_guid,
      first_recovery_fork_guid,
      last_recovery_fork_guid,
      first_lsn,
      last_lsn,
      checkpoint_lsn,
      database_backup_lsn,
      fork_point_lsn,
      backup_set_uuid,
      differential_base_guid
FROM msdb.dbo.backupset
WHERE msdb.dbo.backupset.backup_set_uuid = @t2_diff_base_guid
  AND msdb.dbo.backupset.family_guid = @last_backupset_family_guid


done:

SELECT @count_entries = COUNT( bset.backup_set_id )
  FROM #backupset AS bset
WHERE bset.type = 'D'

/**************************************************************************************/
/* If the backupset info in the msdb is incomplete then the restore_plan may be       */
/* broken. In those cases just don't return anything.                                 */
/**************************************************************************************/

IF @count_entries < 1
BEGIN
  DELETE 
  FROM #backupset
END 


END           
/**************************************************************************/
/* Items commented out are not required but can be commented in as needed */
/**************************************************************************/

SELECT '--******************** CHANGE THE LAST TRANSACTION LOG RESTORE TO RECOVERY ********************'
SELECT
--bkps.server_name AS [ServerName],
--bkps.machine_name AS [MachineName],
--bkps.database_name AS [DatabaseName],
CASE	WHEN bkps.type = 'D' THEN
'RESTORE DATABASE [' + bkps.database_name + '] FROM  DISK = N' + '''' + bkmf.physical_device_name + '''' + ' WITH FILE = 1, NORECOVERY,  NOUNLOAD,  REPLACE,  STATS = 10' 
		WHEN bkps.type = 'L' THEN
'RESTORE LOG [' + bkps.database_name + '] FROM  DISK = N' + '''' + bkmf.physical_device_name + '''' + ' WITH FILE = 1, NORECOVERY,  NOUNLOAD,  REPLACE,  STATS = 10'
		WHEN bkps.type = 'I' THEN
'RESTORE DATABASE [' + bkps.database_name + '] FROM  DISK = N' + '''' + bkmf.physical_device_name + '''' + ' WITH FILE = 1, NORECOVERY,  NOUNLOAD,  REPLACE,  STATS = 10'
		ELSE 'Undefined' END AS Restore_Code,
--bkps.type AS [Type],
--bkmf.physical_device_name,
--bkps.backup_size AS [BackupSize],
--bkps.name AS [Name],
bkps.backup_set_id AS [ID],
--btmp.is_in_restore_plan AS [IsInRestorePlan],
--bkps.backup_set_uuid AS [BackupSetUuid],
--bkps.media_set_id AS [MediaSetId],
--bkps.first_family_number AS [FirstFamilyNumber],
--bkps.first_media_number AS [FirstMediaNumber],
--bkps.last_family_number AS [LastFamilyNumber],
--bkps.last_media_number AS [LastMediaNumber],
--bkps.catalog_family_number AS [CatalogFamilyNumber],
--bkps.catalog_media_number AS [CatalogMediaNumber],
--bkps.position AS [Position],
--bkps.expiration_date AS [ExpirationDate],
--bkps.software_vendor_id AS [SoftwareVendorId],
--bkps.description AS [Description],
--bkps.user_name AS [UserName],
--bkps.software_major_version AS [SoftwareMajorVersion],
--bkps.software_minor_version AS [SoftwareMinorVersion],
--bkps.software_build_version AS [SoftwareBuildVersion],
--bkps.time_zone AS [TimeZone],
--bkps.mtf_minor_version AS [MtfMinorVersion],
--bkps.first_lsn AS [FirstLsn],
--bkps.last_lsn AS [LastLsn],
--bkps.checkpoint_lsn AS [CheckpointLsn],
--bkps.database_backup_lsn AS [DatabaseBackupLsn],
--bkps.database_creation_date AS [DatabaseCreationDate],
--bkps.backup_start_date AS [BackupStartDate],
bkps.backup_finish_date AS [BackupFinishDate]--,
--bkps.sort_order AS [SortOrder],
--bkps.code_page AS [CodePage],
--bkps.compatibility_level AS [CompatibilityLevel],
--bkps.database_version AS [DatabaseVersion],
--bkps.flags AS [Flags],
--bkps.unicode_locale AS [UnicodeLocale],
--bkps.unicode_compare_style AS [UnicodeCompareStyle],
--bkps.collation_name AS [CollationName],
--bkps.is_copy_only AS [IsCopyOnly]
INTO #finaltmp
FROM
#backupset AS btmp
INNER JOIN msdb.dbo.backupset AS bkps ON bkps.backup_set_id = btmp.backup_set_id 
INNER JOIN msdb.dbo.backupmediafamily AS bkmf ON bkps.media_set_id = bkmf.media_set_id
ORDER BY
[BackupFinishDate] ASC,[ID] ASC

select Restore_Code as ' ' from #finaltmp
drop table #backupset
drop table #finaltmp




GO

/****** Object:  StoredProcedure [dbo].[sp_help_revlogin]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_help_revlogin] @login_name sysname = NULL AS
DECLARE @name sysname
DECLARE @type varchar (1)
DECLARE @hasaccess int
DECLARE @denylogin int
DECLARE @is_disabled int
DECLARE @PWD_varbinary  varbinary (256)
DECLARE @PWD_string  varchar (514)
DECLARE @SID_varbinary varbinary (85)
DECLARE @SID_string varchar (514)
DECLARE @tmpstr  varchar (1024)
DECLARE @is_policy_checked varchar (3)
DECLARE @is_expiration_checked varchar (3)

DECLARE @defaultdb sysname
 
IF (@login_name IS NULL)
  DECLARE login_curs CURSOR FOR

      SELECT p.sid, p.name, p.type, p.is_disabled, p.default_database_name, l.hasaccess, l.denylogin FROM 
sys.server_principals p LEFT JOIN sys.syslogins l
      ON ( l.name = p.name ) WHERE p.type IN ( 'S', 'G', 'U' ) AND p.name <> 'sa'
ELSE
  DECLARE login_curs CURSOR FOR


      SELECT p.sid, p.name, p.type, p.is_disabled, p.default_database_name, l.hasaccess, l.denylogin FROM 
sys.server_principals p LEFT JOIN sys.syslogins l
      ON ( l.name = p.name ) WHERE p.type IN ( 'S', 'G', 'U' ) AND p.name = @login_name
OPEN login_curs

FETCH NEXT FROM login_curs INTO @SID_varbinary, @name, @type, @is_disabled, @defaultdb, @hasaccess, @denylogin
IF (@@fetch_status = -1)
BEGIN
  PRINT 'No login(s) found.'
  CLOSE login_curs
  DEALLOCATE login_curs
  RETURN -1
END
SET @tmpstr = '/* sp_help_revlogin script '
PRINT @tmpstr
SET @tmpstr = '** Generated ' + CONVERT (varchar, GETDATE()) + ' on ' + @@SERVERNAME + ' */'
PRINT @tmpstr
PRINT ''
WHILE (@@fetch_status <> -1)
BEGIN
  IF (@@fetch_status <> -2)
  BEGIN
    PRINT ''
    SET @tmpstr = '-- Login: ' + @name
    PRINT @tmpstr
    IF (@type IN ( 'G', 'U'))
    BEGIN -- NT authenticated account/group

      SET @tmpstr = 'CREATE LOGIN ' + QUOTENAME( @name ) + ' FROM WINDOWS WITH DEFAULT_DATABASE = [' + @defaultdb + ']'
    END
    ELSE BEGIN -- SQL Server authentication
        -- obtain password and sid
            SET @PWD_varbinary = CAST( LOGINPROPERTY( @name, 'PasswordHash' ) AS varbinary (256) )
        EXEC sp_hexadecimal @PWD_varbinary, @PWD_string OUT
        EXEC sp_hexadecimal @SID_varbinary,@SID_string OUT
 
        -- obtain password policy state
        SELECT @is_policy_checked = CASE is_policy_checked WHEN 1 THEN 'ON' WHEN 0 THEN 'OFF' ELSE NULL END FROM sys.sql_logins WHERE name = @name
        SELECT @is_expiration_checked = CASE is_expiration_checked WHEN 1 THEN 'ON' WHEN 0 THEN 'OFF' ELSE NULL END FROM sys.sql_logins WHERE name = @name
 
            SET @tmpstr = 'CREATE LOGIN ' + QUOTENAME( @name ) + ' WITH PASSWORD = ' + @PWD_string + ' HASHED, SID = ' + @SID_string + ', DEFAULT_DATABASE = [' + @defaultdb + ']'

        IF ( @is_policy_checked IS NOT NULL )
        BEGIN
          SET @tmpstr = @tmpstr + ', CHECK_POLICY = ' + @is_policy_checked
        END
        IF ( @is_expiration_checked IS NOT NULL )
        BEGIN
          SET @tmpstr = @tmpstr + ', CHECK_EXPIRATION = ' + @is_expiration_checked
        END
    END
    IF (@denylogin = 1)
    BEGIN -- login is denied access
      SET @tmpstr = @tmpstr + '; DENY CONNECT SQL TO ' + QUOTENAME( @name )
    END
    ELSE IF (@hasaccess = 0)
    BEGIN -- login exists but does not have access
      SET @tmpstr = @tmpstr + '; REVOKE CONNECT SQL TO ' + QUOTENAME( @name )
    END
    IF (@is_disabled = 1)
    BEGIN -- login is disabled
      SET @tmpstr = @tmpstr + '; ALTER LOGIN ' + QUOTENAME( @name ) + ' DISABLE'
    END
    PRINT @tmpstr
  END

  FETCH NEXT FROM login_curs INTO @SID_varbinary, @name, @type, @is_disabled, @defaultdb, @hasaccess, @denylogin
   END
CLOSE login_curs
DEALLOCATE login_curs
RETURN 0

GO

/****** Object:  StoredProcedure [dbo].[sp_hexadecimal]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_hexadecimal]
    @binvalue varbinary(256),
    @hexvalue varchar (514) OUTPUT
AS
DECLARE @charvalue varchar (514)
DECLARE @i int
DECLARE @length int
DECLARE @hexstring char(16)
SELECT @charvalue = '0x'
SELECT @i = 1
SELECT @length = DATALENGTH (@binvalue)
SELECT @hexstring = '0123456789ABCDEF'
WHILE (@i <= @length)
BEGIN
  DECLARE @tempint int
  DECLARE @firstint int
  DECLARE @secondint int
  SELECT @tempint = CONVERT(int, SUBSTRING(@binvalue,@i,1))
  SELECT @firstint = FLOOR(@tempint/16)
  SELECT @secondint = @tempint - (@firstint*16)
  SELECT @charvalue = @charvalue +
    SUBSTRING(@hexstring, @firstint+1, 1) +
    SUBSTRING(@hexstring, @secondint+1, 1)
  SELECT @i = @i + 1
END

SELECT @hexvalue = @charvalue

GO

/****** Object:  StoredProcedure [dbo].[sp_Load_Mail_DLL_startup_proc]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[sp_Load_Mail_DLL_startup_proc]
AS
declare @subject varchar(128), @recipients nvarchar(256)
set @recipients ='<Prod_SQLDBA@lsccom.com>' 

if convert(smallint,SERVERPROPERTY('IsClustered')) = 1
BEGIN
declare @LenSrv int , @LenNode int 
declare @SQLCMD varchar(8000)
set @LenSrv =  LEN(@@servername)
set @LenNode =  isnull( (select max(LEN(NodeName))  FROM fn_virtualservernodes()),10)
set @subject = @@servername+': SQL Server is starting up on Node,'+convert(varchar(256),SERVERPROPERTY('ComputerNamePhysicalNetBIOS'))+'.'
set @SQLCMD = 'set nocount on;
SELECT Day = Substring(datename(dw,getdate()),1,3),Mon = Substring(datename(mm,getdate()),1,3), StartupDateTime = getdate()
SELECT substring(@@servername,1,'+convert(varchar(5),@LenSrv)+') ServerName
, NodeName = substring(NodeName,1,'+convert(varchar(5),@LenNode)+')
, ActiveNode = case When isnull(convert(varchar(256),SERVERPROPERTY(''ComputerNamePhysicalNetBIOS'')),'''') =  ''''  then ''?''
					When convert(varchar(256),SERVERPROPERTY(''ComputerNamePhysicalNetBIOS'')) =  NodeName  then ''Yes''
					else '''' end
 FROM fn_virtualservernodes()
order by NodeName'
EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'Database Operations Notifications',
    @recipients = @recipients,
    @body = 'This message sent by startup stored procedure, sp_Load_Mail_DLL_startup_proc.
',
    @subject = @subject,
	@query = @SQLCMD
END
ELSE
BEGIN 
set @subject = @@servername+': SQL Server is starting up.'
set @SQLCMD = 'set nocount on;
SELECT Day = Substring(datename(dw,getdate()),1,3),Mon = Substring(datename(mm,getdate()),1,3), StartupDateTime = getdate()
'
EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'Database Operations Notifications',
    @recipients = @recipients,
    @body = 'This message sent by startup stored procedure, sp_Load_Mail_DLL_startup_proc.
',
    @subject = @subject,
	@query = @SQLCMD
END

WHILE 1=1
WAITFOR DELAY '01:00:00'

GO

EXEC sp_procoption N'[dbo].[sp_Load_Mail_DLL_startup_proc]', 'startup', '1'

GO

/****** Object:  StoredProcedure [dbo].[sp_monthlyindexmaintenance]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_monthlyindexmaintenance]

AS

SET NOCOUNT ON

/* Declare Variables */
DECLARE @objectid int;
DECLARE @indexid int;
DECLARE @partitioncount bigint;
DECLARE @schemaname nvarchar(130); 
DECLARE @objectname nvarchar(130); 
DECLARE @indexname nvarchar(130); 
DECLARE @partitionnum bigint;
DECLARE @partitions bigint;
DECLARE @frag float;
DECLARE @command nvarchar(4000);
DECLARE @engine int 

-- Run system view to gather fragmentation data and insert into table

SELECT * into #index_physical_stats 
from sys.dm_db_index_physical_stats (db_id(), null, null, null, 'detailed')
   
/* Prepare list of indexes to run maint. on w/ >= 5000 pages + min. 10% frag (lower than that provides no benefit) */  
SELECT
    object_id AS objectid,
    index_id AS indexid,
    partition_number AS partitionnum,
    avg_fragmentation_in_percent AS frag
INTO #requires_maintenance
FROM #index_physical_stats where
avg_fragmentation_in_percent >= 10.0 
AND index_id > 0 --make sure no heaps are included
AND page_count >= 5000.0

/* Determine SQL engine edition to determine if online rebuilds can be done  */
SELECT @engine = (SELECT CAST(SERVERPROPERTY( 'EngineEdition') as INT))
	IF @engine = 2 GOTO StandardED
	IF @engine = 3 GOTO EnterpriseED

StandardEd:

-- Declare the cursor for the list of partitions to be processed.
DECLARE partitions CURSOR FOR 
SELECT objectid,indexid,partitionnum,frag 
FROM #requires_maintenance;

-- Open the cursor.
OPEN partitions;

-- Loop through the partitions.
WHILE (1=1)
    BEGIN;
        FETCH NEXT
           FROM partitions
           INTO @objectid, @indexid, @partitionnum, @frag;
        IF @@FETCH_STATUS < 0 BREAK;
        SELECT @objectname = QUOTENAME(o.name), @schemaname = QUOTENAME(s.name)
        FROM sys.objects o
        JOIN sys.schemas s ON s.schema_id = o.schema_id
        WHERE o.object_id = @objectid;
        SELECT @indexname = QUOTENAME(name)
        FROM sys.indexes
        WHERE  object_id = @objectid AND index_id = @indexid;
        SELECT @partitioncount = count (*)
        FROM sys.partitions
        WHERE object_id = @objectid AND index_id = @indexid;

-- 10 & 30 are recommendations from Microsoft on when to reorganize vs. rebuild
        IF @frag >= 10.0 and @frag < 30.0
            SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REORGANIZE';
        IF @frag >= 30.0
            SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REBUILD with (online = off)' ;
        IF @partitioncount > 1
            SET @command = @command + N' PARTITION=' + CAST(@partitionnum AS nvarchar(10));
        EXEC (@command);
        PRINT N'Executed: ' + @command;
		
    END;

GOTO CLOSING

EnterpriseEd:

-- Declare the cursor for the list of partitions to be processed.
DECLARE partitions CURSOR FOR 
SELECT objectid,indexid,partitionnum,frag 
FROM #requires_maintenance;

-- Open the cursor.
OPEN partitions;

-- Loop through the partitions.
WHILE (1=1)
    BEGIN;
        FETCH NEXT
           FROM partitions
           INTO @objectid, @indexid, @partitionnum, @frag;
        IF @@FETCH_STATUS < 0 BREAK;
        SELECT @objectname = QUOTENAME(o.name), @schemaname = QUOTENAME(s.name)
        FROM sys.objects o
        JOIN sys.schemas s ON s.schema_id = o.schema_id
        WHERE o.object_id = @objectid;
        SELECT @indexname = QUOTENAME(name)
        FROM sys.indexes
        WHERE  object_id = @objectid AND index_id = @indexid;
        SELECT @partitioncount = count (*)
        FROM sys.partitions
        WHERE object_id = @objectid AND index_id = @indexid;

-- 10 & 30 are recommendations from Microsoft on when to reorganize vs. rebuild
        IF @frag >= 10.0 and @frag < 30.0
            SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REORGANIZE';
        IF @frag >= 30.0
            SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REBUILD with (online = on)' ;
        IF @partitioncount > 1
            SET @command = @command + N' PARTITION=' + CAST(@partitionnum AS nvarchar(10));
        EXEC (@command);
        PRINT N'Executed: ' + @command;
    END;

GOTO CLOSING

Closing:
-- Close and deallocate the cursor.
CLOSE partitions;
DEALLOCATE partitions;

-- Drop the temporary table.
DROP TABLE #requires_maintenance;
DROP TABLE #index_physical_stats

GO

/****** Object:  StoredProcedure [dbo].[sp_SrvPermissions]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*********************************************************************************************
sp_SrvPermissions V6.0
Kenneth Fisher
  
http://www.sqlstudies.com
  
This stored procedure returns 3 data sets.  The first dataset is the list of server
principals, the second is role membership, and the third is server level permissions.
     
The final 2 columns of each query are "Un-Do"/"Do" scripts.  For example removing a member
from a role or adding them to a role.  I am fairly confident in the role scripts, however, 
the scripts in the server principals query and server permissions query are works in
progress.  In particular certificates and keys are not scripted out.  Also while the scripts 
have worked flawlessly on the systems I've tested them on, these systems are fairly similar 
when it comes to security so I can't say that in a more complicated system there won't be 
the odd bug.
    
Notes on the create script for server principals:
1)  I have included a hashed version of the password and the sid.  This means that when run
    on another server the password and the sid will remain the same.  
2)  In SQL 2005 the create script on the server principals query DOES NOT WORK.  This is 
    because the conversion of the sid (in varbinary) to character doesn't appear to work
    as I expected in SQL 2005.  It works fine in SQL 2008 and above.  If you want to use
    this script in SQL 2005 you can change the CONVERTs in the principal script to
    master.sys.fn_varbintohexstr
    
Standard disclaimer: You use scripts off of the web at your own risk.  I fully expect this
     script to work without issue but I've been known to be wrong before.
     
Parameters:
    @Principal
        If NOT NULL then all three queries only pull for that server principal.  @Principal
        is a pattern check.  The queries check for any row where the passed in value exists.
        It uses the pattern '%' + @Principal + '%'
    @Role
        If NOT NULL then the roles query will pull members of the role.  If it is NOT NULL and
        @Principal is NULL then Server principal and permissions query will pull the principal 
        row for the role and the permissions for the role.  @Role is a pattern check.  The 
        queries check for any row where the passed in value exists.  It uses the pattern 
        '%' + @Role + '%'
    @Type
        If NOT NULL then all three queries will only pull principals of that type.  
        S = SQL login
        U = Windows login
        G = Windows group
        R = Server role
        C = Login mapped to a certificate
        K = Login mapped to an asymmetric key
    @DBName
        If NOT NULL then only return those principals and information about them where the 
        principal exists within the DB specified.
    @UseLikeSearch
        When this is set to 1 (the default) then the search parameters will use LIKE (and 
        %'s will be added around the @Principal and @Role parameters).  
        When set to 0 searchs will use =.
    @IncludeMSShipped
        When this is set to 1 (the default) then all principals will be included.  When set
        to 0 the fixed server roles and SA and Public principals will be excluded.
    @DropTempTables
        When this is set to 1 (the default) the temp tables used are dropped.  If it's 0
        then the tempt ables are kept for references after the code has finished.
        The temp tables are:
            ##SrvPrincipals
            ##SrvRoles 
            ##SrvPermissions
    @Output
        What type of output is desired.
        Default - Either 'Default' or it doesn't match any of the allowed values then the SP
                    will return the standard 3 outputs.
        None - No output at all.  Usually used if you keeping the temp tables to do your own
                    reporting.
        CreateOnly - Only return the create scripts where they aren't NULL.
        DropOnly - Only return the drop scripts where they aren't NULL.
        ScriptsOnly - Return drop and create scripts where they aren't NULL.
        Report - Returns one output with one row per principal and a comma delimited list of
                    roles the principal is a member of and a comma delimited list of the 
                    individual permissions they have.
    @Print
        Defaults to 0, but if a 1 is passed in then the queries are not run but printed
        out instead.  This is primarily for debugging.
         
Data is ordered as follows
    1st result set: SrvPrincipal
    2nd result set: RoleName, LoginName if the parameter @Role is used else
                    LoginName, RoleName
    3rd result set: GranteeName 
   
*********************************************************************************************
-- V2.0
-- 8/18/2013 – Create a stub if the SP doesn’t exist, then always do an alter
-- 9/04/2013 – Change print option to show values of variables not the 
--             Variable names.
-- V3.0
-- 10/5/2013 - Added @Type parameter to pull only principals of a given type.
-- 10/20/2013 - Remove SID in CREATE LOGIN script from v2005 and lower since it requires
                a special function to convert from binary to varchar.
-- V4.0
-- 11/18/2013 - Corrected bug in the order of the parameters for sp_addsrvrolemember
                and sp_dropsrvrolemember, also added parameter names both.
-- 01/09/2014 - Added an ORDER BY to each of the result sets.  See above for details.
-- V5.0
-- 04/27/2014 - Add @DBName parameter
-- V5.5
-- 7/22/2014 - Changed strings to unicode
-- V6.0
-- 10/19/2014 - Add @UserLikeSearch and @IncludeMSShipped parameters. 
-- 03/25/2017 - Move SID towards the end of the first output so the more important 
--              columns are closer to the front.
-- 03/25/2017 - Add IF Exists to drop and create principal scripts
-- 03/25/2017 - Add @DropTempTables to keep the temp tables after the SP is run.
-- 03/26/2017 - Add @Output to allow different types of output.
*********************************************************************************************/
CREATE PROCEDURE [dbo].[sp_SrvPermissions] 
(
    @Principal sysname = NULL, 
    @Role sysname = NULL, 
    @Type nvarchar(30) = NULL,
    @DBName sysname = NULL,
    @UseLikeSearch bit = 1,
    @IncludeMSShipped bit = 1,
    @DropTempTables bit = 1,
    @Output varchar(30) = 'Default',
    @Print bit = 0
)
AS
    
IF @DBName IS NOT NULL AND NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = @DBName)
    BEGIN
        RAISERROR (N'%s is not a valid database name.',
        16,
        1,
        @DBName)
        RETURN
    END 
 
DECLARE @Collation nvarchar(50) 
SET @Collation = N' COLLATE ' + CAST(SERVERPROPERTY('Collation') AS nvarchar(50))
    
DECLARE @Version2005orLower bit
SELECT @Version2005orLower = CASE WHEN PARSENAME(CAST(SERVERPROPERTY('productversion') AS VARCHAR(20)),4) < 10 THEN 1
                            ELSE 0 END
    
DECLARE @sql nvarchar(max)
DECLARE @LikeOperator nvarchar(4)
 
IF @UseLikeSearch = 1
    SET @LikeOperator = N'LIKE'
ELSE 
    SET @LikeOperator = N'='
 
IF @UseLikeSearch = 1
BEGIN 
    IF LEN(ISNULL(@Principal,'')) > 0
        SET @Principal = N'%' + @Principal + N'%'
         
    IF LEN(ISNULL(@Role,'')) > 0
        SET @Role = N'%' + @Role+ N'%'
END
 
--=========================================================================
-- Server Principals
SET @sql = 
    N'SELECT principal_id AS SrvPrincipalId, name AS SrvPrincipal, type, type_desc, is_disabled, default_database_name, 
                default_language_name, sid, ' + NCHAR(13) + 
    N'   CASE WHEN principal_id < 100 THEN NULL ELSE ' + NCHAR(13) + 
    N'          ''IF EXISTS (SELECT * FROM sys.server_principals WHERE name = '' + QuoteName(Logins.name,'''''''') + '') '' + ' + NCHAR(13) + 
    N'           ''DROP '' + CASE [type] WHEN ''C'' THEN NULL ' + NCHAR(13) + 
    N'               WHEN ''K'' THEN NULL ' + NCHAR(13) + 
    N'               WHEN ''R'' THEN ''ROLE'' ' + NCHAR(13) + 
    N'               ELSE ''LOGIN'' END + ' + NCHAR(13) + 
    N'           '' ''+QUOTENAME(name' + @Collation + ') END + '';'' AS DropScript, ' + NCHAR(13) + 
    N'   CASE WHEN principal_id < 100 THEN NULL ELSE ' + NCHAR(13) + 
    N'          ''IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = '' + QuoteName(Logins.name,'''''''') + '') '' + ' + NCHAR(13) + 
    N'           ''CREATE '' + CASE [type] WHEN ''C'' THEN NULL ' + NCHAR(13) + 
    N'               WHEN ''K'' THEN NULL ' + NCHAR(13) + 
    N'               WHEN ''R'' THEN ''ROLE'' ' + NCHAR(13) + 
    N'               ELSE ''LOGIN'' END + ' + NCHAR(13) + 
    N'           '' ''+QUOTENAME(name' + @Collation + ') END + ' + NCHAR(13) + 
    N'           CASE WHEN [type] = (''S'') THEN ' + NCHAR(13) + 
    N'           '' WITH PASSWORD = '' + ' + NCHAR(13) + 
    N'           CONVERT(varchar(256), LOGINPROPERTY(name, ''PasswordHash''),1 ) + '' HASHED' +
    CASE WHEN @Version2005orLower = 0 THEN N','' +  ' + NCHAR(13) + N'         '' SID = '' + 
                CONVERT(varchar(85), sid, 1) +  ' + NCHAR(13) 
                    ELSE N''' +  ' + NCHAR(13) END + 
    N'           CASE WHEN default_database_name IS NOT NULL OR default_language_name IS NOT NULL THEN '',''
                ELSE '''' END ' + NCHAR(13) + 
    N'           WHEN [type] IN (''U'',''G'') THEN '' FROM WINDOWS '' + ' + NCHAR(13) + 
    N'           CASE WHEN default_database_name IS NOT NULL OR default_language_name IS NOT NULL THEN '' WITH ''
                ELSE '''' END ' + NCHAR(13) + 
    N'           ELSE '''' END + ' + NCHAR(13) + 
    N'           ISNULL('' DEFAULT_DATABASE = '' + QUOTENAME(default_database_name' + @Collation + N'), '''') + ' + 
                NCHAR(13) + 
    N'           CASE WHEN default_database_name IS NOT NULL AND default_language_name IS NOT NULL THEN '',''
                ELSE '''' END + ' + NCHAR(13) + 
    N'           ISNULL('' DEFAULT_LANGUAGE = '' + QUOTENAME(default_language_name' + @Collation + N'), '''') + ' +  
                NCHAR(13) + 
    N'           '';'' ' + NCHAR(13) + 
    N'       AS CreateScript ' + NCHAR(13) + 
    N'FROM sys.server_principals Logins ' + NCHAR(13) + 
    N'WHERE 1=1 '
    
IF LEN(ISNULL(@Principal,@Role)) > 0 
    IF @Print = 1
        SET @sql = @sql + NCHAR(13) + N'  AND Logins.name ' + @LikeOperator + N' ' + ISNULL(+QUOTENAME(@Principal,''''),QUOTENAME(@Role,'''')) 
    ELSE
        SET @sql = @sql + NCHAR(13) + N'  AND Logins.name ' + @LikeOperator + N' ISNULL(@Principal,@Role) '
    
IF LEN(@Type) > 0
    IF @Print = 1
        SET @sql = @sql + NCHAR(13) + N'  AND Logins.type ' + @LikeOperator + N' ' + QUOTENAME(@Type,'''')
    ELSE
        SET @sql = @sql + NCHAR(13) + N'  AND Logins.type ' + @LikeOperator + N' @Type'
  
IF @DBName IS NOT NULL
    SET @sql = @sql + NCHAR(13) + N'  AND Logins.SID IN (SELECT SID FROM [' + @DBName + N'].sys.database_principals 
                                                        WHERE type IN (''G'',''S'',''U'',''K'',''C''))'
 
IF @IncludeMSShipped = 0
    SET @sql = @sql + NCHAR(13) + N'  AND Logins.is_fixed_role = 0 ' + NCHAR(13) + 
                '  AND Logins.name NOT IN (''sa'',''public'') '
       
IF @Print = 1
    PRINT '-- Server Principals' + NCHAR(13) + @sql + NCHAR(13) + NCHAR(13)
ELSE
BEGIN
    IF object_id('tempdb..##SrvPrincipals') IS NOT NULL
        DROP TABLE ##SrvPrincipals
 
    -- Create temp table to store the data in
    CREATE TABLE ##SrvPrincipals (
        SrvPrincipalId int NULL,
        SrvPrincipal sysname NULL,
        type char(1) NULL,
        type_desc nchar(60) NULL,
        is_disabled bit NULL,
        default_database_name sysname NULL,
        default_language_name sysname NULL,
        sid varbinary(85) NULL,
        DropScript nvarchar(max) NULL,
        CreateScript nvarchar(max) NULL
        )
     
    SET @sql =  N'INSERT INTO ##SrvPrincipals ' + NCHAR(13) + @sql
 
    EXEC sp_executesql @sql, N'@Principal sysname, @Role sysname, @Type varchar(30)', @Principal, @Role, @Type
END    
--=========================================================================
-- Server level roles
SET @sql = 
    N'SELECT Logins.principal_id AS LoginPrincipalId, Logins.name AS LoginName, Roles.name AS RoleName, ' + NCHAR(13) + 
    N'   ''EXEC sp_dropsrvrolemember @loginame = ''+QUOTENAME(Logins.name' + @Collation + 
            ','''''''')+'', @rolename = ''+QUOTENAME(Roles.name' + @Collation + 
            ','''''''') + '';'' AS DropScript, ' + NCHAR(13) + 
    N'   ''EXEC sp_addsrvrolemember @loginame = ''+QUOTENAME(Logins.name' + @Collation + 
            ','''''''')+'', @rolename = ''+QUOTENAME(Roles.name' + @Collation + 
            ','''''''') + '';'' AS AddScript ' + NCHAR(13) + 
    N'FROM sys.server_role_members RoleMembers ' + NCHAR(13) + 
    N'JOIN sys.server_principals Logins ' + NCHAR(13) + 
    N'   ON RoleMembers.member_principal_id = Logins.principal_id ' + NCHAR(13) + 
    N'JOIN sys.server_principals Roles ' + NCHAR(13) + 
    N'   ON RoleMembers.role_principal_id = Roles.principal_id ' + NCHAR(13) + 
    N'WHERE 1=1 '
    
IF LEN(ISNULL(@Principal,'')) > 0
    IF @Print = 1
        SET @sql = @sql + NCHAR(13) + N'  AND Logins.name ' + @LikeOperator + N' '+QUOTENAME(@Principal,'''')
    ELSE
        SET @sql = @sql + NCHAR(13) + N'  AND Logins.name ' + @LikeOperator + N' @Principal'
    
IF LEN(ISNULL(@Role,'')) > 0
    IF @Print = 1
        SET @sql = @sql + NCHAR(13) + N'  AND Roles.name ' + @LikeOperator + N' '+QUOTENAME(@Role,'''')
    ELSE
        SET @sql = @sql + NCHAR(13) + N'  AND Roles.name ' + @LikeOperator + N' @Role'
    
IF LEN(@Type) > 0
    IF @Print = 1
        SET @sql = @sql + NCHAR(13) + N'  AND Logins.type ' + @LikeOperator + N' ' + QUOTENAME(@Type,'''')
    ELSE
        SET @sql = @sql + NCHAR(13) + N'  AND Logins.type ' + @LikeOperator + N' @Type'
  
IF @DBName IS NOT NULL
    SET @sql = @sql + NCHAR(13) + N'  AND Logins.SID IN (SELECT SID FROM [' + @DBName + N'].sys.database_principals 
                                                        WHERE type IN (''G'',''S'',''U'',''K'',''C''))'
   
IF @IncludeMSShipped = 0
    SET @sql = @sql + NCHAR(13) + N'  AND Logins.is_fixed_role = 0 ' + NCHAR(13) + 
                '  AND Logins.name NOT IN (''sa'',''public'') '
 
IF @Print = 1
    PRINT '-- Server Role Members' + NCHAR(13) + @sql + NCHAR(13) + NCHAR(13)
ELSE
BEGIN
    IF object_id('tempdb..##SrvRoles') IS NOT NULL
        DROP TABLE ##SrvRoles
 
    -- Create temp table to store the data in
    CREATE TABLE ##SrvRoles (
        LoginPrincipalId int NULL,
        LoginName sysname NULL,
        RoleName sysname NULL,
        DropScript nvarchar(max) NULL,
        AddScript nvarchar(max) NULL
        )
 
    SET @sql =  'INSERT INTO ##SrvRoles ' + NCHAR(13) + @sql
 
    EXEC sp_executesql @sql, N'@Principal sysname, @Role sysname, @Type nvarchar(30)', @Principal, @Role, @Type
END
     
--=========================================================================
-- Server Permissions
SET @sql =
    N'SELECT Grantee.principal_id AS GranteePrincipalId, Grantee.name AS GranteeName, ' + NCHAR(13) + 
    N'   Grantor.name AS GrantorName, Permission.class_desc, Permission.permission_name, ' + NCHAR(13) + 
    N'   Permission.state_desc,  ' + NCHAR(13) + 
    N'   ''REVOKE '' + ' + NCHAR(13) + 
    N'       CASE WHEN Permission.class_desc = ''ENDPOINT'' THEN NULL ' + NCHAR(13) + 
    N'       WHEN Permission.[state]  = ''W'' THEN ''GRANT OPTION FOR '' ELSE '''' END + ' + NCHAR(13) + 
    N'       '' '' + Permission.permission_name' + @Collation + ' +  ' + NCHAR(13) + 
    N'       '' FROM '' + QUOTENAME(Grantee.name' + @Collation + ')  + ''; '' AS RevokeScript, ' + NCHAR(13) + 
    N'   CASE WHEN Permission.class_desc = ''ENDPOINT'' THEN NULL ' + NCHAR(13) + 
    N'       WHEN Permission.[state]  = ''W'' THEN ''GRANT'' ELSE Permission.state_desc' + @Collation + 
            ' END + ' + NCHAR(13) + 
    N'       '' '' + Permission.permission_name' + @Collation + ' +  ' + NCHAR(13) + 
    N'       '' TO '' + QUOTENAME(Grantee.name' + @Collation + ')  + '' '' +  ' + NCHAR(13) + 
    N'       CASE WHEN Permission.[state]  = ''W'' THEN '' WITH GRANT OPTION '' ELSE '''' END +  ' + NCHAR(13) + 
    N'       '' AS ''+ QUOTENAME(Grantor.name' + @Collation + ') + '';'' AS GrantScript ' + NCHAR(13) + 
    N'FROM sys.server_permissions Permission ' + NCHAR(13) + 
    N'JOIN sys.server_principals Grantee ' + NCHAR(13) + 
    N'   ON Permission.grantee_principal_id = Grantee.principal_id ' + NCHAR(13) + 
    N'JOIN sys.server_principals Grantor ' + NCHAR(13) + 
    N'   ON Permission.grantor_principal_id = Grantor.principal_id ' + NCHAR(13) + 
    N'WHERE 1=1 '
    
IF LEN(ISNULL(@Principal,@Role)) > 0
    IF @Print = 1
        SET @sql = @sql + NCHAR(13) + N'  AND Grantee.name ' + @LikeOperator + N' ' + ISNULL(+QUOTENAME(@Principal,''''),QUOTENAME(@Role,'''')) 
    ELSE
        SET @sql = @sql + NCHAR(13) + N'  AND Grantee.name ' + @LikeOperator + N' ISNULL(@Principal,@Role) '
    
IF LEN(@Type) > 0
    IF @Print = 1
        SET @sql = @sql + NCHAR(13) + N'  AND Grantee.type ' + @LikeOperator + N' ' + QUOTENAME(@Type,'''')
    ELSE
        SET @sql = @sql + NCHAR(13) + N'  AND Grantee.type ' + @LikeOperator + N' @Type'
   
IF @DBName IS NOT NULL
    SET @sql = @sql + NCHAR(13) + N' AND Grantee.SID IN (SELECT SID FROM [' + @DBName + N'].sys.database_principals 
                                    WHERE type IN (''G'',''S'',''U'',''K'',''C''))'
  
IF @IncludeMSShipped = 0
    SET @sql = @sql + NCHAR(13) + N'  AND Grantee.is_fixed_role = 0 ' + NCHAR(13) + 
                '  AND Grantee.name NOT IN (''sa'',''public'') '
 
IF @Print = 1
    PRINT '-- Server Permissions' + NCHAR(13) + @sql + NCHAR(13) + NCHAR(13)
ELSE
BEGIN
    IF object_id('tempdb..##SrvPermissions') IS NOT NULL
        DROP TABLE ##SrvPermissions
 
    -- Create temp table to store the data in
    CREATE TABLE ##SrvPermissions (
        GranteePrincipalId int NULL,
        GranteeName sysname NULL,
        GrantorName sysname NULL,
        class_desc nvarchar(60) NULL,
        permission_name nvarchar(128) NULL,
        state_desc nvarchar(60) NULL,
        RevokeScript nvarchar(max) NULL,
        GrantScript nvarchar(max) NULL
        )
     
    -- Add insert statement to @sql
    SET @sql = N'INSERT INTO ##SrvPermissions ' + NCHAR(13) + @sql
 
    EXEC sp_executesql @sql, N'@Principal sysname, @Role sysname, @Type nvarchar(30)', @Principal, @Role, @Type
END
 
IF @Print <> 1
BEGIN
 
    IF @Output = 'None'
        PRINT ''
    ELSE IF @Output = 'CreateOnly'
    BEGIN
        SELECT CreateScript FROM ##SrvPrincipals WHERE CreateScript IS NOT NULL
        SELECT AddScript FROM ##SrvRoles WHERE AddScript IS NOT NULL
        SELECT GrantScript FROM ##SrvPermissions WHERE GrantScript IS NOT NULL
    END 
    ELSE IF @Output = 'DropOnly' 
    BEGIN
        SELECT DropScript FROM ##SrvPrincipals WHERE DropScript IS NOT NULL
        SELECT DropScript FROM ##SrvRoles WHERE DropScript IS NOT NULL
        SELECT RevokeScript FROM ##SrvPermissions WHERE RevokeScript IS NOT NULL
    END
    ELSE IF @Output = 'ScriptOnly' 
    BEGIN
        SELECT DropScript, CreateScript FROM ##SrvPrincipals WHERE DropScript IS NOT NULL OR CreateScript IS NOT NULL
        SELECT DropScript, AddScript FROM ##SrvRoles WHERE DropScript IS NOT NULL OR AddScript IS NOT NULL
        SELECT RevokeScript, GrantScript FROM ##SrvPermissions WHERE RevokeScript IS NOT NULL OR GrantScript IS NOT NULL
    END
    ELSE IF @Output = 'Report'
    BEGIN
        SELECT SrvPrincipal, type, type_desc, is_disabled,
                STUFF((SELECT ', ' + ##SrvRoles.RoleName
                        FROM ##SrvRoles
                        WHERE ##SrvPrincipals.SrvPrincipalId = ##SrvRoles.LoginPrincipalId
                        ORDER BY ##SrvRoles.RoleName
                        FOR XML PATH(''),TYPE).value('.','VARCHAR(MAX)')
                    , 1, 2, '') AS RoleMembership,
                STUFF((SELECT ', ' + ##SrvPermissions.state_desc + ' ' + ##SrvPermissions.permission_name + ' ' +
                                CASE WHEN class_desc <> 'SERVER' THEN class_desc ELSE '' END
                        FROM (SELECT DISTINCT * FROM ##SrvPermissions) ##SrvPermissions
                        WHERE ##SrvPrincipals.SrvPrincipalId = ##SrvPermissions.GranteePrincipalId
                        ORDER BY ##SrvPermissions.state_desc, ##SrvPermissions.permission_name
                        FOR XML PATH(''),TYPE).value('.','VARCHAR(MAX)')
                    , 1, 2, '') AS DirectPermissions
        FROM ##SrvPrincipals
        ORDER BY SrvPrincipal
    END
    ELSE -- 'Default' or no match
    BEGIN
        SELECT SrvPrincipal, type, type_desc, is_disabled, default_database_name, 
                default_language_name, sid, DropScript, CreateScript 
        FROM ##SrvPrincipals ORDER BY SrvPrincipal
        IF LEN(@Role) > 0
            SELECT LoginName, RoleName, DropScript, AddScript FROM ##SrvRoles ORDER BY RoleName, LoginName
        ELSE
            SELECT LoginName, RoleName, DropScript, AddScript FROM ##SrvRoles ORDER BY LoginName, RoleName
        SELECT GranteeName, GrantorName, class_desc, permission_name, state_desc, RevokeScript, GrantScript 
        FROM ##SrvPermissions ORDER BY GranteeName
    END
 
    IF @DropTempTables = 1
    BEGIN
        DROP TABLE ##SrvPrincipals
        DROP TABLE ##SrvRoles
        DROP TABLE ##SrvPermissions
    END
END


GO

/****** Object:  StoredProcedure [dbo].[sp_weeklyindexmaintenance]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_weeklyindexmaintenance]

AS

SET NOCOUNT ON

/* Declare Variables */
DECLARE @objectid int;
DECLARE @indexid int;
DECLARE @partitioncount bigint;
DECLARE @schemaname nvarchar(130); 
DECLARE @objectname nvarchar(130); 
DECLARE @indexname nvarchar(130); 
DECLARE @partitionnum bigint;
DECLARE @partitions bigint;
DECLARE @frag float;
DECLARE @command nvarchar(4000);
DECLARE @engine int 

-- Run system view to gather fragmentation data and insert into table

SELECT * into #index_physical_stats 
from sys.dm_db_index_physical_stats (db_id(), null, null, null, 'detailed')
   
/* Prepare list of indexes to run maint. on w/ >= 5000 pages + min. 10% frag & max 30% (lower than that provides no benefit) */  
SELECT
    object_id AS objectid,
    index_id AS indexid,
    partition_number AS partitionnum,
    avg_fragmentation_in_percent AS frag
INTO #requires_maintenance
FROM #index_physical_stats where
avg_fragmentation_in_percent >= 10.0 and avg_fragmentation_in_percent <= 30.0
AND index_id > 0 --make sure no heaps are included
AND page_count >= 5000.0

-- Declare the cursor for the list of partitions to be processed.
DECLARE partitions CURSOR FOR 
SELECT objectid,indexid,partitionnum,frag 
FROM #requires_maintenance;

-- Open the cursor.
OPEN partitions;

-- Loop through the partitions.
WHILE (1=1)
    BEGIN;
        FETCH NEXT
           FROM partitions
           INTO @objectid, @indexid, @partitionnum, @frag;
        IF @@FETCH_STATUS < 0 BREAK;
        SELECT @objectname = QUOTENAME(o.name), @schemaname = QUOTENAME(s.name)
        FROM sys.objects o
        JOIN sys.schemas s ON s.schema_id = o.schema_id
        WHERE o.object_id = @objectid;
        SELECT @indexname = QUOTENAME(name)
        FROM sys.indexes
        WHERE  object_id = @objectid AND index_id = @indexid;
        SELECT @partitioncount = count (*)
        FROM sys.partitions
        WHERE object_id = @objectid AND index_id = @indexid;

-- 10 & 30 are recommendations from Microsoft on when to reorganize vs. rebuild
        IF @frag >= 10.0 and @frag < 30.0
            SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REORGANIZE';
        IF @partitioncount > 1
            SET @command = @command + N' PARTITION=' + CAST(@partitionnum AS nvarchar(10));
        EXEC (@command);
        PRINT N'Executed: ' + @command;
		
    END;

-- Close and deallocate the cursor.
CLOSE partitions;
DEALLOCATE partitions;

-- Drop the temporary table.
DROP TABLE #requires_maintenance;
DROP TABLE #index_physical_stats

GO

/****** Object:  StoredProcedure [dbo].[usp_AlterCredentials]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[usp_AlterCredentials]

AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @CredentialName	nvarchar(255);
	DECLARE @NewLogin			sysname;
	DECLARE @LoginToClone		sysname;
	DECLARE @w_NewDomain	nvarchar(20);
	DECLARE @TSQL nvarchar(MAX);

	SET @w_NewDomain = N'PRSCOAD\';

	DECLARE CredentialsToChange CURSOR STATIC
	FOR
	SELECT	name, credential_identity 
	FROM	sys.credentials
	WHERE	(credential_identity LIKE N'NA\%' OR credential_identity LIKE N'LA\%' OR credential_identity LIKE N'EU\%' OR credential_identity LIKE N'AS\%');

	OPEN CredentialsToChange;

	FETCH FIRST FROM CredentialsToChange INTO @CredentialName, @LoginToClone;

	WHILE (@@FETCH_STATUS = 0)

		BEGIN  

			SET @NewLogin = CASE
						WHEN @LoginToClone LIKE N'NA\%'
							THEN REPLACE(@LoginToClone, N'NA\', @w_NewDomain)
						WHEN @LoginToClone LIKE N'LA\%'
							THEN REPLACE(@LoginToClone, N'LA\', @w_NewDomain)
						WHEN @LoginToClone LIKE N'EU\%'
							THEN REPLACE(@LoginToClone, N'EU\', @w_NewDomain)
						WHEN @LoginToClone LIKE N'AS\%'
							THEN REPLACE(@LoginToClone, N'AS\', @w_NewDomain)
			END;

			SET @TSQL = 'ALTER CREDENTIAL [' + @CredentialName + '] WITH IDENTITY = ''' + @NewLogin + ''';';
			
			PRINT @TSQL;

			FETCH NEXT FROM CredentialsToChange INTO @CredentialName, @LoginToClone;

		END;

	IF CURSOR_STATUS('global', 'CredentialsToChange') != -3
	BEGIN
		CLOSE CredentialsToChange;
		DEALLOCATE CredentialsToChange;
	END;

END;

GO

/****** Object:  StoredProcedure [dbo].[usp_AlterJobOwners]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[usp_AlterJobOwners]

AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @JobName			nvarchar(2000);
	DECLARE @NewLogin			sysname;
	DECLARE @LoginToClone		sysname;
	DECLARE @w_NewDomain		nvarchar(20);
	DECLARE @TSQL				nvarchar(MAX);

	SET @w_NewDomain = N'PRSCOAD\';

	DECLARE JobsToChange CURSOR STATIC
	FOR
	SELECT	s.name,l.name
	FROM	msdb..sysjobs s 
	LEFT OUTER JOIN master.sys.syslogins l 
		ON s.owner_sid = l.sid
	WHERE (l.name LIKE N'NA\%' OR l.name LIKE N'LA\%' OR l.name LIKE N'EU\%' OR l.name LIKE N'AS\%')

	OPEN JobsToChange;

	FETCH FIRST FROM JobsToChange INTO @JobName, @LoginToClone;

	WHILE (@@FETCH_STATUS = 0)

		BEGIN 
		
			SET @NewLogin = CASE
								WHEN @LoginToClone LIKE N'NA\%'
									THEN REPLACE(@LoginToClone, N'NA\', @w_NewDomain)
								WHEN @LoginToClone LIKE N'LA\%'
									THEN REPLACE(@LoginToClone, N'LA\', @w_NewDomain)
								WHEN @LoginToClone LIKE N'EU\%'
									THEN REPLACE(@LoginToClone, N'EU\', @w_NewDomain)
								WHEN @LoginToClone LIKE N'AS\%'
									THEN REPLACE(@LoginToClone, N'AS\', @w_NewDomain)
							END; 

			SET @TSQL = 'EXEC MSDB.dbo.sp_update_job @job_name = ''' + @JobName + ''', @owner_login_name = ''' + @NewLogin + ''';';
			
			PRINT @TSQL;

			FETCH NEXT FROM JobsToChange INTO @JobName, @LoginToClone;

		END;

	IF CURSOR_STATUS('global', 'JobsToChange') != -3
	BEGIN
		CLOSE JobsToChange;
		DEALLOCATE JobsToChange;
	END;

END;

GO

/****** Object:  StoredProcedure [dbo].[usp_CloneDBPerms]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[usp_CloneDBPerms]
  @NewLogin sysname,
  @LoginToClone sysname,
  @DBName sysname
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @SQL	nvarchar(max);
	DECLARE @Return int;

	CREATE TABLE #DBPermissionsTSQL 
	(
		PermsTSQL nvarchar(MAX)
	);


	SET @SQL = 'INSERT INTO #DBPermissionsTSQL (PermsTSQL) 
	SELECT CASE [state]
	   WHEN ''W'' THEN ''GRANT '' + permission_name + '' ON DATABASE::[' 
		 + @DBName + '] TO [' + @NewLogin + '] WITH GRANT OPTION;'' COLLATE DATABASE_DEFAULT
	   ELSE state_desc + '' '' + permission_name + '' ON DATABASE::[' 
		 + @DBNAME + '] TO [' + @NewLogin + '];'' COLLATE DATABASE_DEFAULT
	   END AS ''Permission''
	FROM [' + @DBName + '].sys.database_permissions AS P
	  JOIN [' + @DBName + '].sys.database_principals AS U
		ON P.grantee_principal_id = U.principal_id
	WHERE class = 0
	  AND P.[type] <> ''CO''
	  AND U.name = ''' + @LoginToClone + ''';';

	EXECUTE @Return = sp_executesql @SQL;


	SET @SQL = 'INSERT INTO #DBPermissionsTSQL (PermsTSQL)
	SELECT CASE [state]
	   WHEN ''W'' THEN ''GRANT '' + permission_name + '' ON SCHEMA::['' 
		 + S.name + ''] TO [' + @NewLogin + '] WITH GRANT OPTION;'' COLLATE DATABASE_DEFAULT
	   ELSE state_desc + '' '' + permission_name + '' ON SCHEMA::['' 
		 + S.name + ''] TO [' + @NewLogin + '];'' COLLATE DATABASE_DEFAULT
	   END AS ''Permission''
	FROM [' + @DBName + '].sys.database_permissions AS P
	  JOIN [' + @DBName + '].sys.database_principals AS U
		ON P.grantee_principal_id = U.principal_id
	  JOIN [' + @DBName + '].sys.schemas AS S
		ON S.schema_id = P.major_id
	WHERE class = 3
	  AND U.name = ''' + @LoginToClone + ''';';

	EXECUTE @Return = sp_executesql @SQL;

	
	SET @SQL = 'INSERT INTO #DBPermissionsTSQL (PermsTSQL) 
	SELECT CASE [state]
	   WHEN ''W'' THEN ''GRANT '' + permission_name + '' ON OBJECT::['' 
		 + O.name + ''] TO [' + @NewLogin + '] WITH GRANT OPTION;'' COLLATE DATABASE_DEFAULT
	   ELSE state_desc + '' '' + permission_name + '' ON OBJECT::['' 
		 + O.name + ''] TO [' + @NewLogin + '];'' COLLATE DATABASE_DEFAULT
	   END AS ''Permission''
	FROM [' + @DBName + '].sys.database_permissions AS P
	  JOIN [' + @DBName + '].sys.database_principals AS U
		ON P.grantee_principal_id = U.principal_id
	  JOIN [' + @DBName + '].sys.objects AS O
		ON O.object_id = P.major_id
	WHERE class = 1
	  AND U.name = ''' + @LoginToClone + '''
	  AND P.major_id > 0
	  AND P.minor_id = 0';

	EXECUTE @Return = sp_executesql @SQL;

	
	SET @SQL = 'INSERT INTO #DBPermissionsTSQL (PermsTSQL)
	SELECT CASE [state]
	   WHEN ''W'' THEN ''GRANT '' + permission_name + '' ON OBJECT::['' 
		 + O.name + ''] ('' + C.name + '') TO [' + @NewLogin + '] WITH GRANT OPTION;'' 
		 COLLATE DATABASE_DEFAULT
	   ELSE state_desc + '' '' + permission_name + '' ON OBJECT::['' 
		 + O.name + ''] ('' + C.name + '') TO [' + @NewLogin + '];'' 
		 COLLATE DATABASE_DEFAULT
	   END AS ''Permission''
	FROM [' + @DBName + '].sys.database_permissions AS P
	  JOIN [' + @DBName + '].sys.database_principals AS U
		ON P.grantee_principal_id = U.principal_id
	  JOIN [' + @DBName + '].sys.objects AS O
		ON O.object_id = P.major_id
	  JOIN [' + @DBName + '].sys.columns AS C
		ON C.column_id = P.minor_id AND o.object_id = C.object_id
	WHERE class = 1
	  AND U.name = ''' + @LoginToClone + '''
	  AND P.major_id > 0
	  AND P.minor_id > 0;'

	EXECUTE @Return = sp_executesql @SQL;
	
	
	SET @SQL = 'INSERT INTO #DBPermissionsTSQL (PermsTSQL) 
	SELECT CASE [state]
	   WHEN ''W'' THEN ''GRANT '' + permission_name + '' ON USER::['' 
		 + U2.name + ''] TO [' + @NewLogin + '] WITH GRANT OPTION;'' COLLATE DATABASE_DEFAULT
	   ELSE state_desc + '' '' + permission_name + '' ON USER::['' 
		 + U2.name + ''] TO [' + @NewLogin + '];'' COLLATE DATABASE_DEFAULT
	   END AS ''Permission''
	FROM [' + @DBName + '].sys.database_permissions AS P
	  JOIN [' + @DBName + '].sys.database_principals AS U
		ON P.grantee_principal_id = U.principal_id
	  JOIN [' + @DBName + '].sys.database_principals AS U2
		ON U2.principal_id = P.major_id
	WHERE class = 4
	  AND U.name = ''' + @LoginToClone + ''';';

	EXECUTE @Return = sp_executesql @SQL;

	
	SET @SQL = 'INSERT INTO #DBPermissionsTSQL (PermsTSQL)
	SELECT CASE [state]
	   WHEN ''W'' THEN ''GRANT '' + permission_name + '' ON SYMMETRIC KEY::['' 
		 + K.name + ''] TO [' + @NewLogin + '] WITH GRANT OPTION;'' COLLATE DATABASE_DEFAULT
	   ELSE state_desc + '' '' + permission_name + '' ON SYMMETRIC KEY::['' 
		 + K.name + ''] TO [' + @NewLogin + '];'' COLLATE DATABASE_DEFAULT
	   END AS ''Permission''
	FROM [' + @DBName + '].sys.database_permissions AS P
	  JOIN [' + @DBName + '].sys.database_principals AS U
		ON P.grantee_principal_id = U.principal_id
	  JOIN [' + @DBName + '].sys.symmetric_keys AS K
		ON P.major_id = K.symmetric_key_id
	WHERE class = 24
	  AND U.name = ''' + @LoginToClone + ''';';

	EXECUTE @Return = sp_executesql @SQL;

	
	SET @SQL = 'INSERT INTO #DBPermissionsTSQL (PermsTSQL) 
	SELECT CASE [state]
	   WHEN ''W'' THEN ''GRANT '' + permission_name + '' ON ASYMMETRIC KEY::['' 
		 + K.name + ''] TO [' + @NewLogin + '] WITH GRANT OPTION;'' COLLATE DATABASE_DEFAULT
	   ELSE state_desc + '' '' + permission_name + '' ON ASYMMETRIC KEY::['' 
		 + K.name + ''] TO [' + @NewLogin + '];'' COLLATE DATABASE_DEFAULT
	   END AS ''Permission''
	FROM [' + @DBName + '].sys.database_permissions AS P
	  JOIN [' + @DBName + '].sys.database_principals AS U
		ON P.grantee_principal_id = U.principal_id
	  JOIN [' + @DBName + '].sys.asymmetric_keys AS K
		ON P.major_id = K.asymmetric_key_id
	WHERE class = 26
	  AND U.name = ''' + @LoginToClone + ''';';

	EXECUTE @Return = sp_executesql @SQL;
	
	
	SET @SQL = 'INSERT INTO #DBPermissionsTSQL (PermsTSQL) 
	SELECT CASE [state]
	   WHEN ''W'' THEN ''GRANT '' + permission_name + '' ON CERTIFICATE::['' 
		 + C.name + ''] TO [' + @NewLogin + '] WITH GRANT OPTION;'' COLLATE DATABASE_DEFAULT
	   ELSE state_desc + '' '' + permission_name + '' ON CERTIFICATE::['' 
		 + C.name + ''] TO [' + @NewLogin + '];'' COLLATE DATABASE_DEFAULT
	   END AS ''Permission''
	FROM [' + @DBName + '].sys.database_permissions AS P
	  JOIN [' + @DBName + '].sys.database_principals AS U
		ON P.grantee_principal_id = U.principal_id
	  JOIN [' + @DBName + '].sys.certificates AS C
		ON P.major_id = C.certificate_id
	WHERE class = 25
	  AND U.name = ''' + @LoginToClone + ''';';

	EXECUTE @Return = sp_executesql @SQL;

	
	DECLARE cursDBPermsSQL CURSOR FAST_FORWARD
	FOR
	SELECT PermsTSQL FROM #DBPermissionsTSQL

	OPEN cursDBPermsSQL;

	FETCH FROM cursDBPermsSQL INTO @SQL;

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
	  SET @SQL = 'USE [' + @DBName + ']; ' + @SQL;

	  PRINT @SQL;
	  
	  FETCH NEXT FROM cursDBPermsSQL INTO @SQL;
	END;

	CLOSE cursDBPermsSQL;
	DEALLOCATE cursDBPermsSQL;
	DROP TABLE #DBPermissionsTSQL;
END;


GO

/****** Object:  StoredProcedure [dbo].[usp_CloneLogin]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[usp_CloneLogin]
    @NewLogin				nvarchar(128)
  , @LoginToClone			nvarchar(128)
  , @DefaultDatabaseName	nvarchar(128)
AS BEGIN

	SET NOCOUNT ON;

	DECLARE @SQL nvarchar(MAX);

	SET @SQL = 'CREATE LOGIN [' + @NewLogin + '] FROM WINDOWS WITH DEFAULT_DATABASE = ' + @DefaultDatabaseName;
	
	PRINT @SQL;
	
	-- Query to handle server roles
	DECLARE cursRoleMemberSQL CURSOR FAST_FORWARD
	FOR
	SELECT 'EXEC sp_addsrvrolemember @loginame = ''' + @NewLogin 
			  + ''', @rolename = ''' + R.name + ''';' AS 'SQL'
	FROM sys.server_role_members AS RM
	  JOIN sys.server_principals AS L
		ON RM.member_principal_id = L.principal_id
	  JOIN sys.server_principals AS R
		ON RM.role_principal_id = R.principal_id
	WHERE L.name = @LoginToClone;

	OPEN cursRoleMemberSQL;

	FETCH FROM cursRoleMemberSQL INTO @SQL;

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
	  PRINT @SQL;
	  
	  FETCH NEXT FROM cursRoleMemberSQL INTO @SQL;
	END;

	CLOSE cursRoleMemberSQL;
	DEALLOCATE cursRoleMemberSQL;

	DECLARE cursServerPermissionSQL CURSOR FAST_FORWARD
	FOR
	SELECT CASE P.state WHEN 'W' THEN 
			 'USE master; GRANT ' + P.permission_name + ' TO [' + @NewLogin + '] WITH GRANT OPTION;'
		   ELSE 
			 'USE master;  ' + P.state_desc + ' ' + P.permission_name + ' TO [' + @NewLogin + '];'   
		   END AS 'SQL'
	FROM sys.server_permissions AS P
	  JOIN sys.server_principals AS L
		ON P.grantee_principal_id = L.principal_id
	WHERE L.name = @LoginToClone
	  AND P.class = 100
	  AND P.type <> 'COSQ'
	UNION ALL
	SELECT CASE P.state WHEN 'W' THEN 
			 'USE master; GRANT ' + P.permission_name + ' ON LOGIN::[' + L2.name + 
			 '] TO [' + @NewLogin + '] WITH GRANT OPTION;' COLLATE DATABASE_DEFAULT
		   ELSE 
			 'USE master; ' + P.state_desc + ' ' + P.permission_name + ' ON LOGIN::[' + L2.name 
			 + '] TO [' + @NewLogin + '];' COLLATE DATABASE_DEFAULT
		   END AS 'SQL'
	FROM sys.server_permissions AS P
	  JOIN sys.server_principals AS L
		ON P.grantee_principal_id = L.principal_id
	  JOIN sys.server_principals AS L2
		ON P.major_id = L2.principal_id
	WHERE L.name = @LoginToClone
	  AND P.class = 101
	UNION ALL
	SELECT CASE P.state WHEN 'W' THEN 
			 'USE master; GRANT ' + P.permission_name + ' ON ENDPOINT::[' + E.name + 
			 '] TO [' + @NewLogin + '] WITH GRANT OPTION;' COLLATE DATABASE_DEFAULT
		   ELSE 
			 'USE master; ' + P.state_desc + ' ' + P.permission_name + ' ON ENDPOINT::[' + E.name 
			 + '] TO [' + @NewLogin + '];' COLLATE DATABASE_DEFAULT
		   END AS 'SQL'
	FROM sys.server_permissions AS P
	  JOIN sys.server_principals AS L
		ON P.grantee_principal_id = L.principal_id
	  JOIN sys.endpoints AS E
		ON P.major_id = E.endpoint_id
	WHERE L.name = @LoginToClone
	  AND P.class = 105;

	OPEN cursServerPermissionSQL;

	FETCH FROM cursServerPermissionSQL INTO @SQL;

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		PRINT @SQL;
		
		FETCH NEXT FROM cursServerPermissionSQL INTO @SQL;
	END;

	CLOSE cursServerPermissionSQL;
	DEALLOCATE cursServerPermissionSQL;

END;

GO

/****** Object:  StoredProcedure [dbo].[usp_CreateUserInDB]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[usp_CreateUserInDB]
  @NewLogin sysname,
  @LoginToClone sysname,
  @DBName sysname
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @TSQL nvarchar(MAX);
  DECLARE @Return int;

  SET @TSQL = 'USE [' + @DBName + ']; IF EXISTS(SELECT name FROM sys.database_principals 
                         WHERE name = ''' + @LoginToClone + ''')
                 BEGIN
				   CREATE USER [' + @NewLogin + '] FROM LOGIN [' + @NewLogin + '];
				 END;';
 PRINT @TSQL;

END;

GO

/****** Object:  StoredProcedure [dbo].[usp_GrantUserRoleMembership]    Script Date: 11/13/2022 1:43:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[usp_GrantUserRoleMembership]
  @NewLogin sysname,
  @LoginToClone sysname,
  @DBName sysname
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @TSQL nvarchar(MAX);
  DECLARE @Return int;

  CREATE TABLE #RoleMembershipSQL 
  (
    RoleMembersTSQL nvarchar(MAX)
  );

  SET @TSQL = 'INSERT INTO #RoleMembershipSQL (RoleMembersTSQL) 
	SELECT ''EXEC sp_addrolemember @rolename = '''''' + r.name 
      + '''''', @membername = ''''' + @NewLogin + ''''';''
    FROM [' + @DBName + '].sys.database_principals AS U
      JOIN [' + @DBName + '].sys.database_role_members AS RM
        ON U.principal_id = RM.member_principal_id
      JOIN [' + @DBName + '].sys.database_principals AS R
        ON RM.role_principal_id = R.principal_id
    WHERE U.name = ''' + @LoginToClone + ''';';

  EXECUTE @Return = sp_executesql @TSQL;

  DECLARE cursDBRoleMembersSQL CURSOR FAST_FORWARD
  FOR
  SELECT RoleMembersTSQL 
  FROM #RoleMembershipSQL;

  OPEN cursDBRoleMembersSQL;

  FETCH FROM cursDBRoleMembersSQL INTO @TSQL;

  WHILE (@@FETCH_STATUS = 0)
    BEGIN
	  SET @TSQL = 'USE [' + @DBName + ']; ' + @TSQL;
      PRINT @TSQL;

      FETCH NEXT FROM cursDBRoleMembersSQL INTO @TSQL;
    END;

  CLOSE cursDBRoleMembersSQL;
  DEALLOCATE cursDBRoleMembersSQL;

  DROP TABLE #RoleMembershipSQL;

END;



GO