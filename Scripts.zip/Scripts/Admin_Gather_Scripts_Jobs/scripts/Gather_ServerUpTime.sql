SET NOCOUNT ON;

DECLARE @xp VARCHAR(512)
DECLARE @results TABLE ([output] VARCHAR(MAX))

DECLARE @Original_AdvOptions_State SQL_VARIANT;
DECLARE @Original_CmdShell_State SQL_VARIANT;
DECLARE @Current_AdvOptions_State SQL_VARIANT
DECLARE @Current_CmdShell_State SQL_VARIANT;

SET @Original_AdvOptions_State = 0;
SET @Original_CmdShell_State = 0;
SET @Current_AdvOptions_State = 0;
SET @Current_CmdShell_State = 0;


/*  ENABLE XP_CMDSHELL  */
SELECT
	@Original_AdvOptions_State = value_in_use
FROM master.sys.configurations
WHERE name = 'show advanced options'
SELECT
	@Original_CmdShell_State = value_in_use
FROM master.sys.configurations
WHERE name = 'xp_cmdshell'

IF @Original_AdvOptions_State = 0
	 BEGIN
		 EXEC sp_configure 'show advanced options'
						  ,1
		 RECONFIGURE WITH OVERRIDE
	 END

IF @Original_CmdShell_State = 0
	 BEGIN
		 --    PRINT 'Changing xp_cmdshell is off - CHANGING to on'
		 EXEC sp_configure 'xp_cmdshell'
						  ,1
		 RECONFIGURE WITH OVERRIDE
	 END

	 -- // END

SET @xp = 'powershell.exe -C "Get-WmiObject Win32_OperatingSystem | Select-Object CSName, @{n=''LastBootTime''; e = {$_.ConverttoDateTime($_.lastbootuptime)}} | Format-List"'

INSERT INTO @results
EXEC sys.xp_cmdshell @xp

SELECT
    CAST(CONVERT(VARCHAR,GETDATE(),23) AS SMALLDATETIME)                          AS DateKey
   ,UPPER(CAST(SERVERPROPERTY('ServerName')AS VARCHAR(256)))					  AS SqlInstance
   ,RTRIM( LTRIM( CAST( REPLACE( [T1],'CSName       :','' ) AS VARCHAR(MAX) ) ) ) AS ComputerName
   ,CAST( RTRIM( LTRIM( REPLACE( [T2],'LastBootTime :','' ) ) ) AS DATETIME )	  AS WindowsBootTime
   ,(SELECT login_time FROM sys.dm_exec_sessions WHERE session_id = 1)			  
	AS SqlStartTime
FROM (
	  SELECT
		  [output]
		 ,'T' + CAST( ROW_NUMBER() OVER (ORDER BY [output]) AS CHAR(1) ) AS rn
	  FROM @results
	  WHERE [output] IS NOT NULL
) AS s
PIVOT (MAX( [output] ) FOR rn IN ([T1],[T2])) AS P


/* REVERT TO ORIGINAL STATE */
SELECT
	@Current_CmdShell_State = value_in_use
FROM master.sys.configurations
WHERE name = 'xp_cmdshell'

IF @Original_CmdShell_State <> @Current_CmdShell_State
	 BEGIN
		 --PRINT 'Reverting xp_cmdshell state'
		 EXEC sp_configure 'xp_cmdshell'
						  ,0
		 RECONFIGURE WITH OVERRIDE
	 END

SELECT
	@Current_AdvOptions_State = value_in_use
FROM master.sys.configurations
WHERE name = 'show advanced options'

IF @Original_AdvOptions_State <> @Current_AdvOptions_State
	 BEGIN
		 --PRINT 'Reverting show advanced options state'
		 RECONFIGURE WITH OVERRIDE
	 END

/* END */


SET NOCOUNT OFF;
