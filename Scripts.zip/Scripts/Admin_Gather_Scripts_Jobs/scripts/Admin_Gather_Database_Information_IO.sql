SET NOCOUNT ON

if object_id('tempdb..#MSVer') is not null
	exec ('drop table #MSVer')
create table #MSVer(ID int,  Name  sysname, Internal_Value int, Value nvarchar(512))
insert #MSVer exec master.dbo.xp_msver

CREATE TABLE #wDBInformation_IO  
( 	
	[Date_Key] [datetime] NULL,
	[Server_Name] [nvarchar](128) NULL,
	[Database_Name] [nvarchar](128) NULL,
	[ProcessorCount] [int] NULL,
	[Disk_Drive] [nvarchar](128) NULL,
	[Physical_File_Name] [nvarchar](520) NULL,
	[File_Type] [nvarchar](10) NULL,
	[AverageIOStallsperMS] [int] NULL,
	[FileSize] [int] NULL,
	[GrowthType] [nvarchar](50) NULL,
	[Growth] [nvarchar](50) NULL,
	[File_Read_Percentage] [int] NULL,
	[File_Write_Percentage] [int] NULL,
	[Maximum_File_Size] [nvarchar](50) NULL,
	[Space_RemainingMB] [nvarchar](50) NULL,
	[Number_Of_Reads] [bigint] NULL,
	[Number_Bytes_Read] [bigint] NULL,
	[IOStall_Reads_MS] [bigint] NULL,
	[Number_Of_Writes] [bigint] NULL,
	[Number_Bytes_Written] [bigint] NULL,
	[IOStall_Writes_MB] [bigint] NULL,
	[Total_IOStall_Reads_Writes] [bigint] NULL
)  
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear


INSERT INTO #wDBInformation_IO  (
	[Date_Key],
	[Server_Name],
	[Database_Name],
	[ProcessorCount],
	[Disk_Drive],
	[Physical_File_Name],
	[File_Type],
	[AverageIOStallsperMS],
	[FileSize],
	[GrowthType],
	[Growth],
	[File_Read_Percentage],
	[File_Write_Percentage],
	[Maximum_File_Size],
	[Space_RemainingMB],
	[Number_Of_Reads],
	[Number_Bytes_Read],
	[IOStall_Reads_MS],
	[Number_Of_Writes],
	[Number_Bytes_Written],
	[IOStall_Writes_MB],
	[Total_IOStall_Reads_Writes]
)
SELECT
	@Date_Key as Date_Key, 
	S1.Server_Name, 
	S1.Database_Name, 
	(SELECT Value FROM #MSVer WHERE ID = 16) AS ProcessorCount,
	CASE WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'O:\SQLDATA01\' THEN 'O:\SQLDATA01\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'O:\SQLDATA02\' THEN 'O:\SQLDATA02\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'O:\SQLDATA03\' THEN 'O:\SQLDATA03\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'O:\SQLDATA04\' THEN 'O:\SQLDATA04\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'O:\SQLDATA05\' THEN 'O:\SQLDATA05\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'O:\SQLDATA06\' THEN 'O:\SQLDATA06\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SQLDATA1\' THEN 'O:\SQLDATA1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SQLDATA2\' THEN 'O:\SQLDATA2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SQLDATA3\' THEN 'O:\SQLDATA3\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SQLDATA4\' THEN 'O:\SQLDATA4\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SQLDATA5\' THEN 'O:\SQLDATA5\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SQLDATA6\' THEN 'O:\SQLDATA6\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SQLDATA7\' THEN 'O:\SQLDATA7\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,11)) = 'O:\SQLDATA\' THEN 'O:\SQLDATA\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,11)) = 'O:\SQLLOGS\' THEN 'O:\SQLLOGS\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SQLLOGS1\' THEN 'O:\SQLLOGS1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SQLLOGS2\' THEN 'O:\SQLLOGS2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'O:\SQLTEMPDB\' THEN 'O:\SQLTEMPDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,15)) = 'O:\SQLSYSTEMDB\' THEN 'O:\SQLSYSTEMDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'P:\SQLDATA1\' THEN 'P:\SQLDATA1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'P:\SQLDATA2\' THEN 'P:\SQLDATA2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'P:\SQLDATA3\' THEN 'P:\SQLDATA3\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'P:\SQLDATA4\' THEN 'P:\SQLDATA4\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'P:\SQLDATA5\' THEN 'P:\SQLDATA5\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'P:\SQLDATA6\' THEN 'P:\SQLDATA6\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,11)) = 'P:\SQLDATA\' THEN 'P:\SQLDATA\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'P:\SQLLOGS1\' THEN 'P:\SQLLOGS1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'P:\SQLLOGS2\' THEN 'P:\SQLLOGS2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,11)) = 'P:\SQLLOGS\' THEN 'P:\SQLLOGS\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'P:\SQLTEMPDB\' THEN 'P:\SQLTEMPDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,15)) = 'P:\SQLSYSTEMDB\' THEN 'P:\SQLSYSTEMDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'N:\SQLDATA1\' THEN 'N:\SQLDATA1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'N:\SQLDATA2\' THEN 'N:\SQLDATA2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'N:\SQLDATA3\' THEN 'N:\SQLDATA3\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'N:\SQLDATA4\' THEN 'N:\SQLDATA4\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'N:\SQLDATA5\' THEN 'N:\SQLDATA5\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,11)) = 'N:\SQLDATA\' THEN 'N:\SQLDATA\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,11)) = 'N:\SQLLOGS\' THEN 'N:\SQLLOGS\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'N:\SQLLOGS1\' THEN 'N:\SQLLOGS1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'N:\SQLLOGS2\' THEN 'N:\SQLLOGS2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'N:\SQLTEMPDB\' THEN 'N:\SQLTEMPDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,15)) = 'N:\SQLSYSTEMDB\' THEN 'N:\SQLSYSTEMDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'O:\DATA1\' THEN 'O:\DATA1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'O:\DATA2\' THEN 'O:\DATA2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'O:\DATA3\' THEN 'O:\DATA3\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'O:\DATA4\' THEN 'O:\DATA4\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'O:\DATA5\' THEN 'O:\DATA5\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'O:\DATA6\' THEN 'O:\DATA6\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'O:\DATA7\' THEN 'O:\DATA7\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,10)) = 'O:\TLOGS1\' THEN 'O:\TLOGS1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,10)) = 'O:\TLOGS2\' THEN 'O:\TLOGS2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,10)) = 'O:\TEMPDB\' THEN 'O:\TEMPDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'O:\SYSTEMDB\' THEN 'O:\SYSTEMDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'P:\DATA1\' THEN 'P:\DATA1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'P:\DATA2\' THEN 'P:\DATA2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'P:\DATA3\' THEN 'P:\DATA3\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'P:\DATA4\' THEN 'P:\DATA4\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'P:\DATA5\' THEN 'P:\DATA5\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'P:\DATA6\' THEN 'P:\DATA6\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,9)) = 'P:\DATA7\' THEN 'P:\DATA7\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,10)) = 'P:\TLOGS1\' THEN 'P:\TLOGS1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,10)) = 'P:\TLOGS2\' THEN 'P:\TLOGS2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,10)) = 'P:\TEMPDB\' THEN 'P:\TEMPDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'P:\SYSTEMDB\' THEN 'P:\SYSTEMDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'P:\V2_TEMPDB\' THEN 'P:\V2_TEMPDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,15)) = 'P:\V2_SYSTEMDB\' THEN 'P:\V2_SYSTEMDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,16)) = 'P:\V2_SQLDATA01\' THEN 'P:\V2_SQLDATA01\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,16)) = 'P:\V2_SQLDATA02\' THEN 'P:\V2_SQLDATA02\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,16)) = 'P:\V2_SQLDATA03\' THEN 'P:\V2_SQLDATA03\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,13)) = 'S:\SQLTEMPDB\' THEN 'S:\SQLTEMPDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,15)) = 'S:\SQLSYSTEMDB\' THEN 'S:\SQLSYSTEMDB\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'S:\SQLDATA1\' THEN 'S:\SQLDATA1\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'S:\SQLDATA2\' THEN 'S:\SQLDATA2\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'S:\SQLDATA3\' THEN 'S:\SQLDATA3\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'S:\SQLDATA4\' THEN 'S:\SQLDATA4\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,12)) = 'S:\SQLDATA5\' THEN 'S:\SQLDATA5\'
	     WHEN UPPER(LEFT(S2.PhysicalFile,11)) = 'S:\SQLLOGS\' THEN 'S:\SQLLOGS\'	
	ELSE UPPER(LEFT(S2.PhysicalFile,2)) END AS Disk_Drive, 
	S2.PhysicalFile AS Physical_File_Name, 
	UPPER(RIGHT(S2.PhysicalFile,3)) AS File_Type,	
	CAST((S1.io_stall/(S1.num_of_reads + S1.num_of_writes)) AS INT) AS AverageIOStallsperMS,		
	S2.FileSize, 
	S2.GrowthType, 
	S2.Growth, 
	CAST(ROUND((CONVERT(DECIMAL(18,6),S1.num_of_reads)/(CONVERT(DECIMAL(18,6),S1.num_of_reads) + CONVERT(DECIMAL(18,6),S1.num_of_writes)))*100,0) AS INT) AS File_Read_Percentage,	
	CAST(ROUND((CONVERT(DECIMAL(18,6),S1.num_of_writes)/(CONVERT(DECIMAL(18,6),S1.num_of_reads) + CONVERT(DECIMAL(18,6),S1.num_of_writes)))*100,0)AS INT) AS File_Write_Percentage,	
	S2.MaxFileSize AS Maximum_File_Size, 
	S2.SpaceRemainingMB AS Space_RemainingMB, 
	S1.num_of_reads AS Number_Of_Reads, 
	S1.num_of_bytes_read AS Number_Bytes_Read, 
	S1.io_stall_read_ms AS IOStall_Reads_MS, 
	S1.num_of_writes AS Number_Of_Writes, 
	S1.num_of_bytes_written AS Number_Bytes_Written, 
	S1.io_stall_write_ms IOStall_Writes_MB, 
	S1.io_stall AS Total_IOStall_Reads_Writes
From 		
(		
SELECT     @@SERVERNAME AS Server_Name, DB_NAME(database_id) AS database_name, *		
FROM         sys.dm_io_virtual_file_stats(NULL, NULL)) AS S1 INNER JOIN 		
(		
SELECT 		
	@@ServerName AS Server_Name,	
	DB_NAME(database_id) AS DatabaseName, 	
	File_ID AS DB_File_ID,	
	CAST(name AS varchar(20)) AS NameofFile, 	
	CAST(physical_name AS varchar(100)) AS PhysicalFile, 	
    type_desc AS FileType, 		
    size * 8 / 1024 AS FileSize, 		
    CASE WHEN max_size = - 1 OR max_size = 268435456 THEN 'UNLIMITED' 		
		 WHEN max_size = 0 THEN 'NO_GROWTH' 
		 WHEN max_size <> - 1 OR max_size <> 0 THEN CAST(((max_size * 8) / 1024) AS varchar(15)) 
		 ELSE 'Unknown' 
		 END AS MaxFileSize, 
	CASE WHEN max_size = - 1 OR max_size = 268435456 THEN 'UNLIMITED' 	
		 WHEN max_size <> - 1 OR max_size = 268435456 THEN CAST((((max_size - size) * 8) / 1024) AS varchar(10)) 
		 ELSE 'Unknown' 
		 END AS SpaceRemainingMB, 
	CASE WHEN growth = 0 and is_percent_growth = 1 THEN 'FIXED_SIZE' 
	     	 WHEN is_percent_growth  = 1 THEN CAST(growth AS varchar(10))	
	     	 WHEN growth > 0 THEN CAST(((growth * 8) / 1024) AS varchar(10))
	     	 ELSE 'Unknown' 
	     	 END AS Growth, 
	CASE WHEN is_percent_growth = 1 THEN 'PERCENTAGE' 	
		 WHEN is_percent_growth = 0 THEN 'MBs' 
		 ELSE 'Unknown' 
		 END AS GrowthType
FROM	 sys.master_files	
WHERE    (state = 0) AND (type_desc IN ('LOG', 'ROWS'))) AS S2 ON		
S1.database_name = S2.DatabaseName AND	
S1.file_id = S2.DB_File_ID
ORDER BY S1.database_id, S1.[file_id]

SELECT
	[Date_Key],
	[Server_Name],
	[Database_Name],
	[ProcessorCount],
	[Disk_Drive],
	[Physical_File_Name],
	[File_Type],
	[AverageIOStallsperMS],
	[FileSize],
	[GrowthType],
	[Growth],
	[File_Read_Percentage],
	[File_Write_Percentage],
	[Maximum_File_Size],
	[Space_RemainingMB],
	[Number_Of_Reads],
	[Number_Bytes_Read],
	[IOStall_Reads_MS],
	[Number_Of_Writes],
	[Number_Bytes_Written],
	[IOStall_Writes_MB],
	[Total_IOStall_Reads_Writes]
FROM #wDBInformation_IO  
ORDER BY  
	[Server_Name],
	[Database_Name],
	[Physical_File_Name]
