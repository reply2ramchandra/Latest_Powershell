﻿# Define variables
$ssrsInstanceName = "SSRS2022"
$backupPath = "C:\SSRS_Backup"
$encryptionKeyFile = "$backupPath\SSRS_EncryptionKey.snk"
$encryptionKeyPassword = "YourStrongPassword"
$sqlServerName = "localhost"
$reportServerDb = "ReportServer"
$tempDb = "ReportServerTempDB"

# Create backup directory
New-Item -ItemType Directory -Path $backupPath -Force

# Step 1: Backup Encryption Key from SSRS 2016
Write-Host "Backing up encryption key..."
& "C:\Program Files\Microsoft SQL Server\MSRS13.MSSQLSERVER\Reporting Services\Tools\rskeymgmt.exe" -e -f $encryptionKeyFile -p $encryptionKeyPassword

# Step 2: Backup SSRS Databases
Write-Host "Backing up SSRS databases..."
Backup-SqlDatabase -ServerInstance $sqlServerName -Database $reportServerDb -BackupFile "$backupPath\$reportServerDb.bak"
Backup-SqlDatabase -ServerInstance $sqlServerName -Database $tempDb -BackupFile "$backupPath\$tempDb.bak"

# Step 3: Restore Encryption Key to SSRS 2022
Write-Host "Restoring encryption key to SSRS 2022..."
& "C:\Program Files\Microsoft SQL Server Reporting Services\SSRS\Tools\rskeymgmt.exe" -a -f $encryptionKeyFile -p $encryptionKeyPassword

# Step 4: Connect SSRS 2022 to existing databases
Write-Host "Connecting SSRS 2022 to existing databases..."
# This step is typically done via Reporting Services Configuration Manager GUI
# You can script it using WMI or SQL, but GUI is recommended for accuracy

Write-Host "Migration preparation complete. Please finalize setup using SSRS Configuration Manager."
