
/*
***********************************************************************************************************************************
*                                       This Section Declare the Work Fields                                                      *
***********************************************************************************************************************************
*/
DECLARE @format tinyint
DECLARE @SQL NVARCHAR(1000)
DECLARE @STRLine VARCHAR(8000)
DECLARE @Drive varchar(500)
DECLARE @TotalSize BIGINT
DECLARE @Freesize BIGINT
DECLARE @VolumeName VARCHAR(64)
DECLARE @command VARCHAR(5000)  
DECLARE @NodeName varchar(128)

/*
***********************************************************************************************************************************
*                                       This Section will Create the Work Tables                                                  *
***********************************************************************************************************************************
*/
IF OBJECT_ID('tempdb.dbo.wDrvLetter') IS NOT NULL  
    DROP TABLE tempdb.dbo.wDrvLetter 
IF OBJECT_ID('tempdb.dbo.wDrvInfo') IS NOT NULL  
    DROP TABLE tempdb.dbo.wDrvInfo 
IF OBJECT_ID('tempdb.dbo.wDrvInfo2') IS NOT NULL  
    DROP TABLE tempdb.dbo.wDrvInfo2 
IF OBJECT_ID('tempdb.dbo.wBackupDrive') IS NOT NULL  
    DROP TABLE tempdb.dbo.wBackupDrive 
IF OBJECT_ID('tempdb.dbo.wLogicalDisk') IS NOT NULL  
    DROP TABLE tempdb.dbo.wLogicalDisk 
IF OBJECT_ID('tempdb.dbo.wOutput1') IS NOT NULL  
    DROP TABLE tempdb.dbo.wOutput1 

CREATE TABLE tempdb.dbo.wDrvLetter (
    Drive VARCHAR(500),
    )
CREATE TABLE tempdb.dbo.wDrvInfo (
    Drive VARCHAR(500) null,
    [MB free] BIGINT,
    [MB TotalSize] BIGINT,
    [Volume Name] VARCHAR(64)
    )

CREATE TABLE tempdb.dbo.wDrvInfo2   
	( ServerName VARCHAR(100),  
	DatabaseName VARCHAR(100),  
	FileSizeMB INT,  
	LogicalFileName sysname,  
	PhysicalFileName NVARCHAR(520),  
	Status sysname,  
	Updateability sysname,  
	RecoveryMode sysname,  
	FreeSpaceMB INT,  
	FreeSpacePct VARCHAR(7),  
	FreeSpacePages INT,  
	PollDate datetime)  

CREATE TABLE tempdb.dbo.wBackupDrive   
	( ServerName VARCHAR(100),  
	physical_device_name NVARCHAR(520))  

CREATE TABLE tempdb.dbo.wLogicalDisk 
	( DeviceID varchar(128),
	VolumeName varchar(256)
	)

CREATE TABLE tempdb.dbo.wOutput1 
	(col1 VARCHAR(2048)
	)

/*
***********************************************************************************************************************************
*                                       This Section will update the Work Tables                                                  *
***********************************************************************************************************************************
*/

INSERT INTO tempdb.dbo.wDrvLetter
EXEC xp_cmdshell 'wmic volume where drivetype="3" get caption, freespace, capacity, label'

DELETE
FROM tempdb.dbo.wDrvLetter
WHERE Drive IS NULL OR len(Drive) < 4 OR Drive LIKE '%Capacity%'
	OR Drive LIKE  '%\\%\Volume%'

WHILE EXISTS(SELECT 1 FROM tempdb.dbo.wDrvLetter)
BEGIN
SET ROWCOUNT 1
SELECT @STRLine = Drive FROM tempdb.dbo.wDrvLetter

-- Get TotalSize
SET @TotalSize= CONVERT(BIGINT,CAST(LEFT(@STRLine,CHARINDEX(' ',@STRLine)) AS CHAR(18)))/1024/1024
--SELECT @TotalSize

-- Remove Total Size
SET @STRLine = REPLACE(@STRLine, LEFT(@STRLine,CHARINDEX(' ',@STRLine)),'')
-- Get Drive

SET @Drive = LEFT(LTRIM(@STRLine),CHARINDEX(' ',LTRIM(@STRLine)))
--SELECT @Drive

SET @STRLine = RTRIM(LTRIM(REPLACE(LTRIM(@STRLine), LEFT(LTRIM(@STRLine),CHARINDEX(' ',LTRIM(@STRLine))),'')))

SET @Freesize = CONVERT(BIGINT,CAST(LEFT(LTRIM(@STRLine),CHARINDEX(' ',LTRIM(@STRLine))) AS CHAR(18)))/1024/1024
--SELECT @Freesize/1024/1024

SET @STRLine = RTRIM(LTRIM(REPLACE(LTRIM(@STRLine), LEFT(LTRIM(@STRLine),CHARINDEX(' ',LTRIM(@STRLine))),'')))
SET @VolumeName = @STRLine
-- 

INSERT INTO tempdb.dbo.wDrvInfo
SELECT @Drive, @Freesize , @TotalSize, @VolumeName

DELETE FROM tempdb.dbo.wDrvLetter
END

SET ROWCOUNT 0

-- POPULATE TEMP TABLE WITH LOGICAL DISKS
-- This is FIX/Workaround for Windows 2003 bug that WMIC doesn't return volume name that is over X number of charactors.
SET @SQL ='wmic /FailFast:ON logicaldisk where (drivetype ="3" and volumename!="RECOVERY" AND volumename!="System Reserved") get deviceid,volumename  /Format:csv'
INSERT INTO tempdb.dbo.wOutput1
EXEC master..xp_cmdshell @SQL
DELETE tempdb.dbo.wOutput1 where ltrim(col1) is null or len(col1) = 1 or col1 like 'Node,DeviceID,VolumeName%'

SET @NodeName = (SELECT TOP 1 LEFT(col1, CHARINDEX(',',col1)) FROM tempdb.dbo.wOutput1)

-- Clean up server name
UPDATE tempdb.dbo.wOutput1 SET col1 = REPLACE(col1, @NodeName, '')

INSERT INTO tempdb.dbo.wLogicalDisk
SELECT LEFT(col1, CHARINDEX(',',col1)-2),  SUBSTRING(col1, CHARINDEX(',',col1)+1, LEN(col1))
FROM tempdb.dbo.wOutput1

UPDATE dr
SET dr.[Volume Name] = ld.VolumeName
	FROM tempdb.dbo.wDrvInfo dr RIGHT OUTER JOIN tempdb.dbo.wLogicalDisk ld ON left(dr.Drive,1) = ld.DeviceID
WHERE LEN([Volume Name]) = 1

SELECT @command = 'Use [' + '?' + '] SELECT  
	@@servername as ServerName,  
	' + '''' + '?' + '''' + ' AS DatabaseName,  
	CAST(sysfiles.size/128.0 AS int) AS FileSize,  
	sysfiles.name AS LogicalFileName, sysfiles.filename AS PhysicalFileName,  
	CONVERT(sysname,DatabasePropertyEx(''?'',''Status'')) AS Status,  
	CONVERT(sysname,DatabasePropertyEx(''?'',''Updateability'')) AS Updateability,  
	CONVERT(sysname,DatabasePropertyEx(''?'',''Recovery'')) AS RecoveryMode,  
	CAST(sysfiles.size/128.0 - CAST(FILEPROPERTY(sysfiles.name, ' + '''' +  
		   'SpaceUsed' + '''' + ' ) AS int)/128.0 AS int) AS FreeSpaceMB,  
	CAST(100 * (CAST (((sysfiles.size/128.0 -CAST(FILEPROPERTY(sysfiles.name,  
	' + '''' + 'SpaceUsed' + '''' + ' ) AS int)/128.0)/(sysfiles.size/128.0))  
	AS decimal(4,2))) AS varchar(8)) + ' + '''' +  '''' + ' AS FreeSpacePct
	FROM dbo.sysfiles'  
	INSERT INTO tempdb.dbo.wDrvInfo2  
	   (ServerName,  
	   DatabaseName,  
	   FileSizeMB,  
	   LogicalFileName,  
	   PhysicalFileName,  
	   Status,  
	   Updateability,  
	   RecoveryMode,  
	   FreeSpaceMB,  
	   FreeSpacePct)  
	EXEC sp_MSforeachdb @command  

INSERT INTO tempdb.dbo.wBackupDrive
SELECT @@servername as ServerName
      ,UPPER([physical_device_name]) AS physical_device_name
  FROM [msdb].[dbo].[backupmediafamily]
  WHERE LEFT(UPPER([physical_device_name]),3) IN ('Y:\','X:\','W:\','V:\')

/*
***********************************************************************************************************************************
*                                       This Section will produce the final Result Set                                            *
***********************************************************************************************************************************
*/
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear

--Will collect Database Location Information
SELECT DISTINCT
	@Date_Key AS Date_Key,
	@@servername as ServerName,
	dr.Drive AS Drive,
	dr.[MB TotalSize] AS TotalDiskspaceMB,
	dr.[MB free] AS FreeDiskspaceMB,
	dr.[MB TotalSize] - dr.[MB free] AS  UsedDiskspaceMB,
	CONVERT(INT,(CAST(dr.[MB free] AS DECIMAL(13,4)))/(CAST(dr.[MB TotalSize] AS DECIMAL(13,4)))*100) AS PercentageFree
FROM tempdb.dbo.wDrvInfo AS dr INNER JOIN tempdb.dbo.wDrvInfo2 as db ON
	dr.Drive = LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive)))
UNION ALL
--Will collect Backup Location Information
SELECT DISTINCT
	@Date_Key AS Date_Key,
	@@servername as ServerName,
	dr.Drive AS Drive,
	dr.[MB TotalSize] AS TotalDiskspaceMB,
	dr.[MB free] AS FreeDiskspaceMB,
	dr.[MB TotalSize] - dr.[MB free] AS  UsedDiskspaceMB,
	CONVERT(INT,(CAST(dr.[MB free] AS DECIMAL(13,4)))/(CAST(dr.[MB TotalSize] AS DECIMAL(13,4)))*100) AS PercentageFree
FROM tempdb.dbo.wDrvInfo AS dr INNER JOIN tempdb.dbo.wBackupDrive as bkp ON
	dr.Drive = LEFT(bkp.physical_device_name,LEN(RTRIM(dr.Drive)))
UNION ALL
--Will collect System Location Information
SELECT DISTINCT
	@Date_Key AS Date_Key,
	@@servername as ServerName,
	dr.Drive AS MountPoint,
	dr.[MB TotalSize] AS TotalDiskspaceMB,
	dr.[MB free] AS FreeDiskspaceMB,
	dr.[MB TotalSize] - dr.[MB free] AS  UsedDiskspaceMB,
	CONVERT(INT,(CAST(dr.[MB free] AS DECIMAL(13,4)))/(CAST(dr.[MB TotalSize] AS DECIMAL(13,4)))*100) AS PercentageFree
FROM tempdb.dbo.wDrvInfo AS dr 
WHERE dr.Drive IN ('C:\','D:\')
ORDER BY ServerName, Drive

/*
***********************************************************************************************************************************
*                                       This Section is for Cleanup Processing                                                    *
***********************************************************************************************************************************
*/
IF OBJECT_ID('tempdb.dbo.wDrvLetter') IS NOT NULL  
    DROP TABLE tempdb.dbo.wDrvLetter 
IF OBJECT_ID('tempdb.dbo.wDrvInfo') IS NOT NULL  
    DROP TABLE tempdb.dbo.wDrvInfo 
IF OBJECT_ID('tempdb.dbo.wDrvInfo2') IS NOT NULL  
    DROP TABLE tempdb.dbo.wDrvInfo2 
IF OBJECT_ID('tempdb.dbo.wBackupDrive') IS NOT NULL  
    DROP TABLE tempdb.dbo.wBackupDrive 
IF OBJECT_ID('tempdb.dbo.wLogicalDisk') IS NOT NULL  
    DROP TABLE tempdb.dbo.wLogicalDisk 
IF OBJECT_ID('tempdb.dbo.wOutput1') IS NOT NULL  
    DROP TABLE tempdb.dbo.wOutput1

