﻿CREATE VIEW [Billing].[vProductionHostInstanceCIs]
AS
	SELECT
		[Billing].format_ci(ServerList.SqlInstance) AS [CI Name]
	FROM Inventory.ServerList
	WHERE (IsActive = 1
	AND SupportGroup IS NOT NULL)
	AND Environment = 'P'
	UNION
	SELECT
		Host
	FROM Inventory.ClusterNodeNames
	INNER JOIN Inventory.ServerList
		ON ClusterNodeNames.SqlInstance = ServerList.SqlInstance
	WHERE ServerList.Environment = 'P'