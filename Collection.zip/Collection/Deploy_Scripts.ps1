﻿Import-Module dbatools -EA SilentlyContinue

$srv='TPAPWSQLGNXTB02'
$instance=Find-DbaInstance -ComputerName $srv | Select SqlInstance
$serverinstance=$instance.SqlInstance
$postscripts= Get-ChildItem X:\SQLPostBuild
$postscripts=$postscripts.FullName 
foreach($deploy in $postscripts)
{
Write-host "Post Build Script Deployment is inprogress...." -ForegroundColor Yellow
$serverinstance | Invoke-DbaQuery -File $deploy 
}
<#
#Table/StoredProcedure/UserDefinedFunction/view 
Import-Module dbatools -EA SilentlyContinue
$scripts= Get-ChildItem "D:\PSScripts\databases\GetNext_TestMHC\202408190715\StoredProcedure\"
$scripts=$scripts.FullName
foreach($script in $scripts)
{
##***Take extra care of Server Name and  where you are going to deploy*** 

"TPAPWSQLMHL001" | Invoke-DbaQuery -Database "GetNext_MHC" -File $script}

#>