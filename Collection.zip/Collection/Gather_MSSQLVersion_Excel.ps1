﻿Import-Module dbatools -DisableNameChecking
$servers = Get-DbaRegServer -SqlInstance TPAPWMSSQL002
$sql = Get-DbaProductKey -ComputerName $servers.name
 
$excelFile = 'D:\PSScripts\Excel\SQLVersionInfo.xlsx'
 
$sqlProps = 'ComputerName','InstanceName','SqlInstance','Version','Edition'
  
$sqlExcel = @{
	Path = $excelFile
	WorksheetName = 'SQLVersions'
	AutoSize = $true
	TableName = 'SQLVersions'
	IncludePivotTable = $true
	PivotRows = 'Version'
	PivotData = @{Version='Count'}
	IncludePivotChart = $true
	ChartType = 'ColumnClustered'
}
 
$sql | Select-Object $sqlProps | export-excel @sqlExcel