Import-Module dbatools

# Config
$SqlInstance = "MyServer\MyInstance"
$OutputFile = "C:\Reports\SqlPerfChecklist_$(Get-Date -Format yyyyMMdd_HHmmss).html"

# Start HTML
$html = @"
<html>
<head>
<style>
    body { font-family: Arial, sans-serif; }
    h2 { color: #2F4F4F; }
    table { border-collapse: collapse; width: 100%; margin-bottom: 20px;}
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left;}
    th { background-color: #4CAF50; color: white;}
    tr:nth-child(even) { background-color: #f2f2f2; }
    .high { background-color: #ff6666; }
</style>
<title>SQL Server Performance Checklist</title>
</head>
<body>
"@

$html += "<h1>SQL Server Performance Checklist - $SqlInstance</h1>"

# Server info
$Server = Get-DbaSqlInstance -SqlInstance $SqlInstance
$html += "<h2>Server Info</h2>"
$html += "<table><tr><th>Property</th><th>Value</th></tr>"
$html += "<tr><td>Version</td><td>$($Server.VersionString)</td></tr>"
$html += "<tr><td>Edition</td><td>$($Server.Edition)</td></tr>"
$html += "<tr><td>Processors</td><td>$($Server.Processors)</td></tr>"
$html += "<tr><td>Physical Memory</td><td>$([math]::Round($Server.PhysicalMemory/1GB,2)) GB</td></tr>"
$html += "</table>"

# Memory settings
$Memory = Get-DbaMaxMemory -SqlInstance $SqlInstance
$html += "<h2>Memory Settings</h2>"
$html += "<table><tr><th>Min Server Memory (MB)</th><th>Max Server Memory (MB)</th></tr>"
$html += "<tr><td>$($Memory.MinServerMemory)</td><td>$($Memory.MaxServerMemory)</td></tr></table>"

# MaxDOP
$Dop = Get-DbaMaxDop -SqlInstance $SqlInstance
$html += "<h2>MAXDOP</h2>"
$html += "<table><tr><th>Max Degree of Parallelism</th></tr>"
$html += "<tr><td>$($Dop.MaxDop)</td></tr></table>"

# TempDB
$TempDb = Get-DbaTempDbConfiguration -SqlInstance $SqlInstance
$html += "<h2>TempDB Files</h2>"
$html += "<table><tr><th>Logical Name</th><th>Size (MB)</th><th>File Type</th></tr>"
foreach ($file in $TempDb.DataFiles) {
    $html += "<tr><td>$($file.LogicalName)</td><td>$([math]::Round($file.Size/1MB,2))</td><td>Data</td></tr>"
}
foreach ($file in $TempDb.LogFiles) {
    $html += "<tr><td>$($file.LogicalName)</td><td>$([math]::Round($file.Size/1MB,2))</td><td>Log</td></tr>"
}
$html += "</table>"

# Missing backups
$html += "<h2>Databases Missing Backups (24 hours)</h2>"
$MissingBackups = Get-DbaLastBackup -SqlInstance $SqlInstance | Where-Object { $_.LastFullBackup -lt (Get-Date).AddDays(-1) }
if ($MissingBackups) {
    $html += "<table><tr><th>Database</th><th>Last Full Backup</th></tr>"
    foreach ($db in $MissingBackups) {
        $html += "<tr><td>$($db.Database)</td><td>$($db.LastFullBackup)</td></tr>"
    }
    $html += "</table>"
} else {
    $html += "<p style='color:green;'>All databases have full backups in the last 24 hours.</p>"
}

# Top waits
$html += "<h2>Top Waits</h2>"
$TopWaits = Get-DbaWaitStatistic -SqlInstance $SqlInstance | Sort-Object WaitTimeSeconds -Descending | Select-Object -First 5
$html += "<table><tr><th>Wait Type</th><th>Wait Time (sec)</th></tr>"
foreach ($wait in $TopWaits) {
    $html += "<tr><td>$($wait.WaitType)</td><td>$($wait.WaitTimeSeconds)</td></tr>"
}
$html += "</table>"

# Autogrowth
$html += "<h2>File Autogrowth Settings</h2>"
$Growths = Get-DbaDatabaseFile -SqlInstance $SqlInstance | Select-Object Database, LogicalName, FileGrowth, GrowthType
$html += "<table><tr><th>Database</th><th>File</th><th>Growth</th><th>Type</th></tr>"
foreach ($g in $Growths) {
    $html += "<tr><td>$($g.Database)</td><td>$($g.LogicalName)</td><td>$($g.FileGrowth)</td><td>$($g.GrowthType)</td></tr>"
}
$html += "</table>"

# Fragmentation sample
$html += "<h2>Sample Index Fragmentation &gt; 30%</h2>"
$Fragmented = Get-DbaDatabase -SqlInstance $SqlInstance | ForEach-Object {
    Get-DbaDbIndex -SqlInstance $SqlInstance -Database $_.Name -Fragmentation | Where-Object {$_.AvgFragmentationPercent -gt 30} | Select-Object Database, Table, Index, AvgFragmentationPercent -First 1
}
if ($Fragmented) {
    $html += "<table><tr><th>Database</th><th>Table</th><th>Index</th><th>Fragmentation (%)</th></tr>"
    foreach ($idx in $Fragmented) {
        $fragClass = if ($idx.AvgFragmentationPercent -gt 50) { "high" } else { "" }
        $html += "<tr class='$fragClass'><td>$($idx.Database)</td><td>$($idx.Table)</td><td>$($idx.Index)</td><td>$([math]::Round($idx.AvgFragmentationPercent,2))%</td></tr>"
    }
    $html += "</table>"
} else {
    $html += "<p style='color:green;'>No indexes over 30% fragmentation found.</p>"
}

# End HTML
$html += "</body></html>"

# Save HTML file
$html | Out-File -FilePath $OutputFile -Encoding utf8
Write-Host "Performance checklist completed. HTML report saved to $OutputFile."