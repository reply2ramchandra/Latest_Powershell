﻿Import-Module dbatools -EA SilentlyContinue
clear
Get-DbaOperatingSystem -ComputerName TPADWSQLMHCA01 | Select ComputerName,LastBootTime,LocalDateTime
Get-DbaOperatingSystem -ComputerName TPAPWSQLHHB01 | Select ComputerName,LastBootTime,LocalDateTime
<#
Import-Module dbatools -EA SilentlyContinue
clear
$serverList = "T:\Test\HA_Prod.txt"
$servers = Get-Content $serverList

foreach ($server in $servers) { Get-DbaOperatingSystem -ComputerName $server | Select ComputerName,LastBootTime,LocalDateTime }
#>

<#
Import-Module dbatools -ErrorAction Stop

$thresholdMinutes = 5      # How recent the reboot should be

try {
$server = "TPATWSQLSSRS02"  # Replace with your server name
    $osInfo = Get-DbaOperatingSystem -ComputerName $server | Select-Object ComputerName, LastBootTime, LocalDateTime
    if ($null -eq $osInfo) {
        Write-Host "Could not retrieve OS info for $server."
        return
    }

    # Access the .DateTime property for calculations
    #$lastBoot = $osInfo.LastBootTime.DateTime
    #$now = $osInfo.LocalDateTime.DateTime
    #$minutesSinceBoot = ($now - $lastBoot).TotalMinutes
    $lastBoot = [datetime]::Parse($osInfo.LastBootTime.ToString())
    $now = [datetime]::Parse($osInfo.LocalDateTime.ToString())
    $minutesSinceBoot = ($now - $lastBoot).TotalMinutes

    Write-Host "Server: $($osInfo.ComputerName)"
    Write-Host "Last Boot Time: $lastBoot"
    Write-Host "Current Time: $now"
    Write-Host "Minutes since last boot: $([math]::Round($minutesSinceBoot,2))"

    if ($minutesSinceBoot -le $thresholdMinutes) {
        Write-Host "✅ Server $server rebooted successfully within the last $thresholdMinutes minutes."
    } else {
        Write-Host "⚠️ Server $server has not rebooted recently (last boot was $([math]::Round($minutesSinceBoot,2)) minutes ago)."
    }
} catch {
    Write-Host "❌ Error connecting to $server or retrieving OS info: $_"
}
#>