﻿#drop table if exist
Import-Module dbatools -EA SilentlyContinue 
Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "DROP TABLE IF EXISTS dbo.PatchCompliant" 
$servers=Get-Content "T:\Test\0423.txt"
Import-Module dbatools -DisableNameChecking 
Update-DbaBuildReference
foreach($server in $servers)
{
$instance=Find-DbaInstance -ComputerName $server
$PatchCompliant=Test-DbaBuild -SqlInstance $instance -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant 
if($PatchCompliant){ Write-DbaDataTable -SqlInstance tpapwmssql002 -Database cms -Schema 'dbo' -Table 'PatchCompliant' -InputObject $PatchCompliant  -AutoCreateTable -KeepNulls }
}


#Test-DbaBuild -SqlInstance TPAPWNICESQL001 -Latest