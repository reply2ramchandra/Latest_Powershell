﻿##https://sqlserverbuilds.blogspot.com/
#refer Get-DbaAgentJob to start the DIFF Backup job
##Step 1 - Secondary Node First
$server='TPAPWSQLETB01'
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
#copy patch file
$patchfile= Get-ChildItem X:\SQLISO\CU -Filter '*2019*' 
$source=$patchfile.FullName  
$target="D:\patch"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s -Force -ErrorAction SilentlyContinue
Import-Module dbatools -EA SilentlyContinue 
### SET AGReplica Failover MOde to Manual Before Apply Patches
Get-DbaAgReplica -SqlInstance TPATWSQLMHCA01 | Out-GridView -Passthru | Set-DbaAgReplica -FailoverMode Manual
 
$server='TPATWSQLMHCB01'
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5040948 -Restart -Path C:\patch -Confirm:$false



$server='TPAPWSQLETA01'
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
#copy patch file
$patchfile= Get-ChildItem X:\SQLISO\CU -Filter '*2019*' 
$source=$patchfile.FullName  
$target="D:\patch"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s
##Step 2 -AG Failover
#Failover to SqlInstance given which is secondary now
Get-DbaAvailabilityGroup -SqlInstance TPATWSQLMHCB01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
#check AG DB sync status and AG role
Get-DbaAgDatabase -SqlInstance TPATWSQLMHCB01 | Select SqlInstance, LocalReplicaRole,Name,SynchronizationState,IsFailoverReady
##Step 3 - Apply now on Secondary Node which was Primary prior
$server='TPATWSQLMHCA01'
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5040948 -Restart -Path C:\patch -Confirm:$false

##Step 4 -AG FailBack
#Failover to SqlInstance given which is secondary now
Get-DbaAvailabilityGroup -SqlInstance TPATWSQLMHCB01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false

### SET AGReplica Failover Mode to Manual Before Apply Patches
Get-DbaAgReplica -SqlInstance TPATWSQLMHCA01 | Out-GridView -Passthru | Set-DbaAgReplica -FailoverMode Automatic
