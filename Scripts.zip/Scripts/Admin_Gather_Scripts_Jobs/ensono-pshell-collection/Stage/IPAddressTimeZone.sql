﻿CREATE TABLE [Stage].[IPAddressTimeZone]
(
	SqlInstance VARCHAR(256) NOT NULL,
	MachineName VARCHAR(256),
	IPAddress VARCHAR(24),
	TimeZoneOffset NVARCHAR(64),
	PRIMARY KEY CLUSTERED ([SqlInstance])
)
