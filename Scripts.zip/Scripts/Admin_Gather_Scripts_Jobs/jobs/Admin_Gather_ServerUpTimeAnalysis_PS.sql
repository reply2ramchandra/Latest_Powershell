USE [msdb]
GO

/****** Object:  Job [ACXJOB_Admin_Gather_ServerUpTimeAnalysis_PS]    Script Date: 6/14/2017 11:20:16 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Acx-Maintenance]    Script Date: 6/14/2017 11:20:16 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Acx-Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Acx-Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ACXJOB_Admin_Gather_ServerUpTimeAnalysis_PS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'For all the Active Database Servers connected to the Central Management Server, the Server Version Information will be gathered by the execution of this job. DBA.dbo.DBServersAll.DBSAActive = 1', 
		@category_name=N'Acx-Maintenance', 
		@owner_login_name=N'PRSCOAD\prod-sql-dba', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Truncate Log Tables]    Script Date: 6/14/2017 11:20:16 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Truncate Log Tables', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate Table AdminLog.UpTimeAnalysis', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Deletion of Previously Loaded Data]    Script Date: 6/14/2017 11:20:16 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Deletion of Previously Loaded Data', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'TRUNCATE TABLE AdminServer.UpTimeAnalysis_Repository', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Gather_UpTimeAnalysis_Information]    Script Date: 6/14/2017 11:20:16 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Gather_UpTimeAnalysis_Information', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
."Y:\SSISRoot\APPDBA\PSScripts\Scripts\write-datatable.ps1"

#Looping logic taken from: https://sqljgood.wordpress.com/2014/09/17/using-powershell-to-loop-through-a-list-of-sql-server-databases/

$instances = invoke-sqlcmd -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -Query "SELECT NULL,[DBSAServerConnection],DATEADD(dd,DATEDIFF(dd,0,getdate()),0),NULL FROM AdminControl.DBServersAll WHERE DBSAActive = 1 ORDER BY [DBSAServerConnection]"
Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminLog.UpTimeAnalysis" -Data $instances

foreach ($instance in $instances)
{
	$Inst = $instance.DBSAServerConnection
	try
	{
		$dt=invoke-sqlcmd -ServerInstance ${Inst} -inputfile "Y:\SSISRoot\APPDBA\PSScripts\Scripts\Admin_UpTimeAnalysis_Collection.sql" 
		Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminServer.UpTimeAnalysis_Repository" -Data $dt	}
	catch
	{
		#
	}
}

', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Log Tables]    Script Date: 6/14/2017 11:20:16 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Log Tables', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
Declare @RecordsCollected int
UPDATE AdminLog.UpTimeAnalysis
SET RunResults = ''Collected''
FROM AdminLog.UpTimeAnalysis AS L INNER JOIN AdminControl.DBServersAll AS C ON
L.ServerName = C.DBSAServerConnection 
INNER JOIN 
AdminServer.UpTimeAnalysis_Repository AS R ON
C.DBSAServerName = R.ServerName
WHERE DATEPART(MONTH, R.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, R.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, R.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

