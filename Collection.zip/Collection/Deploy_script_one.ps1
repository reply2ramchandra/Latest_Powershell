﻿clear
Import-Module dbatools -EA SilentlyContinue
$instances=get-content "T:\Test\admin_recovery.txt"
foreach($instance in $instances)
{
$instance | Invoke-DbaQuery -File  X:\SQLPostBuild\set_recovery.sql 

}
<#
$instance='TPAPWSQLDL001'
$instance | Invoke-DbaQuery -File  X:\SQLPostBuild\OnlyDBAs_in_fixed_server_roles.sql | Export-Csv X:\SQLPostBuild\$instance_ServerRole.csv 
$instance | Invoke-DbaQuery -File  D:\PSScripts\Scripts\check_admin_log_file_size_free.sql | Export-Csv X:\SQLPostBuild\Admin_Logfile.csv -Append
#>

