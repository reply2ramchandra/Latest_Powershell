--
-- Version 1.05	Greg Ota Feb 17, 2014
-- (c) 2014 Acxiom Corp, Greg Ota
-- ACXIOM CONFIDENTIAL - not for release to public, not for release to clients
--
-- Version	Date		DBA	Comment
-- 1.01		20140302	GSO	Added Errorlog check; removed dependency on usp_instance_version_query; formatting and commentary
-- 1.02		20140304	GSO	Fixed VLF counts (truncated table between databases, fixed 2012 to run from correct table), auto create and auto update thanks to Chris Murray
--							Changed true/false bits, changed to 'Cost Threshold', some includes and excludes to errorlog check thanks to Randy Owens
--							Added Stack dump to errorlog check
-- 1.03		20140310	GSO	Check for msdb purge job, cache flush, supported version check
-- 1.04		20140311	GSO	Various 2012 fixes, case sensitive fixes, excluded backup failures from the errorlog check, SQL 2005 compatible
-- 1.05		20140311	GSO Added Windows OS check for powercfg (only works with W2K8, W2K3 not supported), various fixes for W2K3, 32-bit, 2005 vs 2012, 32-bit memory
-- 1.06		20140327	GSO	Changed date strings for errorlog per Randy O., correction of SQL SErver 2012 Standard x64 and T845
-- 1.07		20140730	CM	Added description actions for each of the identified issues
-- 1.08		20141112	GSO Various bug fixes
-- 1.10		20141112	GSO Added 2014 version, updated supported versions, changed best practices for non-RRD (tempdb), maxdop change, lock pages in memory
-- 1.11		20150503	GSO	Added min memory check for VM.

-- Instructions:  Set @IsProduction in Step 0.00 and Execute

-- Limitations:		SQL Server 2005 or greater;  
--					Memory check not complete for 32-bit.
--					Must have access to xp_cmdshell

-- Best Practice Checks
-- Step 0		Information gathering
-- Step 0.00	PARAMETERS TO SET
-- Step 0.01	Checks to see if this is a virtual or physical server
-- Step 0.02	Setup output table
-- Step 0.03	Get version, bit (32/64) and edition information (non stored procedure) and version supportability check
-- Step 1.01	TEMPDB:  number of data files
-- Step 1.11	MAXDOP
-- Step 1.12	Cost threshold for parallelism
-- Step 1.21	Memory left for OS
-- Step 1.22	Max Memory
-- Step 1.31	Auditing failed logins
-- Step 2.01	Local security policies - Lock Pages in Memory
-- Step 2.02	Local security policies - Perform volume management tasks
-- Step 2.11	OS Power Scheme
-- Step 3.01	Database settings - Owner
-- Step 3.02	Database settings - Auto close
-- Step 3.03	Database settings - Auto shrink
-- Step 3.04	Database settings - state (e.g. online, offline, etc.)
-- Step 3.05	Database settings - recovery model (presumes Production=FULL else SIMPLE)
-- Step 3.06	VLFs
-- Step 3.07	DB file options
-- Step 3.08	Database settings - Auto create
-- Step 3.09	Database settings - Auto update
-- Step 4.01	Maintenance jobs - looks for "ACXJOBS"
-- Step 5.01	Monitoring - looks for patrol like login
-- Step 6.01	Errorlog

--
-- GENERIC VARIABLES
--

DECLARE @ORIGINAL_ADVOPTIONS_STATE sql_variant
SET @ORIGINAL_ADVOPTIONS_STATE=0
DECLARE @CURRENT_ADVOPTIONS_STATE sql_variant
SET @CURRENT_ADVOPTIONS_STATE=0
DECLARE @ORIGINAL_CMDSHELL_STATE sql_variant
SET @ORIGINAL_CMDSHELL_STATE=0
DECLARE @CURRENT_CMDSHELL_STATE sql_variant
SET @CURRENT_CMDSHELL_STATE=0
DECLARE @ORIGINAL_OLEAUTO_STATE sql_variant
SET @ORIGINAL_OLEAUTO_STATE=0
DECLARE @CURRENT_OLEAUTO_STATE sql_variant
SET @CURRENT_OLEAUTO_STATE=0

SELECT @ORIGINAL_ADVOPTIONS_STATE=value_in_use FROM master.sys.configurations WHERE name='show advanced options'
SELECT @ORIGINAL_CMDSHELL_STATE=value_in_use FROM master.sys.configurations WHERE name='xp_cmdshell'
SELECT @ORIGINAL_OLEAUTO_STATE=value_in_use FROM master.sys.configurations WHERE name='OLE Automation Procedures'

IF @ORIGINAL_ADVOPTIONS_STATE=0
BEGIN
--    PRINT 'Changing show advanced options is off - CHANGING to on'
    EXEC sp_configure 'show advanced options',1
    reconfigure with override
END 
--ELSE PRINT 'Changing show advanced options already on - no change necessary'
    
IF @ORIGINAL_CMDSHELL_STATE=0
BEGIN
--    PRINT 'Changing xp_cmdshell is off - CHANGING to on'
	EXEC sp_configure 'xp_cmdshell', 1
    reconfigure with override
END 
--ELSE PRINT 'Changing xp_cmdshell already on - no change necessary'

IF @ORIGINAL_OLEAUTO_STATE=0
BEGIN
--    PRINT 'Changing OLE Automation Procedures is off - CHANGING to on'
	EXEC sp_configure 'OLE Automation Procedures', 1
    reconfigure with override
END 
--ELSE PRINT 'Changing OLE Automation Procedures already on - no change necessary'

DECLARE @rtn TINYINT
	, @status varchar(50)
	, @message varchar(500)
	, @row_count int
	, @TRUE bit
	, @FALSE bit
	, @IsProduction bit
	, @IsVirtual bit
	, @servername varchar(255)
	, @cmd nvarchar(4000)
	, @param nvarchar(4000)

SET @TRUE = 1
SET @FALSE= 0
SELECT @servername=@@servername

SET @IsProduction = @TRUE
-- Step 0.01	Checks to see if system is virtual
DECLARE @OSVersion varchar(4)
CREATE TABLE #xp_cmdshell_output1 (Output VARCHAR (8000)); 
INSERT INTO #xp_cmdshell_output1 EXEC ('xp_cmdshell ''systeminfo'''); 

IF EXISTS (SELECT * FROM #xp_cmdshell_output1 WHERE Output LIKE 'System Model:%Virtual%')
	SELECT @IsVirtual = @TRUE
ELSE IF EXISTS (SELECT * FROM #xp_cmdshell_output1 WHERE Output LIKE 'System Model:%VMware%')
	SELECT @IsVirtual = @TRUE
ELSE
	SELECT @IsVirtual = @FALSE

IF EXISTS (SELECT * FROM #xp_cmdshell_output1 WHERE Output LIKE 'OS Name:%2003%')
	SELECT @OSVersion = '2003'
ELSE IF EXISTS (SELECT * FROM #xp_cmdshell_output1 WHERE Output LIKE 'OS Name:%2008%')
	SELECT @OSVersion = '2008'
ELSE
	SELECT @OSVersion = '????'

DROP TABLE #xp_cmdshell_output1
-- Step 0.02	Setup output table
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'[tempdb].[dbo].[wBestPractices]') ) 
    DROP TABLE [tempdb].[dbo].[wBestPractices]  

CREATE TABLE #myoutput (
	instance_name	varchar(255)
	, best_practice_name	varchar(255)
	, notes	varchar(8000)
	, steps varchar(8000)
	)

PRINT 'Begin of Best Practices Scan ' + @servername
INSERT INTO #myoutput VALUES (@servername, 'master', @message, 'Begin of Best Practices Scan')

--
-- Step 0.03	Get version and edition information (non stored procedure)
-- 

DECLARE @instance_version varchar(50)
	, @instance_edition varchar(50)  -- edition and instance version information
	, @instance_bit varchar(2) -- "64" for 64-bit "86" for 32-bit
	, @version varchar(50)
	, @edition varchar(50)
	, @activity_type varchar(100)

SELECT @version = CONVERT(varchar(50), SERVERPROPERTY('productversion'))
SELECT @edition = CONVERT(varchar(50), SERVERPROPERTY('Edition'))

IF (@version like '8.00.%')
  set @instance_version = '2000'
ELSE IF (@version like '9.00.%')
  set @instance_version = '2005'
ELSE IF (@version like '10.0.%')
  set @instance_version = '2008'
ELSE IF (@version like '10.50.%')
  set @instance_version = '2008R2'
ELSE IF (@version like '11.0.%')
  set @instance_version = '2012'
ELSE IF (@version like '12.0.%')
  set @instance_version = '2014'
ELSE IF (@version like '13.0.%')
  set @instance_version = '2016'
ELSE 
  GOTO ExitWError

IF @edition like 'Standard%'
  set @instance_edition = 'Standard'
ELSE IF @edition like 'Developer%'
  set @instance_edition = 'Developer'
ELSE IF @edition like 'Enterprise%'
  set @instance_edition = 'Enterprise'
ELSE IF @edition like 'Workgroup%'
  set @instance_edition = 'Workgroup'
ELSE 
  GOTO ExitWError

SELECT @row_count = CHARINDEX('X64',@@VERSION)
IF @row_count > 0
	SELECT @instance_bit='64'
ELSE 
	SELECT @instance_bit='32'

--
-- Step 1.01	TEMPDB:  number of data files
--

DECLARE @num_logical_cpus int
	,@num_physical_cpus int
	,@num_tempdb_files int
	,@max_tempdb_size int
	,@min_tempdb_size int
	,@tempdb_ratio int
	,@tempdb_ratio_mod int
	,@numa_nodes int
	,@hyperthread_ratio int

SELECT @num_logical_cpus = CONVERT(INTEGER,(SELECT cpu_count FROM sys.dm_os_sys_info))
SELECT @num_tempdb_files = (SELECT COUNT([type_desc]) FROM [tempdb].[sys].[database_files] WHERE type_desc = 'ROWS')
	
SELECT 
	@num_physical_cpus = ( cpu_count / hyperthread_ratio )
	,@hyperthread_ratio = hyperthread_ratio
FROM sys.dm_os_sys_info

SELECT
	@numa_nodes = (SELECT MAX(c.memory_node_id) + 1 FROM sys.dm_os_memory_clerks c WHERE memory_node_id < 64)

SELECT @max_tempdb_size = (SELECT (MAX(size)*8)/1024 FROM tempdb.sys.database_files WHERE type_desc = 'ROWS' and state_desc='ONLINE')
SELECT @min_tempdb_size = (SELECT (MIN(size)*8)/1024 FROM tempdb.sys.database_files WHERE type_desc = 'ROWS' and state_desc='ONLINE')

IF @num_logical_cpus = @num_tempdb_files AND @max_tempdb_size = @min_tempdb_size
	PRINT 'Tempdb Correct using 1 to 1 Ratio - Standard:  Num logical cpus: ' + CONVERT(varchar(15),@num_logical_cpus) + ' equals num tempdb files: ' + CONVERT(varchar(15),@num_tempdb_files) + ' and Data Files are the same size'
ELSE IF @num_logical_cpus = @num_tempdb_files AND @max_tempdb_size <> @min_tempdb_size
	BEGIN
	SELECT @message= 'Tempdb Correct using 1 to 1 Ratio - Standard:  Num logical cpus: ' + CONVERT(varchar(15),@num_logical_cpus) + ' equals num tempdb files: ' + CONVERT(varchar(15),@num_tempdb_files) + ' and Data Files are NOT the same size'
	INSERT INTO #myoutput VALUES (@servername, 'TEMPDB', @message, 'Proportional Fill Algorithm Broken, make initial file sizes the same - will require emptying and potentially a restart of SQL')
	END
ELSE IF @num_logical_cpus / @num_tempdb_files = 8.0  AND @max_tempdb_size = @min_tempdb_size
	PRINT 'Tempdb Correct using 8 to 1 Ratio - Standard:  Num logical cpus: ' + CONVERT(varchar(15),@num_logical_cpus) + ' equals num tempdb files: ' + CONVERT(varchar(15),@num_tempdb_files) + ' and Data Files are the same size'
ELSE IF @num_logical_cpus / @num_tempdb_files = 8.0  AND @max_tempdb_size <> @min_tempdb_size
	BEGIN
	SELECT @message= 'Tempdb Correct using 8 to 1 Ratio - Standard:  Num logical cpus: ' + CONVERT(varchar(15),@num_logical_cpus) + ' equals num tempdb files: ' + CONVERT(varchar(15),@num_tempdb_files) + ' and Data Files are NOT the same size'
	INSERT INTO #myoutput VALUES (@servername, 'TEMPDB', @message, 'Proportional Fill Algorithm Broken, make initial file sizes the same - will require emptying and potentially a restart of SQL')
	END
ELSE IF @num_logical_cpus / @num_tempdb_files = 4.0 AND @max_tempdb_size = @min_tempdb_size
	PRINT 'Tempdb Correct using 4 to 1 Ratio - Standard:  Num logical cpus: ' + CONVERT(varchar(15),@num_logical_cpus) + ' equals num tempdb files: ' + CONVERT(varchar(15),@num_tempdb_files) + ' and Data Files are the same size'
ELSE IF @num_logical_cpus / @num_tempdb_files = 4.0 AND @max_tempdb_size <> @min_tempdb_size
	BEGIN
	SELECT @message= 'Tempdb Correct using 4 to 1 Ratio - Standard:  Num logical cpus: ' + CONVERT(varchar(15),@num_logical_cpus) + ' equals num tempdb files: ' + CONVERT(varchar(15),@num_tempdb_files) + ' and Data Files are NOT the same size'
	INSERT INTO #myoutput VALUES (@servername, 'TEMPDB', @message, 'Proportional Fill Algorithm Broken, make initial file sizes the same - will require emptying and potentially a restart of SQL')
	END
ELSE IF @num_logical_cpus / @num_tempdb_files = 2.0 AND @max_tempdb_size = @min_tempdb_size
	PRINT 'Tempdb Correct using 2 to 1 Ratio - Standard:  Num logical cpus: ' + CONVERT(varchar(15),@num_logical_cpus) + ' equals num tempdb files: ' + CONVERT(varchar(15),@num_tempdb_files) + ' and Data Files are the same size'
ELSE IF @num_logical_cpus / @num_tempdb_files = 2.0 AND @max_tempdb_size <> @min_tempdb_size
	BEGIN
	SELECT @message= 'Tempdb Correct using 2 to 1 Ratio - Standard:  Num logical cpus: ' + CONVERT(varchar(15),@num_logical_cpus) + ' equals num tempdb files: ' + CONVERT(varchar(15),@num_tempdb_files) + ' and Data Files are NOT the same size'
	INSERT INTO #myoutput VALUES (@servername, 'TEMPDB', @message, 'Proportional Fill Algorithm Broken, make initial file sizes the same - will require emptying and potentially a restart of SQL')
	END
ELSE 
BEGIN
	SELECT @message='TEMPDB NOT TO BEST PRACTICE:  Num logical cpus: ' + CONVERT(varchar(15),@num_logical_cpus) + ' NOT EQUAL num tempdb files: ' + CONVERT(varchar(15),@num_tempdb_files)
	PRINT @message
	INSERT INTO #myoutput VALUES (@servername, 'TEMPDB', @message, 'Add new files with matching initial size and growth OR remove unnecessary files - will require emptying and potentially a restart of SQL')
END

--
-- Step 1.11	MAXDOP
-- 

DECLARE @MAXDOP int
	, @SuggestedMAXDOP int

SELECT @MAXDOP = CONVERT(int,value) FROM sys.configurations WHERE name = 'max degree of parallelism'

SET @SuggestedMAXDOP = @num_logical_cpus
IF @IsVirtual=@TRUE SET @SuggestedMAXDOP = 0
ELSE
BEGIN
	IF @hyperthread_ratio > 0 AND @SuggestedMAXDOP > @num_physical_cpus SET @SuggestedMAXDOP = @num_physical_cpus
	IF @numa_nodes > 1
		IF @SuggestedMAXDOP > (@num_logical_cpus / @numa_nodes) SET @SuggestedMAXDOP = (@num_logical_cpus / @numa_nodes)
	IF @SuggestedMAXDOP > 8 SET @SuggestedMAXDOP = 8
END

IF (@SuggestedMAXDOP = @MAXDOP)
	PRINT 'MAXDOP Correct:  Suggested MAXDOP ' + CONVERT(varchar(15),@SuggestedMAXDOP) + ' equals MAXDOP: ' + CONVERT(varchar(15),@MAXDOP)
ELSE 
BEGIN
	SELECT @message='MAXDOP NOT TO BEST PRACTICE:  Suggested MAXDOP: ' + CONVERT(varchar(15),@SuggestedMAXDOP) + ' DOES NOT equal MAXDOP: ' + CONVERT(varchar(15),@MAXDOP)
	INSERT INTO #myoutput VALUES (@servername, 'MAXDOP', @message, 'Use GUI or sp_configure to amend MAXDOP to equal to the number of logical CPUs')
END
--
-- Step 1.12	Cost threshold for parallelism
--
DECLARE @parallel_threshold int
SELECT @parallel_threshold=CONVERT(int,value) FROM sys.configurations
WHERE name = 'cost threshold for parallelism'
IF @parallel_threshold = 5
BEGIN
	SELECT @message= 'COST THRESHOLD FOR PARALLEISM NOT TO BEST PRACTICE: ' + CONVERT(varchar(15),@parallel_threshold)
	INSERT INTO #myoutput VALUES (@servername, 'Cost Threshold', @message, 'For new builds � set to 20.  For existing builds change to 15 or 20 only if you encounter CPU pressure due to CXPACKET waits.  Otherwise skip.')
END
ELSE IF @parallel_threshold = 20
		PRINT 'Cost Threshold for Parallelism Correct: ' + CONVERT(varchar(15),@parallel_threshold)
	ELSE
	BEGIN
		SELECT @message= 'Cost Threshold for Parallelism UNKNOWN: ' + CONVERT(varchar(15),@parallel_threshold)
		INSERT INTO #myoutput VALUES (@servername, 'Cost Threshold', @message, 'For new builds � set to 20.  For existing builds change to 15 or 20 only if you encounter CPU pressure due to CXPACKET waits.  Otherwise skip.')
	END

--
-- Step 1.21	Memory left for OS
--

DECLARE @AWE sql_variant
	,@instance_max_memory_mb int
	,@server_memory_mb int
	,@memory_reserved_for_os_mb int
	,@best_practice_amount_memory_reserved_for_os_mb int
	,@server_memory_mb_OUT nvarchar(16)

SELECT @best_practice_amount_memory_reserved_for_os_mb = 3070
	
SELECT @AWE = value_in_use from sys.configurations where name = 'awe enabled'
SELECT @instance_max_memory_mb = CONVERT(int,value_in_use) from sys.configurations where name = 'max server memory (MB)'
IF @instance_version = '2005'
	SELECT @cmd='SELECT @server_memory_mb_OUT = physical_memory_in_bytes / 1024 / 1024 from sys.dm_os_sys_info'
ELSE
	SELECT @cmd='SELECT @server_memory_mb_OUT = total_physical_memory_kb / 1024 from sys.dm_os_sys_memory'

SELECT @param='@server_memory_mb_OUT nvarchar(16) OUTPUT'

EXEC sp_executesql @cmd, @param, @server_memory_mb_OUT=@server_memory_mb_OUT OUTPUT;
SELECT @server_memory_mb = CONVERT(int,@server_memory_mb_OUT)

--
-- Step 1.22	Max Memory
--

DECLARE @IsPAE bit
	, @Is3GB bit
	, @IsAWE bit

IF @instance_bit = '32'
BEGIN
	create table #FileContents
	(
		LineNumber int identity
		, LineContents nvarchar(4000)
	);
     
	insert #FileContents
	exec master.dbo.xp_cmdshell 'type c:\boot.ini'
	IF EXISTS (SELECT * FROM #FileContents WHERE UPPER(LineContents) LIKE '%/3GB%')
		SELECT @Is3GB = @TRUE
	ELSE
		SELECT @Is3GB = @FALSE

	IF EXISTS (SELECT * FROM #FileContents WHERE UPPER(LineContents) LIKE '%/PAE%')
		SELECT @IsPAE = @TRUE
	ELSE
		SELECT @IsPAE = @FALSE

	DROP TABLE #FileContents

	CREATE TABLE #spconfigure
	(
		config_option	varchar(255)
	,	minimum			int
	,	maximum			int
	,	config_value	int
	,	run_value		int
	)

	INSERT INTO #spconfigure EXEC sp_configure 'awe enabled'

	IF EXISTS (SELECT * FROM #spconfigure WHERE run_value = 1)
		SELECT @IsAWE = @TRUE
	ELSE
		SELECT @IsAWE = @FALSE

	DROP TABLE #spconfigure

	SELECT @IsPAE as "PAE", @Is3GB as "3GB", @IsAWE as "AWE"

	IF @instance_max_memory_mb = 2147483647
	BEGIN
		SELECT @message= 'MEMORY NOT TO BEST PRACTICE:  max memory is at the default ' + CONVERT(varchar(15),@instance_max_memory_mb)
		INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Set Max Memory to TOTAL MEMORY less 3GB for OS unless CLR is enabled (see sp_configure) in which case minimum of 4GB')
	END
	IF @server_memory_mb  <= 4096 --4GB
	BEGIN
		IF @Is3GB = @FALSE
		BEGIN
			SELECT @message= 'MEMORY NOT TO BEST PRACTICE:  32-bit system, <= 4GB server memory, no /3GB flag'
			INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Get Intel to add /3GB flag and assign max memory at Max less 1GB')
		END
		IF @IsAWE = @FALSE
		BEGIN
			SELECT @message= 'MEMORY NOT TO BEST PRACTICE:  32-bit system, <= 4GB server memory, and /3GB flag should use AWE'
			INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Get Intel to add /3GB flag and enable AWE through the GUI or sp_configure - NOTE - THIS NEEDS LOCK PAGES IN MEMORY local security policy enabled by Intel')
		END
	END
	ELSE
	BEGIN
		IF @Is3GB = @TRUE
		BEGIN
			SELECT @message= 'MEMORY NOT TO BEST PRACTICE:  32-bit system, > 4GB server memory, with /3GB flag'
			INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Get Intel to remove /3GB flag as /PAE should be enabled, not /3GB')
		END
		IF @IsPAE = @FALSE
		BEGIN
			SELECT @message= 'MEMORY NOT TO BEST PRACTICE:  32-bit system, > 4GB server memory, no /PAE flag'
			INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Get Intel to add /PAE flag')
		END
		IF @IsAWE = @FALSE
		BEGIN
			SELECT @message= 'MEMORY NOT TO BEST PRACTICE:  32-bit system, > 4GB server memory, and /PAE flag should use AWE'
			INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Enable AWE through GUI or sp_configure')
		END
	END

END
ELSE
-- 64-bit calculations
IF @instance_bit = '64'
BEGIN
	IF @instance_max_memory_mb = 2147483647
	BEGIN
		SELECT @message= 'MEMORY NOT TO BEST PRACTICE:  max memory is at the default ' + CONVERT(varchar(15),@instance_max_memory_mb)
		INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Set Max Memory to Maximum less 3GB. 4GB if CLR is enabled - check through sp_configure')
	END
	ELSE
	BEGIN
		SELECT @memory_reserved_for_os_mb = @server_memory_mb - @instance_max_memory_mb
		IF @memory_reserved_for_os_mb < @best_practice_amount_memory_reserved_for_os_mb
		BEGIN
			SELECT @message='MEMORY NOT TO BEST PRACTICE:  server memory: ' + CONVERT(varchar(15),@server_memory_mb) + ' minus instance max: '+ CONVERT(varchar(15),@instance_max_memory_mb) + ' leaves only ' + CONVERT(varchar(15),@memory_reserved_for_os_mb)
			INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Set Max Memory to leave ' +convert(varchar(15),@best_practice_amount_memory_reserved_for_os_mb)+' for the OS')
		END
		ELSE
			PRINT 'Memory Correct:  server memory: ' + CONVERT(varchar(15),@server_memory_mb) + ' minus instance max: '+ CONVERT(varchar(15),@instance_max_memory_mb) + ' leaves ' + CONVERT(varchar(15),@memory_reserved_for_os_mb)
	END
END

--
-- Step 1.23	Min Memory
--

DECLARE @instance_min_memory_mb INT
SELECT @instance_min_memory_mb = CONVERT(int,value_in_use) from sys.configurations where name = 'max server memory (MB)'
IF ((@IsVirtual=@TRUE) AND (@instance_min_memory_mb = 0))
BEGIN
		SELECT @message= 'MEMORY NOT TO BEST PRACTICE:  mmin memory is at the default ' + CONVERT(varchar(15),@instance_min_memory_mb)
		INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Set Min Memory 25%-50% of max memory')
END

--
-- Step 1.31	Audit failed logins
--
-- Modified from Tim Lehner Stackoverflow.com answer
-- 2 = failed logins
-- 3 = failed and successful logins
declare @AuditLevel int
exec master..xp_instance_regread 
    @rootkey='HKEY_LOCAL_MACHINE',
    @key='SOFTWARE\Microsoft\MSSQLServer\MSSQLServer',
    @value_name='AuditLevel',
    @value=@AuditLevel output
IF (@AuditLevel = 2) OR (@AuditLevel = 3)
	PRINT 'Auditing Correct'
ELSE
BEGIN
	SELECT @message= 'AUDITING NOT TO BEST PRACTICE'
	INSERT INTO #myoutput VALUES (@servername, 'Security Auditing', @message, 'Set Login Auditing on (Failures only is sufficient)')
END
--
-- Step 2.01	Local security policies - Lock Pages in Memory
--
-- Code borrowed from SQL Server Central answers
CREATE TABLE #xp_cmdshell_output (Output VARCHAR (8000)); 
-- run whoami command via xp_cmdshell
INSERT INTO #xp_cmdshell_output EXEC ('xp_cmdshell ''whoami /priv'''); 

IF EXISTS (SELECT * FROM #xp_cmdshell_output WHERE Output LIKE '%SeLockMemoryPrivilege%Enabled%')
BEGIN 
	IF @IsVirtual = @TRUE
	BEGIN 
		SELECT @message= 'LOCK PAGES IN MEMORY NOT TO BEST PRACTICE:  Lock Page in memory enabled; Virtual = Yes' 
		INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Get Intel to enable LOCK PAGES IN MEMORY local security policy')
	END
ELSE BEGIN
	PRINT 'Lock Pages in Memory Correct:  Lock Page in memory enabled; Virtual = No'
	IF (@instance_edition = 'Standard' AND (@instance_version != '2012' AND @instance_bit!='64')) 
	BEGIN
		CREATE TABLE #mytemp
		(
			TraceFlag varchar(25)
		,	Status bit
		,	Global bit
		,	Session bit
		)

		INSERT INTO #mytemp EXEC sp_executesql N'DBCC TRACESTATUS(845)';                    

		DECLARE @TraceOn bit

		SELECT @TraceOn=Status from #mytemp

		IF (@TraceOn = 1)
			PRINT 'T845 Correct:  Standard Edition = TRUE, T845 = On, Lock Pages = ENABLED'
		ELSE
		BEGIN
			SELECT @message= 'T845 NOT TO BEST PRACTICE:  Not turned on'
			INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Set trace flag T845 in SQL Server startup parameters')
		END
		DROP TABLE #mytemp
	END
END
END 
ELSE
BEGIN
	IF @IsVirtual = @FALSE BEGIN
		SELECT @message= 'LOCK PAGES IN MEMORY NOT TO BEST PRACTICE:  Lock Page in memory disabled; Virtual = No' 
		INSERT INTO #myoutput VALUES (@servername, 'Memory', @message, 'Get Intel to enable LOCK PAGES IN MEMORY local security policy')
	END
END

--
-- Step 2.02	Local security policies - Perform volume management tasks
--

IF EXISTS (SELECT * FROM #xp_cmdshell_output WHERE Output LIKE '%SeManageVolumePrivilege%Enabled%') 
	PRINT 'Perform Volume Maintenance Tasks Correct' 
ELSE 
BEGIN
	SELECT @message= 'PERFORM VOLUME MAINTENANCE TASKS LOCAL SECURITY POLICY NOT TO BEST PRACTICE'; 
	INSERT INTO #myoutput VALUES (@servername, 'OS Config', @message, 'Get Intel to enable PERFORM VOLUME MAINTENANCE TASKS local security policy for the SQL Service Account')
END

DROP TABLE #xp_cmdshell_output; 
--
-- Step 2.11	OS Power Scheme
--
--
-- Step 2.11	OS Power Scheme
--
CREATE TABLE #xp_cmdshell_output2 (Output VARCHAR (8000)); 
INSERT INTO #xp_cmdshell_output2 EXEC ('xp_cmdshell ''powercfg -L'''); 
INSERT INTO #xp_cmdshell_output2 EXEC ('xp_cmdshell ''powercfg /List'''); 
	IF EXISTS (SELECT * FROM #xp_cmdshell_output2 WHERE Output LIKE '%(High performance) *%')
		PRINT 'OS Power Scheme correct' 
	ELSE
		BEGIN
			SELECT @message=Output FROM #xp_cmdshell_output2 WHERE Output like '%*%'
			SELECT @message= 'OS POWER SCHEME NOT TO BEST PRACTICE: ' + @message 
			INSERT INTO #myoutput VALUES (@servername, 'OS Config', @message, 'Get Intel to set Power Scheme to (High Performance)')
		END
DROP TABLE #xp_cmdshell_output2

--
-- Step 3.01	Database settings - Owner
--

SELECT @row_count = COUNT(*) FROM master..sysdatabases WHERE sid != 0x01
IF @row_count > 0
BEGIN
	SELECT @message= 'DATABASE OWNER NOT TO BEST PRACTICE?: ' + CONVERT(varchar(15), @row_count)
	INSERT INTO #myoutput VALUES (@servername, 'Database owner', @message, 'Databases need to be set to be owned by sa, unless the business owner has a compelling reason not to - SharePoint for example')
END
ELSE
	PRINT 'Database Ownership Correct:  all sa'

--
-- Step 3.02	Database settings - Auto close
--
SELECT @row_count = COUNT(*) FROM master.sys.databases WHERE is_auto_close_on = 1
IF @row_count > 0
BEGIN
	SELECT @message= 'DATABASE AUTO CLOSE NOT TO BEST PRACTICE: ' + CONVERT(varchar(15), @row_count)
--	SELECT name FROM master.sys.databases WHERE is_auto_close_on = 1
	INSERT INTO #myoutput VALUES (@servername, 'Database options', @message, 'Set AUTO CLOSE off, either through the GUI or through script - alter database [dbname] set AUTO_CLOSE OFF')
--	SELECT name, is_auto_close_on from master.sys.databases where is_auto_close_on = 1
END
ELSE
	PRINT 'Database Auto Close Correct'
--
-- Step 3.03	Database settings - Auto shrink
--
SELECT @row_count = COUNT(*) FROM master.sys.databases WHERE is_auto_shrink_on = 1
IF @row_count > 0
BEGIN
	SELECT @message= 'DATABASE AUTO SHRINK NOT TO BEST PRACTICE: ' + CONVERT(varchar(15), @row_count)
--	SELECT name FROM master.sys.databases WHERE is_auto_shrink_on = 1
	INSERT INTO #myoutput VALUES (@servername, 'Database options', @message, 'Set AUTO CLOSE off, either through the GUI or through script - alter database [dbname] set AUTO_SHRINK OFF')
--	SELECT name, is_auto_shrink_on from master.sys.databases where is_auto_shrink_on = 1
END
ELSE
	PRINT 'Database Auto Shrink Correct'
-- Not online
--
-- Step 3.04	Database settings - state (e.g. online, offline, etc.)
--
SELECT @row_count = COUNT(*) FROM master.sys.databases WHERE state > 0
IF @row_count > 0
BEGIN
	SELECT @message= 'DATABASE STATE (online) NOT TO BEST PRACTICE?: ' + CONVERT(varchar(15), @row_count)
	INSERT INTO #myoutput VALUES (@servername, 'Database options', @message, 'Flag OFFLINE databases to business owner for potential removal, RECOVERY PENDING databases may be due to Log Shipping or Mirroring - ensure these are working correctly')
--	SELECT name, state_desc from master.sys.databases where state > 0
END
ELSE
	PRINT 'Database State Correct'
--
-- Step 3.05	Database settings - recovery model (presumes Production=FULL else SIMPLE)
--
IF @IsProduction = @TRUE
BEGIN
	SELECT @row_count = COUNT(*) FROM master.sys.databases WHERE recovery_model != 1 AND name not in ('master', 'tempdb', 'model', 'msdb') AND state = 1
	IF @row_count > 0
	BEGIN
		SELECT @message= 'DATABASE RECOVERY MODEL NOT TO FULL?: ' + CONVERT(varchar(15), @row_count)
		INSERT INTO #myoutput VALUES (@servername, 'Database options', @message, 'Set database recovery model to FULL for Production databases using the GUI or script ALTER DATABASE [dbname] SET RECOVERY FULL - NOTE - take fresh backup of Database set to FULL')
--		SELECT name, recovery_model_desc from master.sys.databases where recovery_model != 1
--		AND name not in ('master', 'tempdb', 'model', 'msdb')
--		AND state = 1
	END
	ELSE PRINT 'Database Recovery Model Correct'
END
ELSE
BEGIN
	SELECT @row_count = COUNT(*) FROM master.sys.databases WHERE recovery_model != 3  AND state = 1
	IF @row_count > 0
	BEGIN
		SELECT @message= 'DATABASE RECOVERY MODEL NOT TO SIMPLE?: ' + CONVERT(varchar(15), @row_count)
		INSERT INTO #myoutput VALUES (@servername, 'Database options', @message, 'Set database recovery model to SIMPLE for non-Production databases using the GUI or script ALTER DATABASE [dbname] SET RECOVERY SIMPLE')
--		SELECT name, recovery_model_desc from master.sys.databases where recovery_model != 3  AND state = 1
	END
	ELSE PRINT 'Database Recovery Model Correct'
END
--
-- Step 3.06	VLFs
--
-- Modified from Brent Ozar
-- need to add 2012 support
IF (@instance_version = '2008') OR (@instance_version = '2008R2')
BEGIN
	CREATE TABLE #mytempVLF
	(
	  FileID SMALLINT ,
	  FileSize BIGINT ,
	  StartOffset BIGINT ,
	  FSeqNo BIGINT ,
	  [Status] TINYINT ,
	  Parity TINYINT ,
	  CreateLSN NUMERIC(38)
	);

       PRINT 'VLFs > 1000:'
       EXEC sp_MSforeachdb N'USE [?];
       DECLARE @message varchar(255) 
              , @servername varchar(255)
       SELECT @servername=@@servername ;
       INSERT INTO #mytempVLF 
       EXEC sp_executesql N''DBCC LogInfo() WITH NO_INFOMSGS'';                    
       IF @@ROWCOUNT > 1000
       BEGIN
              SELECT @message= CONVERT(varchar(255),DB_NAME()) + '' has too many VLFs: '' + CONVERT(varchar(255), COUNT(*)) FROM #mytempVLF;
              INSERT INTO #myoutput VALUES (@servername, ''VLF'', @message, ''Shrink Log file and re-grow to original size in larger growths - e.g. 4000MB - NOTE - this may require an outage or at least tlog backups on Production systems'');
       END
       TRUNCATE TABLE #mytempVLF
'
	DROP TABLE #mytempVLF
END
ELSE IF @instance_version = '2012'
BEGIN
	CREATE TABLE #mytempVLF2012
	(
		  recoveryunitid INT ,
		  FileID SMALLINT ,
		  FileSize BIGINT ,
		  StartOffset BIGINT ,
		  FSeqNo BIGINT ,
		  [Status] TINYINT ,
		  Parity TINYINT ,
		  CreateLSN NUMERIC(38)
	);

       PRINT 'VLFs > 1000:'
       EXEC sp_MSforeachdb N'USE [?];
       DECLARE @message varchar(255) 
              , @servername varchar(255)
       SELECT @servername=@@servername ;
       INSERT INTO #mytempVLF2012 
       EXEC sp_executesql N''DBCC LogInfo() WITH NO_INFOMSGS'';                    
       IF @@ROWCOUNT > 1000
       BEGIN
              SELECT @message= CONVERT(varchar(255),DB_NAME()) + '' '' + CONVERT(varchar(255), COUNT(*)) FROM #mytempVLF2012;
              INSERT INTO #myoutput VALUES (@servername, ''VLF'', @message, ''Shrink Log file and re-grow to original size in larger growths - e.g. 4000MB - NOTE - this may require an outage or at least tlog backups on Production systems'');
       END
       TRUNCATE TABLE #mytempVLF2012
'
	DROP TABLE #mytempVLF2012

END
--
-- Step 3.07	DB file options
--
	CREATE TABLE #myfileoptions
	(
		  myserver varchar(255),
		  mydatabase varchar(255),
		  mycomment varchar(255),
		  mycount int
	);

	EXEC sp_MSforeachdb N'USE [?];
	DECLARE @message varchar(255) 
		, @servername varchar(255)
		;
-- type !=2 excludes FILESTREAM which have 0 max size and 0 growth
	EXEC sp_executesql N''INSERT INTO #myfileoptions SELECT CONVERT(varchar(255),@@SERVERNAME), CONVERT(varchar(255),DB_NAME()), ''''Max Size'''',COUNT(*) FROM sys.database_files WHERE max_size not in (-1,268435456) AND type !=2'' 
	EXEC sp_executesql N''INSERT INTO #myfileoptions SELECT CONVERT(varchar(255),@@SERVERNAME), CONVERT(varchar(255),DB_NAME()), ''''Pct Growth'''',COUNT(*) FROM sys.database_files WHERE is_percent_growth = 1'' 
	EXEC sp_executesql N''INSERT INTO #myfileoptions SELECT CONVERT(varchar(255),@@SERVERNAME), CONVERT(varchar(255),DB_NAME()), ''''1MB Growth'''',COUNT(*) FROM sys.database_files WHERE is_percent_growth = 0 and growth= 128 AND type !=2'' 
	EXEC sp_executesql N''INSERT INTO #myfileoptions SELECT CONVERT(varchar(255),@@SERVERNAME), CONVERT(varchar(255),DB_NAME()), ''''No Growth'''',COUNT(*) FROM sys.database_files WHERE growth =0 AND type !=2'' 

'
IF EXISTS (SELECT * FROM #myfileoptions WHERE mycomment='Max Size' and mycount !=0)
	INSERT INTO #myoutput SELECT @servername, 'Database file options', mydatabase + ' has ' + CONVERT(varchar(15), mycount) + ' files with a maximum size', 'Remove the upper limitations on growth (if possible - available capacity may prevent this change)' FROM #myfileoptions WHERE mycomment='Max Size' and mycount !=0
IF EXISTS (SELECT * FROM #myfileoptions WHERE mycomment='Pct Growth' and mycount !=0)
	INSERT INTO #myoutput SELECT @servername, 'Database file options', mydatabase + ' has ' + CONVERT(varchar(15), mycount) + ' files with percentage file growth', 'Alter growth to by MB and set to 100MB (10MB if file is less than 500MB)' FROM #myfileoptions WHERE mycomment='Pct Growth' and mycount !=0
IF EXISTS (SELECT * FROM #myfileoptions WHERE mycomment='1MB Growth' and mycount !=0)
	INSERT INTO #myoutput SELECT @servername, 'Database file options', mydatabase + ' has ' + CONVERT(varchar(15), mycount) + ' files with 1MB file growth', 'Increase growth increment from 1MB to 100MB (50MB if file is less than 500MB)' FROM #myfileoptions WHERE mycomment='1MB Growth' and mycount !=0
IF EXISTS (SELECT * FROM #myfileoptions WHERE mycomment='No Growth' and mycount !=0)
	INSERT INTO #myoutput SELECT @servername, 'Database file options', mydatabase + ' has ' + CONVERT(varchar(15), mycount) + ' files with no growth allowed', 'Enable autogrowth and set growth to 100MB (50MB if file is less than 500MB) - available capacity may not allow this' FROM #myfileoptions WHERE mycomment='No Growth' and mycount !=0
DROP TABLE #myfileoptions

--
-- Step 3.08	Database settings - Auto create
--

SELECT @row_count = COUNT(*) FROM master.sys.databases WHERE is_auto_create_stats_on = 0
IF @row_count > 0
BEGIN
	SELECT @message= 'DATABASE AUTO CREATE NOT TO BEST PRACTICE: ' + CONVERT(varchar(15), @row_count)
--	SELECT name FROM master.sys.databases WHERE is_auto_create_stats_on = 0
	INSERT INTO #myoutput VALUES (@servername, 'Database options', @message, 'Enable Auto Stats Creation through the GUI or script - ALTER DATABASE [dbname] SET AUTO_CREATE_STATISTICS ON')
END
ELSE
	PRINT 'Database Auto Create Correct'

--
-- Step 3.09	Database settings - Auto update
--

SELECT @row_count = COUNT(*) FROM master.sys.databases WHERE is_auto_update_stats_on = 0
IF @row_count > 0
BEGIN
	SELECT @message= 'DATABASE AUTO UPDATE NOT TO BEST PRACTICE: ' + CONVERT(varchar(15), @row_count)
--	SELECT name FROM master.sys.databases WHERE is_auto_update_stats_on = 0
	INSERT INTO #myoutput VALUES (@servername, 'Database options', @message, 'Enable Auto Stats Update through the GUI or script - ALTER DATABASE [dbname] SET AUTO_UPDATE_STATISTICS ON')
--	SELECT name, is_auto_close_on from master.sys.databases where is_auto_close_on = 1
END
ELSE
	PRINT 'Database Auto Update Correct'
--
-- Step 4.01	Maintenance jobs - looks for "ACXJOBS"
--

SELECT @row_count = COUNT(*) FROM msdb..sysjobsteps WHERE (step_name like 'ACXJOB%Backup%' OR step_name like 'DBAJOB%Backup%')
IF @row_count > 0
	PRINT 'Standard Backup Jobs - Appear to be in place'
ELSE
BEGIN
	SELECT @message= 'STANDARD BACKUP JOBS - DO NOT appear to be in place'
	INSERT INTO #myoutput VALUES (@servername, 'Maintenance', @message, 'Create Backup Job(s) using the standard package on the SharePoint site')
END
SELECT @row_count = COUNT(*) FROM msdb..sysjobsteps WHERE (step_name like 'ACXJOB%Defrag%' OR step_name like 'DBAJOB%Defrag%')
IF @row_count > 0
	PRINT 'Standard Defrag Jobs - Appear to be in place'
ELSE
BEGIN
	SELECT @message= 'STANDARD DEFRAG JOBS - DO NOT appear to be in place'
	INSERT INTO #myoutput VALUES (@servername, 'Maintenance', @message, 'Create Defrag Job(s) using the standard package on the SharePoint site')
END
SELECT @row_count = COUNT(*) FROM msdb..sysjobsteps WHERE (step_name like 'ACXJOB%CHECKDB%' OR step_name like 'DBAJOB%CHECKDB%')
IF @row_count > 0
	PRINT 'Standard DBCC Jobs - Appear to be in place'
ELSE
BEGIN
	SELECT @message= 'STANDARD DBCC JOBS - DO NOT appear to be in place'
	INSERT INTO #myoutput VALUES (@servername, 'Maintenance', @message, 'Create DBCC Job(s) using the standard package on the SharePoint site')
END

SELECT @row_count = COUNT(*) FROM msdb..sysjobsteps WHERE (step_name like 'ACXJOB%Purge%' OR step_name like 'DBAJOB%Purge%')
IF @row_count > 0
	PRINT 'MSDB purge job - Appear to be in place'
ELSE
BEGIN
	SELECT @message= 'MSDB purge job - DO NOT appear to be in place'
	INSERT INTO #myoutput VALUES (@servername, 'Maintenance', @message, 'Create Purge Job using the standard package on the SharePoint site')
END
--
-- Step 5.01	Monitoring - looks for patrol like login
--

SELECT @row_count = COUNT(*) FROM master..syslogins WHERE loginname like '%patrol%' and loginname != 'cwybmcpatrol'
IF @row_count = 0
BEGIN
	SELECT @message= 'MONITORING:  None (no Patrol account).'
	INSERT INTO #myoutput VALUES (@servername, 'Monitoring', @message, 'Determine which BMC Patrol account is relevant for the client and grant sysadmin rights')
END
ELSE
	PRINT 'MONITORING:  Maybe, a login like patrol exists.'

PRINT 'End of Best Practices Scan ' + @servername
INSERT INTO #myoutput VALUES (@servername, 'master', @message, 'End of Best Practices Scan')

--
-- Step 6.01	Errorlog
--
/*
DECLARE @todate nvarchar(8)
	, @fromdate nvarchar(8)

select @todate=CONVERT(nvarchar(8),DATEADD(dd,1,getdate()), 112)
select @fromdate=CONVERT(nvarchar(8),DATEADD(dd,-2,getdate()), 112)

CREATE TABLE #myerrorlog (
	LogDate	datetime
	, ProcessInfo nvarchar(200)
	, MyText nvarchar(max)
	);

INSERT INTO #myerrorlog EXEC master..xp_readerrorlog 0, 1, N'Error:', NULL, @fromdate, @todate
INSERT INTO #myerrorlog EXEC master..xp_readerrorlog 0, 1, N'of I/O requests taking longer than 15 seconds to complete', NULL, @fromdate, @todate
INSERT INTO #myerrorlog EXEC master..xp_readerrorlog 0, 1, N'BEGIN STACK DUMP:', NULL, @fromdate, @todate
INSERT INTO #myerrorlog EXEC master..xp_readerrorlog 0, 1, N'Full-Text filter daemon process failed to start', NULL, @fromdate, @todate
INSERT INTO #myerrorlog EXEC master..xp_readerrorlog 0, 1, N'encryption changes on a database must be serialized', NULL, @fromdate, @todate
INSERT INTO #myerrorlog EXEC master..xp_readerrorlog 0, 1, N'Microsoft Distributed Transaction Coordinator (MS DTC) has stopped this transaction.', NULL, @fromdate, @todate
INSERT INTO #myerrorlog EXEC master..xp_readerrorlog 0, 1, N'Operating system error 32(', NULL, @fromdate, @todate
INSERT INTO #myerrorlog EXEC master..xp_readerrorlog 0, 1, N'995(The I/O operation', NULL, @fromdate, @todate
INSERT INTO #myerrorlog EXEC master..xp_readerrorlog 0, 1, N'occurrence(s) of cachestore flush for the', NULL, @fromdate, @todate

INSERT INTO #myoutput 
SELECT @servername, 'Errorlog', MyText, 'Generic errors - review for any specific, recent issues' from #myerrorlog
WHERE 
MyText not like '%Error: 3041,%'		-- Backup failed
AND MyText not like '%Error: 4014,%'	-- A fatal error occurred while reading the input stream from the network
AND MyText not like '%Error: 17187,%'    -- SQL Server is not ready to accept new client connections
AND MyText not like '%Error: 17806,%'	-- SSPI handshake failed
AND MyText not like '%Error: 17836,%'	-- Length of network packet did not match number of bytes read
AND MyText not like '%Error: 18056,%'   -- which had been reset for connection pooling - Application connectivity Error
AND MyText not like '%Error: 18210,%'	-- Backup error
AND MyText not like '%Error: 18452,%'	-- Login failed
AND MyText not like '%Error: 18456,%'	-- Login failed


AND MyText not like 'BackupMedium::ReportIoError: write failure on backup device%'	--Duplicate
AND MyText not like 'BackupVirtualDeviceFile%'	--Duplicate
AND MyText not like 'BackupIORequest%'	--Duplicate

DROP TABLE #myerrorlog


*/
ExitWError:
  PRINT '****' +@status+ ':' +@message+ '****'

Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear
select @Date_Key AS Date_Key,* from #myoutput
drop table #myoutput

SELECT @CURRENT_CMDSHELL_STATE=value_in_use FROM master.sys.configurations WHERE name='xp_cmdshell'
IF @ORIGINAL_CMDSHELL_STATE <> @CURRENT_CMDSHELL_STATE
BEGIN
    PRINT 'Reverting xp_cmdshell state'
	EXEC sp_configure 'xp_cmdshell', 0
    reconfigure with override
END 
--ELSE PRINT 'Changing xp_cmdshell already original value - no change necessary'

SELECT @CURRENT_OLEAUTO_STATE=value_in_use FROM master.sys.configurations WHERE name='OLE Automation Procedures'
IF @ORIGINAL_OLEAUTO_STATE <> @CURRENT_OLEAUTO_STATE
BEGIN
    PRINT 'Reverting OLE Automation Procedures state'
	EXEC sp_configure 'OLE Automation Procedures', 0
    reconfigure with override
END 
--ELSE PRINT 'Changing OLE Automation Procedures already original value - no change necessary'

SELECT @CURRENT_ADVOPTIONS_STATE=value_in_use FROM master.sys.configurations WHERE name='show advanced options'
IF @ORIGINAL_ADVOPTIONS_STATE <> @CURRENT_ADVOPTIONS_STATE
BEGIN
    PRINT 'Reverting show advanced options state'
	EXEC sp_configure 'show advanced options', 0
    reconfigure with override
END 
--ELSE PRINT 'Changing show advanced options already original value - no change necessary'


