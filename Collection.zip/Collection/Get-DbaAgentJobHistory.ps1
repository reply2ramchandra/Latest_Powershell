﻿<#Import-Module dbatools -EA SilentlyContinue
Get-DbaAgentJobHistory -SqlInstance TPAPWSQLGNRA01 -Job 'DatabaseBackup - USER_DATABASES - LOG' -StartDate '2024-07-03 07:30:00' -EndDate '2024-07-03 07:50:00'
Get-DbaAgentJobHistory -SqlInstance TPAPWDWSQL004 -ExcludeJob SecurityAudit -OutcomeType Failed  -StartDate '2024-02-29' -EndDate '2024-02-29'
Get-DbaAgentJobHistory -SqlInstance TPAPWSQLDL001 -OutcomeType Failed -StartDate '2024-02-29' -EndDate '2024-03-01'
Get-DbaAgentJobHistory -SqlInstance TPAPWDWSQL004 -Job 'PHASE2_ETL_SLA_AUTOMATED_PROCESS_FULL' -OutcomeType Failed 
#>
clear-host
Import-Module dbatools -EA SilentlyContinue
$instances=get-content "T:\Test\100924.txt"
foreach($instance in $instances)
{
Get-DbaAgentJob -SqlInstance $instance | Where-Object Name -Match DatabaseBackup | Get-DbaAgentJobHistory -OutcomeType Failed -StartDate '2024-12-23' -EndDate '2025-01-06 12:30:00'}
$instance=get-content "T:\Test\nonprod.txt"
foreach($instan in $instance)
{
Get-DbaAgentJob -SqlInstance $instan | Where-Object Name -Match DatabaseBackup | Get-DbaAgentJobHistory -OutcomeType Failed -StartDate '2024-12-23' -EndDate '2025-01-06 12:30:00'}