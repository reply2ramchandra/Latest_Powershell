﻿Import-Module dbatools -ErrorAction SilentlyContinue
Export-DbaExecutionPlan -SqlInstance TPAPWSQLHHA01 -Database Harrington_Gateway, Harrington_Gateway_WIP -SinceLastExecution '2025-02-10 00:47:00' -Path X:\scripts\HH
