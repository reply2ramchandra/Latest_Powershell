﻿Update-Module -Name dbatools -SkipPublisherCheck
Get-Module -Name dbatools -ListAvailable | Select-Object -Skip 1 | ForEach-Object -Process { 
        Uninstall-Module -Name $_.Name -RequiredVersion $_.Version 
    }

Uninstall-Module -Name dbatools -AllVersions
Install-Module -Name dbatools -Force

Install-Module PowerShellGet -Force -AllowClobber
Install-Module PackageManagement -Force -AllowClobber

Update-Module PowerShellGet
Update-Module PackageManagement

