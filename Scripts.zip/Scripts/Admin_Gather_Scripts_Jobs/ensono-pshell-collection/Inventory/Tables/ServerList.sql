CREATE TABLE [Inventory].[ServerList] (
    [SqlInstance]      VARCHAR (256)  NOT NULL,
    [Environment]      CHAR (1)       CONSTRAINT DF_ServerList_Environment DEFAULT ('D') NULL,
    [IsActive]         BIT            CONSTRAINT DF_ServerList_IsActive DEFAULT ((1)) NULL,
    [HasAccess]        CHAR (1)       CONSTRAINT DF_ServerList_HasAccess DEFAULT ('Y') NULL,
    [SupportGroup]     VARCHAR (64)   CONSTRAINT DF_ServerList_SupportGroup DEFAULT ('DBA-USA') NULL,
    [Domain]           VARCHAR (128)  NULL,
    [ConnectionMethod] VARCHAR (32)   NULL CONSTRAINT DF_ServerList_ConnMethod DEFAULT ('default'),
    [Description]      VARCHAR (1024) NULL,
    [Port]             INT            CONSTRAINT DF_ServerList_Port DEFAULT(1433) NULL,
    [ConnectionString] AS LEFT(SqlInstance,ISNULL(NULLIF(CHARINDEX('\',SqlInstance),0 ) -1 ,LEN(SqlInstance))) + CASE WHEN Domain LIKE '%AWS%' OR Domain LIKE '%Azure%' THEN SPACE(0) ELSE '.' + Domain END 
    + RIGHT(SqlInstance,CHARINDEX('\',REVERSE(SqlInstance))) +  COALESCE(',' + CAST(NULLIF([Port],1433) AS VARCHAR(16)),''),
    [MachineName] VARCHAR(256) NULL, 
    [IPAddress] VARCHAR(24) NULL, 
    [TimeZoneOffset] DATETIMEOFFSET(1) NULL, 
    PRIMARY KEY CLUSTERED ([SqlInstance] ASC),
    CONSTRAINT [check_environment] CHECK ([Environment]='U' OR [Environment]='T' OR [Environment]='S' OR [Environment]='R' OR [Environment]='Q' OR [Environment]='P' OR [Environment]='D' OR [Environment]='O'),
    CONSTRAINT [check_support_group] CHECK ([SupportGroup]='DBA-GLOBAL' OR [SupportGroup]='DBA-UK' OR [SupportGroup]='DBA-USA')
    --CONSTRAINT [check_connection_method] CHECK ([ConnectionMethod] IS NOT NULL AND (IsActive = 1 AND [SupportGroup] IN ('DBA-USA','DBA-UK','DBA-GLOBAL')))

);


GO

