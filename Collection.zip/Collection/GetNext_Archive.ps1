﻿clear
Import-Module dbatools -ErrorAction SilentlyContinue

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblPackages]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblPackages]'
 Query = " SELECT P. [PackageGUID]
      ,P.[WorkflowDefGUID]
      ,P.[PackageDefGUID]
      ,P.[PackageNumber]
      ,P.[CurrentQueueDefGUID]
      ,P.[PreviousQueueDefGUID]
      ,P.[Status]
      ,P.[AssignedTo]
      ,P.[ReceivedDate]
      ,P.[CreatedUserID]
      ,P.[CreatedTimestamp]
      ,P.[FinishedUserID]
      ,P.[FinishedTimestamp]
      ,P.[LastModifiedUserID]
      ,P.[LastModifiedTimestamp]
      ,P.[LockedBy]
      ,P.[InboxOpenedStatus]
      ,P.[PriorityWeight]
      ,P.[MostRecentFinishedTimestamp]
      ,P.[MostRecentFinishedUser]
	  FROM [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblPackages] P INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblFieldData] FD0
ON FD0.PackageGUID = P.PackageGUID INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDEFtblFields] FDF0 
ON FDF0.FieldDefGUID=FD0.FieldDefGUID AND FDF0.CustomID='Source'
AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
)"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblActivityStatistics]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblActivityStatistics]'
 Query = " SELECT 
       [ID]
      ,[UserID]
      ,[Activity]
      ,[StartTimestamp]
      ,[EndTimestamp]
      ,[ResponseTimeMS]
      ,[HostName]
      ,[DBLoginID]
      ,[ApplicationName]
      ,[PackageGUID]

 FROM [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblActivityStatistics] 
where PackageGUID in(select P.PackageGUID from [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblPackages] P INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblFieldData] FD0 
ON FD0.PackageGUID = P.PackageGUID INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDEFtblFields] FDF0  ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblAttachments]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblAttachments]'
 Query = "SELECT [AttachmentGUID], [PackageGUID], [FieldDefGUID], [FileName], [LastModifiedUserID], [LastModifiedTimestamp], [FileData]
FROM [PRODWMSSPGN2-01\IHGN2P01].[GetNext].[dbo].[FLOWDATAtblAttachments] WITH (NOLOCK) where PackageGUID in
(select P.PackageGUID from FLOWDATAtblPackages P INNER JOIN FLOWDATAtblFieldData FD0 WITH WITH (NOLOCK)
ON FD0.PackageGUID = P.PackageGUID INNER JOIN FLOWDEFtblFields FDF0 WITH WITH (NOLOCK) ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source'AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblEventLog]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblEventLog]'
 Query = "SELECT [EventLogGUID]
      ,[EventLogID]
      ,[PackageGUID]
      ,[EventTimestamp]
      ,[EventType]
      ,[UserID]
      ,[ComponentGUID]
      ,[OldValue]
      ,[NewValue]
      ,[IsEncrypted]

FROM [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblEventLog] where PackageGUID in
(select P.PackageGUID from [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblPackages] P INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblFieldData] FD0 
ON FD0.PackageGUID = P.PackageGUID INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDEFtblFields] FDF0  ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblPackageLinks]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblPackageLinks]'
 Query = "SELECT [PackageLinkGUID], [ParentPackageGUID], [ChildPackageGUID], [UserID], [Timestamp], [ParentPackageLocked], [ChildPackageLocked]
FROM [PRODWMSSPGN2-01\IHGN2P01].[GetNext].[dbo].[FLOWDATAtblPackageLinks] WITH (NOLOCK) where ParentPackageGUID in
(select P.PackageGUID from FLOWDATAtblPackages P INNER JOIN FLOWDATAtblFieldData FD0 WITH WITH (NOLOCK)
ON FD0.PackageGUID = P.PackageGUID INNER JOIN FLOWDEFtblFields FDF0 WITH WITH (NOLOCK) ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblFieldData]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblFieldData]'
 Query = "SELECT * FROM [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblFieldData] where PackageGUID 
in(select P.PackageGUID from [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblPackages] P INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblFieldData] FD0 
ON FD0.PackageGUID = P.PackageGUID INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDEFtblFields] FDF0  ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params


#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblPackageNotes]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblPackageNotes]'
 Query = "SELECT [PackageNoteGUID]
      ,[PackageGUID]
      ,[NoteTimestamp]
      ,[UserID]
      ,[Note]
      ,[NoteType]
      ,[Sequence]
	   FROM [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblPackageNotes] where PackageGUID in
(select P.PackageGUID from [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblPackages] P INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblFieldData] FD0 
ON FD0.PackageGUID = P.PackageGUID INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDEFtblFields] FDF0  ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblRoutingLog]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblRoutingLog]'
 Query = "SELECT * FROM [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblRoutingLog] where PackageGUID in
(select P.PackageGUID from [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblPackages] P INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblFieldData] FD0 
ON FD0.PackageGUID = P.PackageGUID INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDEFtblFields] FDF0  ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblSubPackages]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblSubPackages]'
 Query = "SELECT [SubPackageGUID], [ParentPackageGUID], [ParentFieldDefGUID], [ChildPackageGUID]
FROM [PRODWMSSPGN2-01\IHGN2P01].[GetNext].[dbo].[FLOWDATAtblSubPackages] WITH (NOLOCK) where ParentPackageGUID in
(select P.PackageGUID from FLOWDATAtblPackages P INNER JOIN FLOWDATAtblFieldData FD0 WITH WITH (NOLOCK)
ON FD0.PackageGUID = P.PackageGUID INNER JOIN FLOWDEFtblFields FDF0 WITH WITH (NOLOCK) ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblTriggers]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblTriggers]'
 Query = "SELECT [TriggerGUID], [PackageGUID], [ItemGUID], [TriggerName], [CreatedTimestamp], [CreatedUserID], [CreatedDBLoginID], [Processed], [ProcessedTimestamp], [ProcessedUserID], [ProcessedDBLoginID], [Notes], [OutputGUID], [IsActionTrigger], [ApplicationName], [LockedBy], [ProcessedNotes], [Carrier], [Resolution]
FROM [PRODWMSSPGN2-01\IHGN2P01].[GetNext].[dbo].[FLOWDATAtblTriggers] WITH (NOLOCK) where PackageGUID in
(select P.PackageGUID from FLOWDATAtblPackages P INNER JOIN FLOWDATAtblFieldData FD0 WITH WITH (NOLOCK)
ON FD0.PackageGUID = P.PackageGUID INNER JOIN FLOWDEFtblFields FDF0 WITH WITH (NOLOCK) ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params



#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblUserTATLog]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblUserTATLog]'
 Query = " SELECT * FROM [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblUserTATLog]  where PackageGUID in
(select P.PackageGUID from [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblPackages] P INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDATAtblFieldData] FD0 
ON FD0.PackageGUID = P.PackageGUID INNER JOIN [PRODWMSSPGN2-01\IHGN2P01].[GETNEXT].[DBO].[FLOWDEFtblFields] FDF0 ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params
