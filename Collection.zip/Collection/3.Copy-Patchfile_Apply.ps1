﻿ ##THIS file is subject to change as required over time ###
  ### DON'T CHANGE/MODIFY this Script without Sathiya's  Notice please ####
 #############################
#Read-HostSpecial Function
#############################

Function Read-HostSpecial {
      [cmdletbinding(DefaultParameterSetName="_All")]
      Param(
            [Parameter(Position = 0,Mandatory,HelpMessage = "Enter prompt text.")]
            [Alias("message")]
            [ValidateNotNullorEmpty()]
            [string]$Prompt,
            [Alias("foregroundcolor","fg")]
            [consolecolor]$PromptColor,
            [string]$Title,
            [Parameter(ParameterSetName = "SecureString")]
            [switch]$AsSecureString,
            [Parameter(ParameterSetName = "Set")]
            [ValidateNotNullorEmpty()]
            [string[]]$ValidateSet
      )

Write-Verbose "Starting: $($MyInvocation.Mycommand)"
Write-Verbose "Parameter set = $($PSCmdlet.ParameterSetName)"
Write-Verbose "Bound parameters $($PSBoundParameters | Out-String)"

#combine the Title (if specified) and prompt
$Text = @"
$(if ($Title) {
"$Title`n$("-" * $Title.Length)"
})
$Prompt
"@

 If ($title.length -eq "0"){
      $Object = $Prompt
}
Else {
      $Object = $Text
}


#create a hashtable of parameters to splat to Write-Host
$paramHash = @{
      NoNewLine = $True
      Object = $Object
}

If ($PromptColor) {
    $paramHash.Add("Foregroundcolor",$PromptColor)
}

#display the prompt
Write-Host @paramhash
#get the value
If ($AsSecureString) {
    $r = $host.ui.ReadLineAsSecureString()
}
Else {
  #read console input
  $r = $host.ui.ReadLine()
}

#assume the input is valid unless proved otherwise
$Valid = $True

If ($Valid) {
    Write-Verbose "Writing result to the pipeline"
    #any necessary validation passed
    $r
}
Write-Verbose "Ending: $($MyInvocation.Mycommand)"
} #end function
Import-Module dbatools -EA SilentlyContinue
clear-host
$strtime=Get-Date
Write-Host "Start time : $strtime" -ForegroundColor Yellow
write-host "Welcome you to Copy the Patch file to the target Server.Ensure you attempt at correct HOST." -backgroundColor Cyan
$srv=Read-HostSpecial "Enter Correct Host Name:" -PromptColor Green
$server=$srv
 
 #create a Folder
 
 Invoke-Command -ComputerName $server -ScriptBlock {
 write-host "Lets create a Folder to copy the CU\Patch files." -ForegroundColor cyan
$targetpatchfolder="C:\Patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}

#Copy the ISO file and Patch File
$usr=Read-HostSpecial "What is your hps a- account, pls enter:" -PromptColor Green
$ver=Read-HostSpecial "Select the Version to copy its respective latest CU\Patch: Enter 2022 or 2019 or 2017:" -PromptColor Green
if($ver -eq "2022" )
{
$cufile= Get-ChildItem X:\SQLISO\CU -Filter '*cu13.exe' 
$cufile=$cufile.FullName 
$target="C:\Patch"
$cred=Get-Credential $usr
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $cufile -Destination $target -ToSession $s -Force -ErrorAction SilentlyContinue
Write-Host "Patch file copy completed." -ForegroundColor Cyan
}
elseif($ver -eq "2019")
{

$cufile= Get-ChildItem X:\SQLISO\CU -Filter '*cu27.exe' 
$cufile=$cufile.FullName 
$target="C:\Patch"
$cred=Get-Credential $usr
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $cufile -Destination $target -ToSession $s -Force -ErrorAction SilentlyContinue
Write-Host "Patch file copy completed." -ForegroundColor Cyan
}
elseif($ver -eq "2017")
{
$cufile= Get-ChildItem X:\SQLISO\CU -Filter '*cu31.exe' 
$cufile=$cufile.FullName 
$target="C:\Patch"
$cred=Get-Credential $usr
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $cufile -Destination $target -ToSession $s -Force -ErrorAction SilentlyContinue
Write-Host "Patch file copy completed" -ForegroundColor Cyan
}
else{Write-Host "Sorry, Enter the correct option." -ForegroundColor Yellow}
Start-Sleep -Seconds 2
#verify the content copied and it's size
Write-Host "Lets Review the file copied." -ForegroundColor Yellow
 Invoke-Command -ComputerName $Server -ScriptBlock { 
 $path='C:\Patch'
 Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}}  
 }
$endtime=Get-Date
Write-Host "End time : $endtime" -ForegroundColor Yellow
Start-Sleep -Seconds 5
$con=Read-HostSpecial "Would like to proceed with SQL Patch. Press Y or N to continue:" -PromptColor Green
If($con -eq "Y" -or $con -eq "y")
{ 
if($ver -eq "2022") {
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5036432 -Restart -Path C:\patch -Confirm:$false}
elseif($ver -eq "2019"){
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5037331 -Restart -Path C:\patch -Confirm:$false}
elseif($ver -eq "2017"){
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5029376 -Restart -Path C:\patch -Confirm:$false}
else { Write-Host "Sorry, Check the SQL patch version # and try other option." -ForegroundColor Yellow } }
Else { Write-Host "Terminating without Patching!." -ForegroundColor Yellow
break }

      