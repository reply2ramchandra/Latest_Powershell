﻿[CmdletBinding()]
param (
    [string]$CollectionSql = 'tpapwmssql002',
    [string]$CollectionDb  = 'CMS',
    [string]$OutputRoot    = '\\tpapwmssql002\Reports\All',
    [string]$ReportPrefix  = 'AllDb',
    [string]$SmtpServer    = 'smtprelay.healthplan.com',
    [string]$MailFrom      = 'DBA_Report@Healthplan.com',
    [string[]]$MailTo      = @('WHPS-MSSQL-Admins@wipro.com'),
    [switch]$SkipColoring
)

$ErrorActionPreference = 'Stop'

# Optional transcript (ensure Agent account can write)
$logDir = Join-Path $OutputRoot 'Logs'
try {
    if (-not (Test-Path $logDir)) { New-Item -Path $logDir -ItemType Directory -Force | Out-Null }
    $transcriptPath = Join-Path $logDir ("AllDbServiceReport_{0:yyyyMMdd_HHmmss}.log" -f (Get-Date))
    Start-Transcript -Path $transcriptPath -ErrorAction SilentlyContinue | Out-Null
} catch { }

# Ensure output directory exists
if (-not (Test-Path $OutputRoot)) {
    New-Item -Path $OutputRoot -ItemType Directory -Force | Out-Null
}

$runDateTime = Get-Date -Format 'yyyyMMdd'
$serviceFlag = $false
$serverFlag  = $false

Write-Output "Starting ALL DB service collection at $(Get-Date -Format o)"

# Module loading (SQL Agent may not load user scope modules)
#Install-Module dbatools -Scope AllUsers -Force
Import-Module dbatools -ErrorAction Stop
Import-Module SQLServer -ErrorAction Stop
<#
$modulesToLoad = @('dbatools','SQLServer')
foreach ($m in $modulesToLoad) {
    try {
        if (-not (Get-Module -ListAvailable -Name $m)) {
            Write-Warning "Module $m not found in system scope. Install it for the SQL Agent service account if functionality is required."
        } else {
            Import-Module $m -ErrorAction Stop -Force
            Write-Output "Imported module: $m"
        }
    } catch {
        Write-Warning "Failed to import $m : $_"
    }
}
#>
if (Get-Command Set-DbatoolsInsecureConnection -ErrorAction SilentlyContinue) {
    Set-DbatoolsInsecureConnection -SessionOnly | Out-Null
}

# Prep target tables (wrap in TRY/CATCH to avoid hard failure)
$prepCommands = @"
BEGIN TRY
    IF OBJECT_ID('[dbo].[AllSrvDbaService]','U') IS NOT NULL
        DROP TABLE [dbo].[AllSrvDbaService];
    DELETE FROM [dbo].[AllDBSrvStatus];
END TRY
BEGIN CATCH
    DECLARE @m nvarchar(4000)=ERROR_MESSAGE();
    RAISERROR('Table prep failed: %s',16,1,@m);
END CATCH
"@
Invoke-Sqlcmd -ServerInstance $CollectionSql -Database $CollectionDb -Query $prepCommands -TrustServerCertificate

# Inventory query
$serverQuery = @"
SELECT DISTINCT TRIM([HostName]) AS HostName
FROM [CMS].[dbo].[DBServer]
WHERE [Status] IN ('Y','R')
  AND HostName NOT IN ('localhost','TPAPWSQLSSRS-03','TPATWSQLSSRS02');
"@
$serversDt = Invoke-Sqlcmd -ServerInstance $CollectionSql -Database $CollectionDb -Query $serverQuery -TrustServerCertificate
$servers = @()
if ($serversDt) { $servers = $serversDt | ForEach-Object { $_.HostName } }

if (-not $servers -or $servers.Count -eq 0) {
    Write-Warning "No servers returned from inventory. Exiting."
    Stop-Transcript | Out-Null 2>$null
    return
}

$totalServers = $servers.Count
Write-Output "Discovered $totalServers target servers."

# Collect services
$serviceRows = @()
foreach ($sqlServer in $servers) {
    Write-Output "Collecting services from $sqlServer"
    try {
        $svc = Get-DbaService -ComputerName $sqlServer -ErrorAction Stop |
            Where-Object { $_.ServiceType -in 'Engine','Agent' } |
            Select-Object @{n='DateKey';e={ Get-Date }}, PSComputerName, ComputerName,
                          DisplayName, ServiceType, ServiceName, StartMode, State, StartName
        if ($svc) {
            Write-DbaDataTable -SqlInstance $CollectionSql -Database $CollectionDb -Schema dbo -Table AllSrvDbaService `
                -InputObject $svc -AutoCreateTable -KeepNulls -ErrorAction Stop
        } else {
        $comment = "No Engine/Agent services returned"
$insertQuery = "INSERT INTO [dbo].[AllDBSrvStatus] (HostName, Comments) VALUES (N'$sqlServer', N'$comment');"
Invoke-Sqlcmd -ServerInstance $CollectionSql -Database $CollectionDb -Query $insertQuery -TrustServerCertificate

        }
    }
    catch {
        Write-Warning "Failed to query $sqlServer : $_"
        $comment = "Unreachable"
$insertQuery = "INSERT INTO [dbo].[AllDBSrvStatus] (HostName, Comments) VALUES (N'$sqlServer', N'$comment');"
Invoke-Sqlcmd -ServerInstance $CollectionSql -Database $CollectionDb -Query $insertQuery -TrustServerCertificate

          }
}

# Retrieve collected data
$allServices = Invoke-Sqlcmd -ServerInstance $CollectionSql -Database $CollectionDb -Query "
    SELECT CAST([DateKey] AS datetime) AS DateKey,[ComputerName],[DisplayName],[ServiceType],[ServiceName],[StartMode],[State]
    FROM [dbo].[AllSrvDbaService];" -TrustServerCertificate

$downServices = Invoke-Sqlcmd -ServerInstance $CollectionSql -Database $CollectionDb -Query "
    SELECT CAST([DateKey] AS datetime) AS DateKey,[ComputerName],[DisplayName],[ServiceType],[ServiceName],[StartMode],[State]
    FROM [dbo].[AllSrvDbaService]
    WHERE [State] <> 'Running';" -TrustServerCertificate

$unreachable = Invoke-Sqlcmd -ServerInstance $CollectionSql -Database $CollectionDb -Query "
    SELECT [HostName],[Comments] FROM [dbo].[AllDBSrvStatus];" -TrustServerCertificate

$totalChecked = ($allServices | Where-Object { $_.ServiceType -eq 'Engine' }).Count
$totalserver=+1
# Paths
$serviceReportPath     = Join-Path $OutputRoot ("{0}servicestat{1}.html"     -f $ReportPrefix,$runDateTime)
$serviceReportColored  = Join-Path $OutputRoot ("{0}servicestatN{1}.html"    -f $ReportPrefix,$runDateTime)
$downServiceReportPath = Join-Path $OutputRoot ("{0}serviceDown{1}.html"     -f $ReportPrefix,$runDateTime)
$unreachableReportPath = Join-Path $OutputRoot ("{0}SrvUnreachable{1}.html"  -f $ReportPrefix,$runDateTime)

# CSS & HTML fragments
$css = @"
<style>
table { border-collapse: collapse; width:100%; font-family:Verdana,Arial; font-size:11px; }
th, td { border:1px solid #444; padding:4px 6px; text-align:left; }
th { background-color:#D6EEEE; }
tr:nth-child(even) { background-color: rgba(150,212,212,0.35); }
</style>
"@

$preContentAll = @"
<h3><font face=verdana color=blue>ALL Server DB Service Report</font></h3>
<p>This report lists DB Engine and Agent service status across ALL servers.</p>
"@

$preContentDown = @"
<h3><font face=verdana color=blue>ALL Server DB Service Down Report</font></h3>
<p>This report shows servers where required DB services are not Running or are unreachable.</p>
"@

$postContent = "<p><font face=verdana color=green>Generated on $(Get-Date).</font></p>"

# Build main services report
$servicesHtml = $allServices |
    Sort-Object ComputerName, ServiceType |
    ConvertTo-Html -Property DateKey,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State `
        -Head $css -Title "ALL Server DB Service Report" -PreContent $preContentAll -PostContent $postContent

$servicesHtml | Out-File -FilePath $serviceReportPath -Encoding UTF8

# Coloring & down service report
if ($downServices.Count -gt 0) {
    $serviceFlag = $true
    if (-not $SkipColoring) {
        try {
            $cellColorScript = 'D:\PSScripts\DailyDBAReporting\Set-CellColor.ps1'
            if (Test-Path $cellColorScript) {
                . $cellColorScript
                (Get-Content -Path $serviceReportPath -Raw) |
                Set-CellColor -ColumnName State -Color Yellow -Filter "State -notlike '*Running*'" |
                   #Set-CellColor -Header State -Color Yellow -Filter "State -notlike '*Running*'" |
                    Out-File -FilePath $serviceReportColored -Encoding UTF8
            } else {
                Write-Warning "Coloring script not found ($cellColorScript). Using uncolored report."
                Copy-Item $serviceReportPath $serviceReportColored -Force
            }
        } catch {
            Write-Warning "Failed to apply coloring: $_"
            Copy-Item $serviceReportPath $serviceReportColored -Force
        }
    } else {
        Copy-Item $serviceReportPath $serviceReportColored -Force
    }

    $downServices |
        Sort-Object ComputerName, ServiceType |
        ConvertTo-Html -Property DateKey,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State `
            -Head $css -Title "ALL Server DB Service Down Report" -PreContent $preContentDown -PostContent $postContent |
        Out-File -FilePath $downServiceReportPath -Encoding UTF8
} else {
    Copy-Item $serviceReportPath $serviceReportColored -Force
}

# Unreachable servers
if ($unreachable.Count -gt 0) {
    $serverFlag = $true
    $unreachable |
        Sort-Object HostName |
        ConvertTo-Html -Property HostName,Comments -Head $css -Title "Unreachable ALL DB Servers" `
            -PreContent "<h3><font face=verdana color=blue>Unreachable ALL DB Servers</font></h3>" `
            -PostContent $postContent |
        Out-File -FilePath $unreachableReportPath -Encoding UTF8
}

# Summary AFTER coloring
$summaryTable = @"
<table>
<tr>
  <th>Total_Servers_To_Check</th><td bgcolor='#F0FF33'>$totalServers</td>
  <th>Total_Engine_Services_Collected</th><td bgcolor='#F0FF33'>$totalChecked</td>
</tr>
</table>
"@
Add-Content -Path $serviceReportColored -Value $summaryTable

# Email assembly
$attachments = New-Object System.Collections.Generic.List[string]
$attachments.Add($serviceReportColored) | Out-Null

if ($serviceFlag -or $serverFlag) {
    $mailSubject = 'Alert: ALL Server DB Service / Connectivity Issues'
    $sections = @()
    if ($serverFlag) { $sections += (Get-Content -Path $unreachableReportPath -Raw) ; $attachments.Add($unreachableReportPath) | Out-Null }
    if ($serviceFlag) { $sections += (Get-Content -Path $downServiceReportPath -Raw) ; $attachments.Add($downServiceReportPath) | Out-Null }
    $mailBody = ($sections -join '<hr>')
} else {
    $mailSubject = 'ALL Server DB Service Report - All Healthy'
    $mailBody = "<h4><font face=verdana color=green>All Server DB services are running normally.</font></h4>"
}

# De-duplicate attachments robustly
$attachments = $attachments | Sort-Object -Unique

try {
    Send-MailMessage -From $MailFrom -To $MailTo -Subject $mailSubject -SmtpServer $SmtpServer `
        -Body $mailBody -BodyAsHtml -Attachments $attachments -ErrorAction Stop
    Write-Output "Mail sent: $mailSubject"
} catch {
    Write-Warning "Failed to send email: $_"
}

Write-Output "Report generation complete at $(Get-Date -Format o)"

try { Stop-Transcript | Out-Null } catch { }