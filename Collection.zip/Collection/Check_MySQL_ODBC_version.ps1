﻿clear
$server='TPAPWSQLDL001'
 Invoke-Command -ComputerName $server -ScriptBlock {
$regpath="HKLM:\SOFTWARE\MySQL AB\MySQL Connector/ODBC 9.3 (64-bit)" #change the version as required
$DotNetMySQL=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$ver=$DotNetMySQL.Version
if($ver){
Write-Host "Existing MySQL ODBC Version-" $ver -ForegroundColor Green -NoNewline
write-host " " -ForegroundColor Green -NoNewline }
Else { write-host "NO MySQL ODBC UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname }
