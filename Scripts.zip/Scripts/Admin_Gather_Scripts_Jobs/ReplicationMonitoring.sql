USE [userdbname]
GO

/****** Object:  StoredProcedure [dbo].[ReplicationMonitoring]    Script Date: 2/11/2023 9:20:39 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE procedure [dbo].[ReplicationMonitoring]	
	(
		@publisher_db		sysname			= null
	,	@dist_agent_id		int				= null
	,	@include_pub		bit				= 1
	,	@include_sub		bit				= 1
	,	@include_cmds		bit				= 1
	,	@sort_order			varchar(max)	= 'publisher_db, xact_seqno desc'
	,	@format				bit				= 1
	,	@debug				int				= 0
	,	@help				bit				= 0
	)
as

/********************************************************************************************************************
          Name: Get_Distribution_Status
       Version:	2.4
		Author:	Brian Wilson
	   Created:	20121126
	  Modified: 20131205
          Desc:	Returns Distributtion Agent and Transaction Status Details by Publisher
     Reference: sp_MSdistribution_delete
				sp_MSmaximum_cleanup_seqno
				sp_MSget_repl_commands
********************************************************************************************************************/

begin

	set nocount on;
	set ansi_padding on;
	set transaction isolation level read uncommitted;

	if @help = 1
		begin 
			select [parameter] = '@publisher_db'	, [type] = 'sysname'		, [description] = 'filters result set by publisher_db'	, [options] = 'n/a',																[default] = 'null',								[example] = 'get_distribution_status @publisher_db = ''AdventureWorks'''
			union all
			select [parameter] = '@dist_agent_id'	, [type] = 'int'			, [description] = 'filters result set by agent'			, [options] = 'null	= returns oldest undistributed tran/agent | -1 = returns oldest undistributed tran for all agent(s) | 0 = returns oldest undistributed tran for all active agent(s) | n = returns specified agent', [default] = 'null', [example] = 'get_distribution_status @dist_agent_id = 1'
			union all
			select [parameter] = '@include_pub'		, [type] = 'bit'			, [description] = 'returns publisher column'			, [options] = 'n/a',																[default] = '0',								[example] = 'get_distribution_status @include_pub = 1'
			union all
			select [parameter] = '@include_sub'		, [type] = 'bit'			, [description] = 'returns subscriber column'			, [options] = 'n/a',																[default] = '0',								[example] = 'get_distribution_status @include_sub = 1'
			union all
			select [parameter] = '@include_cmds'	, [type] = 'bit'			, [description] = 'returns cmd detail columns'			, [options] = 'n/a',																[default] = '0',								[example] = 'get_distribution_status @include_cmds = 1'
			union all
			select [parameter] = '@sort_order'		, [type] = 'varchar(max)'	, [description] = 'returns sorted result set'			, [options] = 'n/a',																[default] = 'publisher_db, xact_seqno desc',	[example] = 'get_distribution_status @dist_agent_id = -1, @sort_order = ''xact_article'''
			union all
			select [parameter] = '@format'			, [type] = 'bit'			, [description] = 'returns formatted cmd detail columns', [options] = '0 = unformatted | 1 = formatted',									[default] = '0',								[example] = 'get_distribution_status @format = 1'
			union all
			select [parameter] = '@debug'			, [type] = 'int'			, [description] = 'returns debug data'					, [options] = '0 = no debug | 1 = debug agent cursor | 2 = debug publisher cursor', [default] = '0',								[example] = 'get_distribution_status @debug = 1'
			
			return
		end

	--=declare variables=--
	declare @max_agent_hist_xact_seqno_1	varbinary(16)
		,	@max_agent_hist_xact_seqno_2	varbinary(16)
		,	@xact_seqno						varbinary(16)
		,	@article_id						int
		,	@sql							nvarchar(max)

	--=create temp tables=--
	create table #max_agent_hist_xact_seqno
		(
			[agent_id]						int	
		,	[xact_seqno]					varbinary(16)
		) 

	create table #transaction 
		(
			[publisher_database_id]			int				null
		,	[agent_id]						int				null
		,	[xact_seqno]					varbinary(16)	null
		,	[type]							int				null
		,	[article_id]					int				null
		)

	create table #agent_detail 
		(
			[publisher_database_id]			int				null
		,	[publisher_db]					sysname			null
		,	[subscriber_db]					sysname			null
		,	[dist_agent_id]					int				null
		,	[dist_agent]					sysname			null
		,	[dist_status]					varchar(256)	null
		,	[dist_comments]					varchar(max)	null
		,	[xact_type]						varchar(256)	null
		,	[xact_article]					sysname			null
		,	[xact_seqno]					varbinary(16)	null
		,	[xact_entry_time]				datetime		null
		,	[xact_cmd]						int				null	default 0
		,	[delivery_rate]					float			null	default 0
		,	[cmd_pending]					int				null	default 0
		,	[cmd_tbd]						int				null	default 0
		,	[cmd_blk]						int				null	default 0
		,	[current_delivery_latency]		FLOAT			NULL
		)
		
	--=open cursor (1): publisher=--
	declare	@publisher_database_id			int
		,	@min_cutoff_time				datetime
		,	@max_cleanup_xact_seqno			varbinary(16)
		
	  --set to default based on @min_distretention = 0 (sp_MSdistribution_cleanup)
		set @min_cutoff_time = (select dateadd(hour, -0, getdate()))
		
    declare publisher cursor 
    local fast_forward 
    for 
	select	distinct 
			publisher_database_id
	  from	distribution.dbo.msrepl_transactions
	 where	publisher_database_id in (	
										select	publisher_database_id
										  from	distribution.dbo.MSsubscriptions
									     where	publisher_db =	case
																  --set to publisher for specified @dist_agent_id
																	when @dist_agent_id > 0			then (	
																											select	distinct
																													publisher_db
																											  from	distribution.dbo.MSsubscriptions
																											 where	agent_id = @dist_agent_id
																										  )
																										  
																  --set to publisher for specified @publisher_db
																	when @publisher_db is not null	then @publisher_db
																	
																  --set to all publishers
																	else publisher_db
																 end
									  ) 
	   for	read only

	  open	publisher
	 fetch	publisher into @publisher_database_id
	 
	 while	(@@fetch_status <> -1)
		begin
			--truncate temp tables
			truncate table #max_agent_hist_xact_seqno
			truncate table #transaction
			
			--=open cursor (2): agent minimum subscription sequence=--
			declare	@min_agent_sub_xact_seqno	varbinary(16)
				,	@max_agent_hist_xact_seqno	varbinary(16)
				,	@active						int				= 2
				,	@initiated					int				= 3
				,	@agent_id					int
				,	@min_xact_seqno				varbinary(16)	= NULL
			                
			declare agent_min_sub_seqno cursor 
			local forward_only
			for
			select 	a.id
				,	min(s2.subscription_seqno) 
			  from	distribution.dbo.MSsubscriptions		s2 
		inner join  distribution.dbo.MSdistribution_agents	a on (a.id = s2.agent_id) 
			 where	s2.status in( @active, @initiated ) 
			   and	not exists (	
								select	* 
								  from	distribution.dbo.MSpublications p 
								 where	s2.publication_id	= p.publication_id 
								   and	p.immediate_sync	= 1
								) 
			   and	a.publisher_database_id = @publisher_database_id
		  group by	a.id
									
			  open	agent_min_sub_seqno 
		     fetch	agent_min_sub_seqno into @agent_id, @min_agent_sub_xact_seqno 
			
			--if not exists: set @min_xact_seqno to min_autonosync_lsn
			if (@@fetch_status = -1)
				begin
					if not exists (	
									select	* 
									  from	distribution.dbo.MSpublications			msp
								inner join	distribution.dbo.MSpublisher_databases	mspd on mspd.publisher_id = msp.publisher_id and mspd.publisher_db = msp.publisher_db
									 where	mspd.id = @publisher_database_id 
									   and	msp.immediate_sync = 1
									)
						begin
							select	top(1) 
									@min_xact_seqno = msp.min_autonosync_lsn 
							  from	distribution.dbo.MSpublications			msp
						inner join	distribution.dbo.MSpublisher_databases	mspd on mspd.publisher_id = msp.publisher_id and mspd.publisher_db = msp.publisher_db
							 where	mspd.id								= @publisher_database_id 
							   and	msp.allow_initialize_from_backup	<> 0
							   and	msp.min_autonosync_lsn				is not null
							   and	msp.immediate_sync					= 0
						  order by	msp.min_autonosync_lsn asc
						end
				end
		    
			--if exists: set the @min_xact_seqno to min snapshot subscription_seqno or min of max distributed xact_seqno's
			while (@@fetch_status <> -1)
				begin
					   set	@max_agent_hist_xact_seqno = NULL

					select	top 1 
							@max_agent_hist_xact_seqno = xact_seqno 
					  from	distribution.dbo.MSdistribution_history 
					 where	agent_id = @agent_id 
				  order by	timestamp desc

					if isnull(@max_agent_hist_xact_seqno, @min_agent_sub_xact_seqno) <= @min_agent_sub_xact_seqno 
						begin
							 set @max_agent_hist_xact_seqno = @min_agent_sub_xact_seqno
						end
					
					--log max distributed xact_seqno
					insert #max_agent_hist_xact_seqno 
						   (
								[agent_id], [xact_seqno]
						   )
					select @agent_id
						,  @max_agent_hist_xact_seqno

					if ((@min_xact_seqno is null) or (@min_xact_seqno > @max_agent_hist_xact_seqno))
						begin 
							set @min_xact_seqno = @max_agent_hist_xact_seqno
						end
						
					fetch agent_min_sub_seqno into @agent_id, @min_agent_sub_xact_seqno 
				end
				
			close		agent_min_sub_seqno
			deallocate	agent_min_sub_seqno
			--=close cursor (2)=--

			 --set @max_cleanup_xact_seqno
			   set @max_cleanup_xact_seqno	= 0x00

			select top 1 
				   @max_cleanup_xact_seqno	= xact_seqno
			  from distribution.dbo.MSrepl_transactions with (nolock)
			 where publisher_database_id	= @publisher_database_id 
			   and (
				    xact_seqno				< @min_xact_seqno
				or  @min_xact_seqno			is null
				   ) 
			   and entry_time				<= @min_cutoff_time
		  order by xact_seqno desc
			
			 --set @max_agent_hist_xact_seqno_n
			   set @max_agent_hist_xact_seqno_1	= (	
													select xact_seqno 
													  from (
															select	xact_seqno
																,	row_number() over (order by xact_seqno) as row 
															  from	#max_agent_hist_xact_seqno
														  group by	xact_seqno
															) r
													  where row = 1
													)
			   set @max_agent_hist_xact_seqno_2	= (	
													select xact_seqno 
													  from (
															select	xact_seqno
																,	row_number() over (order by xact_seqno) as row 
															  from	#max_agent_hist_xact_seqno
														  group by	xact_seqno
															) r
													  where row = 2
													)
				
			--=stage transactions=--
			insert	#transaction 
					(
						[publisher_database_id],[agent_id],[xact_seqno],[type],[article_id]
					)
			select	distinct
					s.publisher_database_id
				,	s.agent_id
				,	rc.xact_seqno
				,	rc.type
				,	rc.article_id
			  from	distribution.dbo.MSrepl_commands rc with (index(ucMSrepl_commands))
		inner join	distribution.dbo.MSsubscriptions s  with (index(ucMSsubscriptions)) on (rc.article_id = s.article_id) and rc.publisher_database_id = s.publisher_database_id
			 where	s.publisher_database_id	= @publisher_database_id
			   and	s.agent_id				= case
												when @dist_agent_id > 0 then @dist_agent_id
												else s.agent_id
											  end

			create	clustered index IX_xact_seqno on #transaction (xact_seqno)

			--=open cursor (3): agent minimum transaction sequence=--
			declare agent_min_xact_seqno cursor
			local forward_only
			for
			select	agent_id 
			  from	#max_agent_hist_xact_seqno
			 where	agent_id = case
									when @dist_agent_id > 0 then @dist_agent_id
									else agent_id
								 end
					
			  open	agent_min_xact_seqno 
		     fetch	agent_min_xact_seqno into @agent_id
			
		     while (@@fetch_status <> -1)
				begin
					--set @xact_seqno
					select @xact_seqno				= (	
														--oldest undistributed
														select min(xact_seqno)
														  from #transaction
														 where publisher_database_id	= @publisher_database_id
														   and agent_id					= @agent_id
														   and xact_seqno				> (	
																							select xact_seqno 
																							  from #max_agent_hist_xact_seqno 
																							 where agent_id = @agent_id
																							)
													   )
												  
					--set article_id
					select @article_id				= (	
														select	top 1
																article_id 
														  from	#transaction
														 where	publisher_database_id	= @publisher_database_id
														   and	agent_id				= @agent_id
														   and	xact_seqno				= @xact_seqno
													   )
						
					--log agent & xact_seqno details
					insert	#agent_detail 
							(
								[publisher_database_id],[publisher_db],[subscriber_db],[dist_agent_id],[dist_agent],[dist_status],[dist_comments],[xact_type],
								[xact_article],[xact_seqno],[xact_entry_time],[delivery_rate],[current_delivery_latency]
							)
					select	publisher_database_id	= ( 
														select @publisher_database_id 
														)
						,	publisher_db			= (	
														select distinct 
															   publisher_db
														  from distribution.dbo.MSdistribution_agents 
														 where publisher_database_id	= @publisher_database_id
														   and id						= @agent_id
														)
						,	subscriber_db			= (	
														select distinct 
															   subscriber_db
														  from distribution.dbo.MSdistribution_agents 
														 where publisher_database_id	= @publisher_database_id
														   and id						= @agent_id
														)
						,	dist_agent_id			= ( 
														select @agent_id 
														)
						,	dist_agent				= (	
														select name 
														  from distribution.dbo.MSdistribution_agents 
														 where publisher_database_id	= @publisher_database_id
														   and id						= @agent_id
														)
						,	dist_status				= (	
														select top 1 
																case runstatus
																	when 1 then 'Start'
																	when 2 then 'Stopped' --'Succeed'
																	when 3 then 'In Progress'
																	when 4 then 'Idle'
																	when 5 then 'Retry'
																	when 6 then 'Fail'
																end 
														  from distribution.dbo.MSdistribution_history 
														 where agent_id		= @agent_id
													  order by timestamp desc
														)
						,	dist_comments			= (	
														select top 1 
															   comments
														  from distribution.dbo.MSdistribution_history 
														 where agent_id		= @agent_id
													  order by timestamp desc
														)
						,	xact_type				= (	
														select	case	
																	when exists (	
																					select type
																					  from #transaction
																					 where publisher_database_id	= @publisher_database_id
																					   and agent_id					= @agent_id
																					   and xact_seqno				= @xact_seqno
																					   and type						= -2147483611
																				)
																	then 'snapshot'
																	else 'transaction'
																end
														)
						,	xact_article			= (	
														select top 1
															   article
														  from distribution.dbo.MSarticles 
														 where article_id	= @article_id
														   and publisher_db = (
																				select distinct 
																					  publisher_db
																				 from distribution.dbo.MSsubscriptions
																				where publisher_database_id = @publisher_database_id
																				)
														)
						,	xact_seqno				= (	
														select @xact_seqno 
														)
						,	xact_entry_time			= (	
														select entry_time 
														  from distribution.dbo.MSrepl_transactions 
														 where publisher_database_id	= @publisher_database_id
														   and xact_seqno				= @xact_seqno
														 )
						,	delivery_rate			= (	
														select top 1
																current_delivery_rate
														  from distribution.dbo.MSdistribution_history
														 where agent_id					= @agent_id
													  order by timestamp desc
														)
						, current_delivery_latency = (select top 1 current_delivery_latency*.001																
														  from distribution.dbo.MSdistribution_history
														 where agent_id					= @agent_id
													  order by timestamp desc
														)

					--update command count
					if @include_cmds = 1 and @xact_seqno is not null
						begin
							--update xact_cmd 
							update #agent_detail
							   set xact_cmd			= (	
														select count(*)
														  from distribution.dbo.MSrepl_commands	rc with (index(ucmsrepl_commands))
														 where rc.publisher_database_id	= @publisher_database_id
														   and rc.xact_seqno			= @xact_seqno
														)
							 where publisher_database_id	= @publisher_database_id
							   and xact_seqno				= @xact_seqno
							   and xact_cmd					= 0 
						end

					--debug (agent cursor)
					if @debug = 1
						begin
							select	'=======Debug Agent Cursor======='
							  
							select	param_publisher_database_id		= @publisher_database_id
								,	param_dist_agent_id				= @dist_agent_id
								,	param_include_pub				= @include_pub
								,	param_include_sub				= @include_sub
								,	param_include_cmds				= @include_cmds
								,	param_debug						= @debug
								,	agent_id						= @agent_id
								,	min_xact_seqno					= @min_xact_seqno
								,	max_cleanup_xact_seqno			= @max_cleanup_xact_seqno
								,	max_agent_hist_xact_seqno_1		= @max_agent_hist_xact_seqno_1
								,	max_agent_hist_xact_seqno_2		= @max_agent_hist_xact_seqno_2
								,	xact_seqno						= @xact_seqno
								,	article_id						= @article_id


							select	agent_id
								,	xact_seqno
								,	row_number() over (order by xact_seqno) as row 
							  from	#max_agent_hist_xact_seqno
						end 
						
				fetch agent_min_xact_seqno into @agent_id
				end
				
			close agent_min_xact_seqno
			deallocate agent_min_xact_seqno
			--=close cursor (3)=--
			

			--update command count
			if @include_cmds = 1
				begin
					--set/check variables				--set to oldest undistributed tran
					select @xact_seqno					= xact_seqno
														--set to agent_id for oldest undistributed tran
						,  @agent_id					= dist_agent_id
													    --set to last undistributed tran when only 1 distrubtion agent
						,  @max_agent_hist_xact_seqno_2 = coalesce(
																		@max_agent_hist_xact_seqno_2
																	,	(
																		select max(xact_seqno)
																		  from distribution.dbo.MSrepl_transactions
																		 where publisher_database_id = @publisher_database_id
																		)
																	)
					  from #agent_detail 
					 where xact_seqno	= (
											select min(xact_seqno) 
											  from #agent_detail ad 
											 where publisher_database_id = @publisher_database_id
											)

					--update cmd_pending
					update ad
					   set cmd_pending	= (	
											select count(*)
											  from distribution.dbo.MSrepl_commands	rc with (index(ucmsrepl_commands))
										inner join distribution.dbo.MSsubscriptions	s  with (index(ucmssubscriptions)) on (rc.article_id = s.article_id)
											 where s.publisher_database_id	= @publisher_database_id
											   and s.agent_id				= @agent_id
											   and rc.xact_seqno		   >= @xact_seqno
											   and rc.xact_seqno		   <  @max_agent_hist_xact_seqno_2
											)
					  from #agent_detail ad
					 where publisher_database_id	= @publisher_database_id
					   and xact_seqno				= @xact_seqno

					--update cmd_tbd
					update ad
					   set cmd_tbd		= (	
											select count(*)
											  from distribution.dbo.MSrepl_commands	rc with (index(ucmsrepl_commands))
											 where rc.publisher_database_id	= @publisher_database_id
											   and rc.xact_seqno		   <= @max_cleanup_xact_seqno
											)
					  from #agent_detail ad
					 where publisher_database_id	= @publisher_database_id

					--update cmd_blk
					update ad
					   set cmd_blk		= (	
											select count(*)
											  from distribution.dbo.MSrepl_commands	rc with (index(ucmsrepl_commands))
											 where rc.publisher_database_id	= @publisher_database_id
											   and rc.xact_seqno		   >= @xact_seqno
											   and rc.xact_seqno		   <= @max_agent_hist_xact_seqno_2
											)
					  from #agent_detail ad
					 where publisher_database_id	= @publisher_database_id
					   and xact_seqno				= @xact_seqno
				end			

			--drop clustered index
			drop index IX_xact_seqno on #transaction

			--debug (publisher cursor)
			if @debug = 2
				begin
					select	'=======Debug Publisher Cursor======='

					select	param_publisher_database_id		= @publisher_database_id
						,	param_dist_agent_id				= @dist_agent_id
						,	param_include_pub				= @include_pub
						,	param_include_sub				= @include_sub
						,	param_include_cmds				= @include_cmds
						,	param_debug						= @debug
						,	agent_id						= @agent_id
						,	min_xact_seqno					= @min_xact_seqno
						,	max_cleanup_xact_seqno			= @max_cleanup_xact_seqno
						,	max_agent_hist_xact_seqno_1		= @max_agent_hist_xact_seqno_1
						,	max_agent_hist_xact_seqno_2		= @max_agent_hist_xact_seqno_2
						,	xact_seqno						= @xact_seqno
						,	article_id						= @article_id

					select	*
					  from	#agent_detail

					select	agent_id
						,	xact_seqno
						,	row_number() over (order by xact_seqno) as row 
					  from	#max_agent_hist_xact_seqno
				end 

		fetch publisher into @publisher_database_id 
		end
		
	close publisher
	deallocate publisher
	--=close cursor (1)=--
	

        insert	dbo.Replication_Monitoring
							(
								[publisher_db],[subscriber_db],[dist_agent_id],[dist_agent],[dist_status],
								[dist_comments],[xact_type],[xact_article],[xact_seqno],xact_age,[xact_cmd],[delivery_rate_sec],
								[delivery_est],cmd_pending,cmd_tbd,cmd_blk,xact_entry_time,current_latency
							)
		select	
						publisher_db, 
							subscriber_db, 
						ad.dist_agent_id	
						,	dist_agent
						,	dist_status
						,	dist_comments
						,	xact_type
						,	xact_article
						,	xact_seqno		= (	substring(     (master.dbo.fn_varbintohexstr(xact_seqno)), 1, 2) +
												substring(upper(master.dbo.fn_varbintohexstr(xact_seqno)), 3, 8000))
						,	xact_age		= convert (varchar(10),(datediff(second,(xact_entry_time),getdate()))/86400) + '-' +
												substring(convert(varchar(25),(select dateadd(second,datediff(second,(xact_entry_time),getdate()),'2012-01-01 00:00:00.000')),126),12,12)
						
						,	xact_cmd						
						,	delivery_rate_sec	= convert(numeric(38,2),delivery_rate)
					,	delivery_est	= convert (varchar(10),(datediff(second,(dateadd(second,-(CASE WHEN delivery_rate <> 0 THEN(xact_cmd/convert(numeric(38,2), delivery_rate ))ELSE 0 END),getdate())),getdate()))/86400) + '-' +
																					  substring(convert(varchar(25),(select dateadd(second,datediff(second,(dateadd(second,-
																					  (CASE WHEN delivery_rate <> 0 THEN(xact_cmd/convert(numeric(38,2), delivery_rate ))ELSE 0 END),getdate())),getdate()),'2012-01-01 00:00:00.000')),126),12,12)
						,	cmd_pending
							,	cmd_tbd
						,	cmd_blk
						,xact_entry_time
						,current_delivery_latency
						from	#agent_detail ad 
							order by publisher_db, xact_seqno desc

end
GO


