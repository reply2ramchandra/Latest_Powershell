﻿set-path "X:\SQLISO"
.\Dynatrace-OneAgent-Windows-1.285.113.20240227-120645.exe --set-monitoring-mode=fullstack --set-app-log-content-access=true