

## Pre-requisties
    - Windows 2012 R2 or above OS
    - Powershell version 5.1 
        - Install WMF 5.1 Framework on the collection server to upgrade the Powershell version
    - Sql Server 2016 Standard Edition or Above

## Security
Dedicated AD account to be used for collection process and able access to all SQL instances in the environment. This account should be member of 
* Local Administrators Group
* "sysadmin" privileges to SQL Instances


## Step 1 : Install Powershell Modules
``` powershell
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Install-PackageProvider -Name Nuget -MinimumVersion 2.8.5.208
Install-Module -Name SqlServer -RequiredVersion 21.1.18235 -Force -AllowClobber
Install-Module -Name SqlServerDsc -RequiredVersion 15.1.1 -Force -AllowClobber
Install-Module -Name dbatools -RequiredVersion 1.0.140 -Force
Install-Module Pester -SkipPublisherCheck -Force -RequiredVersion 4.10.0
Import-Module Pester -Force -RequiredVersion 4.10.0 ; Install-Module -Name dbachecks -RequiredVersion 2.0.9 -Force
Install-Module -Name ImportExcel -RequiredVersion 7.1.1 -Force
Install-Module -Name PowershellGet -RequiredVersion 2.2.4.1 -Force
Install-Module -Name PSReadLine -RequiredVersion 2.0.2 -Force
```

## Step 2: Update Configuration File 

There should be a `json` file under *\Powershell* directory that enacts as configuration file with locations and meta information the process is going to refer. Update the file with correct info by appending if it's a NEW customer

``` json
        "DFS":
            {
                "ServerName": "FWPAXD-SQLVM001\\SQL001",
                "Database": "DBA_REPOSITORY",
                "DbaBasepath": "D:\\SQLDBA\\Ensono\\SqlCollection",
                "ScriptFolder": "Powershell",
                "ReportFolder": "Reports",
                "KeyFolder": "Keys",
                "SMTP": "SMTP.FINCOAD.COM",
                "ToMail": "EnsonoSQLServerL3@Ensono.com",
                "CcMail": "prod_sqldba@dfsco.com",
                "FromMail": "no_replyDba@dfsco.com",
                "ConnectionMethod" : {
                                    "default" : {
                                                "PasswordEncryptedFileName": "CollectionSqlPwd.txt",
                                                "AESKeyName": "CollectionAES.Key",
                                                "SqlLogin": "FINCOAD\\prod-sql-dba"
                                                }
                                    }
            },
```            
Create the specified directories/folders under the `DbaBasePath` specified above manually.

## Step 3: Encrypt Collection AD account password 
Replace `$DbaBasePath\$KeyFolder` with file paths as specified in the json file
``` powershell
    $key = New-Object Byte[] 16 # 16,24,32
    [Security.Cryptography.RNGCryptoServiceProvider]::Create().GetBytes($Key)
    $key | Out-File -FilePath '$DbaBasePath\$KeyFolder\CollectionAES.Key'

    $pd = 'Place The Strong Password' | ConvertTo-SecureString -AsPlainText -Force 
    $pd | ConvertFrom-SecureString -Key (Get-Content '$DbaBasePath\$KeyFolder\CollectionAES.Key') | Out-File -FilePath '$DbaBasePath\$KeyFolder\CollectionSqlPwd.txt'
```
## Step 4: Rollout the schema 
Create the `$Database` name with necessary db options
Take database `.dacpac` file from the source control and deploy the package onto the database name.
* Right click on the database
    > Tasks
    >> Update Database Tier
    >>> Location of the `dacpac` 
    >>>> Click **Next** button multiple times

## Step 5: Import the ServerList Inventory
Load SqlInstances into the Inventory schema

``` sql
USE [$Database]
GO
INSERT INTO Inventory.ServerList (SqlInstance,Domain,Environment,Description,Port)
SELECT 'ABC\XYZ','Domain Name','D','This is a sample SQL box for application', 1433
UNION ALL
SELECT 'KLM\NOP','Domain Name','P','This is a sample SQL box for application', 2700

(or)

EXEC Admin.usp_add_sqlinstance
```

## Step 6: Create the Collection Jobs under "CMS" job category



