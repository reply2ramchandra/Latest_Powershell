﻿clear
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
# Module loading (SQL Agent may not load user scope modules)
Install-Module dbatools -Scope AllUsers -Force
Import-Module dbatools -ErrorAction Stop
Import-Module SQLServer -ErrorAction Stop
Set-DbatoolsInsecureConnection -SessionOnly 
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "DROP TABLE IF EXISTS [CMS].[dbo].[AllUserDB];" -TrustServerCertificate

$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance]  FROM [CMS].[dbo].[DBServer]  Where [Status] in ('P','Y','R') and HostName Not in('TPAPWSQLSSRS-03','localhost','PCIPWSQL001')" -TrustServerCertificate
foreach($instance in $servers.SqlInstance)
{
$AlluserDb=Get-DbaDatabase -SqlInstance $instance -ExcludeSystem | Select @{n='DateKey';e={(Get-Date).GetDateTimeFormats()[46]}},SqlInstance,Name,Status
if($AlluserDb){Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'AllUserDB' -InputObject $AlluserDb  -AutoCreateTable -KeepNulls}
}

Start-Sleep -Seconds 2
 $css = @"
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid black; padding: 8px; text-align: left; }
    th { background-color: #D6EEEE; }
    tr:nth-child(even) {
  background-color: rgba(150, 212, 212, 0.4);}
</style>
"@

$runDateTime = (Get-Date -Format yyyyddMM) 
 $preContent = @"
<h3><font face=verdana color=blue> MSSQL Server DB Status Report</font></h3>
<p>This report contains the list of Db(s) which is\are not Online.</p>
"@
$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Please review and take action as Required.</font></p>
"@
$dbstat=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query "SELECT [SqlInstance],[Name],[Status] FROM [CMS].[dbo].[AllUserDB] WHERE Status NOT IN('Normal','Normal,AutoClosed') EXCEPT SELECT [SqlInstance],[Name],[Status] FROM [CMS].[dbo].[DBException];" -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$dbstats=$dbstat | where-Object {$_.Status -ne 'Normal, AutoClosed'}
$dbstats | ConvertTo-Html -Property SqlInstance,Name,Status -Head $css -Title "MSSQL Server DB Status Report" -PreContent $preContent  -PostContent  $postContent  | Out-File -FilePath \\tpapwmssql002\Reports\Dbstat$runDateTime.htm 
       

             if($dbstats.Count -gt 0)
             {
                  Write-host 'Sending mail as we have db not online' -ForegroundColor Green
     
                  $body = Get-Content \\tpapwmssql002\Reports\Dbstat$runDateTime.htm
                  Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'Alert: ALL MSSQL Server DB Status Report' -SmtpServer smtprelay.healthplan.com -BodyAsHtml:$true -Body "$body" 

                 #Invoke-Item \\tpapwmssql002\Reports\backupreport.html--WHPS-MSSQL-Admins                 
             }
           else
             {
              Write-host 'Sending mail' 
              $attachfile="\\tpapwmssql002\Reports\Dbstat$runDateTime.htm"
              Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'ALL MSSQL Server DB Status Report' -SmtpServer smtprelay.healthplan.com -Attachments $attachfile -BodyAsHtml:$true -Body "All SQL Servers DB's are online.Refer to the attached." 
             }
