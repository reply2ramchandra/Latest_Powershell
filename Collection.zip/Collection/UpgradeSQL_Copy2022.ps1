﻿##Copy Software
clear-host
$server= Read-host " Enter Server Name: "
$server=$server.ToUpper()
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\SQL\Software"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}}
#copy SOFTWARE/PATCH file
##change the path according to ISO file version##
$isofile= Get-ChildItem X:\SQLISO\SQL2022 -Filter '*_Ent_*2022*.ISO' 
$patchfile= Get-ChildItem X:\SQLISO\CU -Filter '*2022*.exe'
$source=$isofile.FullName 
$patch=$patchfile.FullName 
$target="D:\SQL\Software"
$user =  [Environment]::username
$cred=Get-Credential $user
$s = New-PSSession -ComputerName $server -Credential $cred
write-Host "Wait...Copying Software." -ForegroundColor Cyan
Copy-Item -Path $source -Destination $target -ToSession $s -Force -ErrorAction SilentlyContinue
Copy-Item -Path $patch -Destination $target -ToSession $s -Force -ErrorAction SilentlyContinue
#Exit-PSSession
Start-Sleep -Seconds 2 
Write-Host " Software Copy should have been completed now !" -ForegroundColor green
Start-Sleep -Seconds 2 
clear-host
Write-Host "Lets Review the files copied." -ForegroundColor Magenta
Invoke-Command -ComputerName $Server -ScriptBlock { 
       $path='D:\SQL\Software'
        Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -gt $(Get-Date).AddDays( - 1))} | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}}  
       }