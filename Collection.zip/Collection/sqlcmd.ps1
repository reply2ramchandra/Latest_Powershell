﻿#In cmd type 'sqlcmd ?'
runas /user:HPS\svc_hpssql "sqlcmd -S TPAPWSQLARCH01 -E -Q \'SELECT @@VERSION\'"
sqlcmd -S TPAPWSQLARCH01,1433 -U recuser -P Sqldba@123 -Q "SELECT @@servername,@@VERSION"