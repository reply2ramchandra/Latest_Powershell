﻿clear
Import-Module dbatools -EA SilentlyContinue

Get-DbaDbTable -SqlInstance TPATWSQLHHA01 -Database ClaimfactsReports | Export-DbaScript -FilePath D:\Mask\export.sql

#Get-DbaDbTable -SqlInstance HPSSQL04\SQL04 -Database ET # -Table MyTable -Schema MySchema |
#Get-DbaDbTable -SqlInstance HPSSQL04\SQL04 -Database ET | format-table -wrap
Get-DbaDbTable -SqlInstance HPSSQL04\SQL04 -Database ET | Write-DbaDataTable -SqlInstance HPSSQL04\SQL04 -Database Admin -Schema 'dbo' -Table 'ETRowCount' -AutoCreateTable

