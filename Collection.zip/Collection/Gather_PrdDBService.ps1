﻿clear
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue
Import-Module SQLServer -EA SilentlyContinue
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "DROP TABLE IF EXISTS [CMS].[dbo].[PrdDbaService];" -TrustServerCertificate
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "DELETE FROM [CMS].[dbo].[PrdDBSrvStatus];" -TrustServerCertificate
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT trim([HostName]) as HostName FROM [CMS].[dbo].[DBServer] Where [Status] in ('Y','R') and HostName Not in('HPSSQL03','localhost') and Category='PROD'"  -TrustServerCertificate 
$total=$servers.count
# Actual Script to collect services status from all Active servers.
foreach($SQL_server in $servers.HostName)
{
	
$PrdDbaService =  Get-DbaService -ComputerName $SQL_server | Where-Object {$_.ServiceType -eq 'Engine' -OR $_.ServiceType -eq 'Agent' }  | Select @{n='DateKey';e={(Get-Date).GetDateTimeFormats()[46]}},PSComputerName,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State,StartName
IF($PrdDbaService -ne $null){
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'PrdDbaService' -InputObject $PrdDbaService  -AutoCreateTable -KeepNulls}
ELSE { Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "INSERT INTO  [CMS].[dbo].[PrdDBSrvStatus] (HostName,Comments) VALUES($SQL_server,'Unreachable')"  -TrustServerCertificate }

}

 $css = @"
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid black; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
</style>
"@

$runDateTime = (Get-Date -Format yyyyddMM) 
 $preContent = @"
<h3><font face=verdana color=blue>PROD Server DB Service Report</font></h3>
<p>This report contains the list of Servers where DB Service(s) is\are not running nor Server is unreachable.</p>
"@

$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Please review and take action as Required.</font></p>
"@
$totalins=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query "SELECT Count([ComputerName]) Total FROM  [CMS].[dbo].[PrdDbaService] WHERE [ServiceType]='Engine';" -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$tco=$totalins.Total
$Dbservicestat=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query "SELECT [DateKey],[ComputerName],[DisplayName],[ServiceType],[ServiceName],[StartMode],[State] FROM  [CMS].[dbo].[PrdDbaService];" -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$Dbservicestat | ConvertTo-Html -Property DateKey,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State -Head $css -Title "PROD Server DB Service Report" -PreContent "PROD Server DB Service Report" -PostContent  $postContent | Out-File -FilePath \\tpapwmssql002\Reports\Dbservicestat$runDateTime.htm
$dbserviceinfo=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query "SELECT [DateKey],[ComputerName],[DisplayName],[ServiceType],[ServiceName],[StartMode],[State] FROM  [CMS].[dbo].[PrdDbaService] WHERE State<>'Running';" -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
if($dbserviceinfo.Count -gt 0 ) {$dbserviceinfo | ConvertTo-Html -Property DateKey,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State -Head $css -Title "PROD Server DB Service Down Report" -PreContent $preContent  -PostContent  $postContent | Out-File -FilePath \\tpapwmssql002\Reports\Dbservicereport$runDateTime.htm}
$dbsrvinfo=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query " SELECT [HostName],[Comments] FROM  [CMS].[dbo].[PrdDBSrvStatus];" -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
if($dbsrvinfo.Count -gt 0 ) {$dbsrvinfo | ConvertTo-Html -Property HostName,Comments -Head $css -Title "PROD Server unreachable Report" -PreContent $preContent  -PostContent  $postContent | Out-File -FilePath \\tpapwmssql002\Reports\Dbservicereport$runDateTime.htm  -Append}
"<table><tr><th>Total_Server_To_Check</th><td bgcolor='#F0FF33'>$total</td><th>Total_Server_Checked</th><td bgcolor='#F0FF33'>$tco</td></tr></table>" |  Out-File -FilePath \\tpapwmssql002\Reports\Dbservicestat$runDateTime.htm -Append
            if($dbserviceinfo.Count -gt 0 -OR $dbsrvinfo.count -gt 0 )
             {
                  Write-host 'Sending mail of Prod Servers''  Service Info' 
                   
                  $body = Get-Content \\tpapwmssql002\Reports\Dbservicereport$runDateTime.htm
                  Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'Alert: PROD Server DB Service Down Report' -SmtpServer smtprelay.healthplan.com -BodyAsHtml:$true -Body "$body" 
                #Invoke-Item \\tpapwmssql002\Reports\backupreport.html
            }
           else
             {
              Write-host 'Sending mail' 
              $attachfile="\\tpapwmssql002\Reports\Dbservicestat$runDateTime.htm"
              Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'PROD Server DB Service Report' -SmtpServer smtprelay.healthplan.com -Attachments $attachfile -BodyAsHtml:$true -Body "All Prod Servers DB Services are up and running fine.Refer to the attached." 
             }
 