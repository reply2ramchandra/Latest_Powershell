﻿clear
import-module dbatools -EA SilentlyContinue
Set-DbaTcpPort -SqlInstance TPAPWSQLETA01\SQL04 -Port 2759 -Confirm:$false
<#
$TargetServer='TPADWSQLAUT001'
Get-DbaService $TargetServer | Start-DbaService -InstanceName LCS
Get-DbaService $TargetServer | Start-DbaService -InstanceName MSSQLSERVER
#Restart-DbaService;Stop-DbaService
#>
Restart-DbaService -ComputerName TPAPWSQLETA01 -Type Engine -Force
#Restart-DbaService -ComputerName TPAPWSQLETA01 -InstanceName SQL04

