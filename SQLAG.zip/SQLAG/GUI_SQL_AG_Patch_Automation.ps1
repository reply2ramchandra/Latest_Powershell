﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ---- Global strict / preferences ------------------------------------------------
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- Helpers --------------------------------------------------------------------
function Stop-Script {
    param(
        [string]$Message,
        [int]$Code = 1
    )
    Write-Error $Message
    Write-Host "Script exiting with code $Code" -ForegroundColor Yellow
    exit $Code
}

function Write-Info {
    param([string]$Message, [ConsoleColor]$Color = [ConsoleColor]::Cyan)
    $fc = $Host.UI.RawUI.ForegroundColor
    $Host.UI.RawUI.ForegroundColor = $Color
    Write-Host $Message
    $Host.UI.RawUI.ForegroundColor = $fc
}

# ---- GUI Form -------------------------------------------------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = "SQL AG Patch Automation"
$form.Size = [System.Drawing.Size]::new(500,400)
$form.StartPosition = "CenterScreen"

$sampleLabel = [System.Windows.Forms.Label]::new()
$sampleLabel.Text = "Sample:  A01   B01   C:\patch   5000071"
$sampleLabel.ForeColor = [System.Drawing.Color]::Green
$sampleLabel.Font = [System.Drawing.Font]::new($form.Font, [System.Drawing.FontStyle]::Bold)
$sampleLabel.AutoSize = $false
$sampleLabel.Height = 24
$sampleLabel.Dock = 'Top'
$sampleLabel.TextAlign = 'MiddleCenter'
$form.Controls.Add($sampleLabel)

$labels    = @("Primary Node:", "Secondary Node:", "Patch Path:", "KB Number:")
$textboxes = @()

for ($row = 0; $row -lt $labels.Count; $row++) {
    $y = 40 + (40 * [int]$row)

    $label = [System.Windows.Forms.Label]::new()
    $label.Text      = $labels[$row]
    $label.Location  = [System.Drawing.Point]::new(30, $y)
    $label.Size      = [System.Drawing.Size]::new(140, 20)
    $form.Controls.Add($label)

    $textbox = [System.Windows.Forms.TextBox]::new()
    $textbox.Location = [System.Drawing.Point]::new(180, $y)
    $textbox.Size     = [System.Drawing.Size]::new(250, 30)
    $form.Controls.Add($textbox)
    $textboxes += $textbox
}

$okButton = [System.Windows.Forms.Button]::new()
$okButton.Text = "Start"
$okButton.Location = [System.Drawing.Point]::new(200, 230)
$okButton.Add_Click({
    try {
        $empty = $textboxes | Where-Object { [string]::IsNullOrWhiteSpace($_.Text) }
        if ($empty) {
            # Optional: visually mark empty boxes
            foreach ($tb in $textboxes) {
                if ([string]::IsNullOrWhiteSpace($tb.Text)) {
                    $tb.BackColor = [System.Drawing.Color]::MistyRose
                } else {
                    $tb.BackColor = [System.Drawing.SystemColors]::Window
                }
            }
            [System.Windows.Forms.MessageBox]::Show(
                "All fields are required.",
                "Input Error",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            ) | Out-Null
            return
        }

        $form.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $form.Close()
    } catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Unexpected error validating input:`r`n$($_.Exception.Message)",
            "Validation Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
})
$form.Controls.Add($okButton)

$result = $form.ShowDialog()
if ($result -ne [System.Windows.Forms.DialogResult]::OK) { Stop-Script "User cancelled." 2 }

# ---- Inputs ---------------------------------------------------------------------
$active    = $textboxes[0].Text.Trim()
$passive   = $textboxes[1].Text.Trim()
$PatchPath = $textboxes[2].Text.Trim()
$KB        = $textboxes[3].Text.Trim()

Clear-Host
Write-Info "Starting SQL AG patch automation..." Green

# ---- Validation -----------------------------------------------------------------
if ($active -ieq $passive) { Stop-Script "Primary and Secondary must differ." }

if ($KB -notmatch '^\d{6,8}$') {
    Stop-Script "KB '$KB' does not match expected numeric pattern."
}

# Basic reachability
foreach ($n in @($active,$passive)) {
    if (-not (Test-Connection -ComputerName $n -Count 1 -Quiet)) {
        Stop-Script "Cannot ping node '$n'."
    }
}

# ---- Module Load ----------------------------------------------------------------
try {
    if (-not (Get-Module -ListAvailable -Name dbatools)) {
        Stop-Script "dbatools module not found on this host."
    }
    Import-Module dbatools -ErrorAction Stop | Out-Null
} catch {
    Stop-Script "Failed to import dbatools: $_"
}

# ---- Functions ------------------------------------------------------------------
function Get-AgName {
    param([string]$SqlInstance)
    $ag = Get-DbaAvailabilityGroup -SqlInstance $SqlInstance -ErrorAction Stop | Select-Object -First 1
    if (-not $ag) { Stop-Script "No Availability Group found on $SqlInstance." }
    return $ag.Name
}

function Test-AgDatabasesHealthy {
    param([string]$SqlInstance)
    $agDbs = Get-DbaAgDatabase -SqlInstance $SqlInstance -ErrorAction Stop
    $unhealthy = $agDbs | Where-Object { $_.SynchronizationState -ne 'Synchronized' -or $_.IsSuspended }
    if ($unhealthy) {
        Write-Warning "Unhealthy AG DBs on ${SqlInstance}:`n$($unhealthy.DatabaseName -join ', ')"
        return $false
    }
    return $true
}

function Patch-SQLNode {
    param(
        [Parameter(Mandatory)] [string]$Node,
        [Parameter(Mandatory)] [string]$PatchPath,
        [Parameter(Mandatory)] [string]$KB
    )
    Write-Info "Validating AG database health on $Node..."
    if (-not (Test-AgDatabasesHealthy -SqlInstance $Node)) {
        Write-Error "AG databases not healthy on $Node. Aborting patch on this node."
        return $false
    }
    Write-Info "AG databases healthy on $Node. Beginning patch."

    try {
        Update-DbaBuildReference -ErrorAction Stop | Out-Null
        Update-DbaInstance -ComputerName $Node -KB $KB -Restart -Path $PatchPath -Confirm:$false -ErrorAction Stop | Out-Null
        Write-Info "Patch command dispatched for $Node. Waiting for restart..."
        return $true
    } catch {
        Write-Error "Patching failed on ${Node}: $_"
        return $false
    }
}

function Wait-Uptime {
    param(
        [string]$SqlInstance,
        [int]$TimeoutSeconds = 900,
        [int]$PollSeconds = 30
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        try {
            if (Get-DbaUptime -SqlInstance $SqlInstance -ErrorAction Stop) {
                return $true
            }
        } catch { }
        Start-Sleep -Seconds $PollSeconds
    }
    Write-Error "Instance $SqlInstance did not come online within $TimeoutSeconds seconds."
    return $false
}

function Invoke-AgFailover {
    param(
        [Parameter(Mandatory)] [string]$NewPrimaryInstance,
        [Parameter(Mandatory)] [string]$AgName,
        [int]$Attempts = 2,
        [int]$DelaySeconds = 120
    )
    for ($attempt=1; $attempt -le $Attempts; $attempt++) {
        Write-Info "Attempt ${attempt}: Initiating AG failover targeting $NewPrimaryInstance..."
        try {
            $res = Invoke-DbaAgFailover -SqlInstance $NewPrimaryInstance -AvailabilityGroup $AgName -Confirm:$false -ErrorAction Stop
            if ($res.PrimaryReplica -eq $NewPrimaryInstance) {
                Write-Info "Failover success (attempt $attempt)." Green
                return $true
            } else {
                Write-Warning "Failover status unsuccessful in attempt $attempt."
            }
        } catch {
            Write-Warning "Failover error on attempt ${attempt}: $_"
        }
        Start-Sleep -Seconds $DelaySeconds
    }
    Write-Error "Failover to $NewPrimaryInstance failed after $Attempts attempts."
    return $false
}

function Verify-KBOnNode {
    param(
        [string]$Node,
        [string]$KB
    )
    # Expect Get-KBNumber script in working directory; wrap safely
    try {
        $kbInfo = ./Get-KBNumber $Node
        if ($null -eq $kbInfo) {
            Write-Warning "Get-KBNumber returned null for $Node"
            return $false
        }
        return ($kbInfo.KB_Number -eq $KB)
    } catch {
        Write-Warning "Failed to verify KB on ${Node}: $_"
        return $false
    }
}

function Assert-RemotePatchPath {
    param(
        [string[]]$Computers,
        [string]$Path
    )
    foreach ($c in $Computers) {
        try {
            $exists = Invoke-Command -ComputerName $c -ScriptBlock {
                param($p)
                Test-Path -LiteralPath $p -PathType Container
            } -ArgumentList $Path -ErrorAction Stop

            if (-not $exists) {
                Stop-Script "Patch path '$Path' NOT found on $c."
            }
            Write-Info "Verified patch path '$Path' on $c"
        } catch {
            Stop-Script "Remote path validation failure on $c for '$Path' : $_"
        }
    }
}
Assert-RemotePatchPath -Computers @($active, $passive) -Path $PatchPath
# ---- Main Logic -----------------------------------------------------------------
$agName = Get-AgName -SqlInstance $active
Write-Info "Detected AG: $agName"

Write-Info "Version BEFORE patching:" Yellow
Connect-DbaInstance -SqlInstance $active  | Select-Object SqlInstance, VersionString
Connect-DbaInstance -SqlInstance $passive | Select-Object SqlInstance, VersionString

# Determine current primary
$agState = Get-DbaAvailabilityGroup -SqlInstance $active -ErrorAction Stop | Where-Object Name -eq $agName
$currentPrimary = $agState.PrimaryReplica
Write-Info "Current primary replica: $currentPrimary"

$activeIsPrimary = ($currentPrimary -ieq $active)
$initialPrimary = $currentPrimary

# Decide first patch target = current secondary
$firstTarget  = if ($activeIsPrimary) { $passive } else { $active }
$secondTarget = if ($activeIsPrimary) { $active } else { $passive }

Write-Info "First patch target (current secondary): $firstTarget"
if (-not (Patch-SQLNode -Node $firstTarget -PatchPath $PatchPath -KB $KB)) {
    Stop-Script "Failed patching first target $firstTarget."
}

if (-not (Wait-Uptime -SqlInstance $firstTarget)) {
    Stop-Script "Patched node $firstTarget did not return in time."
}

# Failover to newly patched node so we can patch the old primary
if (-not (Invoke-AgFailover -NewPrimaryInstance $firstTarget -AgName $agName -Attempts 2 -DelaySeconds 120)) {
    Stop-Script "Failover to $firstTarget failed. Aborting."
}

# Optional KB verification before second patch
Push-Location
try {
    Set-Location "D:\PSScripts\SQLAG"
} catch {
    Write-Warning "Could not change directory to D:\PSScripts\SQLAG (continuing)."
}

if (-not (Verify-KBOnNode -Node $firstTarget -KB $KB)) {
    Stop-Script "KB $KB not verified on $firstTarget. Aborting before second patch."
}
Pop-Location -ErrorAction SilentlyContinue

Write-Info "Second patch target: $secondTarget"
if (-not (Patch-SQLNode -Node $secondTarget -PatchPath $PatchPath -KB $KB)) {
    Stop-Script "Failed patching second target $secondTarget."
}

if (-not (Wait-Uptime -SqlInstance $secondTarget)) {
    Stop-Script "Patched node $secondTarget did not return in time."
}

# Fail back to original primary if it was originally primary
if ($initialPrimary -ieq $active) {
    Write-Info "Failing back to original primary $active ..."
    if (-not (Invoke-AgFailover -NewPrimaryInstance $active -AgName $agName -Attempts 2 -DelaySeconds 120)) {
        Stop-Script "Failback to $active failed."
    }
} else {
    Write-Info "Primary role change retained (original primary was $initialPrimary). No failback required."
}

# Final KB verification both sides
Push-Location
try { Set-Location "D:\PSScripts\SQLAG" | Out-Null } catch {}
$verify1 = Verify-KBOnNode -Node $active  -KB $KB
$verify2 = Verify-KBOnNode -Node $passive -KB $KB
Pop-Location -ErrorAction SilentlyContinue

if (-not ($verify1 -and $verify2)) {
    Stop-Script "Final KB verification failed. Active:$verify1 Passive:$verify2"
}

Write-Info "Version AFTER patching:" Yellow
Connect-DbaInstance -SqlInstance $active  | Select-Object SqlInstance, VersionString
Connect-DbaInstance -SqlInstance $passive | Select-Object SqlInstance, VersionString

Write-Info "Patch process completed successfully." Green
exit 0