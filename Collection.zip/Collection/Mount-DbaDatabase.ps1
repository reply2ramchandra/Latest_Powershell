﻿Import-Module dbatools -EA SilentlyContinue 
DisMount-DbaDatabase -SqlInstance TPAPWSQLHH01 -Database Kaiser
#Mount-DbaDatabase -SqlInstance TPAPWSQLHH01 -Database Kaiser -WhatIf

$fileStructure = New-Object System.Collections.Specialized.StringCollection
$fileStructure.Add("K:\datafiles\Kaiser.MDF")
$filestructure.Add("K:\datafiles\Kaiser_FGNCIndexes.ndf")
$filestructure.Add("L:\logfiles\Kaiser.ldf")
Mount-DbaDatabase -SqlInstance TPAPWSQLHH01 -Database Kaiser -FileStructure $fileStructure


