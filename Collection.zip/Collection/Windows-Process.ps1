﻿#windows process 
##logon to Server and run
TASKLIST /FI "USERNAME eq HPS\a-sm58408" /FI "STATUS eq running"