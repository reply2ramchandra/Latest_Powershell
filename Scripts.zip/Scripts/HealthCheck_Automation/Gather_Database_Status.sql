Use master
go

  select @@Servername AS SQLInstance,
	a.name,
	case 
		When a.state = 0 then 'ONLINE'
		when a.state = 1 then 'RESTORING'
		when a.state = 2 then 'RECOVERING'
		when a.state = 3 then 'RECOVERY_PENDING'
		when a.state = 4 then 'SUSPECT'
		when a.state = 5 then 'EMERGENCY'
		when a.state = 6 then 'OFFLINE'
		when a.state = 7 then 'COPYING - SQL AZURE'
		when a.state = 10 then 'OFFLINE_SECONDARY - SQL AZURE'
	end AS state_desc,
	a.log_reuse_wait_desc ,
	case 
	when a.log_reuse_wait_desc = 'NOTHING' and a.state = 0  then 'Healthy' Else 'UnHealthy' End AS DBHealthStatus,convert(varchar, getdate(), 120) AS Collectiontime
from sys.databases a