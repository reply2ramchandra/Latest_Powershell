﻿$Computers='TPATWSQLMHCA01'
Invoke-Command ($Computers) {
    If ($null -eq (Get-Module -Name PSWindowsUpdate -ListAvailable) ) {
      [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
      Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
      Install-Module PSWindowsUpdate -Force
      Import-Module PSWindowsUpdate
    }
}