﻿Get-EventLog -LogName System -InstanceId 1562 -ComputerName TPAPWSQLALFA01,TPAPWSQLALFB01 -Newest 2
Get-EventLog -LogName System -InstanceId 1135 -ComputerName TPADWSQLGNXTA01,TPADWSQLGNXTB01 -Newest 1
Get-EventLog -LogName System -EntryType Error
#1135 - Cluster Node was removed from the active failover cluster membership.
#1564 / 1562 - File share witness
#1069 - 'SQL Server Availability Group' in clustered role failed

$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [ServerName] FROM [CMS].[dbo].[DbaAGServer] WHERE [PreferredPrimary] <>'';" -TrustServerCertificate
foreach($server in $servers.ServerName)
{ Get-EventLog -LogName System -InstanceId 1135 -ComputerName $server -Newest 1
 }