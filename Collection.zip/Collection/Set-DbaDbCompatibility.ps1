﻿Import-Module dbatools -EA SilentlyContinue 
Set-DbaDbCompatibility -SqlInstance TPAUWSQLDL002
