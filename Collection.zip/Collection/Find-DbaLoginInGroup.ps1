﻿Import-Module dbatools -EA SilentlyContinue 
Find-DbaLoginInGroup -SqlInstance TPAPWSQLMHA001  | Where-Object Login -like '*ms46468*'


