﻿CREATE TABLE [Inventory].[HighAvailabilityInfo]
(
	SqlInstance VARCHAR(256) NOT NULL,
	LogShippingEnabled VARCHAR(5) NULL,
	DbMirrorEnabled VARCHAR(5) NULL,
	ReplicationEnabled VARCHAR(5) NULL,
	CONSTRAINT FK_HighAvailabilityInfo_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
)
