﻿/*
	Created by HPS\a-sm58408 using dbatools Export-DbaScript for objects on TPAPWDWSQL004 at 01/06/2025 06:21:02
	See https://dbatools.io/Export-DbaScript for more information
*/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DS006_TSX_Metrics_JobStatus', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'ICT_DL_SQL', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Job Status Metrics', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF OBJECT_ID(''tempdb..#Results'') IS NOT NULL
    DROP TABLE #Results

IF OBJECT_ID(''tempdb..##ResultsJS'') IS NOT NULL
    DROP TABLE ##ResultsJS




SET  NOCOUNT ON
DECLARE @MaxLength   INT
SET @MaxLength   = 50
DECLARE @xp_results TABLE (

                      job_id uniqueidentifier NOT NULL,
                      last_run_date nvarchar (20) NOT NULL,
                      last_run_time nvarchar (20) NOT NULL,
                      next_run_date nvarchar (20) NOT NULL,
                      next_run_time nvarchar (20) NOT NULL,
                      next_run_schedule_id INT NOT NULL,
                      requested_to_run INT NOT NULL,
                      request_source INT NOT NULL,
                      request_source_id sysname
                            COLLATE database_default NULL,
                      running INT NOT NULL,
                      current_step INT NOT NULL,
                      current_retry_attempt INT NOT NULL,
                      job_state INT NOT NULL
                   )


DECLARE @job_owner   sysname
DECLARE @is_sysadmin   INT
SET @is_sysadmin   = isNULL (is_srvrolemember (''sysadmin''), 0)
SET @job_owner   = suser_sname ()
INSERT INTO @xp_results

  EXECUTE sys.xp_sqlagent_enum_jobs @is_sysadmin, @job_owner


UPDATE @xp_results

  SET last_run_time    = right (''000000'' + last_run_time, 6),
      next_run_time    = right (''000000'' + next_run_time, 6)


SELECT j.name AS JobName,

      j.enabled AS Enabled,
      CASE x.running
         WHEN 1
         THEN
            ''Running''
         ELSE
            CASE h.run_status
               WHEN 2 THEN ''Inactive''
               WHEN 4 THEN ''Inactive''
               ELSE ''Completed''
            END
      END
         AS CurrentStatus,
      coalesce (x.current_step, 0) AS CurrentStepNbr,
      CASE
         WHEN x.last_run_date > 0
         THEN
            convert (datetime,
                       substring (x.last_run_date, 1, 4)
                     + ''-''
                     + substring (x.last_run_date, 5, 2)
                     + ''-''
                     + substring (x.last_run_date, 7, 2)
                     + '' ''
                     + substring (x.last_run_time, 1, 2)
                     + '':''
                     + substring (x.last_run_time, 3, 2)
                     + '':''
                     + substring (x.last_run_time, 5, 2)
                     + ''.000'',
                     121
            )
         ELSE
            NULL
      END
         AS LastRunTime,
      CASE h.run_status
         WHEN 0 THEN ''Fail''
         WHEN 1 THEN ''Success''
         WHEN 2 THEN ''Retry''
         WHEN 3 THEN ''Cancel''
         WHEN 4 THEN ''In progress''
      END
         AS LastRunOutcome,

      CASE
         WHEN h.run_duration > 0
         THEN
              (h.run_duration / 1000000) * (3600 * 24)
            + (h.run_duration / 10000 % 100) * 3600
            + (h.run_duration / 100 % 100) * 60
            + (h.run_duration % 100)
         ELSE
            NULL
      END
         AS LastRunDuration
 INTO #Results
 FROM          @xp_results x
            LEFT JOIN
               msdb.dbo.sysjobs j
            ON x.job_id = j.job_id
         LEFT OUTER JOIN
            msdb.dbo.syscategories c
         ON j.category_id = c.category_id
      LEFT OUTER JOIN
         msdb.dbo.sysjobhistory h
      ON     x.job_id = h.job_id
         AND x.last_run_date = h.run_date
         AND x.last_run_time = h.run_time
         AND h.step_id = 0




SELECT @@SERVERNAME AS Servername, JobName, Enabled, CONVERT(CHAR(8), LastRunTime,112) AS DateKey, 
	CONVERT(CHAR,LastRunTime,108) AS TimeKey, LastRunOutCome ,

CASE LastRunOutcome
		WHEN ''Fail'' THEN 1  --Critical for Health Metrics
		WHEN ''Success'' THEN 3  --OK for Health Metrics
		WHEN ''In progress'' THEN 3  --OK for Health Metrics
		WHEN ''Cancel'' THEN 2  --Warning for Health Metrics (why was it cancelled)
		WHEN ''Retry'' THEN 2  --Warning for Health Metrics (find out why it is retrying)
		ELSE ''Unknown''
	  END 
		AS StatusLevel, ISNULL(LastRunDuration,'''') AS LastRunDuration
INTO ##ResultsJS
FROM #Results
WHERE LastRunTime > GETDATE() - 1



DECLARE @sql varchar(8000)
DECLARE @MachineName varchar(100)
DECLARE @InstanceName varchar(100)
DECLARE @FileName varchar(250)
SET @MachineName = (SELECT CONVERT(varchar(250),SERVERPROPERTY(''MachineName'')))
SET @InstanceName = (SELECT CONVERT(varchar(250),SERVERPROPERTY(''InstanceName'')))

IF @InstanceName IS NULL 
   SET @FileName = @MachineName + ''JobStatus'' + CONVERT(char(8),GETDATE(),112) + ''.txt''
ELSE
   SET @FileName = @MachineName + ''_'' + @InstanceName + ''JobStatus'' + CONVERT(char(8),GETDATE(),112) + ''.txt''


SELECT @sql = ''bcp ##ResultsJS out \\hps-tpa-vast.hps.hph.ad\SqlProd\SQLMetrics\JobStatus\'' + @FileName + '' -c -t"," -T -S''+ @@servername
PRINT @sql
exec master..xp_cmdshell @sql


', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily @ 5:30AM', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140317, 
		@active_end_date=99991231, 
		@active_start_time=53000, 
		@active_end_time=235959, 
		@schedule_uid=N'02109ddc-2a12-4fee-9a9f-eda49f4174c1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

