﻿clear
Import-Module dbatools -EA SilentlyContinue
#Import-DbaCsv -Path D:\temp\housing.csv -SqlInstance sql001 -Database markets
Import-DbaCsv -Path X:\Monthly_Release.csv -SqlInstance TPAPWMSSQL002 -database CMS -Table Monthly_Release -NoHeaderRow
#Import-DbaCsv -Path X:\NICE.csv -SqlInstance TPAPWSQLARCH01 -database Recording_DB  -Table CallDetails2 -NoHeaderRow

#Import-DbaCsv -Path X:\dbo.CallDetails2.csv -SqlInstance TPAPWSQLARCH01 -Database Recording_DB -Column URL,[UNC PATH],Path,[File Name],Status,[Segment ID],[Segment Start Date],[Segment Start Time],[Segment Stop Date],[Segment Stop Time],[Segment Stop],[Internal Segment Client Start Date],[Internal Segment Client Start Time],[Internal Segment Client Stop Date],[Internal Segment Client Stop Time],[Participant Time],[Participant Station],[Segment UCID],[Participant Trunk Group],[Participant Trunk Number],[Segment Dialed Number],[Participant Phone Number],[Segment Call Direction Type ID],[Participant Agent ID],[Full Name],[Queue Name],[Last Name],[First Name],[Case ID],[Customer Identifier]