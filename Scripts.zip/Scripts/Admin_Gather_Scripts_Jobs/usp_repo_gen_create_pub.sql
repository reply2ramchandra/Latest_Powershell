USE [DBA]
GO

/****** Object:  StoredProcedure [dbo].[usp_repo_gen_create_pub]    Script Date: 11/18/2022 4:06:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[usp_repo_gen_create_pub]	@Publisher			Nvarchar(30)    = NULL -- Publisher name
										,@Subscriber		Nvarchar(256)	= NULL -- Subscriber CSV format
										,@force				Bit				= 0  -- 0 = Current repo security (default) ; 1 = Switch the SQL authenication
										,@OnlySubscriptions	Bit				= 0  -- 0 = Pub+Articles+Subs (default) ; 1 = ONLY ADD Subscription details
AS
	/***************************************************************************************************************************************
	 
	  Copyright(c) 2016 Harsha Vasa @ Ensono 
	  All rights reserved. No part of this script may be reproduced/shared in any form or by making any changes - without written 
	  permissions from the author
	 
	 Purpose: This is a generate script to extract publications, articles, articleview, sps, functions and exported to central repository 
	          for DR or emergency situations
			
	    ----------------------------------------------------------------------------------------------------------------------------------
		History:
		----------------------------------------------------------------------------------------------------------------------------------
		Author                                   Date Created                  Comments
		----------------------------------------------------------------------------------------------------------------------------------
		Harsha vasa                              2016-04-13                  Initial draft
	
		Harsha vasa	                             2016-05-18                  Added SETVAR variables and code improvements to scale in.
																			 Added @force parameter to switch existing replication to SQL
																			 authenication model and changes to config settings
	    
		Harsha vasa								 2016-07-05                  Added additional input parameter @OnlySubscriptions to define
		                                                                     only to generate scripts for subscriptions. This will skip creation
																			 of publication,articles,articleviews
		----------------------------------------------------------------------------------------------------------------------------------
	
	Documentation:
	--------------
	## Doesn't include Filter clauses
	
	
	Execution Samples: 
	------------------
	For all Subscribers -- Default
	1) EXEC dbo.usp_repo_gen_create_pub @Publisher = N'RRWIN-SQLDVALRT';
	
	For selected subscribers
	2) EXEC dbo.usp_repo_gen_create_pub @Publisher = N'RRWIN-SQLDVALRT',@Subscriber = N'RRWIN-SQLDVAPI,RRWIN-SQLDVSECU';

	force to switch authenication or Config settings 
	3) EXEC dbo.usp_repo_gen_create_pub @Publisher = N'RRWIN-SQLDVALRT',@Subscriber = N'RRWIN-SQLDVAPI,RRWIN-SQLDVSECU',@force = 1;

	Generate scripts Only to add subscriptions. We may need this setting only when there is a change in subscriber name or adding new subs to an existing publications
	4) EXEC dbo.usp_repo_gen_create_pub @Publisher = N'RRWIN-SQLDVALRT',@Subscriber = N'RRWIN-SQLDVAPI,RRWIN-SQLDVSECU',@OnlySubscriptions = 1

	***************************************************************************************************************************************/

	BEGIN
		SET NOCOUNT ON;
		SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

		-- start of declarting scalar & table variables

		DECLARE	@rOutput		Bit
				,@id			Int
				,@PublisherDb	Nvarchar(128)
				,@PubName		Nvarchar(256)
				,@eHelppub		Nvarchar(1000)
				,@eHelpArticle	Nvarchar(1000)
				,@eHelpView		Nvarchar(4000)
				,@eHelpArtCol	Nvarchar(4000)
				,@eBasePub		Nvarchar(Max)
				,@ArtAux		Nvarchar(256)
				,@ArtCount		Int;


		-- article
		DECLARE @HelpArticle TABLE (ArticleId								Int
									,ArticleName							Nvarchar(256)
									,BaseObject								Nvarchar(257)
									,DestinationObject						Nvarchar(256)
									,SyncObject								Nvarchar(257)
									,ArticleType							SmallInt
									,ArticleStatus							TinyInt
									,ArticleFilter							Nvarchar(257)
									,ArticleDescription						Nvarchar(255)
									,ArticleInsertCommand					Nvarchar(255)
									,ArticleUpdateCommand					Nvarchar(255)
									,ArticleDeleteCommand					Nvarchar(255)
									,ArticleCreationScriptPath				Nvarchar(255)
									,ArticleVerticalPos						Bit
									,ArticlePreCreationCmd					TinyInt
									,ArticleFilterClause					Nvarchar(Max)
									,ArticleSchemaOption					Binary(8)
									,ArticleDestOwner						Nvarchar(64)
									,ArticleSourceOwner						Nvarchar(64)
									,ArticleUnquaSourceObject				Nvarchar(128)
									,ArticleSyncObjOwner					Nvarchar(64)
									,ArticleUnqualifiedSrcObj				Nvarchar(128)
									,ArticleFilterOwner						Nvarchar(64)
									,ArticleUnquaFilter						Nvarchar(Max)
									,ArticleAutoIdentityRange				Int
									,ArticlePubIdentityRange				Int
									,ArticleIdentityRange					BigInt
									,ArticleIdentityThreshold				BigInt
									,AritcleIdentityRangeManagementOption	Int
									,FireTriggersOnSnapshot					Bit);

		-- columns
		DECLARE @HelpArticleColumns TABLE (	columnid		Int
											,columnname		SysName
											,published		Bit
											,publishertype	SysName
											,subscribertype	SysName);
		-- views
		DECLARE @HelpArticleView TABLE (ArticleName	Nvarchar(256)
										,ViewName	Nvarchar(256));

		-- snapshot schedule
		DECLARE @HelpSnapshotSchedule TABLE (	ID								Int
												,name							Nvarchar(100)
												,publisher_security_mode		SmallInt
												,publisher_login				Nvarchar(256)
												,publisher_password				Nvarchar(524)
												,job_id							UniqueIdentifier
												,job_login						Nvarchar(512)
												,job_password					Nvarchar(256)
												,schedule_name					Nvarchar(256)
												,frequency_type					Int
												,frequency_interval				Int
												,frequency_subday_type			Int
												,frequency_subday_interval		Int
												,frequency_relative_interval	Int
												,frequency_recurrence_factor	Int
												,active_start_date				Int
												,active_end_date				Int
												,active_start_time				Int
												,active_end_time				Int);


		DECLARE @DesiredPubDBs TABLE (PublisherDB SysName);

		-- end of declarating scalar & table variables


		-- final output table

		IF OBJECT_ID('tempdb..#ArtOutput') IS NOT NULL
			DROP TABLE #ArtOutput;

		CREATE TABLE #ArtOutput (	seq			Int	IDENTITY (1, 1)
									,pubdb		Varchar(128)
									,pubname	Varchar(256)
									,PubGen		Nvarchar(Max));

		IF OBJECT_ID('tempdb..#syspubs') IS NOT NULL
			DROP TABLE #syspubs;

		CREATE TABLE #syspubs (	ID					Int	IDENTITY (1, 1)
								,PublisherDB		Varchar(128)
								,PublicationName	Varchar(256)
								,SubType			Varchar(20)
								,Subscriber			Nvarchar(64)
								,SubscriberDB		Nvarchar(128)
								,[description]		Nvarchar(255)
								,sync_method		TinyInt
								,[retention]		Int
								,allow_push			Bit
								,allow_pull			Bit
								,repl_freq			TinyInt
								,snapshot_jobid		Binary(16)
								);
       -- create clustered index
	   CREATE CLUSTERED INDEX CIX_syspubs_Pubdb_Pubid_Subcriber ON #syspubs (PublisherDB, PublicationName, Subscriber);
       
	   -- if input @publisher is null
	   SET @Publisher = COALESCE(@Publisher,@@servername);

       -- server validation
	   -- start 
		IF @@servername != @Publisher
			BEGIN
				RAISERROR (N'Servername is not matched.Executed at wrong destination.Input server: %s', 16, 1, @Publisher) WITH NOWAIT;
				RETURN (1);
			END;
		-- end

		BEGIN TRY

			-- pull necessary publisher databases
			INSERT INTO @DesiredPubDBs
			SELECT name
			FROM sys.databases
			WHERE database_id > 4
			AND is_published = 1
			AND DATABASEPROPERTYEX(name, 'STATUS') = 'ONLINE';

			-- return if no dbs are enabled

			IF @@rowcount = 0
				BEGIN
					RAISERROR (N'no databases have been configured in replication topology.', 10, 1) WITH NOWAIT;
					RETURN;
				END;

			-- extract replication info
			SELECT @eBasePub = COALESCE(@eBasePub + ' UNION ALL ', '') + N'SELECT DISTINCT ' + QUOTENAME(PublisherDB, '''') + ',p.name,
		CASE WHEN s.subscription_type = 0 THEN ''push'' ELSE ''pull'' END,COALESCE(s.srvname,''''),COALESCE(s.dest_db,''''),p.[description],sync_method,[retention],allow_push,allow_pull,repl_freq,snapshot_jobid
		FROM ' + QUOTENAME(PublisherDB) + '.dbo.syspublications AS p
		LEFT JOIN ' + QUOTENAME(PublisherDB) + '.dbo.sysarticles AS a ON p.pubid = a.pubid
		LEFT JOIN ' + QUOTENAME(PublisherDB) + '.dbo.sysschemaarticles AS sac ON p.pubid = sac.pubid
		LEFT JOIN ' + QUOTENAME(PublisherDB) + '.dbo.syssubscriptions AS s ON (s.artid = a.artid OR s.artid = sac.artid) AND s.dest_db != ''virtual'''
			FROM @DesiredPubDBs;

			SET @eBasePub = @eBasePub+CHAR(13)+'OPTION (RECOMPILE)';

			-- reference tbl
			INSERT INTO #syspubs
			EXEC sys.sp_executesql @eBasePub;


			-- selected subscribers

			IF @Subscriber IS NOT NULL
				DELETE FROM #syspubs
				WHERE NOT EXISTS (SELECT 1
						FROM DBA.dbo.tfn_SplitStrings(@Subscriber, ',') tss
						WHERE Subscriber = tss.list
					);

			IF @OnlySubscriptions = 0
				BEGIN

					-- loop begins
					WHILE 1 = 1
					BEGIN

						SELECT TOP 1	@id = ID
										,@PublisherDb = S.PublisherDB
										,@PubName = S.PublicationName
						FROM #syspubs AS S
						WHERE ID > COALESCE(@id, 0)
						ORDER BY ID; --Publisherdb,PublicationName;

						-- break point

						IF @@rowcount = 0
							BREAK;

						-- fetch next record if pub already exists

						IF EXISTS (SELECT 1
							FROM #ArtOutput AS AO
							WHERE AO.pubdb = @PublisherDb
							AND AO.pubname = @PubName
						)
							CONTINUE;

						DELETE FROM @HelpSnapshotSchedule;
						DELETE FROM @HelpArticle;
						DELETE FROM @HelpArticleColumns;
						DELETE FROM @HelpArticleView;

						SET @ArtAux = NULL;

						-- load snapshot agent schedule
						SET @eHelppub = N'EXEC ' + QUOTENAME(@PublisherDb) + '.sys.sp_helppublication_snapshot @publication = @PubName;';

						INSERT INTO @HelpSnapshotSchedule
						EXEC sys.sp_executesql	@eHelppub
												,N'@PubName nvarchar(256)'
												,@PubName;

                        -- if snapshot agent wasn't created earlier load the default values
						IF @@rowcount = 0 
						BEGIN 						    
							INSERT INTO @HelpSnapshotSchedule (ID, name, publisher_security_mode, publisher_login, publisher_password, job_id, job_login, job_password, schedule_name, frequency_type, frequency_interval, frequency_subday_type, frequency_subday_interval, frequency_relative_interval, frequency_recurrence_factor, active_start_date, active_end_date, active_start_time, active_end_time)
	                        VALUES (1, @PubName, 1, NULL, NULL, NEWID(), NULL, NULL, NULL,4,1,1,1,1,0,0,0,CONVERT(varchar(8),CONVERT(varchar(2),ROUND(((24 -0 -1) * RAND() + 0), 0))+CONVERT(Varchar(2),ROUND(((59 -10 -1) * RAND() + 10), 0))+'00'),235959);
						END 

						IF @force = 1
							-- to override existing authenication to SQL
							UPDATE @HelpSnapshotSchedule
							SET publisher_security_mode = 0;

						-- load into ArtOutput

						INSERT INTO #ArtOutput
						-- header fro readability
						SELECT @PublisherDb AS Pubdb
							  ,@PubName AS PubName
						      ,'--### Publication Name:' + @PubName + ' ###--' UNION ALL
						-- add publication 
						SELECT DISTINCT	@PublisherDb AS Pubdb
										,@PubName AS PubName
										,'EXEC ' + QUOTENAME(PublisherDB) + '.sys.sp_addpublication @Publication = N' + CHAR(39) + PublicationName + CHAR(39) +
										',@description = N' + CHAR(39) + REPLACE([description], '''', '''''') + CHAR(39) +
										',@Sync_Method = N' + CHAR(39) + CASE
											WHEN sync_method = 0 THEN 'Native'
											WHEN sync_method = 1 THEN 'Character'
											WHEN sync_method = 3 THEN 'Concurrent'
											WHEN sync_method = 4 THEN 'Concurrent_C'
										END + CHAR(39) +
										',@retention = ' + CONVERT(Varchar(5), [retention]) +
										',@allow_push = N' + CHAR(39) + CASE
											WHEN allow_push = 1 THEN 'true'
											ELSE 'false'
										END + CHAR(39) +
										',@allow_pull = N' + CHAR(39) + CASE
											WHEN allow_pull = 1 THEN 'true'
											ELSE 'false'
										END + CHAR(39) +
										',@allow_anonymous = ''False''' +
										',@immediate_sync = ''False''' +
										CASE
											WHEN repl_freq = 1 THEN ',@repl_freq = N''Snapshot'''
											ELSE ''
										END +
										',@replicate_ddl = 1' +
										',@allow_initialize_from_backup = N''false''' +
										',@status = N''active''' + ';' + CHAR(13) + CHAR(10) + 'GO' COLLATE database_default
						FROM #syspubs
						WHERE PublisherDB = @PublisherDb
						AND PublicationName = @PubName UNION ALL
						-- publication snapshot properties
						SELECT	@PublisherDb AS Pubdb
								,@PubName AS PubName
								,'EXEC ' + QUOTENAME(@PublisherDb) + '.sys.sp_addpublication_snapshot	@publication = N' + CHAR(39) + @PubName + CHAR(39) +
								',@frequency_type = ' + CONVERT(Varchar(8), SSS.frequency_type) +
								',@frequency_interval = ' + CONVERT(Varchar(8), SSS.frequency_interval) +
								',@frequency_relative_interval = ' + CONVERT(Varchar(8), SSS.frequency_relative_interval) +
								',@frequency_recurrence_factor = ' + CONVERT(Varchar(8), SSS.frequency_recurrence_factor) +
								',@frequency_subday = ' + CONVERT(Varchar(8), SSS.frequency_subday_type) +
								',@frequency_subday_interval = ' + CONVERT(Varchar(8), SSS.frequency_subday_interval) +
								',@active_start_time_of_day = ' + CONVERT(Varchar(8), SSS.active_start_time) +
								',@active_end_time_of_day = ' + CONVERT(Varchar(8), COALESCE(SSS.active_end_time, 235959)) +
								',@active_start_date = ' + CONVERT(Varchar(8), 0) +
								',@active_end_date = ' + CONVERT(Varchar(8), 99991231) + CHAR(13) +
								',@publisher_security_mode = ' + CASE
									WHEN SSS.publisher_security_mode = 0 OR
										@force = 1 THEN '0, @publisher_login = $(repllink_login), @publisher_password = $(repllink_password)'
									ELSE '1'
								END + ';' + CHAR(13) + CHAR(10) + 'GO' COLLATE database_default
						FROM @HelpSnapshotSchedule AS SSS;

						-- load all articles in the publication
						SET @eHelpArticle = N'EXEC ' + QUOTENAME(@PublisherDb) + '.sys.sp_helparticle @publication = @PubName;';

						INSERT INTO @HelpArticle
						EXEC sys.sp_executesql	@eHelpArticle
												,N'@PubName nvarchar(256)'
												,@PubName;

						-- inner loop to fetch all article properties. selected columns, views etc..
						WHILE 1 = 1
						BEGIN

							DELETE FROM @HelpArticleColumns;
							DELETE FROM @HelpArticleView;

							SET @eHelpView = NULL;
							SET @eHelpArtCol = NULL;
							SET @ArtCount = NULL;

							SELECT TOP 1	@ArtAux = ArticleName
											,@ArtCount = ArticleType
							FROM @HelpArticle
							WHERE ArticleName > COALESCE(@ArtAux, '')
							ORDER BY ArticleName;

							IF @@rowcount = 0
								BREAK;

							IF (@ArtCount = 1) -- only log based articles
								BEGIN

									-- check if all columns are selected
									SET @eHelpView = 'SELECT sa.name as ArticleName, o.name AS ViewName FROM ' + QUOTENAME(@PublisherDb) + '.dbo.sysarticles AS sa 
					INNER JOIN ' + QUOTENAME(@PublisherDb) + '.sys.objects AS o ON sa.sync_objid = o.[object_id]
					INNER JOIN ' + QUOTENAME(@PublisherDb) + '.dbo.syspublications AS sp ON sa.pubid = sp.pubid 
					CROSS APPLY (SELECT COUNT(sc.column_id) AS colcnt FROM ' + QUOTENAME(@PublisherDb) + '.sys.columns AS sc WHERE sa.[Objid] = sc.[object_id]) ca1
	                CROSS APPLY (SELECT COUNT(colid) AS artcolcnt FROM ' + QUOTENAME(@PublisherDb) + '.dbo.sysarticlecolumns AS sac WHERE sa.artid = sac.artid) ca2
					WHERE sp.name = @Pubname AND sa.name = @Article AND ca1.colcnt != ca2.artcolcnt;';

									INSERT INTO @HelpArticleView
									EXEC sys.sp_executesql	@eHelpView
															,N'@Pubname nvarchar(256),@Article nvarchar(256)'
															,@PubName
															,@ArtAux;

									-- not required to proceed further if all cols are selected fetch next log based article    
									IF @@rowcount != 0
										BEGIN
											-- columns check dynamic
											SET @eHelpArtCol = N'EXEC ' + QUOTENAME(@PublisherDb) + '.sys.sp_helparticlecolumns  @publication = N' + CHAR(39) + @PubName + CHAR(39) + ', @article = N' + CHAR(39) + @ArtAux + CHAR(39);

											INSERT INTO @HelpArticleColumns
											EXEC sys.sp_executesql @eHelpArtCol;
										END;

								END;
							-- load the article props into genout

							INSERT INTO #ArtOutput
							-- add article 
							SELECT	@PublisherDb AS Pubdb
									,@PubName AS PubName
									,'EXEC ' + QUOTENAME(@PublisherDb) + '.sys.sp_addarticle @Publication = N' + CHAR(39) + @PubName + CHAR(39) +
									',@article = N' + CHAR(39) + ArticleName + CHAR(39) +
									',@source_owner = N' + CHAR(39) + ArticleSourceOwner + CHAR(39) +
									',@source_object = N' + CHAR(39) + ArticleUnquaSourceObject + CHAR(39) +
									',@pre_creation_cmd = N' + CHAR(39) + CASE
										WHEN ArticlePreCreationCmd = 0 THEN 'NONE'
										WHEN ArticlePreCreationCmd = 1 THEN 'DROP'
										WHEN ArticlePreCreationCmd = 2 THEN 'DELETE'
										WHEN ArticlePreCreationCmd = 3 THEN 'TRUNCATE'
										ELSE 'NULL'
									END + CHAR(39) +
									',@destination_table = N' + CHAR(39) + DestinationObject + CHAR(39) +
									',@destination_owner = N' + CHAR(39) + COALESCE(ArticleDestOwner, ArticleSourceOwner) + CHAR(39) +
									',@schema_option = ' + sys.fn_varbintohexstr(ArticleSchemaOption) + -- 0x00000000000358DF Proposal to Make Default Schema Option
									',@identityrangemanagementoption = N' + CHAR(39) + CASE AritcleIdentityRangeManagementOption
										WHEN 0 THEN 'none'
										WHEN 1 THEN 'auto'
										WHEN 2 THEN 'manual'
										ELSE ''
									END + CHAR(39) +
									',@type = N' + CHAR(39) + CASE ArticleType
										WHEN 1 THEN 'logbased'
										WHEN 8 THEN 'proc exec'
										WHEN 32 THEN 'proc schema only'
										WHEN 64 THEN 'view schema only'
										WHEN 128 THEN 'func schema only'
									END + CHAR(39) +
									',@status = ' + CASE
										WHEN ArticleStatus IN (1, 8, 16, 24) THEN CONVERT(Varchar(2), ArticleStatus)
										ELSE CONVERT(Varchar(2), (ArticleStatus ^ 1))
									END + -- 16 is default
									CASE
										WHEN CONVERT(BigInt, ArticleSchemaOption) = 1 THEN ''
										ELSE ',@ins_cmd = N' + CHAR(39) + COALESCE(ArticleInsertCommand, '') + CHAR(39) +
											',@del_cmd = N' + CHAR(39) + COALESCE(ArticleDeleteCommand, '') + CHAR(39) +
											',@upd_cmd = N' + CHAR(39) + COALESCE(ArticleUpdateCommand, '') + CHAR(39)
									END + ';'
							FROM @HelpArticle
							WHERE ArticleName = @ArtAux UNION ALL
							-- add article columns
							SELECT	@PublisherDb AS Pubdb
									,@PubName AS PubName
									,COALESCE('EXEC ' + QUOTENAME(@PublisherDb) + '.sys.sp_articlecolumn @publication = N' + CHAR(39) + @PubName + CHAR(39) +
									',@article = N' + CHAR(39) + @ArtAux + CHAR(39) +
									',@column = N' + CHAR(39) + columnname + CHAR(39) +
									',@operation = N''add'', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1 ;', '--')
							FROM @HelpArticleColumns UNION ALL
							-- views
							SELECT	@PublisherDb AS Pubdb
									,@PubName AS PubName
									,COALESCE('EXEC ' + QUOTENAME(@PublisherDb) + '.sys.sp_articleview @publication = N' + CHAR(39) + @PubName + CHAR(39) +
									',@article = N' + CHAR(39) + ArticleName + CHAR(39) +
									',@view_name = N' + CHAR(39) + ViewName + CHAR(39) +
									',@filter_clause = N'''', @force_invalidate_snapshot = 1, @force_reinit_subscription = 1 ;', '--')
							FROM @HelpArticleView UNION ALL
							SELECT	@PublisherDb AS Pubdb
									,@PubName AS PubName
									,CHAR(10) + 'GO' COLLATE database_default;
                           
						   -- future version:
						   -- sp_articlefilter : ADD FILTER clauses
						   -- Additional parameter = @filter_clause = N'' in 
						   -- sp_addarticle
						   -- sp_articleview
						    
						END;
						-- add subscription
						INSERT INTO #ArtOutput
						SELECT	@PublisherDb AS Pubdb
								,@PubName AS PubName
								,'EXEC ' + QUOTENAME(PublisherDB) + '.sys.sp_addsubscription @Publication = N' + CHAR(39) + PublicationName + CHAR(39) +
								',@article = N''all''' +
								',@Subscriber = N' + CHAR(39) + Subscriber + CHAR(39) +
								',@destination_db = N' + CHAR(39) + SubscriberDB + CHAR(39) +
								',@subscription_type = ' + CASE
									WHEN @force = 1 THEN '$(subscriptionType)'
									ELSE CHAR(39) + SubType + CHAR(39)
								END +
								',@sync_type = N''automatic'',@update_mode = N''read only'',@subscriber_type = 0 ;' + CHAR(13) +
								-- add subscription agent use SQL Authenication if any of agent uses
								'EXEC ' + QUOTENAME(PublisherDB) + '.sys.sp_addpushsubscription_agent @Publication = N' + CHAR(39) + PublicationName + CHAR(39) +
								',@Subscriber = N' + CHAR(39) + Subscriber + CHAR(39) +
								',@subscriber_db = N' + CHAR(39) + SubscriberDB + CHAR(39) +
								',@subscriber_security_mode = ' + CASE
									WHEN EXISTS (SELECT 1
											FROM @HelpSnapshotSchedule
											WHERE publisher_security_mode = 0
										) OR
										@force = 1 THEN '0, @subscriber_login = $(repllink_login),@subscriber_password= $(repllink_password)'
									ELSE '1'
								END + ';' + CHAR(13) + CHAR(10) + 'GO' COLLATE database_default
						FROM #syspubs
						WHERE PublisherDB = @PublisherDb
						AND PublicationName = @PubName
						AND Subscriber <> '';

					END;
				END; ELSE IF @OnlySubscriptions = 1  -- only ADD subscription scripts
				BEGIN
					-- add subscription
					INSERT INTO #ArtOutput
					SELECT	PublisherDB
							,PublicationName
							,'EXEC ' + QUOTENAME(PublisherDB) + '.sys.sp_addsubscription @Publication = N' + CHAR(39) + PublicationName + CHAR(39) +
							',@article = N''all''' +
							',@Subscriber = N' + CHAR(39) + Subscriber + CHAR(39) +
							',@destination_db = N' + CHAR(39) + SubscriberDB + CHAR(39) +
							',@subscription_type = ' + CASE
								WHEN @force = 1 THEN '$(subscriptionType)'
								ELSE CHAR(39) + SubType + CHAR(39)
							END +
							',@sync_type = N''automatic'',@update_mode = N''read only'',@subscriber_type = 0 ;' + CHAR(13) +
							-- add subscription agent use SQL Authenication if any of agent uses
							'EXEC ' + QUOTENAME(PublisherDB) + '.sys.sp_addpushsubscription_agent @Publication = N' + CHAR(39) + PublicationName + CHAR(39) +
							',@Subscriber = N' + CHAR(39) + Subscriber + CHAR(39) +
							',@subscriber_db = N' + CHAR(39) + SubscriberDB + CHAR(39) +
							',@subscriber_security_mode = ' + CASE
								WHEN EXISTS (SELECT 1
										FROM @HelpSnapshotSchedule
										WHERE publisher_security_mode = 0
									) OR
									@force = 1 THEN '0, @subscriber_login = $(repllink_login),@subscriber_password= $(repllink_password)'
								ELSE '1'
							END + ';' + CHAR(13) + CHAR(10) + 'GO' COLLATE database_default
					FROM #syspubs;
				END;

			-- final output
			SELECT t.PubGenOut AS [--PubGenOut]
			FROM (SELECT	0 AS seq
							,'/' + REPLICATE('*', 5) + SPACE(1) + N'All scripts below should be run in SQLCMD mode. To Enable this mode - SSMS >> Query (Menu) >> Click SQLCMD mode option.' + SPACE(1) + REPLICATE('*', 5) + '/' + CHAR(10) AS [PubGenOut] UNION ALL
				SELECT	0 AS seq
						,'/' + REPLICATE('*', 5) + SPACE(1) + 'SETVAR variables should be enclosed in single quotes' + SPACE(1) + REPLICATE('*', 5) + '/' UNION ALL
				-- setting variables
				SELECT	0 AS seq
						,':SETVAR distributor '+ CHAR(39) + data_source + CHAR(39)
				FROM sys.servers WHERE name = 'repl_distributor' UNION ALL
				SELECT	0 AS seq
						,':SETVAR distadmin_password ''''' UNION ALL
				SELECT	0 AS seq
						,':SETVAR repllink_login ''''' UNION ALL
				SELECT	0 AS seq
						,':SETVAR repllink_password ''''' UNION ALL
				SELECT	0 AS seq
						,':SETVAR subscriptionType ''''' UNION ALL
				SELECT	0 AS seq
						,':CONNECT' + SPACE(1) + UPPER(@Publisher) AS [--PubGenOut--] UNION ALL
				SELECT	0 AS seq
						,'USE [master];' + CHAR(10) + 'EXEC AS LOGIN = ''sa''' + CHAR(10) UNION ALL
				-- remote distributor
				SELECT	0 AS seq
						,CASE
							WHEN S.data_source = @Publisher THEN '--'
							ELSE SPACE(0)
						END + 'EXEC sp_adddistributor @distributor = ' + CASE
							WHEN S.data_source <> @Publisher OR
								@force = 1 THEN '$(distributor)'
							ELSE CHAR(39) + S.data_source + CHAR(39)
						END + ',@password = ' + CASE
							WHEN S.data_source <> @Publisher OR
								@force = 1 THEN '$(distadmin_password) -- if using remote distributor, distributor_admin password required'
							ELSE ''''''
						END + CHAR(13) + CHAR(10) + 'GO' COLLATE database_default
				FROM sys.servers AS S
				WHERE S.name = 'repl_distributor' UNION ALL
				SELECT	0 AS seq
						,'EXEC sys.sp_replicationdboption @dbname = N' + CHAR(39) + PublisherDB + CHAR(39) + ',@optname = N''Publish''' + ',@value = N''true''' + ';' + CHAR(13) + CHAR(10) + 'GO' COLLATE database_default
				FROM @DesiredPubDBs UNION ALL
				SELECT DISTINCT	0 AS seq
								,'EXEC ' + QUOTENAME(PublisherDB) + '.sys.sp_addlogreader_agent @job_login = null, @job_password = null, @publisher_security_mode = ' +
								CASE
									WHEN @force = 1 OR
										EXISTS (SELECT 1
											FROM @HelpSnapshotSchedule
											WHERE publisher_security_mode = 0
										) THEN '0, @publisher_login = $(repllink_login), @publisher_password = $(repllink_password) -- PasswordRequired '
									ELSE '1'
								END + ';' + CHAR(13) + CHAR(10) + 'GO' COLLATE database_default
				FROM @DesiredPubDBs UNION ALL
				SELECT	seq
						,PubGen
				FROM #ArtOutput
			) t
			ORDER BY t.seq;

			SET @rOutput = 0;

		END TRY
		BEGIN CATCH
			DECLARE @rErr Nvarchar(4000);
			SET @rErr = ERROR_MESSAGE() + CAST(ERROR_LINE() AS Varchar(5));
			RAISERROR (@rErr, 11, 1);
			SET @rOutput = 1;
		END CATCH;

		DROP TABLE #ArtOutput;
		DROP TABLE #syspubs;

	END;

GO


