﻿Import-Module dbatools 
Find-DbaOrphanedFile -SqlInstance sqlserver2014a
