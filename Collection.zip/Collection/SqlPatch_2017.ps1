﻿##https://sqlserverbuilds.blogspot.com/
#refer Get-DbaAgentJob to start the DIFF Backup job
$server='TPAPWANALYTIC01'
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="E:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
#copy patch file
$patchfile= Get-ChildItem X:\SQLISO\CU -Filter '*2017*' 
$source=$patchfile.FullName  
$target="E:\patch"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s
Import-Module dbatools -EA SilentlyContinue 
#Restart-Computer -ComputerName $server -Force
$server='TPAPWANALYTIC01'
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -KB 5029376 -Restart -Path E:\patch -Confirm:$false