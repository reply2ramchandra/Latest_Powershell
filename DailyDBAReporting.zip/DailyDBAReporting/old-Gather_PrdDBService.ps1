﻿Clear-Host

# Configuration
$collectionSql = 'tpapwmssql002'
$collectionDb  = 'CMS'
$outputRoot    = '\\tpapwmssql002\Reports'
$reportPrefix  = 'PrdDb'
$runDateTime   = Get-Date -Format 'yyyyMMdd'
$serviceFlag   = $false
$serverFlag    = $false

# Modules
Import-Module dbatools -ErrorAction SilentlyContinue
Import-Module SQLServer -ErrorAction SilentlyContinue  # If not strictly needed, you can remove this.
Set-DbatoolsInsecureConnection -SessionOnly

# Prep target tables
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "DROP TABLE IF EXISTS [CMS].[dbo].[PrdDbaService];" -TrustServerCertificate
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "DELETE FROM [CMS].[dbo].[PrdDBSrvStatus];" -TrustServerCertificate

# Get active servers
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query @"
SELECT TRIM([HostName]) AS HostName
FROM [CMS].[dbo].[DBServer]
WHERE [Status] IN ('Y','R')
  AND HostName NOT IN ('localhost','TPAPWSQLSSRS-03')
  AND Category = 'PROD';
"@ -TrustServerCertificate

if (-not $servers -or $servers.Count -eq 0) {
    Write-Warning "No servers returned from inventory. Exiting."
    return
}

$totalServers = $servers.Count

# Collect services
foreach ($sqlServer in $servers.HostName) {
    try {
        $prdDbaService = Get-DbaService -ComputerName $sqlServer -ErrorAction Stop |
            Where-Object { $_.ServiceType -in 'Engine','Agent' } |
            Select-Object @{n='DateKey';e={(Get-Date).ToString('yyyy-MM-dd HH:mm:ss')}}, PSComputerName, ComputerName,
                          DisplayName, ServiceType, ServiceName, StartMode, State, StartName
        if ($prdDbaService) {
            Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema dbo -Table PrdDbaService `
                -InputObject $prdDbaService -AutoCreateTable -KeepNulls
        } else {
            Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "
                INSERT INTO [CMS].[dbo].[PrdDBSrvStatus] (HostName, Comments)
                VALUES (N'$sqlServer', N'No Engine/Agent services returned');
            " -TrustServerCertificate
        }
    }
    catch {
        Write-Warning "Failed to query $sqlServer : $_"
        Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "
            INSERT INTO [CMS].[dbo].[PrdDBSrvStatus] (HostName, Comments)
            VALUES (N'$sqlServer', N'Unreachable');
        " -TrustServerCertificate
    }
}

# CSS and HTML fragments
$css = @"
<style>
table { border-collapse: collapse; width:100%; font-family:Verdana,Arial; font-size:11px; }
th, td { border:1px solid #444; padding:4px 6px; text-align:left; }
th { background-color:#D6EEEE; }
tr:nth-child(even) { background-color: rgba(150,212,212,0.35); }
</style>
"@

$preContentAll = @"
<h3><font face=verdana color=blue>PROD Server DB Service Report</font></h3>
<p>This report lists DB Engine and Agent service status across PROD servers.</p>
"@

$preContentDown = @"
<h3><font face=verdana color=blue>PROD Server DB Service Down Report</font></h3>
<p>This report shows servers where required DB services are not Running or are unreachable.</p>
"@

$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Review and act as needed.</font></p>
"@

# Queries for report data
$allServices = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "
    SELECT [DateKey],[ComputerName],[DisplayName],[ServiceType],[ServiceName],[StartMode],[State]
    FROM [CMS].[dbo].[PrdDbaService];
" -TrustServerCertificate | Select-Object * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors

$downServices = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "
    SELECT [DateKey],[ComputerName],[DisplayName],[ServiceType],[ServiceName],[StartMode],[State]
    FROM [CMS].[dbo].[PrdDbaService]
    WHERE [State] <> 'Running';
" -TrustServerCertificate | Select-Object * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors

$unreachable = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "
    SELECT [HostName],[Comments] FROM [CMS].[dbo].[PrdDBSrvStatus];
" -TrustServerCertificate | Select-Object * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors

$totalChecked = ($allServices | Where-Object ServiceType -eq 'Engine').Count

# Paths
$serviceReportPath       = Join-Path $outputRoot "${reportPrefix}servicestat$runDateTime.htm"
$serviceReportColored    = Join-Path $outputRoot "${reportPrefix}servicestatN$runDateTime.htm"
$downServiceReportPath   = Join-Path $outputRoot "${reportPrefix}serviceDown$runDateTime.htm"
$unreachableReportPath   = Join-Path $outputRoot "${reportPrefix}SrvUnreachable$runDateTime.htm"

# Build main services report (without summary yet)
$servicesHtml = $allServices |
    ConvertTo-Html -Property DateKey,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State `
        -Head $css -Title "PROD Server DB Service Report" -PreContent $preContentAll -PostContent $postContent

$servicesHtml | Out-File -FilePath $serviceReportPath -Encoding UTF8

# Apply coloring ONLY if there are any non-running services
if ($downServices.Count -gt 0) {
    $serviceFlag = $true
    # Color before appending summary to avoid header mismatch
    try {
        . "D:\PSScripts\DailyDBAReporting\Set-CellColor.ps1"
        (Get-Content -Path $serviceReportPath -Raw) |
            Set-CellColor -Header State -Color Yellow -Filter "State -notlike '*Running*'" |
            Out-File -FilePath $serviceReportColored -Encoding UTF8
    }
    catch {
        Write-Warning "Failed to color cells: $_"
        Copy-Item $serviceReportPath $serviceReportColored -Force
    }

    # Produce separate down service report
    $downServices | ConvertTo-Html -Property DateKey,ComputerName,DisplayName,ServiceType,ServiceName,StartMode,State `
        -Head $css -Title "PROD Server DB Service Down Report" -PreContent $preContentDown -PostContent $postContent |
        Out-File -FilePath $downServiceReportPath -Encoding UTF8
} else {
    # No down services; colored == original
    Copy-Item $serviceReportPath $serviceReportColored -Force
}

# Unreachable servers report (if any)
if ($unreachable.Count -gt 0) {
    $serverFlag = $true
    $unreachable |
        ConvertTo-Html -Property HostName,Comments -Head $css -Title "Unreachable PROD DB Servers" `
        -PreContent "<h3><font face=verdana color=blue>Unreachable PROD DB Servers</font></h3>" `
        -PostContent $postContent |
        Out-File -FilePath $unreachableReportPath -Encoding UTF8
}

# Append summary table AFTER coloring
$summaryTable = @"
<table>
<tr><th>Total_Servers_To_Check</th><td bgcolor='#F0FF33'>$totalServers</td>
    <th>Total_Engine_Services_Collected</th><td bgcolor='#F0FF33'>$totalChecked</td></tr>
</table>
"@
Add-Content -Path $serviceReportColored -Value $summaryTable

# Build mail body & attachments
$attachments = @($serviceReportColored)

$mailSubject = ''
$mailBody    = ''

if ($serviceFlag -or $serverFlag) {
    Write-Host "Sending mail: PROD DB service issues detected."

    $htmlSections = @()
    if ($serverFlag) { $htmlSections += (Get-Content -Path $unreachableReportPath -Raw) }
    if ($serviceFlag) { $htmlSections += (Get-Content -Path $downServiceReportPath -Raw) }

    $mailBody = ($htmlSections -join "<hr>")
    $mailSubject = 'Alert: PROD Server DB Service / Connectivity Issues'

    if ($serviceFlag) { $attachments += $downServiceReportPath }
    if ($serverFlag)   { $attachments += $unreachableReportPath }
} else {
    Write-Host "Sending mail: All services running."
    $mailSubject = 'PROD Server DB Service Report - All Healthy'
    $mailBody = "<h4><font face=verdana color=green>All PROD server DB services are running normally.</font></h4>"
}

# Deduplicate attachments
$attachments = $attachments | Get-Unique

# NOTE: Send-MailMessage is deprecated; consider using Send-MailKitMessage or other modern module.
Send-MailMessage -From 'DBA_Report@Healthplan.com' `
    -To 'WHPS-MSSQL-Admins@wipro.com' `
    -Subject $mailSubject `
    -SmtpServer 'smtprelay.healthplan.com' `
    -Body $mailBody -BodyAsHtml `
    -Attachments $attachments

Write-Host "Report generation complete."