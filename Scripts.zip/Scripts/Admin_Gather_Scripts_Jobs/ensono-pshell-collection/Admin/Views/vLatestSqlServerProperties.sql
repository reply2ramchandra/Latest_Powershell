﻿CREATE VIEW [Admin].[vLatestSqlServerProperties]
AS
	SELECT
		[ip].DateKey
	   ,[ip].SqlInstance
	   ,STUFF( [ip].Edition,CHARINDEX( 'Edition',[ip].Edition ),LEN( [ip].Edition ),'' ) AS [Edition]
	   ,sl.IPAddress
       ,CASE sl.Environment
            WHEN 'P' THEN 'Production'
            WHEN 'T' THEN 'Test'
            WHEN 'U' THEN 'UAT'
            WHEN 'S' THEN 'Stage'
            WHEN 'D' THEN 'Development'
            WHEN 'Q' THEN 'QA'
            WHEN 'O' THEN 'PreProd'
            WHEN 'R' THEN 'DR'
	    END AS [EnvironmentType]
	   ,CASE CAST( REPLACE( LEFT( [ip].[Version],2 ),'.','' ) AS TINYINT )
            WHEN 9 THEN 'SQL Server 2005'
            WHEN 10 THEN 'SQL Server 2008'
            WHEN 11 THEN 'SQL Server 2012'
            WHEN 12 THEN 'SQL Server 2014'
            WHEN 13 THEN 'SQL Server 2016'
            WHEN 14 THEN 'SQL Server 2017'
            WHEN 15 THEN 'SQL Server 2019'
	    END AS [Version]
	   ,[ip].IsClustered
	   ,COALESCE( [ip].IsHadrEnabled,'False' ) AS IsHadrEnabled
	   ,COALESCE( hai.LogShippingEnabled,'False') AS LogShippingEnabled
	   ,COALESCE( hai.DbMirrorEnabled,'False') AS DbMirrorEnabled
	   ,COALESCE( hai.ReplicationEnabled,'False') AS ReplicationEnabled
	   ,UPPER([ip].NetName)					   AS MachineName
	   ,[ip].ServiceAccount
	   ,[ip].[Collation]
	   ,[ip].ProductLevel
	   ,[ip].ProductUpdateLevel
	   ,[ip].PhysicalMemory
	   ,[ip].MaxMemoryInMB
	   ,[ip].Processors
	   ,[ip].[MaxDOP]
	   ,[ip].CostThreshold
	FROM Inventory.[SqlServerProperties] AS [ip] 
	INNER JOIN Inventory.ServerList AS [sl] ON sl.SqlInstance = [ip].[SqlInstance]
	AND [ip].DateKey = (SELECT TOP 1 DateKey FROM Inventory.[SqlServerProperties] ORDER BY DateKey DESC)
	LEFT OUTER JOIN Inventory.HighAvailabilityInfo AS hai ON sl.SqlInstance = hai.SqlInstance
GO