﻿[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$CollectorInstance = 'tpapwmssql002',
    [string]$CollectorDatabase = 'CMS',
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [string]$InstancesFile     = 'T:\Test\100924.txt',
    [ValidateScript({ Test-Path $_ -PathType Container })]
    [string]$BackupQueryFolder = 'X:\SQLPostBuild\DBBackup',
    [ValidateScript({ Test-Path $_ -PathType Container })]
    [string]$ReportShare       = '\\tpapwmssql002\Reports',
    [int]$StaleFullBackupDays = 8,
    [int]$ThrottleLimit = 8,
    [string]$ReportSubject = 'ALL MSSQL DB Backup Alert - NO FULL Backup in the Last 8 Days',
    [string[]]$MailTo = @('WHPS-MSSQL-Admins@wipro.com'),
    [string]$MailFrom = 'DBA_Report@Healthplan.com',
    [string]$SmtpServer = 'smtprelay.healthplan.com',
    [switch]$FilterByAge,
    [switch]$UseSqlAgeFilter,
    [switch]$EnableParallel,
    [switch]$DropTable,
    [switch]$WhatIfOnly,
    [switch]$EmitAllClearEmail
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$scriptStart = Get-Date

function Write-Section {
    param(
        [string]$Message,
        [ValidateSet('Gray','Yellow','Green','Red','Cyan','DarkCyan','Magenta','DarkGreen')]
        [string]$Color = 'Gray'
    )
    Write-Host ("[{0}] {1}" -f (Get-Date -Format HH:mm:ss), $Message) -ForegroundColor $Color
}

Write-Section "=== Backup report run started: $scriptStart ===" Cyan

Import-Module dbatools -ErrorAction Stop
Set-DbatoolsInsecureConnection -SessionOnly

# SqlClient duplication diagnostic (StrictMode-safe)
$msSqlClient = @(
    [AppDomain]::CurrentDomain.GetAssemblies() |
      Where-Object { $_.GetName().Name -eq 'Microsoft.Data.SqlClient' } |
      Select-Object FullName, Location
)
$msSqlClientCount = $msSqlClient.Count
if ($msSqlClientCount -gt 1) {
    Write-Section "Multiple Microsoft.Data.SqlClient assemblies loaded:" Red
    foreach ($a in $msSqlClient) {
        Write-Host "  $($a.FullName) [$($a.Location)]" -ForegroundColor Red
    }
    throw "Multiple Microsoft.Data.SqlClient versions detected."
}
elseif ($msSqlClientCount -eq 1) {
    Write-Section "Using Microsoft.Data.SqlClient: $($msSqlClient[0].FullName)" DarkCyan
}
else {
    Write-Section "No Microsoft.Data.SqlClient assembly loaded yet." Yellow
}

try {
    $sqlFiles = @(Get-ChildItem -Path $BackupQueryFolder -Filter *.sql -ErrorAction Stop)
    switch ($sqlFiles.Count) {
        0 { throw "No .sql files found in $BackupQueryFolder" }
        1 { }
        default { throw "Expected exactly one .sql file in $BackupQueryFolder; found $($sqlFiles.Count)." }
    }
    $BackupScriptPath = $sqlFiles[0].FullName
    Write-Section "Using backup collection script: $BackupScriptPath"

    $instances = Get-Content -Path $InstancesFile |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ } |
        Sort-Object -Unique
    if (-not $instances) { throw "No instances found in $InstancesFile" }
    Write-Section "Instances to process: $(@($instances).Count)"

    if ($DropTable) {
        Write-Section "Dropping dbo.BackupInfo (requested)" Yellow
        Invoke-DbaQuery -SqlInstance $CollectorInstance -Database $CollectorDatabase -Query "IF OBJECT_ID('dbo.BackupInfo','U') IS NOT NULL DROP TABLE dbo.BackupInfo;" -EnableException
    }

    $ensureTable = @"
IF OBJECT_ID('dbo.BackupInfo','U') IS NULL
BEGIN
    CREATE TABLE dbo.BackupInfo (
        ServerName sysname NOT NULL,
        DatabaseName sysname NOT NULL,
        Last_Full datetime NULL,
        AG bit NULL,
        CollectionDate datetime NOT NULL DEFAULT(GETDATE())
    );
END;
TRUNCATE TABLE dbo.BackupInfo;
"@
    Invoke-DbaQuery -SqlInstance $CollectorInstance -Database $CollectorDatabase -Query $ensureTable -EnableException

    $invokeParams = @{
        File            = $BackupScriptPath
        EnableException = $true
    }

    $collected = [System.Collections.Generic.List[object]]::new()

    $canParallel = $EnableParallel -and ($PSVersionTable.PSVersion.Major -ge 7)
    if ($EnableParallel -and -not $canParallel) {
        Write-Section "Parallel requested but PowerShell < 7; using serial collection." Yellow
    }

    Write-Section "Collecting backup metadata"
    if ($canParallel) {
        $results = $instances | ForEach-Object -Parallel {
            param($params)
            try {
                @(Invoke-DbaQuery -SqlInstance $_ @params)
            }
            catch {
                Write-Host "WARN: Instance $_ failed - $($_.Exception.Message)" -ForegroundColor Yellow
                $null
            }
        } -ArgumentList ($invokeParams) -ThrottleLimit $ThrottleLimit

        foreach ($item in $results) {
            if ($null -eq $item) { continue }
            # Flatten nested enumerables except strings
            if ($item -is [System.Collections.IEnumerable] -and -not ($item -is [string])) {
                foreach ($sub in $item) {
                    if ($null -ne $sub) { [void]$collected.Add($sub) }
                }
            } else {
                [void]$collected.Add($item)
            }
        }
    }
    else {
        foreach ($inst in $instances) {
            try {
                $r = @(Invoke-DbaQuery -SqlInstance $inst @invokeParams)
                foreach ($row in $r) {
                    if ($null -ne $row) { [void]$collected.Add($row) }
                }
            }
            catch {
                Write-Section "WARN: $inst failed - $($_.Exception.Message)" Yellow
            }
        }
    }

    if ($collected.Count -eq 0) {
        Write-Section "No data collected; exiting." Red
        return
    }
    Write-Section "Collected rows: $($collected.Count). Writing to dbo.BackupInfo."

    Write-DbaDataTable -SqlInstance $CollectorInstance -Database $CollectorDatabase -Schema dbo -Table BackupInfo -InputObject $collected -KeepNulls -EnableException

    $staleCutoff = (Get-Date).AddDays(-$StaleFullBackupDays)
    $sqlFilter = ""
    if ($UseSqlAgeFilter) {
        $sqlFilter = " AND (Last_Full IS NULL OR Last_Full < DATEADD(DAY,-$StaleFullBackupDays, GETDATE()))"
        Write-Section "Applying age filter in SQL (cutoff $staleCutoff)" DarkCyan
    }

    $query = @"
SELECT ServerName, DatabaseName, Last_Full, AG
FROM dbo.BackupInfo
WHERE AG <> 1$sqlFilter
ORDER BY ServerName, DatabaseName;
"@

    $backupData = @(
        Invoke-DbaQuery -SqlInstance $CollectorInstance -Database $CollectorDatabase -Query $query -EnableException
    )

    if ($FilterByAge -and -not $UseSqlAgeFilter) {
        $before = @($backupData).Count
        $backupData = @(
            $backupData | Where-Object { -not $_.Last_Full -or $_.Last_Full -lt $staleCutoff }
        )
        Write-Section "Client-side age filter kept $(@($backupData).Count)/$before (cutoff $staleCutoff)" DarkCyan
    }

    if (-not (Test-Path $ReportShare)) {
        New-Item -ItemType Directory -Path $ReportShare | Out-Null
    }

    $dateTag    = (Get-Date -Format yyyyMMdd_HHmmss)
    $reportFile = Join-Path $ReportShare ("backupreport_$dateTag.html")

    $css = @"
<style>
body { font-family: Verdana, Arial, sans-serif; font-size: 12px; margin:12px;}
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #555; padding: 5px 7px; }
th { background-color: #D6EEEE; }
tr:nth-child(even) { background: #F3FBFB; }
.ok  { color:#228B22; font-weight:600; }
h3 { color:#0B5394; }
.small { font-size:10px; color:#555; }
</style>
"@

    $header = @"
<h3>ALL MSSQL DB Backup Alert - Missing FULL within $StaleFullBackupDays day(s)</h3>
<p>Cutoff: $staleCutoff</p>
"@

    $footer = @"
<p class='small'>Generated: $(Get-Date) | Host: $env:COMPUTERNAME</p>
"@

    if (@($backupData).Count -gt 0) {
        $backupData |
            Sort-Object ServerName, DatabaseName |
            Select-Object ServerName, DatabaseName,
                @{ n='Last_Full'; e={ if ($_.Last_Full) { $_.Last_Full.ToString('yyyy-MM-dd HH:mm') } else { '<NONE>' } } },
                AG |
            ConvertTo-Html -Head $css -Title 'Missing FULL Backup Report' -PreContent $header -PostContent $footer |
            Out-File -FilePath $reportFile -Encoding UTF8
        Write-Section "Report written: $reportFile" Green
    }
    else {
        $allClear = @"
$css
$header
<p class='ok'>All monitored databases have a FULL backup within $StaleFullBackupDays day(s).</p>
$footer
"@
        Set-Content -Path $reportFile -Value $allClear -Encoding UTF8
        Write-Section "All-clear report written: $reportFile" Green
    }

    $staleCount = @($backupData).Count
    $sendAlert = ($staleCount -gt 0)
    if (-not $sendAlert -and $EmitAllClearEmail) { $sendAlert = $true }

    if ($WhatIfOnly) {
        Write-Section "WhatIfOnly: skipping email send (stale rows: $staleCount)" Yellow
    }
    elseif ($sendAlert) {
        $body = Get-Content -Path $reportFile -Raw
        Write-Section "Sending email: $ReportSubject (stale rows: $staleCount)" Magenta
        #Send-MailMessage -From $MailFrom -To $MailTo -Subject $ReportSubject -SmtpServer $SmtpServer -BodyAsHtml -Body $body -Priority High
    }
    else {
        Write-Section "No stale backups; email suppressed." DarkGreen
    }
}
catch {
    Write-Section "FATAL: $($_.Exception.Message)" Red
    [AppDomain]::CurrentDomain.GetAssemblies() |
      Where-Object { $_.GetName().Name -eq 'Microsoft.Data.SqlClient' } |
      Select-Object FullName, Location |
      ForEach-Object { Write-Host "ASSEMBLY: $_" -ForegroundColor Yellow }
    throw
}
finally {
    $end = Get-Date
    Write-Section "Duration: $([int]($end - $scriptStart).TotalSeconds)s" Cyan
    Write-Section "=== Backup report run completed: $end ===" Cyan
}