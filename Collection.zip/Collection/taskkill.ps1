﻿netstat -ano | findstr :3000
tasklist /FI "PID eq 15004"
taskkill /PID 15004 /F