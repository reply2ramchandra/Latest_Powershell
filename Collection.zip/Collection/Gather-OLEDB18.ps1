﻿clear-host
$servers=get-Content "T:\Test\0527.txt"
foreach($server in $servers)
{
 Invoke-Command -ComputerName $server -ScriptBlock {
$regpath="HKLM:\SOFTWARE\Microsoft\MSOLEDBSQL" 
$oledbversion=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$ver=$oledbversion.InstalledVersion
if($ver){
Write-Host "Existing OLEDB Version" $ver -ForegroundColor Green -NoNewline
write-host " " -ForegroundColor Green -NoNewline }
Else { write-host "NO OLEDB18 UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname}}