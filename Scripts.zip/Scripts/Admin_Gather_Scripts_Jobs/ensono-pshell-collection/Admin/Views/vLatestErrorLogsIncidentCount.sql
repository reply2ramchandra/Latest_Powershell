CREATE VIEW [Admin].[vLatestErrorLogsIncidentCount]
AS
	SELECT
		DateKey
	   ,'LoginFailure' AS [ErrorClass]
	   ,SqlInstance
	   ,COUNT( * )	   AS OccurrenceCount
	   ,[Text]
	FROM Inventory.ErrorLogs
	WHERE DateKey = (SELECT TOP 1 DateKey FROM Inventory.[ErrorLogs] ORDER BY DateKey DESC)
	AND Source = 'Logon'
	GROUP BY DateKey
			,SqlInstance
			,[Text]
	HAVING (COUNT( * ) > 1)
	UNION ALL
	SELECT
		DateKey
	   ,'StackDump'			  AS [ErrorClass]
	   ,SqlInstance
	   ,COUNT( * )			  AS OccurrenceCount
	   ,'Begin of Stack Dump' AS [Text]
	FROM Inventory.ErrorLogs
	WHERE DateKey = (SELECT TOP 1 DateKey FROM Inventory.[ErrorLogs] ORDER BY DateKey DESC)
	AND Source != 'Logon'
	GROUP BY DateKey
			,SqlInstance
