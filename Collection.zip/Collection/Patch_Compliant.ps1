﻿#clear-host
Import-Module dbatools -DisableNameChecking 
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Get-DbaRegServer -SqlInstance TPAPWMSSQL002
foreach($server in $servers.ServerName)
{
$Patch_Compliant=Test-DbaBuild -SqlInstance $server -Latest -Update | Where-Object { $_.Compliant -eq $false } | Select SqlInstance,NameLevel,BuildLevel,BuildTarget,CULevel,SPLevel,Compliant 
if($Patch_Compliant) {Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'Patch_Compliant' -InputObject $Patch_Compliant  -AutoCreateTable -KeepNulls}
}
