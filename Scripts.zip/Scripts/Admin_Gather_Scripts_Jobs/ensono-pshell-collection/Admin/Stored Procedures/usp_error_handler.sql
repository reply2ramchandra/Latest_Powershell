CREATE PROCEDURE [Admin].[usp_error_handler]
AS
	/***************************************************************************************************************************************
		
		Purpose: Error Handling Technique
		

		History:
		------------------------------------------------------------------------------------------------------------------------------------
		Author                                       Date Created                Comments
		------------------------------------------------------------------------------------------------------------------------------------
		Erland Sommarskog                             --	                  Initial draft



	    ------------------------------------------------------------------------------------------------------------------------------------

		Documentation:
		--------------
		USE in BEGIN TRY/CATCH block
		Erland Sommarskog, SQL Server MVP. Latest revision: 2015-05-03. 

		Link: http://www.sommarskog.se/error_handling/Part1.html#error_handler_sp

		Execution Samples:
		------------------


    ***************************************************************************************************************************************/

	SET NOCOUNT ON;

	BEGIN
		DECLARE @errmsg	  NVARCHAR(MAX)
			   ,@severity TINYINT
			   ,@state	  TINYINT
			   ,@errno	  INT
			   ,@proc	  SYSNAME
			   ,@lineno	  INT

		SELECT
			@errmsg = ERROR_MESSAGE()
		   ,@severity = ERROR_SEVERITY()
		   ,@state = ERROR_STATE()
		   ,@errno = ERROR_NUMBER()
		   ,@proc = ERROR_PROCEDURE()
		   ,@lineno = ERROR_LINE()

		IF @errmsg NOT LIKE '***%'
			BEGIN
				SELECT
					@errmsg = '*** ' + COALESCE( QUOTENAME( @proc ),'<dynamic SQL>' ) +
					', Line ' + LTRIM( STR( @lineno ) ) + '. Errno ' +
					LTRIM( STR( @errno ) ) + ': ' + @errmsg
			END
		RAISERROR ('%s',@severity,@state,@errmsg)

	END