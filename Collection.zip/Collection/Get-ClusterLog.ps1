﻿######Logon to Cluster Node and run this##########
Get-ClusterLog -Destination D:\DBA -UseLocalTime
#Create a log file for the local cluster for previous 5 minutes
Get-ClusterLog -TimeSpan 5
#Get-InstalledModule | Where {$_.Name -Like '*Fail*'}
#Get-ClusterLog -Cluster TPAPWSQLALFC01 -Destination D:\DBA -UseLocalTime