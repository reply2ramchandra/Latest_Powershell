﻿Get-TimeZone -ListAvailable 
Set-TimeZone -Name 'Eastern Standard Time' -PassThru
#Set-TimeZone -Name 'Eastern Standard Time' -PassThru
