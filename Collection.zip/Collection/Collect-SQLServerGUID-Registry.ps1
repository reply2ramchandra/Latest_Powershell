﻿$SQLVer = Get-ChildItem -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall, HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall | Get-ItemProperty | Where-Object { $_.DisplayName -match "SQL Server " } | Select-Object -Property DisplayName, UninstallString 

$SQLVer | Format-List

<#
ForEach ($ver in $SQLVer) {
   If ($ver.UninstallString) {
       $uninst = $ver.UninstallString
       Start-Process cmd -ArgumentList "/c $uninst /quiet /norestart" -NoNewWindow
}
#>