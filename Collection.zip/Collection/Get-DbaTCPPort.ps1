﻿clear
import-module dbatools -EA SilentlyContinue
Get-DbaTCPPort -SqlInstance HPSSQL11\SQL11