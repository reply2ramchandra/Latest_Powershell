﻿# Define node names and Patch KB number as required
clear
$active = 'TPATWSQLMHCA01'
$passive = 'TPATWSQLMHCB01'
$patchid ='KB5068791' 
# Load required modules
Import-Module PSWindowsUpdate -ErrorAction SilentlyContinue
Import-Module dbatools -ErrorAction SilentlyContinue

##
function Stop-Script {
    param([string]$Message)
    Write-Error $Message
    Stop-Transcript | Out-Null
    exit 1
}

# Function to check OS patch status
function Test-OsPatchStatus {
    param([string]$ComputerName, [string]$PatchId)

    $patch = Get-WUHistory -ComputerName $ComputerName | Where-Object { $_.Title -match $PatchId }
    if ($patch -and $patch.Result -ne 'Failed') {
        return $true
    } else {
        Write-Warning "Patch $PatchId not found or failed on $ComputerName"
        return $false
    }
}

# Function to check AG database health
function Test-AgDatabasesHealthy {
    param([string]$SqlInstance)

    try {
        $agDbs = Get-DbaAgDatabase -SqlInstance $SqlInstance -ErrorAction Stop
        $unhealthy = $agDbs | Where-Object { $_.SynchronizationState -ne 'Synchronized' -or $_.IsSuspended    }

        if ($unhealthy) {
            Write-Warning "Unhealthy AG DBs on ${SqlInstance}:`n$($unhealthy.DatabaseName -join ', ')"
            return $false
        }
        return $true
    } catch {
        Write-Error "Failed to check AG database health on ${SqlInstance}: $_"
        return $false
    }
}

function Wait-Uptime {
    param(
        [string]$SqlInstance,
        [int]$TimeoutSeconds = 600,
        [int]$PollSeconds = 300
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        try {
            if (Get-DbaUptime -SqlInstance $SqlInstance -ErrorAction Stop) {
                return $true
            }}
catch { Write-Warning "Error during uptime check for ${SqlInstance}: $_" }
        Start-Sleep -Seconds $PollSeconds
        Start-DbaService -ComputerName  $SqlInstance
    }
   
    Write-Error "Instance $SqlInstance did not come online within $TimeoutSeconds seconds."
    return $false
}

# Check patch and AG health before rebooting passive node
if (Test-OsPatchStatus -ComputerName $passive -PatchId $patchid -and Test-AgDatabasesHealthy -SqlInstance $active) {
    Write-Host 'Okay. Rebooting server' $passive
    Restart-Computer -ComputerName $passive -Force
} else {
    Write-Warning "Skipping reboot of passive node due to patch failure or unhealthy AG status."
    Stop-Script "Exiting"
}
Start-Sleep -Seconds 300
Wait-Uptime -SqlInstance $passive
if (-not (Wait-Uptime -SqlInstance $passive)) {
    Stop-Script "OS Patched node $passive did not return in time or SQL Instance is not up yet. Manual Intervention required."
}
# Failover AG to passive
$agReplicas = Get-DbaAvailabilityGroup -SqlInstance $active
$agName = ($agReplicas | Select-Object -First 1).Name
if($agName){ Write-Host 'trying to failover the AG to Passive node'
Invoke-DbaAgFailover -SqlInstance $passive -AvailabilityGroup $agName -Confirm:$false}
Start-Sleep -Seconds 120
# Check patch and AG health before rebooting active node
if (Test-OsPatchStatus -ComputerName $active -PatchId $patchid -and Test-AgDatabasesHealthy -SqlInstance $passive) {
     Write-Host 'Okay. Rebooting server' $active
    Restart-Computer -ComputerName $active -Force
} else {
    Write-Warning "Skipping reboot of active node due to patch failure or unhealthy AG status."
    Stop-Script "Exiting"
}
Start-Sleep -Seconds 300
Wait-Uptime -SqlInstance $active
if (-not (Wait-Uptime -SqlInstance $active)) {
    Stop-Script "OS Patched node $active did not return in time or SQL Instance is not up yet. Manual Intervention required." 
}
# Failback AG to active
if (Get-DbaUptime -SqlInstance $active -ErrorAction Stop) {
 Write-Host 'trying to Failback the AG to Active node'
Invoke-DbaAgFailover -SqlInstance $active -AvailabilityGroup $agName -Confirm:$false}
Start-Sleep -Seconds 120
# Final AG health check
Test-AgDatabasesHealthy -SqlInstance $active
Write-Host "Look at the Result and taken action if required" -BackgroundColor Yellow