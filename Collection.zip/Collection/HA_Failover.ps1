﻿Import-Module dbatools -EA SilentlyContinue 
#AG Failover
#Failover to SqlInstance given which is currently secondary now
Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLETA01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
#check AG DB sync status and AG role
Get-DbaAgDatabase -SqlInstance TPAPWSQLETB01 | Select SqlInstance, LocalReplicaRole,Name,SynchronizationState,IsFailoverReady