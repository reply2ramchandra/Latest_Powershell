USE [msdb]
GO

/****** Object:  Job [ACXJOB_Admin_Gather_Database_Information_PS]    Script Date: 6/14/2017 11:18:00 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Acx-Maintenance]    Script Date: 6/14/2017 11:18:00 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Acx-Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Acx-Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ACXJOB_Admin_Gather_Database_Information_PS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'For all the Active Database Servers connected to the Central Management Server, the Database Information will be gathered by the execution of this job. DBA.dbo.DBServersAll.DBSAActive = 1 The Step Admin_SQLServerDatabaseProperties_Collection_2005 must run prior to Admin_SQLServerDatabaseProperties_Collection as the _2005 reinitializes the Log tables.', 
		@category_name=N'Acx-Maintenance', 
		@owner_login_name=N'PRSCOAD\prod-sql-dba', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Truncate Log Tables DBInformation]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Truncate Log Tables DBInformation', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate Table AdminLog.DBInformation', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Deletion of Previously Loaded Data DBInformation]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Deletion of Previously Loaded Data DBInformation', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
DELETE From AdminServer.Database_Information 
WHERE DATEPART(MONTH, AdminServer.Database_Information.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, AdminServer.Database_Information.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, AdminServer.Database_Information.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Gather_DBInformation]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Gather_DBInformation', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
."Y:\SSISRoot\APPDBA\PSScripts\Scripts\write-datatable.ps1"

#Looping logic taken from: https://sqljgood.wordpress.com/2014/09/17/using-powershell-to-loop-through-a-list-of-sql-server-databases/

$instances = invoke-sqlcmd -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -Query "SELECT NULL,[DBSAServerConnection],DATEADD(dd,DATEDIFF(dd,0,getdate()),0),NULL FROM AdminControl.DBServersAll WHERE DBSAActive = 1 ORDER BY [DBSAServerConnection]"
Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminLog.DBInformation" -Data $instances

foreach ($instance in $instances)
{
	$Inst = $instance.DBSAServerConnection
	try
	{
		$dt=invoke-sqlcmd -ServerInstance ${Inst} -inputfile "Y:\SSISRoot\APPDBA\PSScripts\Scripts\Admin_Gather_Database_Information.sql" 
		Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminServer.Database_Information" -Data $dt	}
	catch
	{
		#
	}
}

', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Log Tables DBInformation]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Log Tables DBInformation', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
Declare @RecordsCollected int
UPDATE AdminLog.DBInformation
SET RunResults = ''Collected''
FROM AdminLog.DBInformation AS L INNER JOIN AdminControl.DBServersAll AS C ON
L.ServerName = C.DBSAServerConnection 
INNER JOIN 
AdminServer.Database_Information AS R ON
C.DBSAServerName = R.ServerName
WHERE DATEPART(MONTH, R.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, R.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, R.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Truncate Log Tables DBInformationIO]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Truncate Log Tables DBInformationIO', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate Table AdminLog.DBInformation_IO', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Deletion of Previously Loaded Data DBInformationIO]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Deletion of Previously Loaded Data DBInformationIO', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
DELETE From AdminServer.Database_IO_Information 
WHERE DATEPART(MONTH, AdminServer.Database_IO_Information.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, AdminServer.Database_IO_Information.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, AdminServer.Database_IO_Information.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Gather_DBInformationIO]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Gather_DBInformationIO', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
."Y:\SSISRoot\APPDBA\PSScripts\Scripts\write-datatable.ps1"

#Looping logic taken from: https://sqljgood.wordpress.com/2014/09/17/using-powershell-to-loop-through-a-list-of-sql-server-databases/

$instances = invoke-sqlcmd -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -Query "SELECT NULL,[DBSAServerConnection],DATEADD(dd,DATEDIFF(dd,0,getdate()),0),NULL FROM AdminControl.DBServersAll WHERE DBSAActive = 1 ORDER BY [DBSAServerConnection]"
Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminLog.DBInformation_IO" -Data $instances

foreach ($instance in $instances)
{
	$Inst = $instance.DBSAServerConnection
	try
	{
		$dt=invoke-sqlcmd -ServerInstance ${Inst} -inputfile "Y:\SSISRoot\APPDBA\PSScripts\Scripts\Admin_Gather_Database_Information_IO.sql" 
		Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminServer.Database_IO_Information" -Data $dt	}
	catch
	{
		#
	}
}

', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Log Tables_DBInformationIO]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Log Tables_DBInformationIO', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
Declare @RecordsCollected int
UPDATE AdminLog.DBInformation_IO
SET RunResults = ''Collected''
FROM AdminLog.DBInformation_IO AS L INNER JOIN AdminControl.DBServersAll AS C ON
L.ServerName = C.DBSAServerConnection 
INNER JOIN 
AdminServer.Database_IO_Information AS R ON
C.DBSAServerName = R.Server_Name
WHERE DATEPART(MONTH, R.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, R.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, R.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Truncate Log Tables DBProperties]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Truncate Log Tables DBProperties', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Truncate Table AdminLog.SQLServerDatabaseProperties
Truncate Table AdminLog.SQLServerDatabaseProperties_2005
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Deletion of Previously Loaded Data DBProperties]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Deletion of Previously Loaded Data DBProperties', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
DELETE From AdminServer.SQLServerDatabaseProperties_Repository 
WHERE DATEPART(MONTH, AdminServer.SQLServerDatabaseProperties_Repository.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, AdminServer.SQLServerDatabaseProperties_Repository.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, AdminServer.SQLServerDatabaseProperties_Repository.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Gather_DBProperties]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Gather_DBProperties', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=13, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
."Y:\SSISRoot\APPDBA\PSScripts\Scripts\write-datatable.ps1"

#Looping logic taken from: https://sqljgood.wordpress.com/2014/09/17/using-powershell-to-loop-through-a-list-of-sql-server-databases/

$instances = invoke-sqlcmd -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -Query "SELECT NULL,[DBSAServerConnection],DATEADD(dd,DATEDIFF(dd,0,getdate()),0),NULL FROM AdminControl.DBServersAll WHERE DBSAActive = 1 ORDER BY [DBSAServerConnection]"
Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminLog.SQLServerDatabaseProperties" -Data $instances

foreach ($instance in $instances)
{
	$Inst = $instance.DBSAServerConnection
	try
	{
		$dt=invoke-sqlcmd -ServerInstance ${Inst} -inputfile "Y:\SSISRoot\APPDBA\PSScripts\Scripts\Admin_Gather_Database_Properties.sql" 
		Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminServer.SQLServerDatabaseProperties_Repository" -Data $dt	}
	catch
	{
		#
	}
}

', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Gather_DBProperties_2005]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Gather_DBProperties_2005', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
."Y:\SSISRoot\APPDBA\PSScripts\Scripts\write-datatable.ps1"

#Looping logic taken from: https://sqljgood.wordpress.com/2014/09/17/using-powershell-to-loop-through-a-list-of-sql-server-databases/

$instances = invoke-sqlcmd -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -Query "SELECT NULL,[DBSAServerConnection],DATEADD(dd,DATEDIFF(dd,0,getdate()),0),NULL FROM AdminControl.DBServersAll INNER JOIN AdminServer.SQLServerProperties_Repository ON
AdminControl.DBServersAll.[DBSAServerName] = AdminServer.SQLServerProperties_Repository.[ServerName]
WHERE DBSAActive = 1 AND AdminServer.SQLServerProperties_Repository.[Date_Key] = (SELECT MAX(Date_Key) AS Date_Key FROM AdminServer.SQLServerProperties_Repository)
AND AdminServer.SQLServerProperties_Repository.ProductVersion LIKE ''9.00.%'' 
ORDER BY [DBSAServerConnection]"
Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminLog.SQLServerDatabaseProperties_2005" -Data $instances

foreach ($instance in $instances)
{
	$Inst = $instance.DBSAServerConnection
	try
	{
		$dt=invoke-sqlcmd -ServerInstance ${Inst} -inputfile "Y:\SSISRoot\APPDBA\PSScripts\Scripts\Admin_Gather_Database_Properties_2005.sql" 
		Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminServer.SQLServerDatabaseProperties_Repository" -Data $dt	}
	catch
	{
		#
	}
}

', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Log Tables_DBProperties]    Script Date: 6/14/2017 11:18:00 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Log Tables_DBProperties', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
Declare @RecordsCollected int
UPDATE AdminLog.SQLServerDatabaseProperties
SET RunResults = ''Collected''
FROM AdminLog.SQLServerDatabaseProperties AS L INNER JOIN AdminControl.DBServersAll AS C ON
L.ServerName = C.DBSAServerConnection 
INNER JOIN 
AdminServer.SQLServerProperties_Repository AS R ON
C.DBSAServerName = R.ServerName
AND R.Date_Key = (SELECT MAX(Date_Key) AS Date_Key FROM AdminServer.SQLServerProperties_Repository)
UPDATE AdminLog.SQLServerDatabaseProperties_2005
SET RunResults = ''Collected''
FROM AdminLog.SQLServerDatabaseProperties_2005 AS L INNER JOIN AdminControl.DBServersAll AS C ON
L.ServerName = C.DBSAServerConnection 
INNER JOIN 
AdminServer.SQLServerDatabaseProperties_Repository AS R ON
C.DBSAServerName = R.ServerName
WHERE DATEPART(MONTH, R.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, R.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, R.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Monthly Schedule', 
		@enabled=1, 
		@freq_type=16, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170612, 
		@active_end_date=99991231, 
		@active_start_time=51500, 
		@active_end_time=235959, 
		@schedule_uid=N'f171dbc2-a4fd-4937-9757-20daa7b333c8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run_Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=32, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20100518, 
		@active_end_date=99991231, 
		@active_start_time=51500, 
		@active_end_time=235959, 
		@schedule_uid=N'e1f1804f-33bb-4217-a234-21c6af9ab8e6'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

