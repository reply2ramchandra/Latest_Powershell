﻿CREATE TABLE [Inventory].[ApplicationContacts]
(
	[SqlInstance] VARCHAR(256) NOT NULL
)
