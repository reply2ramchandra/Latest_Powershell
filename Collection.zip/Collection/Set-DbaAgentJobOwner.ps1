﻿Import-Module dbatools -EA SilentlyContinue
Get-DbaAgentJob -SqlInstance TPAPWSQLGNXTB01 | Where-Object OwnerLoginName -eq HPS\vv12128 | Set-DbaAgentJobOwner -TargetLogin sa | Out-Gridview
