-- Get log file size and free space for the 'admin' database in SQL Server 2022
SET NOCOUNT ON;

IF EXISTS (SELECT 1 FROM sys.databases WHERE name = 'admin')
BEGIN
    CREATE TABLE #logspace (
        [Database Name] sysname,
        [Log Size (MB)] float,
        [Log Space Used (%)] float,
        [Status] int
    );

    INSERT INTO #logspace
    EXEC('DBCC SQLPERF(LOGSPACE)');

    SELECT @@SERVERNAME as [Srv],
        [Database Name],
         CAST([Log Size (MB)] AS DECIMAL(18,2)) AS [Log Size (MB)],
        CAST([Log Space Used (%)] AS DECIMAL(18,2)) AS [Log Space Used (%)],
        CAST(([Log Size (MB)] * (1 - [Log Space Used (%)] / 100.0)) AS DECIMAL(18,2)) AS [Log Free Space (MB)],DATABASEPROPERTYEX('admin', 'Recovery') as [RecoveryModel]
    FROM #logspace
    WHERE [Database Name] = 'admin';

    DROP TABLE #logspace;
END
ELSE
BEGIN
    PRINT 'Database "admin" does not exist.';
END