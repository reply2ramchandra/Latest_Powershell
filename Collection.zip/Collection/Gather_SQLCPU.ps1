﻿Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where [Status]='Y'" -TrustServerCertificate
foreach($SQL in $servers.SqlInstance)
{
$data = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query " DECLARE @db1 table ([Index] int, name nvarchar(128), Internal_value int, [Character_value] nvarchar(128)) 
 insert into @db1 EXEC xp_msver 'ProcessorCount'
 select @@servername as ServerName, [Internal_value] AS [CPU Count] from @db1  where name = 'ProcessorCount' " 
 $data | Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DbaCPU'  -AutoCreateTable -KeepNulls

}