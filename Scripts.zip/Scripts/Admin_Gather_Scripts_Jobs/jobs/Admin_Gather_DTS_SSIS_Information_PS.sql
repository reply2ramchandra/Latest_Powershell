USE [msdb]
GO

/****** Object:  Job [ACXJOB_Admin_Gather_DTS_SSIS_Information_PS]    Script Date: 6/14/2017 11:18:55 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Acx-Maintenance]    Script Date: 6/14/2017 11:18:55 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Acx-Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Acx-Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ACXJOB_Admin_Gather_DTS_SSIS_Information_PS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'For all the Active Database Servers connected to the Central Management Server, the DTS and SSIS Information will be gathered by the execution of this job. DBA.dbo.DBServersAll.DBSAActive = 1', 
		@category_name=N'Acx-Maintenance', 
		@owner_login_name=N'PRSCOAD\prod-sql-dba', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Truncate Log Tables DTSPackages]    Script Date: 6/14/2017 11:18:55 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Truncate Log Tables DTSPackages', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate Table AdminLog.DTSPackages', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Deletion of Previously Loaded Data DTSPackages]    Script Date: 6/14/2017 11:18:55 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Deletion of Previously Loaded Data DTSPackages', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
DELETE From AdminServer.DTS_Information 
WHERE DATEPART(MONTH, AdminServer.DTS_Information.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, AdminServer.DTS_Information.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, AdminServer.DTS_Information.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Gather_DTSPackages]    Script Date: 6/14/2017 11:18:55 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Gather_DTSPackages', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
."Y:\SSISRoot\APPDBA\PSScripts\Scripts\write-datatable.ps1"

#Looping logic taken from: https://sqljgood.wordpress.com/2014/09/17/using-powershell-to-loop-through-a-list-of-sql-server-databases/

$instances = invoke-sqlcmd -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -Query "SELECT NULL,[DBSAServerConnection],DATEADD(dd,DATEDIFF(dd,0,getdate()),0),NULL FROM AdminControl.DBServersAll WHERE DBSAActive = 1 ORDER BY [DBSAServerConnection]"
Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminLog.DTSPackages" -Data $instances

foreach ($instance in $instances)
{
	$Inst = $instance.DBSAServerConnection
	try
	{
		$dt=invoke-sqlcmd -ServerInstance ${Inst} -inputfile "Y:\SSISRoot\APPDBA\PSScripts\Scripts\Admin_Gather_Server_DTSInformation.sql" 
		Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminServer.DTS_Information" -Data $dt	}
	catch
	{
		#
	}
}

', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Log Tables DTSPackages]    Script Date: 6/14/2017 11:18:55 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Log Tables DTSPackages', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
Declare @RecordsCollected int
UPDATE AdminLog.DTSPackages
SET RunResults = ''Collected''
FROM AdminLog.DTSPackages AS L INNER JOIN AdminControl.DBServersAll AS C ON
L.ServerName = C.DBSAServerConnection 
INNER JOIN 
AdminServer.DTS_Information AS R ON
C.DBSAServerName = R.Server_Name
WHERE DATEPART(MONTH, R.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, R.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, R.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Truncate Log Tables SSISPackages]    Script Date: 6/14/2017 11:18:55 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Truncate Log Tables SSISPackages', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate Table AdminLog.SSISPackages', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Deletion of Previously Loaded Data SSISPackages]    Script Date: 6/14/2017 11:18:55 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Deletion of Previously Loaded Data SSISPackages', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
DELETE From AdminServer.SSIS_Information 
WHERE DATEPART(MONTH, AdminServer.SSIS_Information.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, AdminServer.SSIS_Information.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, AdminServer.SSIS_Information.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Gather_DiskSpace_Collection_SSISPackages]    Script Date: 6/14/2017 11:18:55 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Gather_DiskSpace_Collection_SSISPackages', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
."Y:\SSISRoot\APPDBA\PSScripts\Scripts\write-datatable.ps1"

#Looping logic taken from: https://sqljgood.wordpress.com/2014/09/17/using-powershell-to-loop-through-a-list-of-sql-server-databases/

$instances = invoke-sqlcmd -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -Query "SELECT NULL,[DBSAServerConnection],DATEADD(dd,DATEDIFF(dd,0,getdate()),0),NULL FROM AdminControl.DBServersAll WHERE DBSAActive = 1 ORDER BY [DBSAServerConnection]"
Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminLog.SSISPackages" -Data $instances

foreach ($instance in $instances)
{
	$Inst = $instance.DBSAServerConnection
	try
	{
		$dt=invoke-sqlcmd -ServerInstance ${Inst} -inputfile "Y:\SSISRoot\APPDBA\PSScripts\Scripts\Admin_Gather_Server_SSISInformation.sql" 
		Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminServer.SSIS_Information" -Data $dt	}
	catch
	{
		#
	}
}

', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Log Tables_SSISPackages]    Script Date: 6/14/2017 11:18:55 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Log Tables_SSISPackages', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
Declare @RecordsCollected int
UPDATE AdminLog.SSISPackages
SET RunResults = ''Collected''
FROM AdminLog.SSISPackages AS L INNER JOIN AdminControl.DBServersAll AS C ON
L.ServerName = C.DBSAServerConnection 
INNER JOIN 
AdminServer.SSIS_Information AS R ON
C.DBSAServerName = R.Server_Name
WHERE DATEPART(MONTH, R.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, R.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, R.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run_Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=32, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20100518, 
		@active_end_date=99991231, 
		@active_start_time=90000, 
		@active_end_time=235959, 
		@schedule_uid=N'4995df99-c4fa-4bc4-a17d-2e8560585dfc'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

