# Define SSRS Web Service URL and CSV path
$ReportServerUri = "http://<your-new-server>/ReportServer/ReportService2010.asmx?wsdl"
$CsvPath = "C:\SSRS_Permissions.csv"

# Create SSRS proxy
$SSRS = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential -Namespace "SSRS"

# Read CSV and group by report path
$permissions = Import-Csv -Path $CsvPath | Group-Object -Property Path

foreach ($group in $permissions) {
    $reportPath = $group.Name
    $entries = $group.Group

    $policyList = @()

    foreach ($entry in $entries) {
        $user = $entry.UserName
        $roleName = $entry.RoleName

        # Get role object
        $role = $SSRS.GetRole($roleName, "System")
        if ($role -eq $null) {
            Write-Host "Role '$roleName' not found. Skipping $user on $reportPath"
            continue
        }

        # Create policy
        $policy = New-Object SSRS.Policy
        $policy.GroupUserName = $user
        $policy.Roles = @($role)
        $policyList += $policy
    }

    # Apply policies to the report/folder
    try {
        $SSRS.SetPolicies($reportPath, $policyList)
        Write-Host "Applied permissions to: $reportPath"
    } catch {
        Write-Host "Failed to apply permissions to: $reportPath - $_"
    }
}