﻿Import-Module dbatools -DisableNameChecking 
Copy-DbaSystemDbUserObject -Source sqlserver2014a -Destination sqlcluster
