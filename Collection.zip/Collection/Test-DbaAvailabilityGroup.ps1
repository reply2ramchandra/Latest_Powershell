﻿Import-Module dbatools -EA SilentlyContinue 
Enable-DbaAgHadr -SqlInstance TPADWSQLMHCA01 -Force
Enable-DbaAgHadr -SqlInstance TPADWSQLMHCB01 -Force
New-DbaAvailabilityGroup -Primary TPADWSQLMHCA01 -Name DevMH_AG 
Get-DbaAvailabilityGroup -SqlInstance TPADWSQLMHCB01 -AvailabilityGroup DevMH_AG | Add-DbaAgReplica -SqlInstance TPADWSQLMHCB01
#make sure Listener IP is pingable before you add it.
Add-DbaAgListener -SqlInstance TPADWSQLMHCA01 -Name TPADWSQLMHCL01 -AvailabilityGroup DMH_AG -IPAddress 10.40.41.238 -Port 1433 -SubnetMask 255.255.255.0
#Test-DbaAvailabilityGroup -SqlInstance TPADWSQLMHCA01 -AvailabilityGroup DevMH_AG -AddDatabase test -SeedingMode Automatic
