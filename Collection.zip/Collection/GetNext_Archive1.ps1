﻿clear
get-date
Import-Module dbatools -ErrorAction SilentlyContinue
#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblAttachments]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblAttachments]'
 Query = "SELECT [AttachmentGUID], [PackageGUID], [FieldDefGUID], [FileName], [LastModifiedUserID], [LastModifiedTimestamp], [FileData]
FROM [PRODWMSSPGN2-01\IHGN2P01].[GetNext].[dbo].[FLOWDATAtblAttachments] WITH (NOLOCK) where PackageGUID in
(select P.PackageGUID from FLOWDATAtblPackages P INNER JOIN FLOWDATAtblFieldData FD0 WITH(NOLOCK)
ON FD0.PackageGUID = P.PackageGUID INNER JOIN FLOWDEFtblFields FDF0 WITH(NOLOCK) ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source'AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblPackageLinks]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblPackageLinks]'
 Query = "SELECT [PackageLinkGUID], [ParentPackageGUID], [ChildPackageGUID], [UserID], [Timestamp], [ParentPackageLocked], [ChildPackageLocked]
FROM [PRODWMSSPGN2-01\IHGN2P01].[GetNext].[dbo].[FLOWDATAtblPackageLinks] WITH (NOLOCK) where ParentPackageGUID in
(select P.PackageGUID from FLOWDATAtblPackages P INNER JOIN FLOWDATAtblFieldData FD0 WITH(NOLOCK)
ON FD0.PackageGUID = P.PackageGUID INNER JOIN FLOWDEFtblFields FDF0 WITH(NOLOCK) ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params


#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblSubPackages]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblSubPackages]'
 Query = "SELECT [SubPackageGUID], [ParentPackageGUID], [ParentFieldDefGUID], [ChildPackageGUID]
FROM [PRODWMSSPGN2-01\IHGN2P01].[GetNext].[dbo].[FLOWDATAtblSubPackages] WITH (NOLOCK) where ParentPackageGUID in
(select P.PackageGUID from FLOWDATAtblPackages P INNER JOIN FLOWDATAtblFieldData FD0 WITH(NOLOCK)
ON FD0.PackageGUID = P.PackageGUID INNER JOIN FLOWDEFtblFields FDF0 WITH(NOLOCK) ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params

#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblTriggers]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblTriggers]'
 Query = "SELECT [TriggerGUID], [PackageGUID], [ItemGUID], [TriggerName], [CreatedTimestamp], [CreatedUserID], [CreatedDBLoginID], [Processed], [ProcessedTimestamp], [ProcessedUserID], [ProcessedDBLoginID], [Notes], [OutputGUID], [IsActionTrigger], [ApplicationName], [LockedBy], [ProcessedNotes], [Carrier], [Resolution]
FROM [PRODWMSSPGN2-01\IHGN2P01].[GetNext].[dbo].[FLOWDATAtblTriggers]  WITH (NOLOCK) where PackageGUID in
(select P.PackageGUID from FLOWDATAtblPackages P INNER JOIN FLOWDATAtblFieldData FD0 WITH(NOLOCK)
ON FD0.PackageGUID = P.PackageGUID INNER JOIN FLOWDEFtblFields FDF0 WITH(NOLOCK) ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-01-01 00:00:00' AND '2020-02-26 23:59:59'
AND P.WorkflowDefGUID in('DEA1EA51-3539-4383-B2B1-B81EAA1CC01B'--CIGNA
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params
get-date