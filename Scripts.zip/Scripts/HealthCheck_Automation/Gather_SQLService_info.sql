Use master
go

SELECT 
@@Servername AS SQLInstance,SERVICENAME, STARTUP_TYPE_DESC, STATUS_DESC,
LAST_STARTUP_TIME,SERVICE_ACCOUNT,
IS_CLUSTERED ,convert(varchar, getdate(), 120) AS Collectiontime, 
CASE 
WHEN STATUS_DESC <> 'Running' Then 'UnHealthy' ELse 'Healthy' END AS ServicesHealthStatus
FROM SYS.DM_SERVER_SERVICES