﻿Import-Module dbatools -EA SilentlyContinue
Remove-DbaRegServerGroup -SqlInstance TPAPWMSSQL002 -Group NonProd -Confirm:$false
Import-DbaRegServer -SqlInstance TPAPWMSSQL002 -Path C:\Users\a-sm58408\Documents\DbatoolsExport\TPAPWMSSQL002-reggroup-NonProd-20250707101435.xml
Remove-DbaRegServerGroup -SqlInstance TPAPWMSSQL002 -Group Prod -Confirm:$false
Import-DbaRegServer -SqlInstance TPAPWMSSQL002 -Path C:\Users\a-sm58408\Documents\DbatoolsExport\TPAPWMSSQL002-reggroup-Prod-20250707102941.xml