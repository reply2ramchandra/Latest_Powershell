﻿$server='PRODWMSSPGN2-01'
Import-Module dbatools -DisableNameChecking 
Update-DbaBuildReference 
Update-DbaInstance -ComputerName $server -Version 2012 -Type ServicePack -Restart -Path D:\patch -Confirm:$false
#Update-DbaInstance -ComputerName $server -Version 2012 -Type ALL -Restart -Path D:\patch -Confirm:$false