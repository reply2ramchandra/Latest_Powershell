USE [DBA]
GO

/****** Object:  StoredProcedure [dbo].[usp_repo_gen_drop_replication]    Script Date: 11/18/2022 4:07:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [dbo].[usp_repo_gen_drop_replication] @Distributor Nvarchar(256) = NULL
AS 

	/***************************************************************************************************************************************
		 Copyright(c) 2016 Harsha Vasa @ Ensono 
         All rights reserved. No part of this script may be reproduced/shared in any form or by making any changes - without written 
         permissions from the author

		Purpose: This script is used to generate scripts to drop,disable the replication topology objects. Should be executed at distributor
		

		History:
		------------------------------------------------------------------------------------------------------------------------------------
		Author                                   Date Created                Comments
		------------------------------------------------------------------------------------------------------------------------------------
		Harsha vasa                              2016-04-21                  Initial draft



	    ------------------------------------------------------------------------------------------------------------------------------------

		Documentation:
		--------------
		# Only to execute at distributor
		# Dependent object - view - dba.dbo.vreplinfo
		# Run the output generated in SQLCMD mode


		Execution Samples:
		------------------

		1. EXEC dbo.usp_repo_gen_drop_replication N'RRWIN-SQLDVAPI'


    ***************************************************************************************************************************************/
 
BEGIN 
SET NOCOUNT ON;
DECLARE @rOutput BIT;
        
		SET @Distributor = COALESCE(@Distributor,@@servername);

		-- begin validation
		IF @@servername != @Distributor
		BEGIN 
		    RAISERROR ('Servername is not matched. Input server : %s',16,1,@Distributor) WITH NOWAIT;
			RETURN (1);
		END 
		IF OBJECT_ID('msdb.dbo.MSdistributiondbs','U') IS NULL
		BEGIN 
			RAISERROR ('Server : %s is not configured for any distribution',16,1,@Distributor) WITH NOWAIT;
			RETURN (1);
		END 

		IF OBJECT_ID('dbo.vreplinfo','V') IS NULL
		BEGIN
            RAISERROR ('Dependent view : [dbo].[vreplinfo] is missing in the DBA database. Please deploy the view and re-run the script. Location to the script : \\ACWIN-MGMT03\D$\DBA\Replication Monitor Suite\1_vReplInfo.sql',16,1) WITH NOWAIT;
			RETURN (1);
		END
		-- end validation

        BEGIN TRY
		    
			
			SELECT t.GenDropScript AS [--GenDropScript]
			FROM (
			-- Script Header
			SELECT 0 AS Ord,1 AS ExecOrd,'/'+REPLICATE('*',5)+SPACE(1)+N'All the below scripts should be run in SQLCMD mode. To Enable this mode - SSMS >> Query (Menu) >> Click SQLCMD mode option.'+SPACE(1)+REPLICATE('*',5)+'/'+CHAR(10) AS [GenDropScript]
			UNION ALL 
			-- print commands
			SELECT 1 ,1,'/'+REPLICATE('*',5)+SPACE(1)+N'Generated scripts to DISABLE/DROP replication suite on the server:'+SPACE(1)+QUOTENAME(@Distributor)+SPACE(1)+REPLICATE('*',5)+'/' 
			FROM msdb.dbo.MSdistpublishers AS M
			WHERE name = @Distributor
			UNION ALL

			-- execute at Publisher
			SELECT 1,2,SPACE(1)+N':CONNECT'+SPACE(1)+M.name
			FROM msdb.dbo.MSdistpublishers AS M 
			WHERE EXISTS ( SELECT 1 FROM dbo.vReplInfo AS RI WHERE RI.Publisher = M.name)
			UNION ALL
			-- 1. drop subscriptions		
			SELECT DISTINCT 1,3,'EXEC '+QUOTENAME(RI.publisherdb)+'.sys.sp_dropsubscription @Publication = N'+CHAR(39)+RI.PublicationName+CHAR(39)+',@article = ''ALL'''+
			',@Subscriber = N'+CHAR(39)+RI.Subscriber+CHAR(39)+
			',@destination_db = N'+CHAR(39)+RI.Subscriberdb+CHAR(39) + CHAR(10)+'GO' COLLATE database_default 
			FROM dbo.vReplInfo AS RI
			WHERE RI.Subscriber IS NOT NULL 
			UNION ALL

			-- 2. drop articles 
			SELECT DISTINCT 2,1,'EXEC '+QUOTENAME(RI.publisherdb)+'.sys.sp_droparticle @Publication = N'+CHAR(39)+RI.PublicationName+CHAR(39)+',@article = N'+CHAR(39)+RI.source_object+CHAR(39)+
			',@force_invalidate_snapshot = 1'+ CHAR(10)+'GO' COLLATE database_default 
			FROM dbo.vReplInfo AS RI
			UNION ALL 

			-- 3. drop publication 
			SELECT DISTINCT 3,1,'EXEC '+QUOTENAME(dmp.publisher_db)+'.sys.sp_droppublication @Publication = N'+CHAR(39)+dmp.Publication+CHAR(39)+ CHAR(10)+'GO' COLLATE database_default 
			FROM [distribution].dbo.MSpublications AS dmp
			UNION ALL

			-- execute at distributor
			SELECT 3,2,SPACE(1)+N':CONNECT'+SPACE(1)+@Distributor
			UNION ALL

			-- 4. disable replication
			SELECT DISTINCT 4,1,'EXEC [master].sys.sp_replicationdboption @dbname = N'+CHAR(39)+RI.publisherdb+CHAR(39)+',@optname = N''publish'', @value = N''false'''+ CHAR(10)+'GO' COLLATE database_default 
			FROM dbo.vReplInfo AS RI
			UNION ALL 

			-- 5. dropping registered subscribers
			SELECT DISTINCT 5,1, 'EXEC [master].sys.sp_dropsubscriber @Subscriber = N'+CHAR(39)+RI.Subscriber+CHAR(39)+CHAR(10)+'GO' COLLATE database_default 
			FROM dbo.vReplInfo AS RI
			WHERE RI.Subscriber IS NOT NULL
			UNION ALL 

			-- 6. drop distribution publishers
			SELECT 6,1,'EXEC [master].sys.sp_dropdistpublisher @publisher = N'+QUOTENAME(M.name,'''')+CHAR(10)+'GO' COLLATE database_default 
			FROM msdb.dbo.MSdistpublishers AS M
			UNION ALL 

			-- 7. drop distribution db
			SELECT 7,1,'EXEC [master].sys.sp_dropdistributiondb @database = N'+QUOTENAME(M.name,'''')+CHAR(10)+'GO' COLLATE database_default
			FROM msdb.dbo.MSdistributiondbs AS M
			UNION ALL

			-- 8. uninstall the server as disributor
			SELECT 8,1,'EXEC [master].sys.sp_dropdistributor @no_checks = 1,@ignore_distributor = 1'+CHAR(10)+'GO' COLLATE database_default 
			) t
			ORDER BY t.ord,t.ExecOrd
			;

			SET @rOutput = 0;

		END TRY
		BEGIN CATCH

			DECLARE @rErr Nvarchar(4000);
			SET @rErr = ERROR_MESSAGE() + CAST(ERROR_LINE() AS Varchar(5));
			RAISERROR (@rErr, 11, 1);
			SET @rOutput = 1;

		END CATCH;
END; 

GO


