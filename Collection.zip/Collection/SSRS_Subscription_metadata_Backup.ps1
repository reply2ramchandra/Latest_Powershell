﻿# Load Reporting Services Tools module
Import-Module ReportingServicesTools

# Define SSRS server URI and export path
$ReportServerUri = "http://your-ssrs-server/reportserver"
$ExportPath = "C:\SSRS_Backup"

# Create export directory if it doesn't exist
if (!(Test-Path -Path $ExportPath)) {
    New-Item -ItemType Directory -Path $ExportPath
}

# Get all items in the SSRS report server
$items = Get-RsFolderContent -ReportServerUri $ReportServerUri -Path "/"

# Filter only reports
$reports = $items | Where-Object { $_.TypeName -eq "Report" }

# Loop through each report
foreach ($report in $reports) {
    $reportPath = $report.Path
    $safeReportName = $report.Name -replace '[\\/:*?"<>|]', '_'
    $reportFolder = "$ExportPath\$safeReportName"

    # Create folder for each report
    if (!(Test-Path -Path $reportFolder)) {
        New-Item -ItemType Directory -Path $reportFolder
    }

    # Export subscriptions
    $subscriptions = Get-RsSubscription -ReportServerUri $ReportServerUri -RsItem $reportPath
    $counter = 1
    foreach ($sub in $subscriptions) {
        $filePath = "$reportFolder\Subscription_$counter.xml"
        $sub | Export-RsSubscriptionXml -Path $filePath
        $counter++
    }

    # Export report metadata
    $metadataFile = "$reportFolder\Metadata.txt"
    $reportDetails = @"
Report Name: $($report.Name)
Path: $($report.Path)
Created By: $($report.CreatedBy)
Creation Date: $($report.CreationDate)
Modified By: $($report.ModifiedBy)
Modified Date: $($report.ModifiedDate)
Description: $($report.Description)
"@
    $reportDetails | Out-File -FilePath $metadataFile -Encoding UTF8
}

Write-Host "All subscriptions and metadata exported to $ExportPath"
