USE [msdb]
GO

/****** Object:  Job [ACXJOB_Admin_Gather_ServerLog_Information_PS]    Script Date: 6/14/2017 11:19:36 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Acx-Maintenance]    Script Date: 6/14/2017 11:19:36 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Acx-Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Acx-Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ACXJOB_Admin_Gather_ServerLog_Information_PS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'For all the Active Database Servers connected to the Central Management Server, the Server Log Information will be gathered by the execution of this job. DBA.dbo.DBServersAll.DBSAActive = 1', 
		@category_name=N'Acx-Maintenance', 
		@owner_login_name=N'PRSCOAD\prod-sql-dba', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Truncate Log Tables]    Script Date: 6/14/2017 11:19:37 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Truncate Log Tables', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate Table AdminLog.ErrorLogs', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Deletion of Previously Loaded Data]    Script Date: 6/14/2017 11:19:37 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Deletion of Previously Loaded Data', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate Table AdminServer.StageErrorLog', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Gather StageErrorLog]    Script Date: 6/14/2017 11:19:37 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Gather StageErrorLog', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
."Y:\SSISRoot\APPDBA\PSScripts\Scripts\write-datatable.ps1"

#Looping logic taken from: https://sqljgood.wordpress.com/2014/09/17/using-powershell-to-loop-through-a-list-of-sql-server-databases/

$instances = invoke-sqlcmd -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -Query "SELECT NULL,[DBSAServerConnection],DATEADD(dd,DATEDIFF(dd,0,getdate()),0),NULL FROM AdminControl.DBServersAll WHERE DBSAActive = 1 ORDER BY [DBSAServerConnection]"
Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminLog.ErrorLogs" -Data $instances

foreach ($instance in $instances)
{
	$Inst = $instance.DBSAServerConnection
	try
	{
		$dt=invoke-sqlcmd -ServerInstance ${Inst} -inputfile "Y:\SSISRoot\APPDBA\PSScripts\Scripts\Admin_Gather_Errorlog.sql" 
		Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminServer.StageErrorLog" -Data $dt	}
	catch
	{
		#
	}
}

', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update SQL_ErrorLog]    Script Date: 6/14/2017 11:19:37 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update SQL_ErrorLog', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
MERGE AdminServer.SQL_ErrorLog AS Target
USING  AdminServer.StageErrorLog AS Source
ON (Source.LogDate = Target.LogDate and Source.ProcessInfo = Target.ProcessInfo 
and Source.Text = Target.Text and Source.Server = Target.Server)

WHEN NOT MATCHED BY TARGET THEN
    INSERT (LogDate,ProcessInfo,Text,Server)
    VALUES (Source.LogDate, Source.Processinfo, Source.Text,Source.Server)  ;
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Log Tables]    Script Date: 6/14/2017 11:19:37 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Log Tables', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
UPDATE AdminLog.ErrorLogs
SET RunResults = ''Collected''
FROM AdminLog.ErrorLogs AS L INNER JOIN AdminControl.DBServersAll AS C ON
L.ServerName = C.DBSAServerConnection 
INNER JOIN 
AdminServer.StageErrorLog AS R ON
C.DBSAServerName = R.Server
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run_Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20100518, 
		@active_end_date=99991231, 
		@active_start_time=61500, 
		@active_end_time=235959, 
		@schedule_uid=N'4703b5b2-4538-4a3d-a428-2cda28c47e65'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

