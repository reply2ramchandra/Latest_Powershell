﻿##logon to Server and run..make sure you have file at correct path and change filename accordingly
Get-Date
Start-Process -wait wusa.exe -ArgumentList "/update C:\Patch\windows10.0-KB5052000-x64-2015-02.msu","/quiet","/norestart","/log"
Get-date
