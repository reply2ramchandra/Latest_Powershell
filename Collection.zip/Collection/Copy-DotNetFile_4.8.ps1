﻿$server='TPATWSQLCLU04'
Invoke-Command -ComputerName $server -ScriptBlock {
 write-host "Lets create a Folder to copy the reg files if not exist." -ForegroundColor cyan
$targetpatchfolder="C:\Patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
} 
Write-Host "Let's copy the DotNet File." -ForegroundColor cyan
$cufile= Get-ChildItem X:\ -Filter 'NDP48*.exe' 
$cufile=$cufile.FullName 
$target="C:\Patch"
$cred=Get-Credential a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $cufile -Destination $target -ToSession $s  -Force -ErrorAction SilentlyContinue
