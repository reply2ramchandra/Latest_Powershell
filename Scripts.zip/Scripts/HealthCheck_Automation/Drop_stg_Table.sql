-- use database
USE [DFIN_ArcReporting_Issue];
GO
 
IF OBJECT_ID(N'stg.DbaService', N'U') IS NOT NULL  
DROP TABLE [stg].[DbaService];  
GO

IF OBJECT_ID(N'stg.DbaDatabase', N'U') IS NOT NULL  
DROP TABLE [stg].[DbaDatabase];  
GO


IF OBJECT_ID(N'stg.DbaDbLogSpace', N'U') IS NOT NULL  
DROP TABLE [stg].[DbaDbLogSpace];  
GO

IF OBJECT_ID(N'stg.DbaDbSpace', N'U') IS NOT NULL  
DROP TABLE [stg].[DbaDbSpace];  
GO

IF OBJECT_ID(N'stg.DbaMemoryCondition', N'U') IS NOT NULL  
DROP TABLE [stg].[DbaMemoryCondition];  
GO

IF OBJECT_ID(N'stg.DbaCpuRingBuffer', N'U') IS NOT NULL  
DROP TABLE [stg].[DbaCpuRingBuffer];  
GO

IF OBJECT_ID(N'stg.DbaProcess', N'U') IS NOT NULL  
DROP TABLE [stg].[DbaProcess];  
GO

IF OBJECT_ID(N'stg.DbaDiskSpace', N'U') IS NOT NULL  
DROP TABLE [stg].[DbaDiskSpace];  
GO