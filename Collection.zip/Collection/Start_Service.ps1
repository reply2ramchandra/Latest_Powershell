﻿ ##MAKE SURE THE TARGET SERVERNAME IS INTENED SERVER TO CHECK#####
 Import-Module dbatools -EA SilentlyContinue
 $TargetServer='TPAPWPEDSQL001'
Get-DbaService $TargetServer | Where-Object  {$_.State -eq 'Stopped'} | Select-Object ServiceName,state

Invoke-Command -ComputerName $TargetServer -ScriptBlock {
$service=Get-Service '*SQL*' | Where-Object {$_.Status -eq 'Stopped'} | Select Name
if($service)
{
foreach($servicename in $service.Name)
{
Start-Service $servicename -Verbose
$servicename.Refresh
}
 }
 
 
else
{ 
write-Host " SQL Services are up and running fine!" -ForegroundColor Green} }

#$servicename.Refresh
Get-DbaService $TargetServer | Where-Object  {$_.State -eq 'Running' -and $_.StartMode -eq 'Automatic'}  | Select-Object ComputerName,ServiceName,StartName,State

 
##Start SQL Server Agent
Import-Module dbatools -EA SilentlyContinue
$TargetServer='TPADWSQLARCH01'
 #$TargetServer='PROD-BECUBICDB1'
 Get-DbaService $TargetServer | Where-Object  {$_.State -eq 'Stopped' -and $_.ServiceName -eq 'SQLSERVERAGENT'}  | Start-DbaService
#Get-DbaService $TargetServer | Where-Object  {$_.State -eq 'Stopped' -and $_.ServiceName -eq 'MSSQLSERVER'}  | Start-DbaService