﻿Get-EventLog -LogName System -Message *KB5053594* -ComputerName TPATWSQLHHA01 | FT Message -AutoSize
 Get-EventLog -LogName System  -ComputerName TPAPWSQLHH005 | Where-Object {$_.Message -like '*terminate*'} |  Select-Object -Property Source, EventID, InstanceId, Message
#Get-EventLog -LogName 'System' -Message '*restart of computer*' -Newest 5 -ComputerName TPAPWSQLGNXTA01 | format-table machinename, username, timegenerated,Message -autosize
