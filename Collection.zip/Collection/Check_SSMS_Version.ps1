﻿clear-host
$server='TPAPWSQLGNXTB01'
 Invoke-Command -ComputerName $server -ScriptBlock {
    
    $filter = 'Microsoft SQL Server Management Studio'
    $uninstall32 = Get-ChildItem "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall" | ForEach-Object { Get-ItemProperty $_.PSPath } | Where-Object { $_ -match $filter } | Select-Object DisplayVersion
    $uninstall64 = Get-ChildItem "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" | ForEach-Object { Get-ItemProperty $_.PSPath } | Where-Object { $_ -match $filter } | Select-Object DisplayVersion

    if ($uninstall64) {
        $isInstalled = $true
        $installedVersion = $uninstall64.DisplayVersion
    }
    if ($uninstall32) {
        $isInstalled = $true
        $installedVersion = $uninstall32.DisplayVersion
    }

    if ($isInstalled -eq $true) {
        Write-Host "Version $installedVersion was detected on your system! " -ForegroundColor Yellow -NoNewline
        hostname
            }}