﻿CLEAR
import-module dbatools -EA SilentlyContinue
#Get-DbaDatabase -SqlInstance HPSSQL03\SQL03 -IncludeLastUsed -ExcludeSystem
Get-DbaDatabase -SqlInstance TPAPWACTSQL001 -Database HPSCommissions_14Jan25 -IncludeLastUsed
