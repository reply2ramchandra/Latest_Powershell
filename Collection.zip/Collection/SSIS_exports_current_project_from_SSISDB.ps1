﻿# Parameters
$serverName = "YourSqlServerInstance"
$catalogFolder = "YourSSISCatalogFolder"   # e.g., "SSISProjects"
$backupRoot = "C:\SSISBackups"

# Load SMO and Integration Services assemblies
Add-Type -AssemblyName "Microsoft.SqlServer.Smo"
Add-Type -AssemblyName "Microsoft.SqlServer.Management.IntegrationServices"

# Connect to the server
$server = New-Object Microsoft.SqlServer.Management.Smo.Server $serverName

# Get Integration Services catalog
$integrationServices = New-Object Microsoft.SqlServer.Management.IntegrationServices.IntegrationServices $server

# Get the SSISDB catalog
$catalog = $integrationServices.Catalogs["SSISDB"]

# Get the folder
$folder = $catalog.Folders[$catalogFolder]

# Loop through all projects in the folder
foreach ($project in $folder.Projects) {
    $projectName = $project.Name
    $projectBackupPath = Join-Path $backupRoot $projectName

    # Create project backup folder if it doesn't exist
    if (-not (Test-Path $projectBackupPath)) {
        New-Item -Path $projectBackupPath -ItemType Directory | Out-Null
    }

    # Set backup file path with timestamp
    $timestamp = Get-Date -Format yyyyMMdd_HHmmss
    $backupFile = Join-Path $projectBackupPath "$projectName-$timestamp.ispac"

    # Export the project
    $project.Export($backupFile)
    Write-Host "Exported $projectName to $backupFile"
}