﻿# Load list of SQL Server instances
$sourceInstances = Get-Content "T:\Test\admin_recovery.txt"

# Define your SQL query
$query = "ALTER DATABASE [admin] SET RECOVERY SIMPLE;"  # Replace with your actual query

# Loop through each instance
foreach ($sourceInstance in $sourceInstances) {
            try {
            # Build connection string
            $sourceConnStr = "Server=$sourceInstance;Database=master;Trusted_Connection=True;"
            
            # Create and open connection
            $sourceConn = New-Object System.Data.SqlClient.SqlConnection $sourceConnStr
            $sourceCmd = $sourceConn.CreateCommand()
            $sourceCmd.CommandText = $query
            $sourceConn.Open()

            # Execute query and load results
            $reader = $sourceCmd.ExecuteReader()
            $table = New-Object System.Data.DataTable
            $table.Load($reader)

            # Close connection
            $sourceConn.Close()

            # Output results (optional)
            Write-Host "Results from ${sourceInstance}:"
            $table | Format-Table -AutoSize
        }
        catch {
            Write-Warning "Error connecting to ${sourceInstance}: $_"
        }
    }