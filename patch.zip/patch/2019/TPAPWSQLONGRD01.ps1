Import-Module dbatools -EA SilentlyContinue
Update-DbaBuildReference
Update-DbaInstance -ComputerName BLDPWLOGGER12 -KB 5065222 -Restart -Path C:\patch -Confirm:$false
