USE [msdb]
GO

/****** Object:  Job [ACXJOB_Admin_Gather_DBINFO_Information_PS]    Script Date: 6/14/2017 11:18:34 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Acx-Maintenance]    Script Date: 6/14/2017 11:18:34 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Acx-Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Acx-Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ACXJOB_Admin_Gather_DBINFO_Information_PS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'For all the Active Database Servers connected to the Central Management Server, the DBINFO Information will be gathered by the execution of this job. DBA.dbo.DBServersAll.DBSAActive = 1', 
		@category_name=N'Acx-Maintenance', 
		@owner_login_name=N'PRSCOAD\prod-sql-dba', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Truncate Log Tables]    Script Date: 6/14/2017 11:18:34 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Truncate Log Tables', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate Table AdminLog.DBINFO', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Deletion of Previously Loaded Data]    Script Date: 6/14/2017 11:18:34 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Deletion of Previously Loaded Data', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
DELETE From AdminServer.DBINFO_Information 
WHERE DATEPART(MONTH, AdminServer.DBINFO_Information.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, AdminServer.DBINFO_Information.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, AdminServer.DBINFO_Information.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Gather Server Properties]    Script Date: 6/14/2017 11:18:34 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Gather Server Properties', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'
."Y:\SSISRoot\APPDBA\PSScripts\Scripts\write-datatable.ps1"

#Looping logic taken from: https://sqljgood.wordpress.com/2014/09/17/using-powershell-to-loop-through-a-list-of-sql-server-databases/

$instances = invoke-sqlcmd -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -Query "SELECT NULL,[DBSAServerConnection],DATEADD(dd,DATEDIFF(dd,0,getdate()),0),NULL FROM AdminControl.DBServersAll WHERE DBSAActive = 1 ORDER BY [DBSAServerConnection]"
Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminLog.DBINFO" -Data $instances

foreach ($instance in $instances)
{
	$Inst = $instance.DBSAServerConnection
	try
	{
		$dt=invoke-sqlcmd -ServerInstance ${Inst} -inputfile "Y:\SSISRoot\APPDBA\PSScripts\Scripts\Admin_Gather_Server_DBINFO_Information.sql" 
		Write-DataTable -ServerInstance "PWPAXD-SQLVM001.PRSCOAD.COM\SQL001" -Database "DBA" -TableName "AdminServer.DBINFO_Information" -Data $dt	}
	catch
	{
		#
	}
}

', 
		@database_name=N'master', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Log Tables]    Script Date: 6/14/2017 11:18:34 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Log Tables', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + ''/'' + @DateDay + ''/'' + @DateYear
Declare @RecordsCollected int
UPDATE AdminLog.DBINFO
SET RunResults = ''Collected''
FROM AdminLog.DBINFO AS L INNER JOIN AdminControl.DBServersAll AS C ON
L.ServerName = C.DBSAServerConnection 
INNER JOIN 
AdminServer.DBINFO_Information AS R ON
C.DBSAServerName = R.Server
WHERE DATEPART(MONTH, R.Date_Key) = DATEPART(MONTH, @Date_Key) AND
      DATEPART(DAY, R.Date_Key) = DATEPART(DAY, @Date_Key) AND
      DATEPART(YEAR, R.Date_Key) = DATEPART(YEAR, @Date_Key)
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Database Control Information � Inserts]    Script Date: 6/14/2017 11:18:34 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Database Control Information � Inserts', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
MERGE [AdminControl].[Database_Control_Information] AS Target
USING  (SELECT DISTINCT TOP 100 PERCENT 
	   ''LSC Communications, Inc.'' AS CustomerName
	  ,D.[server] AS [ServerName]
      ,D.[db] AS [DatabaseName]
	  ,D.[crdate] AS [CreateDate]
	  ,D.[Date_Key] AS [UpdateDate]
--      ,NULL AS [Application]
--      ,NULL AS [Owners]
--      ,NULL AS [Functional Group]
--	    ,NULL AS [ARC]
  FROM [DBA].[AdminServer].[DBINFO_Information] AS D 
  WHERE Date_Key = (SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[DBINFO_Information])) AS Source
ON (Source.ServerName = Target.ServerName and Source.DatabaseName = Target.DatabaseName)

WHEN NOT MATCHED BY TARGET THEN
    INSERT (CustomerName,ServerName,DatabaseName,CreateDate, UpdateDate)
    VALUES (Source.CustomerName, Source.ServerName, Source.DatabaseName,Source.CreateDate, Source.UpdateDate)  
WHEN NOT MATCHED BY Source THEN
    DELETE ;
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Database Control Information � Updates]    Script Date: 6/14/2017 11:18:34 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Database Control Information � Updates', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
UPDATE [DBA].[AdminControl].[Database_Control_Information]
SET [DBA].[AdminControl].[Database_Control_Information].[Application] = [DBA].[AdminServer].[Database_Information].[Applications]
FROM [DBA].[AdminControl].[Database_Control_Information] INNER JOIN [DBA].[AdminServer].[Database_Information] ON
[DBA].[AdminControl].[Database_Control_Information].[ServerName] =  [DBA].[AdminServer].[Database_Information].[ServerName] 
LEFT JOIN [DBA].[AdminServer].[ACXIOM_Admin_Server_Information_Bowne] ON
  [DBA].[AdminServer].[Database_Information].[ServerName] = [DBA].[AdminServer].[ACXIOM_Admin_Server_Information_Bowne].[ServerName]
  WHERE [DBA].[AdminServer].[Database_Information].[DatabaseName] NOT IN (''master'',''msdb'',''model'',''tempdb'',''DBA'')
  AND [DBA].[AdminControl].[Database_Control_Information].[Application] IS NULL
  AND Date_Key = (SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[Database_Information])

UPDATE [DBA].[AdminControl].[Database_Control_Information]
SET [DBA].[AdminControl].[Database_Control_Information].[Owners] = [DBA].[AdminServer].[Database_Information].[Owners]
FROM [DBA].[AdminControl].[Database_Control_Information] INNER JOIN [DBA].[AdminServer].[Database_Information] ON
[DBA].[AdminControl].[Database_Control_Information].[ServerName] =  [DBA].[AdminServer].[Database_Information].[ServerName] 
LEFT JOIN [DBA].[AdminServer].[ACXIOM_Admin_Server_Information_Bowne] ON
  [DBA].[AdminServer].[Database_Information].[ServerName] = [DBA].[AdminServer].[ACXIOM_Admin_Server_Information_Bowne].[ServerName]
  WHERE [DBA].[AdminServer].[Database_Information].[DatabaseName] NOT IN (''master'',''msdb'',''model'',''tempdb'',''DBA'')
  AND [DBA].[AdminControl].[Database_Control_Information].[Owners] IS NULL
  AND Date_Key = (SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[Database_Information])

UPDATE [DBA].[AdminControl].[Database_Control_Information]
SET [DBA].[AdminControl].[Database_Control_Information].[Functional Group] = [DBA].[AdminServer].[Database_Information].[FunctionalGroups]
FROM [DBA].[AdminControl].[Database_Control_Information] INNER JOIN [DBA].[AdminServer].[Database_Information] ON
[DBA].[AdminControl].[Database_Control_Information].[ServerName] =  [DBA].[AdminServer].[Database_Information].[ServerName] 
LEFT JOIN [DBA].[AdminServer].[ACXIOM_Admin_Server_Information_Bowne] ON
  [DBA].[AdminServer].[Database_Information].[ServerName] = [DBA].[AdminServer].[ACXIOM_Admin_Server_Information_Bowne].[ServerName]
  WHERE [DBA].[AdminServer].[Database_Information].[DatabaseName] NOT IN (''master'',''msdb'',''model'',''tempdb'',''DBA'')
  AND [DBA].[AdminControl].[Database_Control_Information].[Functional Group] IS NULL
  AND Date_Key = (SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[Database_Information])

UPDATE [DBA].[AdminControl].[Database_Control_Information]
SET [DBA].[AdminControl].[Database_Control_Information].[ARC] = CASE WHEN [DBA].[AdminServer].[ACXIOM_Admin_Server_Information_Bowne].[ServerName] IS NULL THEN ''Standard'' ELSE ''Bowne'' END
FROM [DBA].[AdminControl].[Database_Control_Information] INNER JOIN [DBA].[AdminServer].[Database_Information] ON
[DBA].[AdminControl].[Database_Control_Information].[ServerName] =  [DBA].[AdminServer].[Database_Information].[ServerName] 
LEFT JOIN [DBA].[AdminServer].[ACXIOM_Admin_Server_Information_Bowne] ON
  [DBA].[AdminServer].[Database_Information].[ServerName] = [DBA].[AdminServer].[ACXIOM_Admin_Server_Information_Bowne].[ServerName]
  WHERE [DBA].[AdminServer].[Database_Information].[DatabaseName] NOT IN (''master'',''msdb'',''model'',''tempdb'',''DBA'')
  AND [DBA].[AdminControl].[Database_Control_Information].[ARC] IS NULL
  AND Date_Key = (SELECT MAX(Date_Key) FROM [DBA].[AdminServer].[Database_Information])

UPDATE [DBA].[AdminControl].[Database_Control_Information]
  SET ARC = ''Not Billed''
  WHERE DatabaseName IN (''DBA'',''System DBs'')
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Monthly Schedule', 
		@enabled=1, 
		@freq_type=16, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20170614, 
		@active_end_date=99991231, 
		@active_start_time=50000, 
		@active_end_time=235959, 
		@schedule_uid=N'603d5ed4-5f48-4bee-889d-d9fc13becf00'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Run_Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=32, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20100518, 
		@active_end_date=99991231, 
		@active_start_time=50000, 
		@active_end_time=235959, 
		@schedule_uid=N'2db8e338-9b05-465d-b3c9-b9f1b5c044a2'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

