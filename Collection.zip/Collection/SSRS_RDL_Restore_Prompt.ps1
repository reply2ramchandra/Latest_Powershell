# Define SSRS Web Service URL and source path
$ReportServerUri = "http://<your-report-server>/ReportServer/ReportService2010.asmx?wsdl"
$SourcePath = "C:\SSRS_Backup"

# Create SSRS proxy
$SSRS = New-WebServiceProxy -Uri $ReportServerUri -UseDefaultCredential -Namespace "SSRS"

# Function to create folders and upload reports with prompt
function Upload-SSRSReports {
    param (
        [string]$LocalPath,
        [string]$SSRSFolder
    )

    # Ensure SSRS folder exists
    try {
        $SSRS.GetItem($SSRSFolder)
    } catch {
        $parent = [System.IO.Path]::GetDirectoryName($SSRSFolder).Replace("\", "/")
        if ($parent -eq "") { $parent = "/" }
        $folderName = [System.IO.Path]::GetFileName($SSRSFolder)
        $SSRS.CreateFolder($folderName, $parent, $null)
        Write-Host "Created folder: $SSRSFolder"
    }

    # Upload .rdl files
    Get-ChildItem -Path $LocalPath -Filter *.rdl | ForEach-Object {
        $reportName = $_.BaseName
        $reportDefinition = [System.IO.File]::ReadAllBytes($_.FullName)

        $existingItems = $SSRS.ListChildren($SSRSFolder, $false)
        $reportExists = $existingItems | Where-Object { $_.Name -eq $reportName -and $_.TypeName -eq "Report" }

        if ($reportExists) {
            $choice = Read-Host "Report '$reportName' exists in '$SSRSFolder'. Overwrite (O), Skip (S), Backup (B)?"
            switch ($choice.ToUpper()) {
                "O" {
                    $SSRS.CreateReport($reportName, $SSRSFolder, $true, $reportDefinition, $null)
                    Write-Host "Overwritten: $reportName"
                }
                "S" {
                    Write-Host "Skipped: $reportName"
                }
                "B" {
                    $timestamp = Get-Date -Format "yyyyMMddHHmmss"
                    $backupName = "$reportName-backup-$timestamp"
                    $SSRS.MoveItem("$SSRSFolder/$reportName", "$SSRSFolder/$backupName")
                    Write-Host "Backed up existing report as: $backupName"
                    $SSRS.CreateReport($reportName, $SSRSFolder, $true, $reportDefinition, $null)
                    Write-Host "Uploaded new report: $reportName"
                }
                default {
                    Write-Host "Invalid choice. Skipped: $reportName"
                }
            }
        } else {
            $SSRS.CreateReport($reportName, $SSRSFolder, $true, $reportDefinition, $null)
            Write-Host "Uploaded: $reportName"
        }
    }

    # Recurse into subfolders
    Get-ChildItem -Path $LocalPath -Directory | ForEach-Object {
        $subFolder = $_.FullName
        $subSSRSFolder = "$SSRSFolder/$($_.Name)"
        Upload-SSRSReports -LocalPath $subFolder -SSRSFolder $subSSRSFolder
    }
}

# Start upload from root folder
Upload-SSRSReports -LocalPath $SourcePath -SSRSFolder "/"
