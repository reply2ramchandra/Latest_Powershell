﻿$node = 'TPAPWSQLMHB001'
$patchid ='KB5068791' 

# Load required modules
Import-Module PSWindowsUpdate -ErrorAction SilentlyContinue
Import-Module dbatools -ErrorAction SilentlyContinue

function Stop-Script {
    param([string]$Message)
    Write-Error $Message
    Stop-Transcript | Out-Null
    exit 1
}

# Function to check OS patch status
function Test-OsPatchStatus {
    param([string]$ComputerName, [string]$PatchId)
    $patch = Get-WUHistory -ComputerName $ComputerName | Where-Object { $_.Title -match $PatchId }
    if ($patch -and $patch.Result -ne 'Failed') {
        return $true
    } else {
        Write-Warning "Patch $PatchId not found or failed on $ComputerName"
        return $false
    }
}

function Wait-Uptime {
    param(
        [string]$SqlInstance,
        [int]$TimeoutSeconds = 600,
        [int]$PollSeconds = 30
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        try {
            if (Get-DbaUptime -SqlInstance $SqlInstance -ErrorAction Stop) {
                return $true
            }
        } catch { Write-Warning "Error during uptime check for ${SqlInstance}: $_" }
        Start-Sleep -Seconds $PollSeconds
    }
    Write-Error "Instance $SqlInstance did not come online within $TimeoutSeconds seconds."
    return $false
}

# Function to check SQL Server status using dbatools
function Test-SqlServerStatus {
    param([string]$SqlInstance)
    try {
        $status = Get-DbaService -ComputerName $SqlInstance -ErrorAction Stop
        $dbengine = $status | Where-Object { $_.ServiceType -eq 'Engine' }
        $agent = $status | Where-Object { $_.ServiceType -eq 'agent' }
        if ($dbengine) {
            Write-Host "SQL Server $($dbengine.ServiceType) status on ${SqlInstance}: is $($dbengine.State)"
            Write-Host "SQL Server $($agent.ServiceType)  status on ${SqlInstance}: is $($agent.State)"
            if ($dbengine.State -eq 'Running') {
                return $true
            } 
           
            else {
                Write-Warning "SQL Server service on $SqlInstance is not running (Status: $($dbengine.State))"
                return $false
            }
        } else {
            Write-Warning "SQL Server service not found on $SqlInstance."
            return $false
        }}
     catch {
        Write-Warning "Error checking SQL Server status on ${SqlInstance}: $_"
        return $false
  }  
}

# Check patch before rebooting node
if (Test-OsPatchStatus -ComputerName $node -PatchId $patchid ) {
   Write-Host ' Okay. Rebooting ' $node -BackgroundColor Green
    Restart-Computer -ComputerName $node -Force
} else {
    Write-Warning "Skipping reboot of $node due to patch failure status."
    Stop-Script "Exiting"
}

Start-Sleep -Seconds 120

if (-not (Wait-Uptime -SqlInstance $node)) {
    Stop-Script "OS Patched node $node did not return in time or SQL Instance $node is not up yet. Manual Intervention required." 
}

# Check SQL Server status after reboot
if (-not (Test-SqlServerStatus -SqlInstance $node)) {
    Stop-Script "SQL Server service on $node is not running after reboot. Manual intervention required."
} else {
    Write-Host "SQL Server service on $node is running and healthy after reboot." -BackgroundColor Green
}