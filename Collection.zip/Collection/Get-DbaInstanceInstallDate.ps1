﻿Import-Module dbatools -EA SilentlyContinue 
Get-DbaInstanceInstallDate -SqlInstance TPADWSQLMHCA01, TPADWSQLMHCB01 -IncludeWindows
