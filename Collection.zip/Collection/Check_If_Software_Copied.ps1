﻿Write-Host "Lets Review the files copied." -ForegroundColor Magenta
$servers=get-content "T:\Test\copy_sw.txt"
foreach($srv in $servers)
{
Invoke-Command -ComputerName $srv -ScriptBlock { 
       $path='D:\SQL\Software'
        Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Where-Object { ($_.CreationTime -gt $(Get-Date).AddDays( - 1))} | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}}  
       }
       }