

DECLARE @dbname sysname    
SET @dbname = NULL --set this to be whatever dbname you want
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Declare @AGC_Primary sysname
Declare @AGC_Status nvarchar(60) 
SELECT  @AGC_Primary = 'TBD'
SELECT  @AGC_Status = 'TBD'
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear

CREATE TABLE #Backup_Audit_Daily (
       [Date_Key] [datetime] NOT NULL,
       [User] [nvarchar](128) NULL,
       [Database] [nvarchar](128) NULL,
       [Server] [nvarchar](128) NULL,
       [BackupType] [char](1) NULL,
       [Review] [varchar](23) NOT NULL,
       [Backup Started] [datetime] NULL,
       [Backup Finished] [datetime] NULL,
       [Total Time] [varchar](116) NULL,
       [BackupFileName] [nvarchar](260) NULL
)

IF SERVERPROPERTY ('IsHadrEnabled') = 1
BEGIN
SELECT @AGC_Status = (SELECT ARS.role_desc FROM master.sys.dm_hadr_availability_replica_states AS ARS WHERE ARS.role_desc <> 'PRIMARY' )
SELECT @AGC_Primary = (SELECT
RCS.replica_server_name -- SQL cluster node name
FROM
sys.availability_groups_cluster AS AGC
  INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS RCS
   ON
    RCS.group_id = AGC.group_id
  INNER JOIN sys.dm_hadr_availability_replica_states AS ARS
   ON
    ARS.replica_id = RCS.replica_id
  INNER JOIN sys.availability_group_listeners AS AGL
   ON
    AGL.group_id = ARS.group_id
WHERE
ARS.role_desc = 'PRIMARY')
END

If @@version like '%2012%' AND @AGC_Primary <> 'TBD'
INSERT INTO #Backup_Audit_Daily 
SELECT @Date_Key AS Date_Key, bup.user_name AS [User],      
bup.database_name AS [Database], 
CONVERT(sysname, SERVERPROPERTY('ServerName')) AS [Server],       
bup.type AS BackupType,   
CASE WHEN DATEDIFF(HH, bup.backup_finish_date, GETDATE()) < 30 THEN 'Full Backup Current'     
         ELSE 'Full Backup Not Current'
         END AS Review,
bup.backup_start_date AS [Backup Started],    
bup.backup_finish_date AS [Backup Finished]   
,CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/3600 AS varchar) + ' hours, '     
 + CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/60 AS varchar)+ ' minutes, '      
+ CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))%60 AS varchar)+ ' seconds' 
AS [Total Time],
bmf.physical_device_name as BackupFileName 
FROM msdb.dbo.backupset bup INNER JOIN msdb..backupmediafamily bmf On bup.media_set_id = bmf.media_set_id
WHERE bmf.family_sequence_number = 1 AND bup.backup_set_id IN      
  (SELECT MAX(backup_set_id) FROM msdb.dbo.backupset 
  WHERE database_name = ISNULL(@dbname, database_name) --if no dbname, then return all   
  AND type = 'D' --only interested in the time of last full backup
  GROUP BY database_name) 
/* COMMENT THE NEXT LINE IF YOU WANT ALL BACKUP HISTORY */  
AND bup.database_name IN 
(SELECT name FROM master.dbo.sysdatabases WHERE DATABASEPROPERTYEX (name, 'Status') = 'ONLINE' AND DATABASEPROPERTYEX (name, 'IsInStandBY') = 0)
UNION ALL    
SELECT @Date_Key AS Date_Key, bup.user_name AS [User],      
bup.database_name AS [Database], 
CONVERT(sysname, SERVERPROPERTY('ServerName')) AS [Server],       
bup.type AS BackupType,   
CASE WHEN DATEDIFF(HH, bup.backup_finish_date, GETDATE()) < 4 THEN 'Log Backup Current'     
         WHEN CONVERT(sysname,DatabasePropertyEx(bup.database_name,'Recovery')) = 'Simple'
                    THEN 'Error-DB in Simple Mode'  
         ELSE 'Log Backup Not Current'
         END AS Review,
bup.backup_start_date AS [Backup Started],    
bup.backup_finish_date AS [Backup Finished]
,CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/3600 AS varchar) + ' hours, ' 
 + CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/60 AS varchar)+ ' minutes, '
+ CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))%60 AS varchar)+ ' seconds'
AS [Total Time],
bmf.physical_device_name as BackupFileName 
FROM msdb.dbo.backupset bup INNER JOIN msdb..backupmediafamily bmf On bup.media_set_id = bmf.media_set_id
WHERE bmf.family_sequence_number = 1 AND bup.backup_set_id IN
  (SELECT MAX(backup_set_id) FROM msdb.dbo.backupset
  WHERE database_name = ISNULL(@dbname, database_name) --if no dbname, then return all
  AND type = 'L' --only interested in the time of last Log backup
  GROUP BY database_name) 
/* COMMENT THE NEXT LINE IF YOU WANT ALL BACKUP HISTORY */
AND bup.database_name IN 
(SELECT name FROM master.dbo.sysdatabases WHERE DATABASEPROPERTYEX (name, 'Status') = 'ONLINE' AND DATABASEPROPERTYEX (name, 'IsInStandBY') = 0)
UNION ALL
SELECT @Date_Key AS Date_Key, bup.user_name AS [User],      
bup.database_name AS [Database],
CONVERT(sysname, SERVERPROPERTY('ServerName')) AS [Server],       
bup.type AS BackupType,   
CASE WHEN DATEDIFF(HH, bup.backup_finish_date, GETDATE()) < 30 THEN 'Diff Backup Current'     
         ELSE 'Diff Backup Not Current'
         END AS Review,
bup.backup_start_date AS [Backup Started],    
bup.backup_finish_date AS [Backup Finished]   
,CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/3600 AS varchar) + ' hours, '     
 + CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/60 AS varchar)+ ' minutes, '      
+ CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))%60 AS varchar)+ ' seconds' 
AS [Total Time],
bmf.physical_device_name as BackupFileName 
FROM msdb.dbo.backupset bup INNER JOIN msdb..backupmediafamily bmf On bup.media_set_id = bmf.media_set_id
WHERE bmf.family_sequence_number = 1 AND bup.backup_set_id IN      
  (SELECT MAX(backup_set_id) FROM msdb.dbo.backupset 
  WHERE database_name = ISNULL(@dbname, database_name) --if no dbname, then return all   
  AND type = 'I' --only interested in the time of last DIF backup  
  GROUP BY database_name) 
/* COMMENT THE NEXT LINE IF YOU WANT ALL BACKUP HISTORY */
AND bup.database_name IN 
(SELECT name FROM master.dbo.sysdatabases WHERE DATABASEPROPERTYEX (name, 'Status') = 'ONLINE' AND DATABASEPROPERTYEX (name, 'IsInStandBY') = 0)
UNION ALL
SELECT @Date_Key AS Date_Key,    
       NULL as [User],
       MAS.name as database_name,
    CONVERT(sysname, SERVERPROPERTY('ServerName')) AS [Server],    
    NULL AS BackupType,
    'NO DB Backup Performed' AS Review,
    NULL AS [Backup Started],
    NULL AS [Backup Finished],
    NULL AS [Total Time],
    NULL AS BackupFileName 
FROM master.dbo.sysdatabases AS MAS
WHERE name NOT IN ('tempdb') AND 
name NOT IN (SELECT DISTINCT database_name from msdb.dbo.backupset) AND
DATABASEPROPERTYEX (name, 'Status') = 'ONLINE' AND 
DATABASEPROPERTYEX (name, 'IsInStandBY') = 0
ORDER BY Server,bup.database_name,BackupType
--
--
ELSE IF @AGC_Status = 'TBD' -- For 2012 set to SECONDARY or Greater leaving all other versions set to TBD 
INSERT INTO #Backup_Audit_Daily 
SELECT @Date_Key AS Date_Key, bup.user_name AS [User],      
bup.database_name AS [Database], 
CONVERT(sysname, SERVERPROPERTY('ServerName')) AS [Server],       
bup.type AS BackupType,   
CASE WHEN DATEDIFF(HH, bup.backup_finish_date, GETDATE()) < 30 THEN 'Full Backup Current'     
         ELSE 'Full Backup Not Current'
         END AS Review,
bup.backup_start_date AS [Backup Started],    
bup.backup_finish_date AS [Backup Finished]   
,CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/3600 AS varchar) + ' hours, '     
 + CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/60 AS varchar)+ ' minutes, '      
+ CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))%60 AS varchar)+ ' seconds' 
AS [Total Time],
bmf.physical_device_name as BackupFileName 
FROM msdb.dbo.backupset bup INNER JOIN msdb..backupmediafamily bmf On bup.media_set_id = bmf.media_set_id
WHERE bmf.family_sequence_number = 1 AND bup.backup_set_id IN      
  (SELECT MAX(backup_set_id) FROM msdb.dbo.backupset 
  WHERE database_name = ISNULL(@dbname, database_name) --if no dbname, then return all   
  AND type = 'D' --only interested in the time of last full backup 
  GROUP BY database_name) 
/* COMMENT THE NEXT LINE IF YOU WANT ALL BACKUP HISTORY */  
AND bup.database_name IN 
(SELECT name FROM master.dbo.sysdatabases WHERE DATABASEPROPERTYEX (name, 'Status') = 'ONLINE' AND DATABASEPROPERTYEX (name, 'IsInStandBY') = 0)
UNION ALL    
SELECT @Date_Key AS Date_Key, bup.user_name AS [User],      
bup.database_name AS [Database], 
CONVERT(sysname, SERVERPROPERTY('ServerName')) AS [Server],       
bup.type AS BackupType,   
CASE WHEN DATEDIFF(HH, bup.backup_finish_date, GETDATE()) < 4 THEN 'Log Backup Current'     
         WHEN CONVERT(sysname,DatabasePropertyEx(bup.database_name,'Recovery')) = 'Simple'
                    THEN 'Error-DB in Simple Mode'  
         ELSE 'Log Backup Not Current'
         END AS Review,
bup.backup_start_date AS [Backup Started],    
bup.backup_finish_date AS [Backup Finished]
,CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/3600 AS varchar) + ' hours, ' 
 + CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/60 AS varchar)+ ' minutes, '
+ CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))%60 AS varchar)+ ' seconds'
AS [Total Time],
bmf.physical_device_name as BackupFileName 
FROM msdb.dbo.backupset bup INNER JOIN msdb..backupmediafamily bmf On bup.media_set_id = bmf.media_set_id
WHERE bmf.family_sequence_number = 1 AND bup.backup_set_id IN
  (SELECT MAX(backup_set_id) FROM msdb.dbo.backupset
  WHERE database_name = ISNULL(@dbname, database_name) --if no dbname, then return all
  AND type = 'L' --only interested in the time of last Log backup
  GROUP BY database_name) 
/* COMMENT THE NEXT LINE IF YOU WANT ALL BACKUP HISTORY */
AND bup.database_name IN 
(SELECT name FROM master.dbo.sysdatabases WHERE DATABASEPROPERTYEX (name, 'Status') = 'ONLINE' AND DATABASEPROPERTYEX (name, 'IsInStandBY') = 0)
UNION ALL
SELECT @Date_Key AS Date_Key, bup.user_name AS [User],      
bup.database_name AS [Database],
CONVERT(sysname, SERVERPROPERTY('ServerName')) AS [Server],       
bup.type AS BackupType,   
CASE WHEN DATEDIFF(HH, bup.backup_finish_date, GETDATE()) < 30 THEN 'Diff Backup Current'     
         ELSE 'Diff Backup Not Current'
         END AS Review,
bup.backup_start_date AS [Backup Started],    
bup.backup_finish_date AS [Backup Finished]   
,CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/3600 AS varchar) + ' hours, '     
 + CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))/60 AS varchar)+ ' minutes, '      
+ CAST((CAST(DATEDIFF(s, bup.backup_start_date, bup.backup_finish_date) AS int))%60 AS varchar)+ ' seconds' 
AS [Total Time],
bmf.physical_device_name as BackupFileName 
FROM msdb.dbo.backupset bup INNER JOIN msdb..backupmediafamily bmf On bup.media_set_id = bmf.media_set_id
WHERE bmf.family_sequence_number = 1 AND bup.backup_set_id IN      
  (SELECT MAX(backup_set_id) FROM msdb.dbo.backupset 
  WHERE database_name = ISNULL(@dbname, database_name) --if no dbname, then return all   
  AND type = 'I' --only interested in the time of last DIF backup  
  GROUP BY database_name) 
/* COMMENT THE NEXT LINE IF YOU WANT ALL BACKUP HISTORY */
AND bup.database_name IN 
(SELECT name FROM master.dbo.sysdatabases WHERE DATABASEPROPERTYEX (name, 'Status') = 'ONLINE' AND DATABASEPROPERTYEX (name, 'IsInStandBY') = 0)
UNION ALL
SELECT @Date_Key AS Date_Key,    
       NULL as [User],
       MAS.name as database_name,
    CONVERT(sysname, SERVERPROPERTY('ServerName')) AS [Server],    
    NULL AS BackupType,
    'NO DB Backup Performed' AS Review,
    NULL AS [Backup Started],
    NULL AS [Backup Finished],
    NULL AS [Total Time],
    NULL AS BackupFileName 
FROM master.dbo.sysdatabases AS MAS
WHERE name NOT IN ('tempdb') AND 
name NOT IN (SELECT DISTINCT database_name from msdb.dbo.backupset) AND
DATABASEPROPERTYEX (name, 'Status') = 'ONLINE' AND 
DATABASEPROPERTYEX (name, 'IsInStandBY') = 0
ORDER BY Server,bup.database_name,BackupType

SELECT
       [Date_Key],
       [User],
       [Database],
       [Server],
       [BackupType],
       [Review],
       [Backup Started],
       [Backup Finished],
       [Total Time],
       [BackupFileName]
FROM #Backup_Audit_Daily

