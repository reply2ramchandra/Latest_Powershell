SELECT     TOP 100 PERCENT 
	CONVERT(nvarchar(128), S1.ServerName) AS ServerName,
	S1.rundate, 
	CONVERT(nvarchar(128),S1.name) AS name, 
	S1.step_id,
	CONVERT(nvarchar(128),S1.step_name) AS step_name,
	CONVERT(nvarchar(1024),S1.message) AS message,
	S1.run_status,
	CAST(S1.run_duration / 3600 AS varchar) + ':' + RIGHT('00' + CAST((S1.run_duration % 3600) / 60 AS varchar), 2) 
	+ ':' + RIGHT('00' + CAST(((S1.run_duration % 3600) % 60) AS varchar), 2) AS run_duration
FROM	
(
SELECT  
      sjh.server AS ServerName
    , sjh.run_date
    , sj.name
    , sjh.step_id
    , sjh.step_name
    , sjh.message
    , sjh.run_status
    ,
    CASE
      WHEN LEN(CONVERT(varchar, sjh.run_time)) = 1 THEN 
	CONVERT(datetime, (SUBSTRING(CONVERT(varchar, sjh.run_date), 5, 2) + '/' + RIGHT(CONVERT(varchar, sjh.run_date),2) + '/'
    	+ LEFT(CONVERT(varchar,sjh.run_date), 4) + ' 00:00:0' + RIGHT(CONVERT(varchar, sjh.run_time), 2)))
      WHEN LEN(CONVERT(varchar, sjh.run_time)) = 2 THEN
    	CONVERT(datetime, (SUBSTRING(CONVERT(varchar, sjh.run_date), 5, 2) + '/' + RIGHT(CONVERT(varchar, sjh.run_date),2) + '/'
    	+ LEFT(CONVERT(varchar,sjh.run_date), 4) + ' 00:00:' +  RIGHT(CONVERT(varchar, sjh.run_time), 2)))
      WHEN LEN(CONVERT(varchar, sjh.run_time)) = 3 THEN
    	CONVERT(datetime, (SUBSTRING(CONVERT(varchar, sjh.run_date), 5, 2) + '/' + RIGHT(CONVERT(varchar, sjh.run_date),2) + '/'
    	+ LEFT(CONVERT(varchar,sjh.run_date), 4) + ' 00:0' + LEFT(CONVERT(varchar,sjh.run_time), 1)
    	+ ':' + RIGHT(CONVERT(varchar, sjh.run_time), 2)))
      WHEN LEN(CONVERT(varchar, sjh.run_time)) = 4 THEN
    	CONVERT(datetime, (SUBSTRING(CONVERT(varchar, sjh.run_date), 5, 2) + '/' + RIGHT(CONVERT(varchar, sjh.run_date),2) + '/'
    	+ LEFT(CONVERT(varchar,sjh.run_date), 4) + ' 00:' + LEFT(CONVERT(varchar,sjh.run_time), 2)
    	+ ':' + RIGHT(CONVERT(varchar, sjh.run_time), 2)))
      WHEN LEN(CONVERT(varchar, sjh.run_time)) = 5 THEN
    	CONVERT(datetime, (SUBSTRING(CONVERT(varchar, sjh.run_date), 5, 2) + '/' + RIGHT(CONVERT(varchar, sjh.run_date),2) + '/'
    	+ LEFT(CONVERT(varchar,sjh.run_date), 4) + ' 0' + LEFT(CONVERT(varchar, sjh.run_time),1) + ':' + SUBSTRING(CONVERT(varchar,sjh.run_time), 2, 2)
    	+ ':' + RIGHT(CONVERT(varchar, sjh.run_time), 2)))
      ELSE
    	CONVERT(datetime, (SUBSTRING(CONVERT(varchar, sjh.run_date), 5, 2) + '/' + RIGHT(CONVERT(varchar, sjh.run_date),2) + '/'
    	+ LEFT(CONVERT(varchar,sjh.run_date), 4) + ' ' + LEFT(CONVERT(varchar, sjh.run_time),2) + ':' + SUBSTRING(CONVERT(varchar,sjh.run_time), 3, 2)
    	+ ':' + RIGHT(CONVERT(varchar, sjh.run_time), 2)))
        END
      AS rundate
    , sjh.run_time
    , CASE WHEN LEN(CAST(run_duration AS varchar)) > 5 THEN CAST(LEFT(CAST(run_duration AS varchar), 2) AS int) * 3600 
		+ CAST(SUBSTRING(CAST(run_duration AS varchar), 3, 2) AS int) * 60 + CAST(RIGHT(CAST(run_duration AS varchar), 2) AS int) 
	   WHEN LEN(CAST(run_duration AS varchar)) = 5 THEN CAST(LEFT(CAST(run_duration AS varchar), 1) AS int) * 3600 
		+ CAST(SUBSTRING(CAST(run_duration AS varchar), 2, 2) AS int) * 60 + CAST(RIGHT(CAST(run_duration AS varchar), 2) AS int) 
	   WHEN LEN(CAST(run_duration AS varchar)) = 4 THEN CAST(LEFT(CAST(run_duration AS varchar), 2) AS int) * 60 
		+ CAST(RIGHT(CAST(run_duration AS varchar), 2) AS int) WHEN LEN(CAST(run_duration AS varchar)) = 3 
	        THEN CAST(LEFT(CAST(run_duration AS varchar), 1) AS int) * 60 + CAST(run_duration AS varchar) 
	   ELSE run_duration END AS run_duration
    , sj.date_created
    , sj.date_modified
    , sj.version_number
FROM msdb..sysjobhistory sjh JOIN msdb..sysjobs sj ON 
	sj.job_id = sjh.job_id) S1
WHERE DATEDIFF(MONTH, S1.rundate, GETDATE())< 3
ORDER BY S1.ServerName, S1.rundate, S1.name, S1.step_id
