﻿CREATE PROCEDURE [Admin].[usp_get_inventory_os_sql_sdlc]

/***************************************************************************************************************************************
	Copyright © 2021 Ensono LP, USA. All rights reserved

	Purpose: Get the Ensono Inventory of managed nodes with OSInfo and SqlInstance running 
	

	History:
	------------------------------------------------------------------------------------------------------------------------------------
	Author                                 Date Created                Comments
	------------------------------------------------------------------------------------------------------------------------------------
	Harsha vasa                              2021-10-13                  Initial draft



    ------------------------------------------------------------------------------------------------------------------------------------

	Documentation:
	--------------
            ASCII(169) - ©


	Execution Samples:
	------------------
	#1
	EXEC [Admin].[usp_get_inventory_os_sql_sdlc]

***************************************************************************************************************************************/

AS

	BEGIN
		
		SELECT
			OperatingSystemInfo.ComputerName											   AS WindowsMachineName
		   ,vLatestSqlServerProperties.SqlInstance										   AS SqlInstanceName
		   ,OperatingSystemInfo.OSVersion												   AS WindowsVersion
		   ,CASE OperatingSystemInfo.SPVersion
				WHEN 0 THEN 'RTM'
				ELSE 'SP-' + CAST( OperatingSystemInfo.SPVersion AS VARCHAR(1) )
			END																			   AS WindowsVersionDescription
		   ,vLatestSqlServerProperties.Version + '||' + vLatestSqlServerProperties.Edition AS SqlVersion
		   ,'Node Type:' + CASE
				WHEN vLatestSqlServerProperties.IsClustered = 'True' OR
				vLatestSqlServerProperties.IsHadrEnabled = 'True' THEN 'WindowsFailover Cluster Node'
				ELSE 'Standalone'
			END																			   AS Comments
		FROM Admin.vLatestSqlServerProperties
		OUTER APPLY (SELECT Host FROM Inventory.ClusterNodeNames WHERE SqlInstance = vLatestSqlServerProperties.SqlInstance) AS Cluster
		INNER JOIN Inventory.OperatingSystemInfo ON ComputerName LIKE ISNULL( Host,MachineName ) + '%'

	END