﻿#View the ACL folder using Get-NTFSAccess:
Get-NTFSAccess -Path C:\Foo | Format-Table -AutoSize
#View the ACL file:
Get-NTFSAccess -Path C:\Foo\Foo.Txt | Format-Table -AutoSize