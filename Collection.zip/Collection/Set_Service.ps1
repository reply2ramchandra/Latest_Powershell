﻿Get-Service -ComputerName TPAPWSQLSSRS-03 | Where-Object {$_.Name -like '*MSSQL*' -or $_.Name -like '*SQLSERVER*' -or $_.Name -like '*SQLAgent*' -or $_.Name -like '*Report*'} | Select MachineName,Name,Status, StartType
#Get-Service *SQL* -ComputerName WIN-QUEST-01 | Stop-Service -Force
Get-Service *SQL* -ComputerName TPATWSQLCLU02 | Where-Object {$_.Name -eq "MSSQLSERVER" } | start-Service 
Get-Service *SQL* -ComputerName TPATWSQLCLU02  | Where-Object {$_.Name -eq "SQLSERVERAGENT" } | Start-Service
#Get-Service *SQL* -ComputerName TPAPWANALYTIC01  | Where-Object {$_.Name -eq "SQLAgent`$IHGN2P01" } | Start-Service
#Get-Service *SQL* -ComputerName GCPUWDWSQL004 | Where-Object {$_.Name -eq "MsDtsServer120" } | Start-Service
#Get-Service *SQL* -ComputerName TPATWSQLCLU01 | Where-Object {$_.Name -like "*MSSQLSERVER*" } | ReStart-Service -Force
#Get-Service *SQL* -ComputerName TPATWSQLCLU01 | Restart-Service -Force
#Get-Service *Report* -ComputerName TPAPWSQLSSRS01 | Restart-Service -Force
#Get-Service *MsDtsServer120* -ComputerName HPSSQL11 | Set-Service –StartupType Disabled
#Get-Service *SQLSERVERAGENT* -ComputerName TPADWSQLDL001 | Set-Service –StartupType Automatic
#Get-Service *idera* -ComputerName TPAPWIDESQL001 | Stop-Service -force
#Get-Service *SQL* -ComputerName HPSSQL01 | Select-Object Name, Status, StartType |  Format-Table -AutoSize
#Get-Service *MySQL* -ComputerName TPAPWGSTSQL001
<#
clear
Get-Service *SQL* -ComputerName TPAPWSQLETA01  | Stop-Service
Get-Service *SQL* -ComputerName TPAPWSQLETA01
clear 
Get-Service *SQL* -ComputerName TPAPWSQLETA01  | Start-Service
Get-Service *SQL* -ComputerName TPAPWSQLETA01 
#>
