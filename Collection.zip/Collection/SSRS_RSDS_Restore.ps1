# Load ReportingServicesTools module
# Install-Module -Name ReportingServicesTools -Force
Import-Module ReportingServicesTools

# Define SSRS Report Server URL
$reportServerUri = "http://localhost/ReportServer"  # Change to your SSRS URI

# Define the folder containing your .rsds files
$dataSourceFolder = "C:\SSRS_Backup"  # Change to your folder path

# Define the target folder on SSRS where you want to restore the data sources
$targetFolder = "/Shared Data Sources"  # Change as needed

# Get all .rsds files in the folder
Get-ChildItem -Path $dataSourceFolder -Filter *.rsds | ForEach-Object {
    $dataSourceFilePath = $_.FullName
    Write-Host "Restoring $dataSourceFilePath to $targetFolder ..."
    Import-RsCatalogItem -Path $dataSourceFilePath -Destination $targetFolder -ReportServerUri $reportServerUri -Overwrite
}

Write-Host "All shared data sources restored to $targetFolder"