﻿CREATE SYNONYM [Billing].[format_ci]
	FOR [Admin].[fn_format_sqlci]
