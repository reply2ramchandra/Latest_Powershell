﻿$server='GCPUWUCCE01'
 Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="E:\SQLAudit"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}