﻿Import-Module dbatools -ErrorAction SilentlyContinue
#Failover to SqlInstance given
Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLALFA01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
<#Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLFTPA01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLGNRA01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
Get-DbaAvailabilityGroup -SqlInstance TPAPWSQLSANTA01 | Out-GridView -Passthru | Invoke-DbaAgFailover -Confirm:$false
#>
