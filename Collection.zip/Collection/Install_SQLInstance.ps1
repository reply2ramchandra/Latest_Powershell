﻿ $server='TPAPWSQLTEST01'
 
 #check drive allocation Unit
 Get-DbaDiskSpace $server

<#
 ###IMPORTANT WARNING#####
#Make sure you were try to FORMAT drive in New Server
#one drive at a time
###Use CORRECT SERVER NAME #####
$server='TPAPWSQLGNRB01'
#format the start with "T:" drive for 64kb allocation unit size
invoke-command -computername $server {
Format-Volume -DriveLetter T -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel Tempdb
Format-Volume -DriveLetter L -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel SQLLog
Format-Volume -DriveLetter M -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel SQLData
Format-Volume -DriveLetter D -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel SQLRoot 
#64 kb
Get-Volume | Format-List DriveLetter, AllocationUnitSize}
#>
 #create a Folder
  $server='TPAPWSQLTEST01'
 Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\SQL\Software"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}

<#Copy the ISO file and Patch File

$server='TPAPWSQLTEST01'
#$spfile= Get-ChildItem X:\SQLISO\SP -Filter '*2019*.exe' 
#$spfile=$spfile.FullName 
$cufile= Get-ChildItem X:\SQLISO\CU -Filter '*cu26*.exe' 
$cufile=$cufile.FullName 
$isofile= Get-ChildItem X:\SQLISO\SQL2019 -Filter '*_Ent_*2019*.ISO' 
$isofile=$isofile.FullName
$SSMS= Get-ChildItem X:\SQLISO\ -Filter '*SSMS*.exe' 
$SSMS=$SSMS.FullName  
$target="D:\SQL\Software"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
#foreach ($spfiles in $source){ Copy-Item -Path $spfiles -Destination $target -ToSession $s }
Copy-Item -Path $cufile -Destination $target -ToSession $s
Copy-Item -Path $isofile -Destination $target -ToSession $s
Copy-Item -Path $SSMS -Destination $target -ToSession $s
#>

#reboot the machine before install SQL
$server='TPAPWSQLTEST01'
Restart-Computer -ComputerName $server -Force
Start-Sleep -seconds 300
##wait for server be online
$server='TPAPWSQLTEST01'
$check=Test-NetConnection -ComputerName $server | select PingSucceeded
$check=$check.PingSucceeded
if($check -eq $True){write-host "ALL ok. You may start the activity" -ForegroundColor Green}
#Mount the ISO
$server='TPAQWSQLDL002'
 Invoke-Command -ComputerName $server -ScriptBlock {
 $binarypath="D:\SQL\Software"
 $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO"
 $isoImg=$isoImg.FullName
 $diskImg = Mount-DiskImage -ImagePath $isoImg 
 # Get mounted ISO volume
 $mountvol = ($diskImg | Get-Volume).DriveLetter
 $mountvol=$mountvol+":\"
 write-Host $mountvol }
#Setup Drive Letter
$server='TPAQWSQLDL002'
##Replace correct Drive Letter
 Set-DbatoolsConfig -Name Path.SQLServerSetup -Value E:\
 $SqlInstance = Find-DbaInstance -ComputerName $server

 if ($SqlInstance -eq $null)
 {
 
 Install-DbaInstance -ComputerName $server -Version 2019 -InstancePath D:\SQLServer -Restart -DataPath M:\SQLData -LogPath L:\SQLLog -TempPath T:\Tempdb -UpdateSourcePath D:\SQL\Software -PerformVolumeMaintenanceTasks  -Confirm:$false
 }
 Else{ write-Host " Default SQL Instance already running on the Server, Try Named Instance" -ForegroundColor Green
  }


#$svcAcc = Get-Credential HPS\svc_servername
#Install-DbaInstance -ComputerName $computer -Version 2019 -ConfigurationFile D:\SQL\Software\ConfigurationFile.ini  -EngineCredential $svcAcc -Confirm:$false
#Install-DbaInstance -Version 2008R2 -SqlInstance sql2017 -ConfigurationFile C:\temp\configuration.ini
#Install a default named SQL Server instance on the remote machine, sql2017 and use the local configuration.ini
# Get-Help -Name Install-DbaInstance -Detailed | Select -ExpandProperty Parameters

<#
#Error 
There was an error generating the XML document.
Error code 0x84B10001
Inner exception type: System.Security.Cryptography.CryptographicException
#>
<#
#registry Change and restart
$server='TPATWSQLMHCA01'
 Invoke-Command -ComputerName $server -ScriptBlock {
$regpath="HKLM:\Software\Microsoft\Cryptography\Protect\Providers\df9d8cd0-1501-11d1-8c7a-00c04fc297eb"
$name="ProtectionPolicy"
$value=1
New-ItemProperty -Path $regpath -Name $name -Value $value -PropertyType DWORD -Force
start-Sleep -Seconds 2
Restart-Computer . -Force}
#>
$server='TPAPWSQLTEST01'
#copy SSMS and Install
$SSMS= Get-ChildItem X:\SQLISO\ -Filter '*SSMS*.exe' 
$SSMS=$SSMS.FullName 
$target="D:\SQL\"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $SSMS -Destination $target -ToSession $s

 Invoke-Command -ComputerName $server -ScriptBlock {
 $filepath= Get-ChildItem -path D:\SQL\Software -Filter "*SSMS*.exe" 
 $filepath=$filepath.FullName
write-host "Beginning SSMS install..." -nonewline
$Parms = " /Install /Quiet /Norestart /Logs D:\SQL\log.txt"
$Prms = $Parms.Split(" ")
& "$filepath" $Prms | Out-Null
Write-Host "SSMS installation complete" -ForegroundColor Green }

$server='TPAPWSQLTEST01'
Get-DbaService $server | Select-Object ComputerName,ServiceName,StartName,State

<#
#copy Postbuild Scripts
$server='TPATWSQLMHCA01'
$postscripts= Get-ChildItem D:\PSScripts\SQLPostBuild 
$postscripts=$postscripts.FullName 
$target="D:\SQL"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
foreach ($scriptfile in $postscripts){ Copy-Item -Path $scriptfile -Destination $target -ToSession $s }


#deploy postbuild script
$server='TPATWSQLMHCA01'
Invoke-Command -ComputerName $server -ScriptBlock {
$deploy=Get-ChildItem D:\SQL -Filter "*.sql"
foreach($deployscript in $deploy.FullName)
{
Invoke-Sqlcmd -ServerInstance $server -Database master -InputFile  $deployscript
}
}
#>
#deploy the postbuild script on the target instance
$serverinstance='TPAQWSQLDL002'
$postscripts= Get-ChildItem D:\PSScripts\SQLPostBuild
$postscripts=$postscripts.FullName 
foreach($deploy in $postscripts)
{
$serverinstance | Invoke-DbaQuery -File $deploy
}

#Restart the SQL Agent


$TargetServer='TPAQWSQLDL002'
Get-DbaService $TargetServer | Where-Object  {$_.ServiceName -eq 'SQLSERVERAGENT'}  | Restart-DbaService -Verbose

#unmount disk
$server='TPAQWSQLDL002'
Invoke-Command -ComputerName $server -ScriptBlock {
$binarypath="D:\SQL\Software"
 $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO"
 $isoImg=$isoImg.FullName
 DisMount-DiskImage -ImagePath $isoImg
 }
##cleanup software copied
$server='TPAQWSQLDL002'
Invoke-Command -ComputerName $server -ScriptBlock {
$binarypath="D:\SQL\"
Get-ChildItem -Path $binarypath -Recurse| Remove-Item -force }

<#
use master
go
exec sp_configure 'Agent XPs',1
Go
reconfigure with override
go
#>

<#
Error: SQL Server setup failure - Setup encountered a failure while running job UpdateResult
Workaround: Set UpdateEnabled = False in the INI file
#>