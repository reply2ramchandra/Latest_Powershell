﻿$file = "X:\SQLPostBuild\test_columnheader.xlsx"

$pkg  = Open-ExcelPackage -Path $file
$ws   = $pkg.Workbook.Worksheets["Sheet1"]   # or use name: $pkg.Workbook.Worksheets["Sheet1"]

$lastCol = $ws.Dimension.End.Column

# Track to avoid duplicate headers after replacement
$used = [System.Collections.Generic.HashSet[string]]::new()

for($c = 1; $c -le $lastCol; $c++){
    $val = [string]$ws.Cells[1,$c].Value
    if(-not $val){ continue }
    $new = $val -replace ' ', '_'
    if(-not $used.Add($new)){
        $i = 2
        while(-not $used.Add("$new`_$i")){ $i++ }
        $new = "$new`_$i"
    }
    $ws.Cells[1,$c].Value = $new
}

Close-ExcelPackage -ExcelPackage $pkg -SaveAs 'X:\SQLPostBuild\test_columnheader_updated.xlsx'