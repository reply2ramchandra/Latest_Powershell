﻿# Module loading (SQL Agent may not load user scope modules)
#Install-Module dbatools -Scope AllUsers -Force
Import-Module dbatools -ErrorAction Stop
Set-DbatoolsInsecureConnection -SessionOnly   # If you rely on trust bypass internally

# Diagnostic: Check for duplicate Microsoft.Data.SqlClient assemblies[AppDomain]::CurrentDomain.GetAssemblies() |Where-Object Location -match 'Microsoft.Data.SqlClient' |Select FullName, Location

$collectionSql = 'tpapwmssql002'
$collectionDb  = 'CMS'

# Get target hosts
$servers = Invoke-DbaQuery -SqlInstance $collectionSql -Database $collectionDb -Query @"
SELECT HostName
FROM dbo.DBServer
WHERE Status IN ('Y','R')
  AND HostName <> 'PCIPWSQL001'
"@

if (-not $servers) {
    Write-Warning "No servers returned."
    return
}

$hostNames = $servers.HostName | Sort-Object -Unique

Write-Host "Collecting OS info from $($hostNames.Count) servers..."

# Bulk OS collection (parallelizable if desired)
$osInfo = Get-DbaOperatingSystem -ComputerName $hostNames -ErrorAction SilentlyContinue |
          Select-Object ComputerName, OSVersion

# Track failures (hosts not returned)
$responded = $osInfo.ComputerName
# Normalize responded hostnames to short names
$responded = $responded | ForEach-Object { $_.Split('.')[0] }
$missing   = $hostNames | Where-Object { $_ -notin $responded }

if ($missing) {
    Write-Warning "No OS data for: $($missing -join ', ')"
}

# Clean usable rows
$validRows = $osInfo | Where-Object { $_.OSVersion -and $_.ComputerName }

if (-not $validRows) {
    Write-Warning "No valid OSVersion values collected. Aborting update."
    return
}

Write-Host "Updating DB with $($validRows.Count) OSVersion values..."

# Use a parameterized UPDATE to avoid string injection and quoting issues
$updateQuery = "UPDATE dbo.DBServer SET OSVersion = @OSVersion WHERE HostName = @HostName;"

$updated = 0
$failed  = 0

foreach ($row in $validRows) {
    try {
        Invoke-DbaQuery -SqlInstance $collectionSql -Database $collectionDb -Query $updateQuery -SqlParameter @{
            OSVersion = $row.OSVersion
            HostName  = $row.ComputerName.Split('.')[0]
        } -ErrorAction Stop | Out-Null
        $updated++
    }
    catch {
        Write-Warning "Failed to update $($row.ComputerName): $_"
        $failed++
    }
}

Write-Host ("Completed. Updated={0} Failed={1} MissingHostsWithoutData={2}" -f $updated, $failed, $missing.Count)

# Optional: show duplicates of Microsoft.Data.SqlClient if you still get conversion errors
# [AppDomain]::CurrentDomain.GetAssemblies() | Where-Object Location -match 'Microsoft.Data.SqlClient' | Select FullName, Location