﻿#Converting plaintext to secure string
$Password_securestring = "hxhd pxqq ipcs kqqt" | ConvertTo-SecureString -AsPlainText -Force

#Converting the secure string to encrypted string and saving it to a file.
$Password_securestring | ConvertFrom-SecureString | Out-File \\tpapwmssql002\Common\pwd_encrypted.txt

#Pull it from the text file using Convertto-securestring commandlet when you want to refer it in the script.
$password_securestring_new = Get-Content \\tpapwmssql002\Common\pwd_encrypted.txt | ConvertTo-SecureString