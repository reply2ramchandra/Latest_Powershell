﻿Import-Module dbatools -EA SilentlyContinue
#New-DbaCredential -SqlInstance TPAPWMSSQL002 -Identity "PowerShell Proxy"
##&Morning@7890&
New-DbaCredential -SqlInstance TPAPWMSSQL002 -Name "PowerShell Proxy" -Identity "HPS\a-sm58408" -SecurePassword (Get-Credential NoUsernameNeeded).Password
#Remove-DbaCredential -SqlInstance TPAPWMSSQL002 -Credential "PowerShell Proxy"
New-DbaAgentProxy -SqlInstance TPAPWMSSQL002 -Name DBA_Proxy -ProxyCredential 'PowerShell Proxy'