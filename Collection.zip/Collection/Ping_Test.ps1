﻿#Test-NetConnection TPAPWPEDSQL001
$mysql=get-Content "T:\Test\mysqlinactive.txt"
$count=$mysql.Count
Write-Host "Total Host to check is : " $count -ForegroundColor Red
$chk=0
foreach($server in $mysql)
{ 
$chk++
#ping -a $server
Test-NetConnection $server | select ComputerName,RemoteAddress , PingSucceeded| FT -AutoSize
}
Write-Host "Verified Count:" $chk -ForegroundColor Green