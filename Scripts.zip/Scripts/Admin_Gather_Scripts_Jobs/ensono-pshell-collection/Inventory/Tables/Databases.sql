CREATE TABLE [Inventory].[Databases] (
    [DateKey]                    SMALLDATETIME,
    [SqlInstance]                VARCHAR (256)   NOT NULL,
    [DatabaseName]               VARCHAR (1024)  NOT NULL,
    [Size]                       DECIMAL (20, 2) NULL,
    [CompatibilityLevel]         VARCHAR (32)    NULL,
    [RecoveryModel]              VARCHAR (16)    NULL,
    [Owner]                      VARCHAR (256)   NULL,
    [PageVerify]                 VARCHAR (256)   NULL,
    [LastBackupDate]             DATETIME2 (1)   NULL,
    [LastDifferentialBackupDate] DATETIME2 (1)   NULL,
    [LastLogBackupDate]          DATETIME2 (1)   NULL,
    [Status]                     VARCHAR (256)   NULL,
    [CreateDate]                 DATETIME2 (1)   NULL
    CONSTRAINT FK_Databases_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
);


GO



CREATE CLUSTERED INDEX [CX_Databases_DateKey] ON [Inventory].[Databases] ([DateKey])

GO

CREATE INDEX [NIX_Databases_SqlInstance_DatabaseName] ON [Inventory].[Databases] ([SqlInstance],[DatabaseName]) INCLUDE ([LastBackupDate],[LastDifferentialBackupDate],[LastLogBackupDate])

GO
