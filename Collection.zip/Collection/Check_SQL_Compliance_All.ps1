﻿clear
Set-StrictMode -Version Latest 
Update-Module -Name dbatools -Force -ErrorAction Stop | Out-Null
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-DbaQuery -SqlInstance  $collectionSql -Database $collectionDb -Query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where Status='Y' AND MajorVersion='SQL Server 2022' and Category ='NonPROD' And HA=1;" -EnableException #-TrustServerCertificate 
Update-DbaBuildReference
foreach($server in $servers.SqlInstance)
{
Test-DbaBuild -SqlInstance $server -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant | Format-Table -AutoSize
}
# Test-DbaBuild -SqlInstance 'TPADWSQLALF001' -Latest -Update
<#
clear
Import-Module dbatools -EA SilentlyContinue 
$instances=get-content "T:\Test\100924.txt"
foreach($instance in $instances)
{
Test-DbaBuild -SqlInstance $instance -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant | Format-Table -AutoSize}
#>
<#
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where Status='Y'"
Update-DbaBuildReference
foreach($server in $servers.SqlInstance)
{
$SQLBuild=Test-DbaBuild -SqlInstance $server -Latest -Update | select SqlInstance,BuildLevel,SPLevel,CULevel
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'SQLBuild' -InputObject $SQLBuild  -AutoCreateTable -KeepNulls
}
#>

<#
Import-Module dbatools -EA SilentlyContinue 
Update-DbaBuildReference
$instances=get-Content "T:\Test\620.txt"
foreach($instance in $instances)
{
Test-DbaBuild -SqlInstance $instance -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant
}
#>
Import-Module dbatools -EA SilentlyContinue 
$instance='TPAPWSQLSSRS02'
Test-DbaBuild -SqlInstance $instance -Latest -Update | select SqlInstance,BuildLevel,BuildTarget,Compliant