﻿$server='PRODSQL2K802'
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\SQL\Software"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
#copy patch file
##change the path according to ISO file version
$isofile= Get-ChildItem X:\SQLISO\SQL2014 -Filter '*2014*.ISO' 
$source=$isofile.FullName  
$target="D:\SQL\Software"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s -Force

Write-Host "Lets Review the files copied." -ForegroundColor Cyan
   Invoke-Command -ComputerName $Server -ScriptBlock { 
       $path='D:\SQL\Software'
        Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Select-Object Name,@{Name="SizeInMB"; Expression={ [math]::Round($_.Length / 1MB,2)}}  
       }
#Check drive free space
Get-DbaDiskSpace $server 