Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear

create table [#wSQLVersion](ID int,  Name  sysname, Internal_Value int, Value nvarchar(256))

insert #wSQLVersion exec master.dbo.xp_msver

SELECT DISTINCT
	NULL,
	@Date_Key AS Date_Key,
	CONVERT(nvarchar(128), SERVERPROPERTY('ServerName')) AS ServerName,
        (SELECT     Value FROM #wSQLVersion WHERE ID = 1) AS ProductName,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 2)) AS ProductVersion,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 3)) AS Language,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 4)) AS Platform,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 7)) AS SQLVersion,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 8)) AS FileVersion,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 15)) AS WindowsVersion,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 16)) AS ProcessorCount,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 17)) AS ProcessorAffinity,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 18)) AS ProcessorType,
	CONVERT(nvarchar(128),(SELECT     Value FROM [#wSQLVersion] WHERE ID = 19)) AS PhysicalMemory
FROM [#wSQLVersion]

drop table #wSQLVersion