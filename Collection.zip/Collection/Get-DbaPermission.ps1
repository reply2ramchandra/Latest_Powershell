﻿import-module dbatools -EA SilentlyContinue
Get-DbaPermission -SqlInstance PRODSQL2K802\PRODSQL2K802 -ExcludeSystemObjects -IncludeServerLevel | Format-Table -AutoSize

Get-DbaPermission -SqlInstance PRODSQL2K802\PRODSQL2K802

