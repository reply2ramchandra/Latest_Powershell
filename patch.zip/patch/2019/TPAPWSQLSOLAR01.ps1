Import-Module dbatools -EA SilentlyContinue
Update-DbaBuildReference
Update-DbaInstance -ComputerName TPAPWNICESQL001 -KB 5065227  -Path C:\patch -Confirm:$false
