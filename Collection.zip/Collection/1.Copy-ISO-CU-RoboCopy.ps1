﻿# THIS file is subject to change as required over time
# DON'T CHANGE/MODIFY this Script without Sathiya's Notice please
###############################################################

Function Read-HostSpecial {
    [cmdletbinding(DefaultParameterSetName="_All")]
    Param(
        [Parameter(Position = 0,Mandatory)]
        [string]$Prompt,
        [consolecolor]$PromptColor,
        [string]$Title
    )

    $Text = @"
$(if ($Title) {
"$Title`n$("-" * $Title.Length)"
})
$Prompt
"@

    $Object = if ($Title.Length -eq 0) { $Prompt } else { $Text }
    $paramHash = @{ NoNewLine = $True; Object = $Object }
    if ($PromptColor) { $paramHash.Add("Foregroundcolor",$PromptColor) }
    Write-Host @paramHash
    $host.ui.ReadLine()
}

Clear-Host
$strtime = Get-Date
Write-Host "Start time : $strtime" -ForegroundColor Yellow
Write-Host "Welcome! Copy SQL Binaries to target Server using Robocopy." -BackgroundColor Cyan

# Get target server
$server = Read-HostSpecial "Enter Correct Host Name:" -PromptColor Green

# Create folder on target server
Invoke-Command -ComputerName $server -ScriptBlock {
    $targetpatchfolder = "D:\SQL\Software"
    if (Test-Path $targetpatchfolder) {
        Write-Host "Folder Exists" -ForegroundColor Green
    } else {
        New-Item -ItemType Directory -Path $targetpatchfolder
        Write-Host "Folder Created" -ForegroundColor Yellow
    }
}

# Get user and version details

$ver = Read-HostSpecial "SQL Server Version 2022:(Y/N)" -PromptColor Green
$ed  = Read-HostSpecial "Confirm Edition: 1 for Ent, 2 for Std:" -PromptColor Green
$ver=$ver.ToUpper()
# Determine source files
$target = "\\$server\D$\SQL\Software"
if ($ver -eq "Y" -and $ed -eq "1") {
    $isofile = (Get-ChildItem X:\SQLISO\SQL2022 -Filter '*_Ent_*2022*.ISO').FullName
    $cufile  = (Get-ChildItem X:\SQLISO\CU\2022 -Filter '*2022*.exe').FullName
}  else {
    Write-Host "Invalid selection." -ForegroundColor Red
    exit
}

# Use Robocopy for copying files
Write-Host "Starting Robocopy transfer..." -ForegroundColor Cyan
$logFile = "C:\robocopy_SQL_copy.log"
robocopy (Split-Path $isofile) $target (Split-Path -Leaf $isofile) /R:3 /W:5 /LOG:$logFile
robocopy (Split-Path $cufile) $target (Split-Path -Leaf $cufile) /R:3 /W:5 /LOG+:$logFile

Write-Host "SQL Binary copy completed using Robocopy." -ForegroundColor Green

# Verify copied files
Invoke-Command -ComputerName $server -ScriptBlock {
    $path = 'D:\SQL\Software'
    Get-ChildItem -Path $path -Recurse | Select-Object Name,@{Name="SizeMB";Expression={[math]::Round($_.Length/1MB,2)}}
}

$endtime = Get-Date
Write-Host "End time : $endtime" -ForegroundColor Yellow