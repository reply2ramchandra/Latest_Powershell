SET NOCOUNT ON

IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wtmpServices') ) 
    DROP TABLE #wtmpServices
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wtmpServicesDetail') ) 
    DROP TABLE #wtmpServicesDetail
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wtmpServicesFinal') ) 
    DROP TABLE #wtmpServicesFinal
      

--  Temporary Tables
CREATE TABLE #wtmpServices 
(oOutput VARCHAR(1024))
CREATE TABLE #wtmpServicesDetail
(oOutput VARCHAR(1024))

CREATE TABLE #wtmpServicesFinal
(ServiceName VARCHAR(100),
ServiceOwner VARCHAR(100),
ServiceStartTp VARCHAR(100),
ServiceBinary VARCHAR(150))

-- sc query is used to query the entire service control manager and then filters 
-- by anything with "SQL" in it's name.  /I option ignores Case.
INSERT INTO #wtmpServices EXEC xp_cmdshell 'sc query |find /I "MsDtsServer"|find /I "service_name"'
INSERT INTO #wtmpServices EXEC xp_cmdshell 'sc query |find /I "sql"|find /I "service_name"'
INSERT INTO #wtmpServices EXEC xp_cmdshell 'sc query |find /I "ReportServer"|find /I "service_name"'

-- Remove NULL records
DELETE FROM #wtmpServices WHERE oOutput IS NULL

-- Cursor variables
DECLARE @curServNm  VARCHAR(100)
DECLARE @cCMD       VARCHAR(100)
DECLARE @cBinary    VARCHAR(150)
DECLARE @cOwner     VARCHAR(100)
DECLARE @cStartTp   VARCHAR(100)

DECLARE cCursor CURSOR FOR
SELECT RTRIM(LTRIM(SUBSTRING(oOutput,PATINDEX('%:%', oOutput)+1, LEN(oOutput)) )) AS ServiceName
FROM #wtmpServices

OPEN cCursor
FETCH NEXT FROM cCursor INTO @curServNm

 WHILE @@FETCH_STATUS = 0

  BEGIN

   --  You can use different Options  to query SC.  For Example, use sc queryex to pull PID
   SET @cCMD = 'sc qc "#SERVICENAME#"'
   SET @cCMD = REPLACE(@cCMD, '#SERVICENAME#', @curServNm)
   
    INSERT INTO #wtmpServicesDetail EXEC xp_cmdshell @cCMD

    DELETE FROM #wtmpServicesDetail WHERE oOutput IS NULL
                           
    --  To extract any other piece of data, you should modify/add variable:  
    -- For Example:  If I use sc queryex to get PID, then I would make the following changes: 
    -- Then You can Insert it into Temp Table
    -- SELECT @cPID = RTRIM(LTRIM(SUBSTRING(oOutput,PATINDEX('%:%', oOutput)+1, LEN(oOutput)) )) 
    -- FROM   #tmpServicesDetail
    -- WHERE  PATINDEX('%PID%', oOutput) > 0
    
    SELECT @cBinary = RTRIM(LTRIM(SUBSTRING(oOutput,PATINDEX('%:%', oOutput)+1, LEN(oOutput)) )) 
    FROM   #wtmpServicesDetail
    WHERE  PATINDEX('%BINARY_PATH_NAME%', oOutput) > 0
    
    SELECT @cOwner = RTRIM(LTRIM(SUBSTRING(oOutput,PATINDEX('%:%', oOutput)+1, LEN(oOutput)) )) 
    FROM   #wtmpServicesDetail
    WHERE  PATINDEX('%SERVICE_START_NAME%:%', oOutput) > 0
    
    SELECT @cStartTp = RTRIM(LTRIM(SUBSTRING(oOutput,PATINDEX('%:%', oOutput)+1, LEN(oOutput)) )) 
    FROM   #wtmpServicesDetail
    WHERE  PATINDEX('%START_TYPE%:%', oOutput) > 0

    INSERT INTO #wtmpServicesFinal (
     ServiceName,
     ServiceOwner,
     ServiceStartTp,
     ServiceBinary)
    VALUES(
     @curServNm,
     @cOwner,
     @cStartTp,
     @cBinary)

FETCH NEXT FROM cCursor INTO @curServNm
END

CLOSE cCursor
DEALLOCATE cCursor

Declare @Date_Key  datetime
Select @Date_Key = DATEADD(dd,DATEDIFF(dd,0,getdate()),0)

-- Final result set
SELECT @Date_Key AS Date_Key,
CONVERT(sysname, @@SERVERNAME) as ServerName,* FROM #wtmpServicesFinal

-- Clean-up objects
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wtmpServices') ) 
    DROP TABLE #wtmpServices
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wtmpServicesDetail') ) 
    DROP TABLE #wtmpServicesDetail
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wtmpServicesFinal') ) 
    DROP TABLE #wtmpServicesFinal
