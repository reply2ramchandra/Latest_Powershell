﻿Import-Module dbatools -DisableNameChecking 
Get-DbaUserPermission -SqlInstance TPAPWDWSQL004 | Where-Object { $_.Member -eq "HPS\SQLEDWPRO"  -and $_.Object -eq "HPS_ODS" } 
