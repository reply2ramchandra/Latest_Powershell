USE [DBA]
GO

/****** Object:  StoredProcedure [dbo].[usp_repo_gen_create_dist]    Script Date: 11/18/2022 4:03:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [dbo].[usp_repo_gen_create_dist]	@Distributor	Nvarchar(256)	= NULL  -- distributor server name 
											,@force			Bit				= 0
AS
	/***************************************************************************************************************************************
	 
	 Copyright(c) 2016 Harsha Vasa @ Ensono 
	 All rights reserved. No part of this script may be reproduced/shared in any form or by making any changes - without written 
	 permissions from the author
	 
	 Purpose: This is a generate script to extract distribution properties and export to central repository for DR or emergency situations
			
	    ----------------------------------------------------------------------------------------------------------------------------------
		History:
		----------------------------------------------------------------------------------------------------------------------------------
		Author                                   Date Created                  Comments
		----------------------------------------------------------------------------------------------------------------------------------
		Harsha vasa                              2016-04-13                  Initial draft
	
	
	
		----------------------------------------------------------------------------------------------------------------------------------
	
	Execution Samples: 
	------------------
	
	For Standard execution
	1) EXEC dbo.usp_repo_gen_create_dist N'RRWIN-SQLDVALRT';
	
	Force to change the authentication and config settings
	2) EXEC dbo.usp_repo_gen_create_dist N'RRWIN-SQLDVALRT', 1;
	
	***************************************************************************************************************************************/
	BEGIN
		SET NOCOUNT ON;
		DECLARE @rOutput Bit

		SET @Distributor = COALESCE(@Distributor, @@servername);

		-- begin validation
		-- validate distribution db 
		IF OBJECT_ID('msdb.dbo.MSdistributiondbs') IS NULL
			BEGIN
				RAISERROR (N'Distributor has not been configured on this instance: %s.', 16, 1, @Distributor) WITH NOWAIT
				RETURN (1);
			END
		IF @@servername != @Distributor
			BEGIN
				RAISERROR (N'Servername is not matched.Executed at wrong destination.Input server: %s', 16, 1, @Distributor) WITH NOWAIT;
				RETURN (1);
			END
		-- end validation

		-- trim white spaces in the tail
		SET @Distributor = LTRIM(RTRIM(@Distributor));


		BEGIN TRY


			SELECT t.DistGen AS [--distgen]
			FROM (SELECT	0 AS ord
							,1 AS execord
							,'/' + REPLICATE('*', 5) + SPACE(1) + N'All below scripts should be run in SQLCMD mode. To Enable this mode - SSMS >> Query (Menu) >> Click SQLCMD mode option.' + SPACE(1) + REPLICATE('*', 5) + '/' + CHAR(13) AS [distgen] UNION ALL
				SELECT	0
						,1
						,'/' + REPLICATE('*', 5) + SPACE(1) + N'SETVAR variable values should be enclosed in single quotes' + SPACE(1) + REPLICATE('*', 5) + '/' + CHAR(13) UNION ALL
				SELECT	0
						,2
						,':SETVAR publisher ''''' UNION ALL
				SELECT	0
						,3
						,':SETVAR distadmin_password ''''' UNION ALL
				SELECT	0
						,4
						,':SETVAR repllink_login ''''' UNION ALL
				SELECT	0
						,5
						,':SETVAR repllink_password ''''' UNION ALL
				SELECT	0
						,6
						,':SETVAR datafolder ''''' UNION ALL
				SELECT	0
						,7
						,':SETVAR workingdirectory ''''' UNION ALL
				SELECT	0
						,8
						,':CONNECT' + SPACE(1) + UPPER(@Distributor) UNION ALL
				SELECT	1
						,1
						,'USE [master];' + CHAR(10) + 'EXEC AS LOGIN = ''sa''' UNION ALL
				SELECT	1
						,1
						,'/' + REPLICATE('*', 5) + SPACE(1) + N'Generated scripts to CREATE/CONFIGURE distributor on the server:' + SPACE(1) + QUOTENAME(@Distributor) + SPACE(1) + REPLICATE('*', 5) + '/' UNION ALL
				SELECT	1
						,1
						,'/' + REPLICATE('*', 5) + SPACE(1) + N'Please Note: For security reasons, all password parameters were scripted with either NULL or SETVAR variable name.' + SPACE(1) + REPLICATE('*', 5) + '/' UNION ALL
				SELECT	1
						,2
						,'EXEC sp_adddistributor @distributor = N' + CHAR(39) + name + CHAR(39) + ',@password = ' + CASE
							WHEN @force = 1 OR
								EXISTS (SELECT 1
									FROM msdb.dbo.MSdistpublishers
									WHERE name != @Distributor
								) THEN '$(distadmin_password) -- required if using as remote dist server'
							ELSE ''''
						END + CHAR(39) + CHAR(10) + 'GO' COLLATE database_default
				FROM msdb.dbo.MSdistpublishers
				WHERE name = @Distributor UNION ALL
				SELECT	1
						,3
						,'EXEC sp_adddistributiondb @database = N' + CHAR(39) + dist.name + CHAR(39) +
						',@data_folder = ' + CASE
							WHEN @force = 1 THEN '$(datafolder)'
							ELSE (	SELECT CHAR(39) + SUBSTRING(mf.physical_name, 1, LEN(mf.physical_name) - CHARINDEX('\', REVERSE(mf.physical_name))) + CHAR(39)
									FROM sys.master_files AS mf
									WHERE database_id = DB_ID(dist.name)
									AND [type] = 0
								)
						END + -- rows
						',@data_file_size = 100' +
						',@log_folder = ' + CASE
							WHEN @force = 1 THEN '$(datafolder)'
							ELSE (	SELECT CHAR(39) + SUBSTRING(mf.physical_name, 1, LEN(mf.physical_name) - CHARINDEX('\', REVERSE(mf.physical_name))) + CHAR(39)
									FROM sys.master_files AS mf
									WHERE database_id = DB_ID(dist.name)
									AND [type] = 1
								)
						END + -- logs
						',@log_file_size = 50' +
						',@min_distretention = 0' + -- +CONVERT(VARCHAR(5),dist.min_distretention)+
						',@max_distretention = ' + CONVERT(Varchar(5), dist.max_distretention) +
						',@history_retention = ' + CONVERT(Varchar(5), dist.history_retention) +
						',@security_mode = 1;' + CHAR(10) + 'GO' COLLATE database_default
				FROM msdb.dbo.MSdistributiondbs AS dist UNION ALL
				SELECT	1
						,4
						,'EXEC sp_adddistpublisher @Publisher = ' + CASE
							WHEN @force = 1 AND
								name <> @Distributor THEN '$(publisher)'
							ELSE CHAR(39) + name + CHAR(39)
						END + ',@distribution_db = N' + CHAR(39) + distribution_db + CHAR(39) +
						',@working_directory = ' + CASE
							WHEN @force = 1 AND
								name <> @Distributor THEN '$(workingdirectory)'
							ELSE CHAR(39) + working_directory + CHAR(39)
						END +
						',@security_mode = ' + CASE
							WHEN name <> @Distributor THEN CASE
									WHEN security_mode = 0 OR
										@force = 1 THEN '0,@login = $(repllink_login),@password = $(repllink_password)'
									ELSE '1'
								END
							ELSE '1'
						END + ';' + CHAR(10) + 'GO' COLLATE database_default
				FROM msdb.dbo.MSdistpublishers UNION ALL
				SELECT	2
						,1
						,'DECLARE @distProfileid Int;
IF EXISTS
(
	SELECT
		1
	FROM msdb.dbo.MSagent_profiles
	WHERE agent_type = 3
	AND profile_name = N''repl_distagprof''
)
BEGIN
	SELECT @distProfileid = profile_id
	FROM msdb.dbo.MSagent_profiles
	WHERE agent_type = 3
	AND profile_name = N''repl_distagprof'';
END 
ELSE  
EXEC msdb.dbo.sp_add_agent_profile	@Profile_id = @distProfileid OUT
							,@Profile_Name = N''repl_distagprof''
							,@agent_type = 3
							,@default = 1;
EXEC msdb.dbo.sp_change_agent_parameter	@distProfileid
								,@parameter_name = ''BcpBatchSize ''
								,@parameter_value = 100000;
EXEC msdb.dbo.sp_change_agent_parameter	@distProfileid
								,@parameter_name = ''CommitBatchSize''
								,@parameter_value = 1000;
EXEC msdb.dbo.sp_change_agent_parameter	@distProfileid
								,@parameter_name = ''CommitBatchThreshold''
								,@parameter_value = 10000;
EXEC msdb.dbo.sp_change_agent_parameter	@distProfileid
								,@parameter_name = ''QueryTimeOut''
								,@parameter_value = 6000;' + CHAR(10) + 'GO' COLLATE database_default UNION ALL
				SELECT	2
						,2
						,'DECLARE @SnapProfileid Int;
IF EXISTS
(
	SELECT
		1
	FROM msdb.dbo.MSagent_profiles
	WHERE agent_type = 1
	AND profile_name = N''repl_snapagprof''
)
BEGIN
	SELECT @SnapProfileid = profile_id
	FROM msdb.dbo.MSagent_profiles
	WHERE agent_type = 1
	AND profile_name = N''repl_snapagprof'';
END 
ELSE  
EXEC msdb.dbo.sp_add_agent_profile	@Profile_id = @SnapProfileid OUT
							,@Profile_Name = N''repl_snapagprof''
							,@agent_type = 1
							,@default = 1;
EXEC msdb.dbo.sp_change_agent_parameter	@SnapProfileid
						,@parameter_name = ''BcpBatchSize ''
						,@parameter_value = 100000;
EXEC msdb.dbo.sp_change_agent_parameter	@SnapProfileid
						,@parameter_name = ''QueryTimeOut''
						,@parameter_value = 6000;' + CHAR(10) + 'GO' COLLATE database_default
			) t
			ORDER BY ord, execord;

		END TRY
		BEGIN CATCH
			DECLARE @rErr Nvarchar(4000);
			SET @rErr = ERROR_MESSAGE() + CAST(ERROR_LINE() AS Varchar(5));
			RAISERROR (@rErr, 11, 1);
			SET @rOutput = 1;
		END CATCH

	END

GO


