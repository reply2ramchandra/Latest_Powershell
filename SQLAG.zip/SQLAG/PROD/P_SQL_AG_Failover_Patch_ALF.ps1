﻿Clear-Host
Import-Module dbatools -ErrorAction SilentlyContinue
$Active='TPAPWSQLALFA01'
$Passive='TPAPWSQLALFB01'
$KB= 5065865
# Fetch AG name
$agReplicas = Get-DbaAvailabilityGroup -SqlInstance  $active
$agName = $agReplicas.Name | Select-Object -First 1
Invoke-DbaAgFailover -SqlInstance $Passive -AvailabilityGroup $agName -Confirm:$false

Import-Module dbatools -EA SilentlyContinue
Update-DbaBuildReference
Update-DbaInstance -ComputerName TPAPWSQLALFA01 -KB $KB -Restart -Path C:\Patch -Confirm:$false