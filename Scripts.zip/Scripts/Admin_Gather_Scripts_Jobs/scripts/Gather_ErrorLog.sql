
SET NOCOUNT ON;
DECLARE @startdate DATETIME
DECLARE @enddate DATETIME

SET @enddate = GETDATE()
SET @startdate = DATEADD( dd,-1,GETDATE() )

IF OBJECT_ID( 'tempdb..#errors' ) IS NOT NULL
	DROP TABLE #Errors;

CREATE TABLE #Errors ([LogDate] DATETIME
					 ,[Source] VARCHAR(25)
					 ,[Text] VARCHAR(MAX))

-- LOGIN FAILURES					
INSERT INTO #Errors
EXEC sys.xp_readerrorlog 0
						,1
						,N'login failed'
						,NULL
						,@startdate
						,@enddate;

-- STACK DUMP
INSERT INTO #Errors
EXEC sys.xp_readerrorlog 0
						,1
						,N'***Stack Dump'
						,NULL
						,@startdate
						,@enddate;



SELECT 
    CAST(CONVERT(VARCHAR,GETDATE(),23) AS SMALLDATETIME) AS DateKey
   ,UPPER(CAST(SERVERPROPERTY('ServerName')AS VARCHAR(256))) AS SqlInstance
   ,e.LogDate
   ,e.[Source]
   ,e.[Text] 
FROM #Errors AS e

-- CLEAN-UP
DROP TABLE #Errors;

GO