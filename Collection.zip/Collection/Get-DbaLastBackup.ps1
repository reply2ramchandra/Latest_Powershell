﻿Import-Module dbatools -EA SilentlyContinue 
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$Instances = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where [Status]='Y' and Category='PROD'" -TrustServerCertificate
foreach($Instance in $Instances.SqlInstance)
{
$DbaLastBackup=Get-DbaLastBackup -SqlInstance $instance
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DbaLastBackup' -InputObject $DbaLastBackup  -AutoCreateTable -KeepNulls 
}