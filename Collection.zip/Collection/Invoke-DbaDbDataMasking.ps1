﻿clear
Import-Module dbatools -ErrorAction SilentlyContinue
#Get-DbaDbTable -SqlInstance TPATWSQLHHA01 -Database ClaimfactsReports | Export-DbaScript -FilePath D:\Mask\export.sql

#New-DbaDbMaskingConfig -SqlInstance TPATWSQLHHA01 -Database ClaimfactsReports -Path "D:\Mask\clone"
#-Table Customer -Column City

Get-ChildItem -Path 'D:\Mask\clone\TPATWSQLHHA01.ClaimfactsReports.DataMaskingConfig.json' | Invoke-DbaDbDataMasking -SqlInstance TPADWSQLARCH01 -Database ClaimfactsReports -Confirm:$false
