﻿clear-host
get-date
#make s/w already copied to path that we refer to
$servers=get-content "T:\Test\ADS_P.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& C:\patch\azuredatastudio-windows-arm64-setup-1.51.1.exe /VERYSILENT /MERGETASKS=!runcode"} }
get-date