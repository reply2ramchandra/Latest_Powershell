# Intro

Ensono featured collection process to give ability to analysis & validate the SQL instance environment. Keep the Inventory table up-to-date 🙏🤝. Leave your valuable suggestions to DBA team to improve the product


## Customers 
Rolling out the collection process to each customer environment is desired but not everyone would agree. Need minimum SQL 2016 Standard Edition with Powershell 5.1 version and domain account which has access to all the SQL instances in the `Inventory.ServerList` table


Collection process is enabled for following customers

| Customer | Collection Server |
| :-- | :-- |
| LSC Communications | PWPAXD-SQLVM020 |
| Ensono | DGWPSQL01 |
| Dun & Bradstreet ( Hoovers ) | DEV1-BBIS-SVC01.INTONLINE.OSINTERNAL.NET |
| Dun & Bradstreet ( DNBINT )| CWMONDBPW01 |
| Donnelley Financials Solutions (DFS) | FWPAXD-SQLVM001\SQL001 |


### Rollout Process:
Refer this [article](/Misc/Install_Enable_CollectionProcess.md) for rolling out process to a new or existing customer.


## Add SQL Instance to Inventory

``` 
Eg:

USE [DBA_REPOSITORY];

EXEC Admin.usp_add_sqlinstance 
 @SqlInstance = 'REPLACE\NEWINSTANCE'
,@Environment = ''  -- eg: 'D'
                /* Check the appropriate 
                'P' =  'Production'
                'T' =  'Test'
                'U' =  'UAT'
                'S' =  'Stage'
                'D' =  'Development'
                'Q' =  'QA'
                'O' =  'PreProd'
                'R' =  'DR'
                */
,@Domain = ''
                /*
                eg: Hoovers:  INTONLINE.OSINTERNAL.NET
                    DNB: DNBINT.NET
                    KDC: DNBAPP.NET
                    Ensono: INT.ENSONO.COM
                    LSC: PRSCOAD.COM
                    DFS: FINCOAD.COM
                */
,@Description = 'Location:<> ; Application: <> ; Owners: <>'
                /*
                 Parameter is not Mandatory but it would be helpful when entered with above format - Replace <> with values
                */

GO 
-- Validation
SELECT * FROM Inventory.ServerList WHERE SqlInstance = 'REPLACE\NEWINSTANCE'

GO

-- Disable SqlInstance from Collection (eg:AWS-RDS,MDRUS & DNBAPP)
UPDATE [Inventory].[ServerList]
SET ConnectionMethod = NULL
WHERE SqlInstance = 'REPLACE\NEWINSTANCE'

```

## Remove SQL Instance from Inventory
This is a soft delete meaning we still keep the entry in table with all Flags turned OFF 
``` 
Eg:

USE [DBA_REPOSITORY];

EXEC Admin.usp_decom_sqlinstance 
@SqlInstance = N'REPLACE\INSTANCENAME', 
@Additional_Comments = N'Add Ticket or TeamTrak Details'

GO

-- Validation
SELECT * FROM Inventory.ServerList WHERE SqlInstance = 'REPLACE\INSTANCENAME'
```

## What Reports are published
1. **Daily** 
    * Missing Backups in last 24 hours
    * Disk Space report ( Free % < 20.00)
    * Errorlog Occurrence ( Login failures & Stack Dump ) from last 24 hours
2. **Weekly**
    * Database file properties 
3. **Monthly**
    * SqlServer Inventory with includes below info in each worksheet
        * Sql Server Instance properties
        * Database Properties
        * Login Details    
    * Server Uptime Analysis (following Monday after 3rd Saturday - Maintenance Window)

