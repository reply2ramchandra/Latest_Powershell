﻿CREATE FUNCTION [Admin].[fn_date_of_monday_after_third_saturday] (@Date DATE = NULL)
RETURNS DATE
AS

	/***************************************************************************************************************************************
		Copyright © 2021 Ensono LP, USA. All rights reserved

		Purpose: To get following Monday's date after Maintenance window i.e.,3rd Saturday
		

		History:
		------------------------------------------------------------------------------------------------------------------------------------
		Author                                 Date Created                Comments
		------------------------------------------------------------------------------------------------------------------------------------
		Harsha vasa                              2021-04-21                  Initial draft



	    ------------------------------------------------------------------------------------------------------------------------------------

		Documentation:
		--------------
                ASCII(169) - ©


		Execution Samples:
		------------------
		* SELECT [Admin].[fn_date_of_monday_after_third_saturday] ()
		* SELECT [Admin].[fn_date_of_monday_after_third_saturday] ('04/23/2021')

    ***************************************************************************************************************************************/
	BEGIN
		
		DECLARE @MondayDate DATE
			   ,@MonthFirst DATE
        
		-- first date of month
		SET @MonthFirst = CONVERT( DATE,DATEADD( DD,-DATEPART( dd,ISNULL( @Date,GETDATE() ) ) + 1,ISNULL( @Date,GETDATE() ) ) )

		-- @@DATEFIRST = 7 for US-English (default),SUNDAY is the start day of the week with datepart value = 1; 1..7 <==> Sunday..Saturday
		-- find first saturday of the month, add 14 days ( 2 weeks * 7 days) plus 2 days to get to Monday 
		SET @MondayDate = DATEADD( dd,2 + ((2 * 7) + (7 - DATEPART( dw,@MonthFirst ))),@MonthFirst ) 
		-- Another Way: DATEADD(wk,2,DATEADD(dd, (7-DATEPART(dw,@MonthFirst))%7,@MonthFirst))


		RETURN @MondayDate;

	END
