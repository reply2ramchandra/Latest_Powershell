CREATE PROCEDURE [Admin].[usp_analyze_dbgrowth] @Server		 VARCHAR(128) = NULL
											   ,@StartDate	 DATE		  = NULL
											   ,@EndDate	 DATE		  = NULL
											   ,@MonthPeriod SMALLINT	  = 6
AS
	/***************************************************************************************************************************************
			
			Purpose: This stored procedure is used to analyze database growth for Active servers. Collection process will capture the data 
			         weekly.
	
			
	
			History:
			------------------------------------------------------------------------------------------------------------------------------------
			Author                                  Date Created                                  Comments
			------------------------------------------------------------------------------------------------------------------------------------
			Harsha vasa                              2016-01-18                                 Initial draft
	
	
	
		    ------------------------------------------------------------------------------------------------------------------------------------
	
			Documentation:
			--------------
			1) Collection table used : Inventory.Databases
	        2) Use ROW_NUMBER function to retreive the Max DB size grouped by Server, database name , Year and Month
			3) Pivot the data gathered from step #1 across the date cycle
			4) Calculates the percentage of growth/decline for the period specified
			5) Ratio of size:  Current to Last Month     > 1.00  <=> Increase
			                                             < 1.00  <=> Decrease
														 = 1.00  <=> No Growth
														 = 0.00  <=> No Data Collected
	
	
			Execution Samples:
			------------------
			-- ALL servers
			1. Exec Admin.usp_analyze_dbgrowth

			-- Specific Server
			2. Exec Admin.usp_analyze_dbgrowth @Server = 'RRWIN-SQLDROLL'

			-- Specific date ranges
			3. Exec Admin.usp_analyze_dbgrowth @Server = 'RRWIN-SQLDROLL' ,@StartDate = '20150401',@EndDate = '20151115'
	        
	
	    ***************************************************************************************************************************************/
	BEGIN
		SET NOCOUNT ON;
		SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;


		DECLARE @iStartDate DATETIME
			   ,@iEndDate DATETIME
			   ,@dMonthString VARCHAR(1000)
			   ,@dMonCoSelectString VARCHAR(8000)
			   ,@dMonCoAscString VARCHAR(4000)
			   ,@dMonCoDescString VARCHAR(4000)
			   ,@dServerList VARCHAR(1000)
			   ,@eSql NVARCHAR(MAX)
			   ,@rc INT = 1;


		IF OBJECT_ID( 'tempdb..#gDate' ) IS NOT NULL
			DROP TABLE #gDate;

		-- Generate Date Keys 

		CREATE TABLE #gDate (DateKeys DATETIME PRIMARY KEY CLUSTERED);

		-- Server Validation

		IF LTRIM( RTRIM( @Server ) ) IS NOT NULL
		AND NOT EXISTS (
			  SELECT
				  *
			  FROM Inventory.ServerList
			  WHERE SqlInstance = @Server
			  AND (IsActive = 1 AND ConnectionMethod IS NOT NULL)
		)
			 BEGIN
				 RAISERROR ('The server specified %s either doesn''t exist or inactive.',16,1,@Server) WITH NOWAIT;
				 RETURN (1);
			 END;

		BEGIN TRY

			SET @iEndDate = COALESCE( @EndDate,CONVERT( DATE,GETDATE() ) );

			SET @iEndDate = [Admin].fn_endofmonth( @iEndDate );    -- End of Month
			SET @iStartDate = COALESCE( @StartDate,DATEADD( MONTH,DATEDIFF( MONTH,0,@iEndDate ) - (@MonthPeriod - 1),0 ) )


			-- Populate dates
			;
			WITH C0
			AS (
				  SELECT
					  *
				  FROM (VALUES(0)
							 ,(0)
							 ,(0)
							 ,(0)) X (v)
			),  -- 4 
			C1
			AS (SELECT a.v FROM C0 AS a CROSS JOIN C0 AS b)  -- 16
			,
			CNums
			AS (SELECT ROW_NUMBER() OVER (ORDER BY v) AS n FROM C1)

			INSERT INTO #gDate
			SELECT
				@iStartDate AS dates
			UNION ALL
			SELECT
				DATEADD( MONTH,n,@iStartDate ) AS pcDate
			FROM CNums
			WHERE n <= DATEDIFF( MONTH,@iStartDate,@iEndDate );


			-- Dynamic Strings
			-- #1 Months


			SELECT
				@dMonthString = STUFF( ((
					  SELECT
						  ',' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' )
			   ,@dMonCoDescString = 'COALESCE(' + STUFF( ((
					  SELECT
						  ',' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys DESC
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' ) + ',0.00)'
			   ,@dMonCoAscString = 'COALESCE(' + STUFF( ((
					  SELECT
						  ',' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' ) + ',0.00)'
			   ,@dMonCoSelectString = +STUFF( ((
					  SELECT
						  ',' + 'COALESCE(' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) ) + ',0.00) AS ' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' );

			IF @Server IS NOT NULL
				 BEGIN
					 SET @dServerList = N'AND [SqlInstance] = N''' + RTRIM( LTRIM( @Server ) ) + '''';
				 END;

			-- Build Dynamic Sql String to execute

			SET @eSql =
			N';WITH cMax
			AS
				(
					SELECT
						DI.DateKey
						,DI.SqlInstance
						,DI.DatabaseName
						,DI.[Size]
						,ROW_NUMBER() OVER (PARTITION BY DI.[SqlInstance], DatabaseName, YEAR(DateKey), MONTH(DateKey) ORDER BY DI.[Size] DESC, DI.DateKey DESC) AS rn
					FROM Inventory.Databases AS DI 
					WHERE DI.DateKey BETWEEN @iStartDate AND @iEndDate
					' + COALESCE( @dServerList,'' ) + '
				)
            
			SELECT 
			 [SqlInstance]
			, DatabaseName
			,' + @dMonCoSelectString + ' 
			,(ca1.ratio-1)*100 AS GrowthPercent
			,CASE WHEN ca1.ratio = 0.00 THEN ''No Data Collected''
			      WHEN ca1.ratio > 1.00 THEN ''Increase In Database Growth''
				  WHEN ca1.ratio < 1.00 THEN ''Decrease In Database Growth''
				  WHEN ca1.ratio = 1.00 THEN ''No Growth'' 
			  END AS Comments
			FROM (  
					SELECT	CONVERT(Varchar(6), DateKey, 112)	AS YYYYMM
							,[SqlInstance]
							,DatabaseName
							,[Size]
					FROM cMax
					WHERE rn = 1 
				  ) sub 
			PIVOT ( MAX([Size]) FOR YYYYMM IN (' + @dMonthString + ')) AS PVT
			CROSS APPLY ( SELECT CONVERT(Decimal(10,2),' + @dMonCoDescString + '/' + 'CASE WHEN ' + @dMonCoAscString + ' = 0.00 THEN 1.00 ELSE ' + @dMonCoAscString + ' END) as ratio ) as ca1
			ORDER BY SqlInstance,DatabaseName,GrowthPercent DESC
			OPTION (RECOMPILE);';

			--PRINT @eSql;

			EXEC @rc = sys.sp_executesql @eSql
											 ,N'@iStartDate DateTime,@iEndDate DateTime'
											 ,@iStartDate
											 ,@iEndDate;


		END TRY
		BEGIN CATCH

			SET @rc = 1

			EXEC [Admin].usp_error_handler

		END CATCH;

		-- clear temp tables from cache

		DROP TABLE #gDate;

		RETURN (@rc);

	END;



	GO
