﻿Import-Module dbatools -EA SilentlyContinue 
#Set-DbaSpn -SPN MSSQLSvc/SQLSERVERA.domain.something -ServiceAccount domain\account
Set-DbaSpn -SPN MSSQLSvc/TPAPWSQLMHC007.HPS.HPH.AD -ServiceAccount HPS\svc_hpssql -EnableException -credential HPS\a-sm58408
