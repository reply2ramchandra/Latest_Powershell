﻿CREATE TABLE [Inventory].[DatabaseFiles]
(
	[DateKey] SMALLDATETIME NOT NULL, 
    [SqlInstance] VARCHAR(256),
    [Database] VARCHAR(1024),
    [LogicalName] VARCHAR(MAX),
    [ID] INT,
    [PhysicalName] VARCHAR(MAX),
    [MaxSizeMb] DECIMAL(20,2),
    [Growth] INT,
    [GrowthType] VARCHAR(64),
    [SizeMb] DECIMAL(20,2)
	CONSTRAINT FK_DatabaseFiles_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
)
GO

CREATE CLUSTERED INDEX [CX_DatabaseFiles_DateKey] ON [Inventory].[DatabaseFiles] (DateKey)