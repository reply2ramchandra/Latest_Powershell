﻿Get-HotFix -ComputerName TPATWSQLHHA01  | Sort-Object InstalledOn
Get-HotFix -ComputerName TPATWSQLSP001| Where-Object {$_.InstalledOn -gt (Get-Date).AddDays(-10)} 
Get-HotFix -ComputerName TPAPWSQLGNRA01 | Where-Object {$_.HotFixID -eq "KB5068791"} 
# test-NetConnection BLDPWHDS11