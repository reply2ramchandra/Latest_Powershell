SET NOCOUNT ON
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wDBLogins') ) 
    DROP TABLE #wDBLogins  

CREATE TABLE #wDBLogins  
(ServerName VARCHAR(128),  
DBName NVARCHAR(128),  
DBRole NVARCHAR(128),  
DBRoleMember NVARCHAR (128))  

SET NOCOUNT ON
DECLARE @command VARCHAR(5000)  

SELECT @command = 'Use [' + '?' + '] SELECT  
@@servername as ServerName,  
' + '''' + '?' + '''' + ' AS DBName,  
sysusers_1.name AS DBRole, sysusers.name AS DBRoleMember 
FROM sysusers AS sysusers_1 INNER JOIN sysusers ON sysusers_1.uid = sysusers.gid'  
INSERT INTO #wDBLogins  
   (ServerName,  
   DBName,  
   DBRole,  
   DBRoleMember)  
EXEC sp_MSforeachdb @command  

Declare @Date_Key  datetime
Select @Date_Key = DATEADD(dd,DATEDIFF(dd,0,getdate()),0)

SELECT @Date_Key as Date_Key,
   ServerName,  
   DBName,  
   DBRole,  
   DBRoleMember  
FROM #wDBLogins

IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wDBLogins') ) 
    DROP TABLE #wDBLogins  
    