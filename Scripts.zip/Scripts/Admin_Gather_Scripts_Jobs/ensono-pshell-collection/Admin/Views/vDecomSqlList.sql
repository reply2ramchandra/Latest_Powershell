﻿CREATE VIEW [Admin].[vDecomSqlList]
AS 
SELECT	SqlInstance
       ,Environment
       ,SupportGroup
	   ,[Description]
FROM [Inventory].[ServerList]
WHERE IsActive = 0 AND SupportGroup IS NULL
