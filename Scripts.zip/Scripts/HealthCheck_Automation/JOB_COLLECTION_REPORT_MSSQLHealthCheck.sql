USE [msdb]
GO

/****** Object:  Job [JOB_COLLECTION_REPORT_DFIN_ArcReporting_MSSQLHealthCheck]    Script Date: 2/4/2023 12:24:41 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Data Collector]    Script Date: 2/4/2023 12:24:41 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Data Collector' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Data Collector'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'JOB_COLLECTION_REPORT_DFIN_ArcReporting_MSSQLHealthCheck', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Data Collector', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Drop_xlsx_files]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Drop_xlsx_files', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Drop_xlsx_files.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DROP_Tables]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DROP_Tables', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Use [DFIN_ArcReporting_Issue]
Go
TRUNCATE TABLE [DFIN_ArcReporting_Issue].[stg].[DbaService];
TRUNCATE TABLE [DFIN_ArcReporting_Issue].[stg].[DbaDatabase];
TRUNCATE TABLE [DFIN_ArcReporting_Issue].[stg].[DbaDbLogSpace];
TRUNCATE TABLE [DFIN_ArcReporting_Issue].[stg].[DbaMemoryCondition];
TRUNCATE TABLE [DFIN_ArcReporting_Issue].[stg].[DbaCpuRingBuffer];
TRUNCATE TABLE [DFIN_ArcReporting_Issue].[stg].[DbaSPWhoisactive];
TRUNCATE TABLE [DFIN_ArcReporting_Issue].[stg].[DbaDiskSpace];
TRUNCATE TABLE [DFIN_ArcReporting_Issue].[stg].[DbaDbSpace];
Go', 
		@database_name=N'DFIN_ArcReporting_Issue', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Collection_DbaService]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Collection_DbaService', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Collection_DbaService.ps1"', 
		@output_file_name=N'D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_Healthcheck_progress.txt', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Collection_DbaDatabase]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Collection_DbaDatabase', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Collection_DbaDatabase.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Collection_DbaDbLogSpace]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Collection_DbaDbLogSpace', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Collection_DbaDbLogSpace.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Collection_DbaMemoryCondition]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Collection_DbaMemoryCondition', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Collection_DbaMemoryCondition.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Collection_DbaCpuRingBuffer]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Collection_DbaCpuRingBuffer', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Collection_DbaCpuRingBuffer.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Collection_DbaSPWhoisactive]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Collection_DbaSPWhoisactive', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Collection_DbaSPWhoisactive.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Collection_DbaDiskSpace]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Collection_DbaDiskSpace', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Collection_DbaDiskSpace.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Collection_DbaDbSpace]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Collection_DbaDbSpace', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Collection_DbaDbSpace.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [FIN_ArcReporting_HealthReport]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'FIN_ArcReporting_HealthReport', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'

USE [DFIN_ArcReporting_Issue]
GO
Begin
Truncate Table  [stg].[DFIN_HealthReport] 
END


/****** Record DbaDatabase Status  ******/
USE [DFIN_ArcReporting_Issue]
GO
Begin
DECLARE @Healthy INT
DECLARE @UnHealthy INT
DECLARE @Collection NVARCHAR(500)
DECLARE @CollectionTime Datetime

Set @CollectionTime = (Select convert(varchar, getdate(), 120) AS Collectiontime)
Set @Collection = ''DbaDatabase''
Set @Healthy = (SELECT Count(*) AS Healthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaDatabase] where DatabaseHealthSTatus = ''Healthy'')
Set @UnHealthy = (SELECT Count(*) AS Healthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaDatabase] where DatabaseHealthSTatus = ''UnHealthy'')

INSERT INTO [stg].[DFIN_HealthReport] ([Description],[Collectiontime],[Healthy],[UnHealthy]) VALUES (@Collection,@CollectionTime,@Healthy,@UnHealthy)
END

/****** Record DbaService Status  ******/
USE [DFIN_ArcReporting_Issue]
GO
Begin
DECLARE @Healthy INT
DECLARE @UnHealthy INT
DECLARE @Collection NVARCHAR(500)
DECLARE @CollectionTime Datetime

Set @CollectionTime = (Select convert(varchar, getdate(), 120) AS Collectiontime)
Set @Collection = ''DbaService''
Set @Healthy = (SELECT Count(*) AS Healthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaService] Where ServerHealthstatus = ''Healthy'')
Set @UnHealthy = (SELECT Count(*) AS UnHealthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaService] Where ServerHealthstatus = ''UnHealthy'')

INSERT INTO [stg].[DFIN_HealthReport] ([Description],[Collectiontime],[Healthy],[UnHealthy]) VALUES (@Collection,@CollectionTime,@Healthy,@UnHealthy)
END

/****** Record DbaDbLogSpace Status  ******/
USE [DFIN_ArcReporting_Issue]
GO
Begin
DECLARE @Healthy INT
DECLARE @UnHealthy INT
DECLARE @Collection NVARCHAR(500)
DECLARE @CollectionTime Datetime

Set @CollectionTime = (Select convert(varchar, getdate(), 120) AS Collectiontime)
Set @Collection = ''DbaDbLogSpace''
Set @Healthy = (SELECT Count(*) AS Healthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaDbLogSpace] Where DbaDbLogSpacestatus = ''Healthy'')
Set @UnHealthy = (SELECT Count(*) AS UnHealthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaDbLogSpace] Where DbaDbLogSpacestatus = ''UnHealthy'')

INSERT INTO [stg].[DFIN_HealthReport] ([Description],[Collectiontime],[Healthy],[UnHealthy]) VALUES (@Collection,@CollectionTime,@Healthy,@UnHealthy)
END

/****** Record DbaDiskSpace Status  ******/
USE [DFIN_ArcReporting_Issue]
GO
Begin
DECLARE @Healthy INT
DECLARE @UnHealthy INT
DECLARE @Collection NVARCHAR(500)
DECLARE @CollectionTime Datetime

Set @CollectionTime = (Select convert(varchar, getdate(), 120) AS Collectiontime)
Set @Collection = ''DbaDiskSpace''
Set @Healthy = (SELECT Count(*) AS Healthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaDiskSpace] Where DbaDiskspaceStatus = ''Healthy'')
Set @UnHealthy = (SELECT Count(*) AS UnHealthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaDiskSpace] Where DbaDiskspaceStatus = ''UnHealthy'')

INSERT INTO [stg].[DFIN_HealthReport] ([Description],[Collectiontime],[Healthy],[UnHealthy]) VALUES (@Collection,@CollectionTime,@Healthy,@UnHealthy)
END

/****** Record DbaCpuRingBuffer Status  ******/
USE [DFIN_ArcReporting_Issue]
GO
Begin
DECLARE @Healthy INT
DECLARE @UnHealthy INT
DECLARE @Collection NVARCHAR(500)
DECLARE @CollectionTime Datetime

Set @CollectionTime = (Select convert(varchar, getdate(), 120) AS Collectiontime)
Set @Collection = ''DbaCpuRingBuffer''
Set @Healthy = (SELECT Count(*) AS Healthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaCpuRingBuffer] Where ServerHealthStatus = ''Healthy'')
Set @UnHealthy = (SELECT Count(*) AS UnHealthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaCpuRingBuffer] Where ServerHealthStatus = ''UnHealthy'')

INSERT INTO [stg].[DFIN_HealthReport] ([Description],[Collectiontime],[Healthy],[UnHealthy]) VALUES (@Collection,@CollectionTime,@Healthy,@UnHealthy)
END


/****** Record DbaSPWhoisactive Status  ******/
USE [DFIN_ArcReporting_Issue]
GO
Begin
DECLARE @Healthy INT
DECLARE @UnHealthy INT
DECLARE @Collection NVARCHAR(500)
DECLARE @CollectionTime Datetime

Set @CollectionTime = (Select convert(varchar, getdate(), 120) AS Collectiontime)
Set @Collection = ''DbaSPWhoisactive''
Set @Healthy = (SELECT Count(*) AS Healthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaSPWhoisactive] Where [DbaSPWhoisactiveStatus] = ''Healthy'')
Set @UnHealthy = (SELECT Count(*) AS UnHealthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaSPWhoisactive] Where [DbaSPWhoisactiveStatus] = ''UnHealthy'')

INSERT INTO [stg].[DFIN_HealthReport] ([Description],[Collectiontime],[Healthy],[UnHealthy]) VALUES (@Collection,@CollectionTime,@Healthy,@UnHealthy)
END


/****** Record DbaSPWhoisactive Status  ******/
USE [DFIN_ArcReporting_Issue]
GO
Begin
DECLARE @Healthy INT
DECLARE @UnHealthy INT
DECLARE @Collection NVARCHAR(500)
DECLARE @CollectionTime Datetime

Set @CollectionTime = (Select convert(varchar, getdate(), 120) AS Collectiontime)
Set @Collection = ''DbaMemoryCondition''
Set @Healthy = (SELECT Count(*) AS Healthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaMemoryCondition] Where ServerHealthStatus = ''Healthy'')
Set @UnHealthy = (SELECT Count(*) AS UnHealthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaMemoryCondition] Where ServerHealthStatus = ''UnHealthy'')

INSERT INTO [stg].[DFIN_HealthReport] ([Description],[Collectiontime],[Healthy],[UnHealthy]) VALUES (@Collection,@CollectionTime,@Healthy,@UnHealthy)
END

/****** Record DbaSPWhoisactive Status  ******/
USE [DFIN_ArcReporting_Issue]
GO
Begin
DECLARE @Healthy INT
DECLARE @UnHealthy INT
DECLARE @Collection NVARCHAR(500)
DECLARE @CollectionTime Datetime

Set @CollectionTime = (Select convert(varchar, getdate(), 120) AS Collectiontime)
Set @Collection = ''DbaDbSpace''
Set @Healthy = (SELECT Count(*) AS Healthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaDbSpace] Where DbaDbSpaceStatus = ''Healthy'')
Set @UnHealthy = (SELECT Count(*) AS UnHealthy FROM [DFIN_ArcReporting_Issue].[dbo].[Vw_DbaDbSpace] Where DbaDbSpaceStatus = ''UnHealthy'')

INSERT INTO [stg].[DFIN_HealthReport] ([Description],[Collectiontime],[Healthy],[UnHealthy]) VALUES (@Collection,@CollectionTime,@Healthy,@UnHealthy)
END


USE [DFIN_ArcReporting_Issue]
GO
Begin
Insert INTO [dbo].[DFIN_HealthReport] Select * from [stg].[DFIN_HealthReport]
END




', 
		@database_name=N'DFIN_ArcReporting_Issue', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Export_Excel]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Export_Excel', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Export_Excel.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Copy_Table]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Copy_Table', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Copy.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DFIN_ArcReporting_Collection_Email_Report]    Script Date: 2/4/2023 12:24:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DFIN_ArcReporting_Collection_Email_Report', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe -File "D:\EnsonoSQLDBA\powershell\DFIN_ArcReporting_healthCheck\DFIN_ArcReporting_Collection_Email_Report.ps1"', 
		@flags=0, 
		@proxy_name=N'DBA_Proxy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DFIN_ArcReporting_Healthcheck_4Hrs', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20230201, 
		@active_end_date=99991231, 
		@active_start_time=111000, 
		@active_end_time=104344, 
		@schedule_uid=N'c756132d-8deb-4529-a6d2-640121146ec7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Test', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20230201, 
		@active_end_date=99991231, 
		@active_start_time=235900, 
		@active_end_time=235959, 
		@schedule_uid=N'fb91f7be-a59e-43f9-8718-b690e65f92cc'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


