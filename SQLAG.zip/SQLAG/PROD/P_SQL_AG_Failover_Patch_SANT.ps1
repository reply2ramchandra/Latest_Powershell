﻿Clear-Host
Import-Module dbatools -ErrorAction SilentlyContinue
$Active='TPAPWSQLSANTA01'
$Passive='TPAPWSQLSANTB01'
$KB=5063814
# Fetch AG name
$agReplicas = Get-DbaAvailabilityGroup -SqlInstance  $active
$agName = $agReplicas.Name | Select-Object -First 1
Invoke-DbaAgFailover -SqlInstance $Passive -AvailabilityGroup $agName -Confirm:$false

Import-Module dbatools -EA SilentlyContinue
Update-DbaBuildReference
Update-DbaInstance -ComputerName TPAPWSQLSANTA01 -KB $KB -Restart -Path C:\Patch -Confirm:$false