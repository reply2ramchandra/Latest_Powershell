# Set variables
$SSRSUrl     = "http://your-ssrs-server/reportserver/ReportService2010.asmx"
$SSRSFolder  = "/TargetFolder"           # SSRS folder path (e.g., "/Reports")
$LocalPath   = "C:\Path\To\RDLs"         # Local folder containing .rdl files

# Create SSRS proxy object
$SSRS = New-WebServiceProxy -Uri $SSRSUrl -Namespace SSRS -UseDefaultCredential

# Upload .rdl files
Get-ChildItem -Path $LocalPath -Filter *.rdl | ForEach-Object {
    $reportName = $_.BaseName
    $reportDefinition = [System.IO.File]::ReadAllBytes($_.FullName)
    $warnings = $null

    # Create or overwrite the report
    $result = $SSRS.CreateCatalogItem(
        "Report",                # ItemType: "Report" for .rdl files
        $reportName,             # Name: report name without extension
        $SSRSFolder,             # Parent: SSRS folder path
        $true,                   # Overwrite: true to overwrite if exists
        $reportDefinition,       # Definition: byte[] of the .rdl file
        $null,                   # Properties: can be $null or a Property array
        [ref]$warnings           # Warnings: output warnings
    )

    Write-Host "Uploaded: $($_.FullName) -> $SSRSFolder/$reportName"
    if ($warnings) {
        Write-Host "Warnings for $reportName:`n$($warnings | Out-String)"
    }
}