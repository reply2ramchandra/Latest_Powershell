﻿<#
$logFile = "C:\Program Files (x86)\Tanium\Tanium Client\Patch\Patch0.log"
$line = Get-Content $logFile
$line = "7/23/2025 6:14:26 Fetch endpoint configuration from config cx complete"
$line = "7/23/2025 6:14:26"
if ($line -match $pattern) {
    $logDate = Get-Date $matches['dt']
    Write-Host "Matched: $logDate"
} else {
    Write-Host "No match"
}
#>
clear-host
# Path to the server list file (one server per line)
$serverList = "T:\Test\np_ha_false.txt"

# Path to the Tanium log file on each server
$logFile = "C:\Program Files (x86)\Tanium\Tanium Client\Patch\Patch0.log"

# Define the datetime range (adjust format as needed)
$startDateTime = Get-Date "2025-07-22 11:08:00 PM"
$endDateTime   = Get-Date "2025-07-22 11:20:00 PM"

# Read server names from file
$servers = Get-Content $serverList

foreach ($server in $servers) {
    Write-Host "Checking $server..."

    $scriptBlock = {
        param($logFile, $startDateTime, $endDateTime)
        if (Test-Path $logFile) {
            # Regex pattern for log lines starting with 'YYYY-MM-DD HH:mm:ss' 'D/MM/YYYY HH:mm:ss'
            #$pattern = '^(?<dt>\d{1}/\d{2}/\d{4} \d{2}:\d{2}:\d{2})'
            $pattern = '^(?<dt>\d{1,2}/\d{1,2}/\d{4} \d{1,2}:\d{2}:\d{2} (AM|PM)[+-]\d{4})'
            $results = @()
            Get-Content $logFile | ForEach-Object {
                if ($_ -match $pattern) {
                    $logDate = Get-Date $matches['dt']
                    if ($logDate -ge $startDateTime -and $logDate -le $endDateTime) {
                        $results += $_
                    }
                }
            }
            if ($results) {
                $results
            } else {
                "No log entries found in range $startDateTime to $endDateTime."
            }
        } else {
            "Log file not found: $logFile"
        }
    }

    try {
        $result = Invoke-Command -ComputerName $server -ScriptBlock $scriptBlock -ArgumentList $logFile, $startDateTime, $endDateTime
        Write-Host "Results from ${server}:`n$result`n"
    } catch {
        Write-Host "Failed to connect to ${server}: $_"
    }
}