﻿# Load required assemblies
Add-Type -AssemblyName "System.Net.Mail"
#Add-Type -AssemblyName "System.Net"

# Prompt for credentials
$secureCred = Get-Credential
$username = $secureCred.UserName
$password = $secureCred.GetNetworkCredential().Password

# Create the email message
$message = New-Object MimeKit.MimeMessage
$message.From.Add($username)

# Add multiple recipients
$message.To.Add("sathiyaneethi.mani@wipro.com")
#$message.To.Add("recipient2@example.com")

# Subject
$message.Subject = "Test Email with HTML and Attachment"

# Create the body
$bodyBuilder = New-Object MimeKit.BodyBuilder
$bodyBuilder.HtmlBody = "<h2>Hello!</h2><p>This is a <b>test email</b> sent using <i>MailKit</i> in PowerShell.</p>"

# Add attachment
$attachmentPath = "D:\PSScripts\Reports\All\AllDbservicestat20251013.html"
$bodyBuilder.Attachments.Add($attachmentPath)

# Assign the body to the message
$message.Body = $bodyBuilder.ToMessageBody()

# Set up the SMTP client
$smtp = New-Object MailKit.Net.Smtp.SmtpClient

try {
    # Connect to the SMTP server
    $smtp.Connect("smtprelay.healthplan.com", 25, [MailKit.Security.SecureSocketOptions]::StartTls)

    # Authenticate using credentials
    $smtp.Authenticate($username, $password)

    # Send the message
    $smtp.Send($message)
    Write-Host "✅ Email sent successfully."

    # Disconnect
    $smtp.Disconnect($true)
} catch {
    Write-Host "❌ Error sending email: $_"
}