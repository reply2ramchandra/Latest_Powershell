﻿Import-Module dbatools -EA SilentlyContinue 
Get-DbaAvailabilityGroup -SqlInstance TPATWSQLCLU01
#Remove-DbaAgDatabase -SqlInstance TPAPWSQLHHB01 -AvailabilityGroup HH_AG -Database Kaiser -Confirm:$false
#Remove-DbaAgDatabase -SqlInstance TPAPWSQLHHA01 -AvailabilityGroup HH_AG -Database Kaiser -Confirm:$false
Import-Module dbatools -EA SilentlyContinue
# Using dbatools
Enable-DbaAgHadr -SqlInstance TPATWSQLCLU03,TPATWSQLCLU04 -Force

Restart-DbaService -ComputerName TPATWSQLCLU01 -InstanceName MSSQLSERVER
Restart-DbaService -ComputerName TPATWSQLCLU02 -InstanceName MSSQLSERVER

Get-DbaEndpoint -SqlInstance TPATWSQLCLU01,TPATWSQLCLU02 -Type DatabaseMirroring |
  Select SqlInstance, Name, EndpointState, Port, Owner, IsHadrEndpoint

  Test-DbaAvailabilityGroup -Primary TPATWSQLCLU01 -Secondary TPATWSQLCLU02 -Name test_alf -Detailed

  New-DbaAvailabilityGroup `
  -Primary TPATWSQLCLU03 `
  -Secondary TPATWSQLCLU04 `
  -Name test_alf `
  -Database SampleSalesDb `
  -ClusterType WSFC `
  -SeedingMode Automatic `
  -AvailabilityMode SynchronousCommit `
  -FailoverMode Automatic `
  -Confirm:$false
# This restarts each SQL Server service 
Remove-DbaAvailabilityGroup -SqlInstance TPATWSQLCLU01 -AvailabilityGroup test_alf -Confirm:$false
New-DbaAvailabilityGroup -Primary TPATWSQLCLU01 -Name test_alf -Secondary TPATWSQLCLU02
Add-DbaAgDatabase -SqlInstance TPAPWSQLHHA01 -AvailabilityGroup HH_AG -Database Kaiser -Confirm:$false
<#
--- YOU MUST EXECUTE THE FOLLOWING SCRIPT IN SQLCMD MODE.
:Connect tpatwsqlclu01
USE [master]
GO
ALTER AVAILABILITY GROUP [test_alf]
MODIFY REPLICA ON N'TPATWSQLCLU02' WITH (SEEDING_MODE = AUTOMATIC)
GO
USE [master]
GO
ALTER AVAILABILITY GROUP [test_alf]
ADD DATABASE [EmployeeDB];
GO
:Connect TPATWSQLCLU02
ALTER AVAILABILITY GROUP [test_alf] GRANT CREATE ANY DATABASE;
GO
Add-DbaAgDatabase -SqlInstance TPAPWSQLHHA01 -AvailabilityGroup HH_AG -Database Kaiser -Secondary TPAPWSQLHHB01 -SeedingMode Manual -SharedPath \\tpadd9300\SQLBackupsprod\TPAPWSQLGNXTA01\GetNext\Full\Backup -AdvancedBackupParams @{ CompressBackup = $true ;FileCount = 4 }
#>
Add-DbaAgDatabase -SqlInstance TPAPWSQLHHA01 -AvailabilityGroup HH_AG -Database Kaiser -Secondary TPAPWSQLHHB01 -SeedingMode Automatic
Get-DbaAvailabilityGroup -SqlInstance TPATWSQLCLU01 -AvailabilityGroup test_alf | Add-DbaAvailabilityGroup -SqlInstance TPATWSQLCLU02
#Get-DbaAvailabilityGroup -SqlInstance TPATWSQLCLU01 -AvailabilityGroup Test_Alf | Add-DbaAgReplica -SqlInstance TPATWSQLCLU02 -FailoverMode Manual

# for Listener name created make sure 1) Add cluster ad object account to the created listener
#Remove-DbaAvailabilityGroup -SqlInstance sqlserver2012 -AllAvailabilityGroups
Import-Module dbatools -EA SilentlyContinue
Add-DbaAgListener -SqlInstance TPATWSQLCLU02 `
  -AvailabilityGroup test_alf `
  -Name TPATWLISTNER02 `
  -IPAddress 10.40.41.25 `
  -SubnetMask 255.255.252.0 `
  -Port 1433 -Verbose
#Remove-DbaAgListener -SqlInstance sqlserver2012 -AvailabilityGroup ag1, ag2 -Confirm:$false
#Get-DbaAgListener -SqlInstance sql2017 | Out-GridView -Passthru | Set-DbaAgListener -Port 1433 -Confirm:$false
<# port check
$computer = 'TPATWSQLMHCB01'
$port = "5022"                 # replace with the port from your database_mirroring_endpoints.
Test-NetConnection -ComputerName $computer -Port $port
#>

<# for MHC
##get a dedicated Service Account 
Import-Module dbatools -EA SilentlyContinue
Disable-DbaAgHadr -SqlInstance TPAPWDWSQLB05 -Force
Enable-DbaAgHadr -SqlInstance TPATWSQLETA01 -Force
Enable-DbaAgHadr -SqlInstance TPATWSQLMHCB01 -Force
New-DbaAvailabilityGroup -Primary TPATWSQLMHCA01 -Name MH_AG -Secondary TPATWSQLMHCB01
Get-DbaAvailabilityGroup -SqlInstance TPATWSQLMHCA01 | Sync-DbaAvailabilityGroup -Secondary TPATWSQLMHCB01 -AvailabilityGroup MH_AG
#Join AG from secondary Replica
ALTER AVAILABILITY GROUP MH_AG JOIN;
Remove-DbaAvailabilityGroup -SqlInstance TPATWSQLMHCA01 -AvailabilityGroup MH_AG -Confirm:$false
Backup-DbaDatabase -SqlInstance TPATWSQLMHCA01 -Database Admin
Backup-DbaDatabase -SqlInstance TPATWSQLMHCA01 -Database Admin -Type Log
Add-DbaAgDatabase -SqlInstance sql2017a -AvailabilityGroup ag1 -Database db1 -Secondary sql2017b -SeedingMode Manual -SharedPath \\FS\Backup -AdvancedBackupParams @{ CompressBackup = $true ;FileCount = 3 }
Add-DbaAgDatabase -SqlInstance TPATWSQLMHCA01 -AvailabilityGroup MH_AG -Database Admin -Confirm:$false
Add-DbaAgListener -SqlInstance TPATWSQLMHCA01 -AvailabilityGroup MH_AG -IPAddress 10.14.41.230 -Static -SubnetMask 255.255.252.0 
Get-DbaAvailabilityGroup -SqlInstance TPATWSQLMHCA01 -AvailabilityGroup MH_AG
Test-DbaAvailabilityGroup -SqlInstance TPATWSQLMHCA01 -AvailabilityGroup MH_AG -AddDatabase Admin -SeedingMode Automatic

 #>

