﻿clear
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
# Module loading (SQL Agent may not load user scope modules)
#Install-Module dbatools -Scope AllUsers -Force
Import-Module dbatools -ErrorAction Stop
Import-Module SQLServer -ErrorAction Stop
Set-DbatoolsInsecureConnection -SessionOnly
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "DROP TABLE IF EXISTS [CMS].[dbo].[DiskSpace];" -TrustServerCertificate
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT TRIM([HostName]) as HostName FROM [CMS].[dbo].[DBServer] Where [Status] IN ('Y','R') and Category='PROD'" -TrustServerCertificate
foreach($server in $servers.HostName)
{
$DiskSpace=Get-DbaDiskSpace $server | Select-Object ComputerName,Name,Capacity,Free,PercentFree
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DiskSpace' -InputObject $DiskSpace  -AutoCreateTable -KeepNulls }
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "UPDATE [CMS].[dbo].[DiskSpace] SET ComputerName='TPAPWMSSQL002' where ComputerName='localhost';"  -TrustServerCertificate 
Start-Sleep -Seconds 2

 $css = @"
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid black; padding: 8px; text-align: left; }
    th { background-color: #D6EEEE; }
    tr:nth-child(even) {
  background-color: rgba(150, 212, 212, 0.4);}
</style>
"@

$runDateTime = (Get-Date -Format yyyyddMM) 
 $preContent = @"
<h3><font face=verdana color=blue>PROD Server Disk Space Report</font></h3>
<p>This report contains the list of Servers where disk space is less than 10% free space.</p>
"@

$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Please review and take action as Required.</font></p>
"@

$diskinfo=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query " SELECT [ComputerName] ,[Name],[Capacity]/1024/1024/1000 [Capacity_GB],cast([Free]/1024/1024/1000.0 as Decimal(10,2)) [Free_GB],[PercentFree] FROM [CMS].[dbo].[DiskSpace] WHERE [PercentFree]<10 order by [ComputerName]; " -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors

$highlightedRows = foreach ($row in $diskinfo) {
    $color = if ($row.PercentFree -lt 5) {
        'style="background-color:#FFCCCC;"'  # Light red
    } elseif ($row.PercentFree -lt 10) {
        'style="background-color:#FFFFCC;"'  # Light yellow
    } else {
        ''
    }
    "<tr $color><td>$($row.ComputerName)</td><td>$($row.Name)</td><td>$($row.Capacity_GB)</td><td>$($row.Free_GB)</td><td>$($row.PercentFree)</td></tr>"
}
$head = @"
<style>
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid black; padding: 8px; text-align: left; }
th { background-color: #D6EEEE; }
</style>
"@
$preContent = @"
<h3><font face=verdana color=blue>PROD Server Disk Space Report</font></h3>
<p>This report contains the list of Servers where disk space is less than 10% free space.</p>
"@
$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Please review and take action as Required.</font></p>
"@
$html = @"
<html>
<head>
$head
<title>PROD Server Disk Space Report</title>
</head>
<body>
$preContent
<table>
<tr><th>ComputerName</th><th>Name</th><th>Capacity_GB</th><th>Free_GB</th><th>PercentFree</th></tr>
$($highlightedRows -join "`n")
</table>
$postContent
</body>
</html>
"@
$html | Out-File -FilePath \\tpapwmssql002\Reports\DriveSpaceReport$runDateTime.htm
       

             if($diskinfo.Count -gt 0)
             {
                  Write-host 'Sending mail of Prod Servers''  drive Info' -ForegroundColor Green
                   
                  $body = Get-Content \\tpapwmssql002\Reports\DriveSpaceReport$runDateTime.htm
                  Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'PROD Server Drive Report | Less than 10 Percent Free space' -SmtpServer smtprelay.healthplan.com -BodyAsHtml:$true -Body "$body" 
                #Invoke-Item \\tpapwmssql002\Reports\backupreport.html
            }
             else
             {
              Write-host 'Not sending mail since we are good' -ForegroundColor Yellow
             }
  