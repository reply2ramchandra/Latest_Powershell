﻿clear

$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue
#$instances=get-content "T:\Test\100924.txt" 
$instances = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] WHERE STATUS IN('Y','P','R') and [HostName] NOT IN('PCIPWSQL001') and Category='Prod'"  -TrustServerCertificate 
#foreach($instance in $instances) 
foreach($instance in $instances.SqlInstance)
{
#$instances=get-content "T:\Test\100924.txt"
#foreach($instance in $instances)
#{
Get-DbaAgentJob -SqlInstance $instance -Job 'Maint - Generate DR Report' | Start-DbaAgentJob}

#Start-DbaAgentJob -SqlInstance sql2016 -Job cdc.DBWithCDC_capture

