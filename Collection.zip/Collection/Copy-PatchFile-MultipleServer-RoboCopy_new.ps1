﻿Clear-Host

Write-Host "Key your Password" -ForegroundColor Green
$user = [Environment]::UserName
$cred = Get-Credential $user

# Define local and remote paths
$localPath  = "X:\SQLISO\CU\2022"      # Source path
$remotePath = "C:\Patch"               # Target path on remote servers
$servers    = Get-Content "T:\Test\HA_NonProd.txt"

# Define log file paths
$logFile       = "D:\PSScripts\Logs\FileCopy.log"
$errorLogFile  = "D:\PSScripts\Logs\FileCopyErrors.log"

function Init-Logs {
    param($logFile, $errorLogFile)
    $logDir = Split-Path $logFile
    if (-not (Test-Path $logDir)) { New-Item -Path $logDir -ItemType Directory -Force | Out-Null }
    foreach ($f in @($logFile, $errorLogFile)) {
        if (Test-Path $f) { Remove-Item $f -Force }
        New-Item -ItemType File -Path $f -Force | Out-Null
    }
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('Info','Warn','Error')] [string]$Level = 'Info'
    )
    $ts   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "$ts [$Level] $Message"
    Add-Content -Path $logFile -Value $line
    if ($Level -eq 'Error') { Add-Content -Path $errorLogFile -Value $line }
}

Init-Logs -logFile $logFile -errorLogFile $errorLogFile
Write-Log "===== File copy run started ====="

foreach ($remoteHost in $servers) {
    Write-Log "Starting processing for $remoteHost"
    try {
        # Ensure remote folder exists (capture output instead of Write-Host so we can log)
        $remoteResult = Invoke-Command -ComputerName $remoteHost -Credential $cred -ScriptBlock {
            param($remotePath)
            if (-not (Test-Path $remotePath)) {
                New-Item -Path $remotePath -ItemType Directory -Force | Out-Null
                "Created remote path: $remotePath"
            } else {
                "Remote path already exists: $remotePath"
            }
        } -ArgumentList $remotePath

        foreach ($line in $remoteResult) { Write-Log "[$remoteHost] $line" }

        # UNC path: \\Server\C$\Patch
        $remoteUNC = "\\$remoteHost\$($remotePath.Substring(0,1))$" + $remotePath.Substring(2)

        Write-Log "[$remoteHost] Starting robocopy from $localPath to $remoteUNC"

        # Build robocopy arguments. /LOG+: appends; we already recreated file at start, so all servers accumulate.
        $roboArgs = @(
            "`"$localPath`"",
            "`"$remoteUNC`"",
            '/MIR','/Z','/NP','/R:2','/W:5','/TEE',"/LOG+:`"$logFile`""
        )

        # Invoke robocopy directly so $LASTEXITCODE is populated
        & robocopy @roboArgs | Out-Null
        $rc = $LASTEXITCODE

        if ($rc -ge 8) {
            Write-Log "[$remoteHost] Robocopy failed with exit code $rc" -Level Error
            Write-Host "Robocopy failed on $remoteHost (exit code $rc)" -ForegroundColor Red
        } else {
            Write-Log "[$remoteHost] Robocopy completed successfully (exit code $rc)"
            Write-Host "File copy completed for $remoteHost." -ForegroundColor Cyan
        }
    }
    catch {
        $errorMessage = "[$remoteHost] Exception: $($_.Exception.Message)"
        Write-Log $errorMessage -Level Error
        Write-Host $errorMessage -ForegroundColor Red
    }
}

Write-Log "===== File copy run finished ====="
Write-Host "All processing done. See log: $logFile ; errors: $errorLogFile" -ForegroundColor Green