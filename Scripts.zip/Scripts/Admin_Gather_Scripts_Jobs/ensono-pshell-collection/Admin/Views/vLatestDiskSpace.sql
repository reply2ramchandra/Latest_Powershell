﻿CREATE VIEW [Admin].[vLatestDiskSpace]
AS 
SELECT 
	 DateKey
	,ComputerName
	,Drive
	,TotalGB
	,FreeGB
	,PercentFree
	,[BlockSize] 
FROM [Inventory].[DiskSpace] 
WHERE DateKey = (SELECT TOP 1 DateKey FROM Inventory.[DiskSpace] ORDER BY DateKey DESC)
