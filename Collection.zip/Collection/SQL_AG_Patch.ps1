﻿# Change the KB number as required
Clear-Host

param (
    [Parameter(Mandatory)]
    [string]$SqlInstance,

    [Parameter(Mandatory)]
    [string]$PassiveNode,

    [Parameter(Mandatory)]
    [string]$ActiveNode,

    [string]$PatchPath = "C:\Patch\",

    [string]$KB = "5058721"
)

Import-Module dbatools -ErrorAction SilentlyContinue

# Fetch AG name
$agReplicas = Get-DbaAgReplica -SqlInstance $SqlInstance
$agName = $agReplicas.AvailabilityGroup | Select-Object -First 1

Write-Host "Here is the SQL Version# Before patching:" -BackgroundColor Cyan

# Get Version # of both nodes
Connect-DbaInstance -SqlInstance $PassiveNode | Select-Object SqlInstance, VersionString
Connect-DbaInstance -SqlInstance $ActiveNode | Select-Object SqlInstance, VersionString

function Patch-SQLNode {
    param (
        [string]$Node,
        [string]$AGName,
        [string]$PatchPath,
        [string]$KB
    )

    $agHealth = Get-DbaAgDatabase -SqlInstance $Node
    $unhealthy = $agHealth | Where-Object { $_.SynchronizationState -ne 'Synchronized' }

    if ($unhealthy.Count -gt 0) {
        Write-Warning "Warning: Some AG databases on $Node are not healthy!"
        return
    }

    Write-Host "All AG databases on $Node are healthy."
    Write-Host "Starting patching on $Node"

    Suspend-DbaAgHadr -SqlInstance $Node -AvailabilityGroup $AGName

    Update-DbaBuildReference
    Update-DbaInstance -ComputerName $Node -KB $KB -Restart -Path $PatchPath -Confirm:$false

    Start-Sleep -Seconds 5

    Resume-DbaAgHadr -SqlInstance $Node -AvailabilityGroup $AGName

    Write-Host "Completed patching on $Node"
}

# Check which node is primary
$chk = Get-DbaAvailabilityGroup -SqlInstance $PassiveNode
$isPrimary = $chk.PrimaryReplica -eq $PassiveNode

if (-not $isPrimary) {
    # Patch passive node first
    Patch-SQLNode -Node $PassiveNode -AGName $agName -PatchPath $PatchPath -KB $KB
    Start-Sleep -Seconds 15
    Start-DbaService -ComputerName $PassiveNode
    Invoke-DbaAgFailover -SqlInstance $PassiveNode -AvailabilityGroup $agName -Confirm:$false
    $primaryPending = $true
} else {
    # Patch second node
    Patch-SQLNode -Node $ActiveNode -AGName $agName -PatchPath $PatchPath -KB $KB
    Start-Sleep -Seconds 15
    Start-DbaService -ComputerName $ActiveNode
    Invoke-DbaAgFailover -SqlInstance $ActiveNode -AvailabilityGroup $agName -Confirm:$false
    $primaryPending = $false
}

# Patch the other node if needed
if ($primaryPending) {
Set-Location "D:\PSScripts\SQLAG"
    $kbn = ./Get-KBNumber $ActiveNode
    if ($kbn.KB_Number -eq $KB) {
        Patch-SQLNode -Node $ActiveNode -AGName $agName -PatchPath $PatchPath -KB $KB
        Start-Sleep -Seconds 15
        Start-DbaService -ComputerName $ActiveNode
        Invoke-DbaAgFailover -SqlInstance $ActiveNode -AvailabilityGroup $agName -Confirm:$false
    }
} else {
Set-Location "D:\PSScripts\SQLAG"
    $kbn = & Get-KBNumber $PassiveNode
    if ($kbn.KB_Number -eq $KB) {
        Patch-SQLNode -Node $PassiveNode -AGName $agName -PatchPath $PatchPath -KB $KB
        Start-Sleep -Seconds 15
        Start-DbaService -ComputerName $PassiveNode
        Invoke-DbaAgFailover -SqlInstance $PassiveNode -AvailabilityGroup $agName -Confirm:$false
    }
}

Write-Host "Here is the SQL Version# after patching:" -BackgroundColor Cyan
Connect-DbaInstance -SqlInstance $PassiveNode | Select-Object SqlInstance, VersionString
Connect-DbaInstance -SqlInstance $ActiveNode | Select-Object SqlInstance, VersionString