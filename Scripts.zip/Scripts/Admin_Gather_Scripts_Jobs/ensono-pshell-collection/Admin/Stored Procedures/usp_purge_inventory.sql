CREATE PROCEDURE [Admin].[usp_purge_inventory]
AS

	/***************************************************************************************************************************************
		Copyright � 2021 Ensono LP, USA. All rights reserved

		Purpose: To purge collection data from Inventory schema tables
		

		History:
		------------------------------------------------------------------------------------------------------------------------------------
		Author                                 Date Created                Comments
		------------------------------------------------------------------------------------------------------------------------------------
		Harsha vasa                              2021-03-09                  Initial draft



	    ------------------------------------------------------------------------------------------------------------------------------------

		Documentation:
		--------------
                ASCII(169) - �

        Referred table: [Admin].[PurgeInventory]


		Execution Samples:
		------------------


    ***************************************************************************************************************************************/

	BEGIN
		SET NOCOUNT ON;
		SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

		DECLARE @Object SYSNAME
			   ,@Column SYSNAME
			   ,@CleanupDate DATETIME
			   ,@Sqlcmd NVARCHAR(MAX)
			   ,@Rows INT

		BEGIN TRY

			-- begin cursor

			DECLARE cur CURSOR FAST_FORWARD READ_ONLY LOCAL
			FOR
				SELECT
					QUOTENAME( [Schema] ) + '.' + QUOTENAME( [Table] )	 AS [object]
				   ,ColumnName
				   ,DATEADD( dd,-[Retention],CONVERT( DATE,GETDATE() ) ) AS CleanUp
				FROM [Admin].PurgeInventory

			OPEN cur

			FETCH NEXT FROM cur INTO @Object,@Column,@CleanupDate

			-- outer loop to delete from each table
			WHILE @@fetch_status = 0
				 BEGIN

					 SET @Sqlcmd = N'DELETE TOP (2000)' + SPACE( 1 ) + 'FROM' + SPACE( 1 ) + @Object + SPACE( 1 ) + 'WHERE' + SPACE( 1 ) + @Column + ' < @cleanup_date ;'

					 -- inner loop to delete in 2000 batch
					 WHILE (1 = 1)
						  BEGIN

							  EXEC sys.sp_executesql @Sqlcmd
													,N'@cleanup_date  DATETIME'
													,@CleanupDate;

							  SET @Rows = @@rowcount;

							  IF @Rows = 2000
								  CONTINUE;
							  ELSE
								  BREAK;

						  END
					 -- end inner

					 FETCH NEXT FROM cur INTO @Object,@Column,@CleanupDate

				 END
			-- end outer

			CLOSE cur
			DEALLOCATE cur
		-- cursor end

		END TRY
		BEGIN CATCH

			--PRINT @Sqlcmd;
			EXEC [Admin].usp_error_handler

		END CATCH;

	-- clear temp tables from cache

	END
	GO 

