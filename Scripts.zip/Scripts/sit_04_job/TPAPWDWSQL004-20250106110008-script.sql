/*
	Created by HPS\a-sm58408 using dbatools Export-DbaScript for objects on TPAPWDWSQL004 at 01/06/2025 11:00:08
	See https://dbatools.io/Export-DbaScript for more information
*/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'MSTR JOS RUNNING STATUS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'ICT_DL_SQL', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MSTR JOB RUNNING STATUS', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=2, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @xml NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)

SET @xml = CAST(( 
SELECT AA.DAY_ID as''td'','''',
AA.EXECSTARTTIME as''td'','''',
AA.EXECFINISHTIME as''td'','''',
AA.SCHEDULEID as''td'','''',
BB.REPORTID as''td'','''',
CC.IS_SCHED_GUID as''td'','''',
CC.IS_SCHED_NAME as''td'','''',
AA.RECIPIENTCONTACTNAME as''td'','''',
AA.SUBINSTNAME as''td'','''',
AA.PHYSICALADDRESS as''td'','''',
AA.ISNOTIFICATIONMESSAGE as''td'','''',
AA.DELIVERYTYPE as''td'','''',
AA.DELIVERYSTATUS as''td'','''',
BB.CANCELINDICATOR as''td'','''',
BB.ERRORMESSAGE as''td'',''''

FROM [MSTR_STATS_10_2].dbo.STG_IS_MESSAGE_STATS AA 
FULL OUTER JOIN [MSTR_STATS_10_2].dbo.STG_IS_REPORT_STATS BB
ON ( AA.DAY_ID = BB.DAY_ID and AA.SESSIONID = BB.SESSIONID and AA.schedulejobid=BB.jobid)
Join [MSTR_STATS_10_2].dbo.IS_SCHED CC
ON (CC.IS_SCHED_GUID=AA.SCHEDULEID)
WHERE AA.DAY_ID >= CAST(getdate() as date)
AND BB.ERRORMESSAGE is not null
ORDER BY AA.DAY_ID , AA.EXECSTARTTIME 
FOR XML PATH(''tr''), ELEMENTS ) AS NVARCHAR(MAX))


SET @body =''<html><body><H3>MSTR JOB RUNNING STATUS</H3>
<table border = 2> 
<tr>
<th> DAY_ID </th> <th> EXECSTARTTIME </th> <th> EXECFINISHTIME </th><th> SCHEDULEID </th><th> REPORTID </th><th> IS_SCHED_GUID </th><th> IS_SCHED_NAME </th><th> RECIPIENTCONTACTNAME </th><th> SUBINSTNAME </th><th>  PHYSICALADDRESS</th><th>  ISNOTIFICATIONMESSAGE</th><th>  DELIVERYTYPE</th><th>  DELIVERYSTATUS</th><th>  CANCELINDICATOR</th><th> ERRORMESSAGE </th></tr>''    
 
SET @body = @body + @xml +''</table></body></html>''

EXEC msdb.dbo.sp_send_dbmail
@profile_name = ''DataLink Notify'',
@body = @body,
@body_format =''HTML'',
@recipients = ''WHPS-Datalink-Internal@wipro.com'', 
@subject = ''MSTR Job Running Status'' ;', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Take backup of the running status', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'INSERT INTO  HPS_ODS.dbo.MSTR_JOB_RUNNING_STATUS(DAY_ID
,EXECSTARTTIME
,EXECFINISHTIME
,REPORTID
,IS_SCHED_GUID
,IS_SCHED_NAME
,RECIPIENTCONTACTNAME
,SUBINSTNAME
,PHYSICALADDRESS
,ISNOTIFICATIONMESSAGE
,DELIVERYTYPE
,DELIVERYSTATUS
,CANCELINDICATOR
,ERRORMESSAGE)
  
  SELECT AA.DAY_ID,
AA.EXECSTARTTIME,
AA.EXECFINISHTIME,
BB.REPORTID ,
CC.IS_SCHED_GUID ,
CC.IS_SCHED_NAME,
AA.RECIPIENTCONTACTNAME,
AA.SUBINSTNAME,
AA.PHYSICALADDRESS,
AA.ISNOTIFICATIONMESSAGE,
AA.DELIVERYTYPE,
AA.DELIVERYSTATUS,
BB.CANCELINDICATOR,
BB.ERRORMESSAGE

FROM [MSTR_STATS_10_2].dbo.STG_IS_MESSAGE_STATS AA 
FULL OUTER JOIN [MSTR_STATS_10_2].dbo.STG_IS_REPORT_STATS BB
ON ( AA.DAY_ID = BB.DAY_ID and AA.SESSIONID = BB.SESSIONID and AA.schedulejobid=BB.jobid)
Join [MSTR_STATS_10_2].dbo.IS_SCHED CC
ON (CC.IS_SCHED_GUID=AA.SCHEDULEID)
WHERE AA.DAY_ID >= CAST(getdate() as date)
----AND BB.ERRORMESSAGE is not null
ORDER BY AA.DAY_ID , AA.EXECSTARTTIME', 
		@database_name=N'HPS_ODS', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'MSTR JOB RUNNING STATUS', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20220804, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'e24911e7-0715-40b3-8f49-8d7cedb704a8'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

