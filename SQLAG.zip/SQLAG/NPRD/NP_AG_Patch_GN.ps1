

# Change the KB number as required
#####**********WARNING: Try for AG Servers ONLY *********
# ---- Inputs ---------------------------------------------------------------------
$active    = 'TPADWSQLGNXTA01'
$passive   = 'TPADWSQLGNXTB01'
$PatchPath = 'C:\Patch'
$KB        = 5068406
#--few function here ########

function Stop-Script {
    param([string]$Message)
    Write-Error $Message
    Stop-Transcript | Out-Null
    exit 1
}
function Write-Info {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Message,

        [ValidateSet("Black", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow", "Gray", "DarkGray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "White")]
        [string]$Color = "White"
    )

    Write-Host $Message -ForegroundColor $Color
}
#######--------------############

Start-Transcript -Path "D:\PSScripts\PatchLogs\AGPatchLog_hh.txt" -Append
Clear-Host
Write-Info "Starting SQL AG patch automation..." Green

# ---- Validation -----------------------------------------------------------------
if ($active -ieq $passive) { Stop-Script "Primary and Secondary must differ." }

if ($KB -notmatch '^\d{6,8}$') {
    Stop-Script "KB '$KB' does not match expected numeric pattern."
}

# Basic reachability
foreach ($n in @($active,$passive)) {
    if (-not (Test-Connection -ComputerName $n -Count 1 -Quiet)) {
        Stop-Script "Cannot ping node '$n'."
    }
}

# ---- Module Load ----------------------------------------------------------------
try {
    if (-not (Get-Module -ListAvailable -Name dbatools)) {
        Stop-Script "dbatools module not found on this host."
    }
    Import-Module dbatools -ErrorAction Stop | Out-Null
} catch {
    Stop-Script "Failed to import dbatools: $_"
}

# ---- Functions ------------------------------------------------------------------
function Get-AgName {
    param([string]$SqlInstance)
    $ag = Get-DbaAvailabilityGroup -SqlInstance $SqlInstance -ErrorAction Stop | Select-Object -First 1
        if ($ag) { return $ag.Name } else {
        Write-Warning "No Availability Group found on $SqlInstance. Skipping AG-dependent operations."
        return $null}
}

function Test-AgDatabasesHealthy {
    param([string]$SqlInstance)
    $agDbs = Get-DbaAgDatabase -SqlInstance $SqlInstance -ErrorAction Stop
    $unhealthy = $agDbs | Where-Object { $_.SynchronizationState -ne 'Synchronized' -or $_.IsSuspended }
    if ($unhealthy) {
        Write-Warning "Unhealthy AG DBs on ${SqlInstance}:`n$($unhealthy.DatabaseName -join ', ')"
        return $false
    }
    return $true
}

function Patch-SQLNode {
    param(
        [Parameter(Mandatory)] [string]$Node,
        [Parameter(Mandatory)] [string]$PatchPath,
        [Parameter(Mandatory)] [string]$KB
    )
    Write-Info "Validating AG database health on $Node..."
    if (-not (Test-AgDatabasesHealthy -SqlInstance $Node)) {
        Write-Error "AG databases not healthy on $Node. Aborting patch on this node."
        return $false
    }
    Write-Info "AG databases healthy on $Node. Beginning patch."

    try {
        Update-DbaBuildReference -ErrorAction Stop | Out-Null
        Update-DbaInstance -ComputerName $Node -KB $KB -Restart -Path $PatchPath -Confirm:$false -ErrorAction Stop | Out-Null
        Write-Info "Patch command dispatched for $Node. Waiting for restart..."
        return $true
    } catch {
        Write-Error "Patching failed on ${Node}: $_"
        return $false
    }
}

function Wait-Uptime {
    param(
        [string]$SqlInstance,
        [int]$TimeoutSeconds = 600,
        [int]$PollSeconds = 60
    )
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        try {
            if (Get-DbaUptime -SqlInstance $SqlInstance -ErrorAction Stop) {
                return $true
            }}
catch { Write-Warning "Error during uptime check for ${SqlInstance}: $_" }
        Start-Sleep -Seconds $PollSeconds
    }
    Write-Error "Instance $SqlInstance did not come online within $TimeoutSeconds seconds."
    return $false
}

function Invoke-AgFailover {
    param(
        [Parameter(Mandatory)] [string]$NewPrimaryInstance,
        [Parameter(Mandatory)] [string]$AgName,
        [int]$Attempts = 2,
        [int]$DelaySeconds = 120
    )
    for ($attempt=1; $attempt -le $Attempts; $attempt++) {
        Write-Info "Attempt ${attempt}: Initiating AG failover targeting $NewPrimaryInstance..."
        try {
            $res = Invoke-DbaAgFailover -SqlInstance $NewPrimaryInstance -AvailabilityGroup $AgName -Confirm:$false -ErrorAction Stop
            if ($res.PrimaryReplica -eq $NewPrimaryInstance) {
                Write-Info "Failover success (attempt $attempt)." Green
                return $true
            } else {
                Write-Warning "Failover status unsuccessful in attempt $attempt."
            }
        } catch {
            Write-Warning "Failover error on attempt ${attempt}: $_"
        }
        Start-Sleep -Seconds $DelaySeconds
    }
    Write-Error "Failover to $NewPrimaryInstance failed after $Attempts attempts."
    return $false
}

function Verify-KBOnNode {
    param(
        [string]$Node,
        [string]$KB
    )
    # Expect Get-KBNumber script in working directory; wrap safely
    try {

if (-not (Test-Path "D:\PSScripts\SQLAG\Get-KBNumber.ps1")) {
    Stop-Script "Required script Get-KBNumber.ps1 not found in current directory."
} Set-Location -path "D:\PSScripts\SQLAG"
        $kbInfo = ./Get-KBNumber $Node
        if ($null -eq $kbInfo) {
            Write-Warning "Get-KBNumber returned null for $Node"
            return $false
        }
        return ($kbInfo.KB_Number -eq $KB)
    } catch {
        Write-Warning "Failed to verify KB on ${Node}: $_"
        return $false
    }
}


function Assert-RemotePatchPath {
    param(
        [string[]]$Computers,
        [string]$Path
    )
    foreach ($cmp in $Computers) {
        try {
            $exists = Invoke-Command -ComputerName $cmp -ScriptBlock {
                param($p)
                Test-Path -LiteralPath $p -PathType Container
            } -ArgumentList $Path -ErrorAction Stop

            if (-not $exists) {
                Stop-Script "Patch path '$Path' NOT found on $cmp."
            }
            Write-Info "Verified patch path '$Path' on $cmp"
        } catch {
            Stop-Script "Remote path validation failure on $cmp for '$Path' : $_"
        }
    }
}
Assert-RemotePatchPath -Computers @($active, $passive) -Path $PatchPath
$ScriptDirectory = "D:\PSScripts\SQLAG"
# ---- Main Logic -----------------------------------------------------------------
$agName = Get-AgName -SqlInstance $active
Write-Info "Detected AG: $agName"

Write-Info "Version BEFORE patching:" Yellow
Connect-DbaInstance -SqlInstance $active  | Select-Object SqlInstance, VersionString
Connect-DbaInstance -SqlInstance $passive | Select-Object SqlInstance, VersionString

# Determine current primary
$agState = Get-DbaAvailabilityGroup -SqlInstance $active -ErrorAction Stop | Where-Object Name -eq $agName
$currentPrimary = $agState.PrimaryReplica
Write-Info "Current primary replica: $currentPrimary"

$activeIsPrimary = ($currentPrimary -ieq $active)
$initialPrimary = $currentPrimary

# Decide first patch target = current secondary
$firstTarget  = if ($activeIsPrimary) { $passive } else { $active }
$secondTarget = if ($activeIsPrimary) { $active } else { $passive }

Write-Info "First patch target (current secondary): $firstTarget"
if (-not (Patch-SQLNode -Node $firstTarget -PatchPath $PatchPath -KB $KB)) {
    Stop-Script "Failed patching first target $firstTarget."
}

if (-not (Wait-Uptime -SqlInstance $firstTarget)) {
    Stop-Script "Patched node $firstTarget did not return in time."
}

# Failover to newly patched node so we can patch the old primary
if (-not (Invoke-AgFailover -NewPrimaryInstance $firstTarget -AgName $agName -Attempts 2 -DelaySeconds 120)) {
    Stop-Script "Failover to $firstTarget failed. Aborting."
}

# Optional KB verification before second patch
Push-Location
try {

if (-not (Test-Path -Path $ScriptDirectory -PathType Container)) {
    Write-Warning "Directory $ScriptDirectory does not exist. Continuing without changing location."
} else {
    Set-Location $ScriptDirectory
}
} catch {
    Write-Warning "Could not change directory to D:\PSScripts\SQLAG (continuing)."
}

if (-not (Verify-KBOnNode -Node $firstTarget -KB $KB)) {
    Stop-Script "KB $KB not verified on $firstTarget. Aborting before second patch."
}
Pop-Location -ErrorAction SilentlyContinue

Write-Info "Second patch target: $secondTarget"
if (-not (Patch-SQLNode -Node $secondTarget -PatchPath $PatchPath -KB $KB)) {
    Stop-Script "Failed patching second target $secondTarget."
}

if (-not (Wait-Uptime -SqlInstance $secondTarget)) {
    Stop-Script "Patched node $secondTarget did not return in time."
}

# Fail back to original primary if it was originally primary
if ($initialPrimary -ieq $active) {
    Write-Info "Failing back to original primary $active ..."
    if (-not (Invoke-AgFailover -NewPrimaryInstance $active -AgName $agName -Attempts 2 -DelaySeconds 120)) {
        Stop-Script "Failback to $active failed."
    }
} else {
    Write-Info "Primary role change retained (original primary was $initialPrimary). No failback required."
}

# Final KB verification both sides
Push-Location
try { Set-Location "D:\PSScripts\SQLAG" | Out-Null } catch {}
$verify1 = Verify-KBOnNode -Node $active  -KB $KB
$verify2 = Verify-KBOnNode -Node $passive -KB $KB
Pop-Location -ErrorAction SilentlyContinue

if (-not ($verify1 -and $verify2)) {
    Stop-Script "Final KB verification failed. Active:$verify1 Passive:$verify2"
}

Write-Info "Version AFTER patching:" Yellow
Connect-DbaInstance -SqlInstance $active  | Select-Object SqlInstance, VersionString
Connect-DbaInstance -SqlInstance $passive | Select-Object SqlInstance, VersionString

Stop-Transcript | Out-Null
Write-Info "Patch process completed successfully." Green