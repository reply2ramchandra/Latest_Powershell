﻿#Microsoft ODBC Driver 17 for SQL Server on Windows version  17.10.6.1 
#Microsoft ODBC Driver 18 for SQL Server on Windows version  18.5.1.1
clear-host
$server='TPAPWPEDSQL001'
 Invoke-Command -ComputerName $server -ScriptBlock {
<#
$regpath="HKLM:\SOFTWARE\Microsoft\MSODBCSQL13"
$odbc13version=Get-ItemProperty -Path $regpath  -ErrorAction Ignore
$ver=$odbc13version.InstalledVersion
Write-Host "Existing ODBC 13 Version: " $ver -ForegroundColor Green -NoNewline
write-host " " -NoNewline
hostname
#>
$regpath="HKLM:\SOFTWARE\Microsoft\MSODBCSQL17"
$odbc17version=Get-ItemProperty -Path $regpath  -ErrorAction Ignore
$ver1=$odbc17version.InstalledVersion
if($ver1){
Write-Host "Existing ODBC 17 Version: " $ver1 -ForegroundColor Green -NoNewline
write-host " " -NoNewline}
else { write-host "NO ODBC17 UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname
<#if($ver -ne "17.10.5.1")
{ 
Write-Host "Server Name:"
hostname
Write-Host "Need a ODBC17 update " -ForegroundColor Red
}
#>
$regpath="HKLM:\SOFTWARE\Microsoft\MSODBCSQL18"
$odbc18version=Get-ItemProperty -Path $regpath -ErrorAction Ignore
$ver2=$odbc18version.InstalledVersion
if($ver2){
Write-Host "Existing ODBC 18 Version: " $ver2 -ForegroundColor Green -NoNewline
write-host " " -NoNewline}
else {write-host "NO ODBC18 UPDATE is Required " -ForegroundColor Yellow -NoNewline }
hostname}
<#if( -not $ver1)
{
break
Write-Host "Existing ODBC 18 Version: " $ver1 -ForegroundColor Green -NoNewline
Hostname
if($ver -ne "18.3.2.1")
{ 
Write-Host "Server Name:"
hostname
Write-Host "Need a ODBC18 update " -ForegroundColor Red
}
}
#>


#CREATE A FOLDER ON SERVER

$targetpatchfolder="c:\patch"
$server="TPAPWPEDSQL001"
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="c:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}


#copy ODBC 17
$server='TPAPWPEDSQL001'
$patchfile= Get-ChildItem D:\OLEDB_ODBC -Filter '*odbc*17.*.msi' 
$source=$patchfile.FullName
$target='c:\patch'
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s  

#Update ODBC 17
$server="TPAPWPEDSQL001"
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& msiexec /quiet /passive /qn /i C:\patch\msodbcsql-17.10.6.1.msi IACCEPTMSODBCSQLLICENSETERMS=YES"}

<#
$patchfile= Get-ChildItem c:\patch -Filter '*odbc*17.*.msi'
$source=$patchfile.FullName
$source }
msiexec /quiet /passive /qn /i $source IACCEPTMSODBCSQLLICENSETERMS=YES ADDLOCAL=ALL}
#>

#copy ODBC 18
$server='TPAPWO365SQL001'
$patchfile= Get-ChildItem D:\OLEDB_ODBC -Filter '*odbc*18.*.msi' 
$source=$patchfile.FullName
$target='C:\patch'
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s  

#Update ODBC 18
$server="TPAPWO365SQL001"
Invoke-Command -ComputerName $server -ScriptBlock {
powershell.exe -command "& msiexec /quiet /passive /qn /i C:\patch\msodbcsql-18.3.3.1.msi IACCEPTMSODBCSQLLICENSETERMS=YES"
}
