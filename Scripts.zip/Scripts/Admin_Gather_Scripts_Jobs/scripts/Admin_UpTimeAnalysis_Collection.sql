CREATE TABLE #xp_cmdshell_output1 (Output VARCHAR (8000)); 
DECLARE @IsVirtual int
DECLARE @SystemUpTime varchar(100)
DECLARE @TRUE bit
DECLARE @FALSE bit
SET @TRUE = 1
SET @FALSE= 0

INSERT INTO #xp_cmdshell_output1 EXEC ('xp_cmdshell ''systeminfo | find "System"'''); 

IF EXISTS (SELECT * FROM #xp_cmdshell_output1 WHERE Output LIKE 'System Model:%Virtual%')
	SELECT @IsVirtual = @TRUE
ELSE IF EXISTS (SELECT * FROM #xp_cmdshell_output1 WHERE Output LIKE 'System Model:%VMware%')
	SELECT @IsVirtual = @TRUE
ELSE
	SELECT @IsVirtual = @FALSE
SELECT @SystemUpTime = (SELECT * FROM #xp_cmdshell_output1 WHERE Output LIKE 'System Up Time:%')
If @SystemUpTime IS NULL 
BEGIN
	SELECT @SystemUpTime = (SELECT * FROM #xp_cmdshell_output1 WHERE Output LIKE 'System Boot Time:%') 
END

DROP TABLE #xp_cmdshell_output1

--Set up Date Information
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear

CREATE TABLE #UpTimeAnalysis(
      [Date_Key] [datetime] NOT NULL,
      [MachineName] [nvarchar](128) NOT NULL,
      [ServerName] [nvarchar](128) NOT NULL,
      [EnvironmentType] [nvarchar](10) NOT NULL,
      [ManagedBy] [nvarchar](10) NOT NULL,
      [Edition] [nvarchar](128) NULL,
      [ProductLevel] [nvarchar](128) NULL,
      [ProductVersion] [nvarchar](128) NULL,
      [IsClusterd] [varchar](100) NULL,
      [ServerUpTime] [varchar](100) NULL,
      [SQLServerUptimeInDays] INT NULL,
      [SQLServerUptimeInHrs] INT NULL,
      [SQLServerUptimeInMins] INT NULL 
)

INSERT INTO #UpTimeAnalysis
           ([Date_Key]
           ,[MachineName]
           ,[ServerName]
           ,[EnvironmentType]
           ,[ManagedBy]
           ,[Edition]
           ,[ProductLevel]
           ,[ProductVersion]
           ,[IsClusterd]
           ,[ServerUpTime]
           ,[SQLServerUptimeInDays]
           ,[SQLServerUptimeInHrs]
           ,[SQLServerUptimeInMins])
(
select 
	@Date_Key AS Date_Key, 
	CONVERT (NVARCHAR (128),SERVERPROPERTY('ComputerNamePhysicalNetBIOS')) AS MachineName,
	CONVERT (NVARCHAR (128),SERVERPROPERTY('ServerName')) AS ServerName,
	CASE WHEN @IsVirtual = 1 THEN 'Virtual' ELSE 'Physical' END as EnvironemntType,
	CASE WHEN CONVERT (NVARCHAR (128),SERVERPROPERTY('ServerName')) = 'RRWIN-SQLP110' THEN 'Ensono'
	     WHEN @IsVirtual = 1 THEN 'LSC' ELSE 'Ensono' END as ManagedBy,
	CONVERT (NVARCHAR (128),SERVERPROPERTY('Edition')) AS Edition,
	CONVERT (NVARCHAR (128),SERVERPROPERTY('ProductLevel')) AS ProductLevel,
	CONVERT (NVARCHAR (128),SERVERPROPERTY('ProductVersion')) AS ProductVersion,
	CASE WHEN SERVERPROPERTY('IsClustered') = 0 THEN 'Not Clustered'
	     WHEN SERVERPROPERTY('IsClustered') = 1 THEN 'Clustered'
	     ELSE 'Undefined' END AS IsCLustered,
	ServerUpTime = @SystemUpTime,
	SQLServerUptimeInDays = (datediff(hh, login_time, current_timestamp))/24,
	SQLServerUptimeInHrs = datediff(hh, login_time, current_timestamp),
	SQLServerUptimeInMins = (datediff(hh, login_time, current_timestamp))*60
from sys.dm_exec_sessions
where session_id = 1
)

--Select Results Set
SELECT
      NULL,
      [Date_Key],
      [MachineName],
      [ServerName],
      [EnvironmentType],
      [ManagedBy],
      [Edition],
      [ProductLevel],
      [ProductVersion],
      [IsClusterd],
      [ServerUpTime],
      [SQLServerUptimeInDays],
      [SQLServerUptimeInHrs],
      [SQLServerUptimeInMins]    
FROM #UpTimeAnalysis
