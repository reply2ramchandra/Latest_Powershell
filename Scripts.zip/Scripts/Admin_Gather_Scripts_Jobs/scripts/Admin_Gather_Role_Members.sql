
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wDBLOGINS_Memberships') ) 
    DROP TABLE #wDBLOGINS_Memberships 
    
    
CREATE TABLE #wDBLOGINS_Memberships 
(ServerName VARCHAR(128),  
DatabaseName NVARCHAR(128),  
UserName NVARCHAR(128),  
DBRoleName NVARCHAR (128)) 

SET NOCOUNT ON
DECLARE @command VARCHAR(5000)  

SELECT @command = 'Use [?];
select @@servername AS ServerName, db_name() AS DatabaseName,UserName = u.name,DBRoleName = g.name
from sys.database_role_members m
RIGHT OUTER JOIN sys.database_principals g ON g.principal_id = m.role_principal_id
RIGHT OUTER JOIN sys.database_principals u ON u.principal_id = m.member_principal_id
where u.type_desc <> ''DATABASE_ROLE''
'
INSERT INTO #wDBLOGINS_Memberships  
   (ServerName,DatabaseName,UserName, DBRoleName)
EXEC sp_MSforeachdb @command 

Declare @Date_Key  datetime
Select @Date_Key = DATEADD(dd,DATEDIFF(dd,0,getdate()),0)

SELECT @Date_Key as Date_Key,
   ServerName,
   DatabaseName,  
   UserName,  
   DBRoleName  
FROM #wDBLOGINS_Memberships

IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wDBLOGINS_Memberships') ) 
    DROP TABLE #wDBLOGINS_Memberships  