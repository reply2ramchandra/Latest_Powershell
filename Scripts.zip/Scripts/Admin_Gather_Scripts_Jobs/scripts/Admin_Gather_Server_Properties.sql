Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)
Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear
SELECT 
NULL,
@Date_Key AS Date_Key,
	CONVERT(NVARCHAR(128),SERVERPROPERTY('ServerName')) AS ServerName
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('ComputerNamePhysicalNetBIOS')) AS ComputerName
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('MachineName')) AS MachineName
	  ,CONVERT(NVARCHAR(128),SERVERPROPERTY('Edition')) AS Edition
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('ProductLevel')) AS ProductLevel
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('ProductVersion')) AS ProductVersion
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('Collation')) AS Collation
      ,CASE WHEN SERVERPROPERTY('IsClustered') = 0 THEN 'Not Clustered'
            WHEN SERVERPROPERTY('IsClustered') = 1 THEN 'Clustered'
            ELSE 'Undefined' END AS IsCLustered
      ,CASE WHEN SERVERPROPERTY('IsFullTextInstalled') = 0 THEN 'Full Text Not Installed'
            WHEN SERVERPROPERTY('IsFullTextInstalled') = 1 THEN 'Full Text Installed'
            ELSE 'Undefined' END AS IsFullTextInstalled
      ,CASE WHEN SERVERPROPERTY('IsIntegratedSecurityOnly') = 0 THEN 'Mixed Mode Authentication'
            WHEN SERVERPROPERTY('IsIntegratedSecurityOnly') = 1 THEN 'Windows Authentication Only'
            ELSE 'Undefined' END AS IsIntegratedSecurityOnly
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('LicenseType')) AS LicenseType
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('NumLicenses')) AS NumLicenses
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('ResourceLastUpdateDateTime')) AS ResourceLastUpdateDateTime
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('ResourceVersion')) AS ResourceVersion
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('SqlCharSetName')) AS SqlCharSetName
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('SqlSortOrderName')) AS SqlSortOrderName
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('FileStreamShareName')) AS FileStreamShareName
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('FileStreamConfiguredLevel')) AS FileStreamConfigureLevel
      ,CONVERT(NVARCHAR(128),SERVERPROPERTY('FileStreamEffectiveLevel')) AS FileStreamEffectiveLevel
