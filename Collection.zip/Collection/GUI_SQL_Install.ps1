﻿Add-Type -AssemblyName System.Windows.Forms

# Main Form
$form = New-Object System.Windows.Forms.Form
$form.Text = "SQL Server Automated Installer"
$form.Size = New-Object System.Drawing.Size(700, 800)
$form.StartPosition = "CenterScreen"

# Host Name
$lblHost = New-Object System.Windows.Forms.Label
$lblHost.Text = "Host Name:"
$lblHost.Location = New-Object System.Drawing.Point(20, 20)
$form.Controls.Add($lblHost)

$txtHost = New-Object System.Windows.Forms.TextBox
$txtHost.Location = New-Object System.Drawing.Point(120, 20)
$txtHost.Size = New-Object System.Drawing.Size(120, 20)
$form.Controls.Add($txtHost)

# Copy Binary button
$btnCopyBinary = New-Object System.Windows.Forms.Button
$btnCopyBinary.Text = "Copy Binary"
$btnCopyBinary.Size = New-Object System.Drawing.Size(120, 30)
$btnCopyBinary.Location = New-Object System.Drawing.Point(340, 80)
$form.Controls.Add($btnCopyBinary)

# Binary Status
<#$lblBinary= New-Object System.Windows.Forms.Label
$lblBinary.Text = ""
$lblBinary.Location = New-Object System.Drawing.Point(20, 50)
$lblBinary.Size = New-Object System.Drawing.Size(600, 20)
$form.Controls.Add($lblBinary)
#>


# Copy SSMS Button 
$btnCopySSMS = New-Object System.Windows.Forms.Button
$btnCopySSMS.Text = "Copy SSMS"
$btnCopySSMS.Size = New-Object System.Drawing.Size(120, 30)
$btnCopySSMS.Location = New-Object System.Drawing.Point(340, 120) # 40px below Copy Binary
$form.Controls.Add($btnCopySSMS)

# SSMS Status
<#$lblSSMS= New-Object System.Windows.Forms.Label
$lblSSMS.Text = ""
$lblSSMS.Location = New-Object System.Drawing.Point(20, 50)
$lblSSMS.Size = New-Object System.Drawing.Size(600, 20)
$form.Controls.Add($lblSSMS)
#>


# Check Drives Button
$btnCheckDrives = New-Object System.Windows.Forms.Button
$btnCheckDrives.Text = "Check Drives"
$btnCheckDrives.Size = New-Object System.Drawing.Size(120, 30)
$btnCheckDrives.Location = New-Object System.Drawing.Point(340, 20)
$form.Controls.Add($btnCheckDrives)

# Drives Status
$lblDrives = New-Object System.Windows.Forms.Label
$lblDrives.Text = ""
$lblDrives.Location = New-Object System.Drawing.Point(20, 50)
$lblDrives.Size = New-Object System.Drawing.Size(600, 20)
$form.Controls.Add($lblDrives)

# Apply Policy Button
$btnApplyPolicy = New-Object System.Windows.Forms.Button
$btnApplyPolicy.Text = "Apply Policy"
$btnApplyPolicy.Size = New-Object System.Drawing.Size(130, 30)
$btnApplyPolicy.Location = New-Object System.Drawing.Point(180, 80)
$form.Controls.Add($btnApplyPolicy)

<#
# Apply Policy Status
$btnApplyPolicy = New-Object System.Windows.Forms.Label
$btnApplyPolicy.Text = ""
$btnApplyPolicy.Location = New-Object System.Drawing.Point(150, 80)
$btnApplyPolicy.Size = New-Object System.Drawing.Size(400, 40)
$form.Controls.Add($btnApplyPolicy)
#>

# Reboot Button
$btnReboot = New-Object System.Windows.Forms.Button
$btnReboot.Text = "Reboot Server"
$btnReboot.Size = New-Object System.Drawing.Size(130, 30)
$btnReboot.Location = New-Object System.Drawing.Point(20, 80)
$form.Controls.Add($btnReboot)

<#
# Reboot Status
$lblReboot = New-Object System.Windows.Forms.Label
$lblReboot.Text = ""
$lblReboot.Location = New-Object System.Drawing.Point(150, 80)
$lblReboot.Size = New-Object System.Drawing.Size(400, 40)
$form.Controls.Add($lblReboot)
#>

# Mount ISO Button
$btnMountISO = New-Object System.Windows.Forms.Button
$btnMountISO.Text = "Mount ISO"
$btnMountISO.Size = New-Object System.Drawing.Size(120, 30)
$btnMountISO.Location = New-Object System.Drawing.Point(20, 120)
$form.Controls.Add($btnMountISO)

<#
# ISO Status
$lblISO = New-Object System.Windows.Forms.Label
$lblISO.Text = ""
$lblISO.Location = New-Object System.Drawing.Point(150, 120)
$lblISO.Size = New-Object System.Drawing.Size(400, 20)
$form.Controls.Add($lblISO)
#>
# Setup Drive Letter
$lblSetupDrive = New-Object System.Windows.Forms.Label
$lblSetupDrive.Text = "Setup Drive Letter:"
$lblSetupDrive.Size = New-Object System.Drawing.Size(180, 30)
$lblSetupDrive.Location = New-Object System.Drawing.Point(20, 160)
$form.Controls.Add($lblSetupDrive)

$txtSetupDrive = New-Object System.Windows.Forms.TextBox
$txtSetupDrive.Location = New-Object System.Drawing.Point(220, 160)
$txtSetupDrive.Size = New-Object System.Drawing.Size(30, 20)
$form.Controls.Add($txtSetupDrive)

# SQL Version
$lblSQLVer = New-Object System.Windows.Forms.Label
$lblSQLVer.Text = "SQL Version (2022/2025):"
$lblSQLVer.Size = New-Object System.Drawing.Size(200, 40)
$lblSQLVer.Location = New-Object System.Drawing.Point(20, 200)
$form.Controls.Add($lblSQLVer)

$txtSQLVer = New-Object System.Windows.Forms.TextBox
$txtSQLVer.Location = New-Object System.Drawing.Point(220, 200)
$txtSQLVer.Size = New-Object System.Drawing.Size(60, 20)
$form.Controls.Add($txtSQLVer)

# Instance Name
$lblInstance = New-Object System.Windows.Forms.Label
$lblInstance.Text = "Instance Name (1 for default):"
$lblInstance.Size = New-Object System.Drawing.Size(200, 40)
$lblInstance.Location = New-Object System.Drawing.Point(20, 240)
$form.Controls.Add($lblInstance)

$txtInstance = New-Object System.Windows.Forms.TextBox
$txtInstance.Location = New-Object System.Drawing.Point(220, 240)
$txtInstance.Size = New-Object System.Drawing.Size(100, 20)
$form.Controls.Add($txtInstance)

# Install SQL Button
$btnInstallSQL = New-Object System.Windows.Forms.Button
$btnInstallSQL.Text = "Install SQL Server"
$btnInstallSQL.Size = New-Object System.Drawing.Size(200, 30)
$btnInstallSQL.Location = New-Object System.Drawing.Point(20, 300)
$form.Controls.Add($btnInstallSQL)

# SQL Install Status
$lblSQLStatus = New-Object System.Windows.Forms.Label
$lblSQLStatus.Text = ""
$lblSQLStatus.Location = New-Object System.Drawing.Point(150, 320)
$lblSQLStatus.Size = New-Object System.Drawing.Size(400, 20)
$form.Controls.Add($lblSQLStatus)

# Install SSMS Button
$btnInstallSSMS = New-Object System.Windows.Forms.Button
$btnInstallSSMS.Text = "Install SSMS"
$btnInstallSSMS.Size = New-Object System.Drawing.Size(180, 30)
$btnInstallSSMS.Location = New-Object System.Drawing.Point(30, 340)
$form.Controls.Add($btnInstallSSMS)

# SSMS Status
<#$lblSSMS = New-Object System.Windows.Forms.Label
$lblSSMS.Text = ""
$lblSSMS.Location = New-Object System.Drawing.Point(150, 360)
$lblSSMS.Size = New-Object System.Drawing.Size(400, 20)
$form.Controls.Add($lblSSMS)
#>

# Post Build Button
$btnPostBuild = New-Object System.Windows.Forms.Button
$btnPostBuild.Text = "Run Post-Build Scripts"
$btnPostBuild.Size = New-Object System.Drawing.Size(200, 25)
$btnPostBuild.Location = New-Object System.Drawing.Point(20, 380)
$form.Controls.Add($btnPostBuild)

<#
# Post Build Status
$lblPostBuild = New-Object System.Windows.Forms.Label
$lblPostBuild.Text = ""
$lblPostBuild.Location = New-Object System.Drawing.Point(200, 360)
$lblPostBuild.Size = New-Object System.Drawing.Size(400, 20)
$form.Controls.Add($lblPostBuild)
#>

# Unmount ISO Button
$btnUnmountISO = New-Object System.Windows.Forms.Button
$btnUnmountISO.Text = "Unmount ISO"
$btnUnmountISO.Size = New-Object System.Drawing.Size(180, 25)
$btnUnmountISO.Location = New-Object System.Drawing.Point(30, 420)
$form.Controls.Add($btnUnmountISO)


<#
# Unmount Status
$lblUnmount = New-Object System.Windows.Forms.Label
$lblUnmount.Text = ""
$lblUnmount.Location = New-Object System.Drawing.Point(150, 420)
$lblUnmount.Size = New-Object System.Drawing.Size(400, 20)
$form.Controls.Add($lblUnmount)
#>

# Cleanup Button
$btnCleanup = New-Object System.Windows.Forms.Button
$btnCleanup.Text = "Cleanup Software"
$btnCleanup.Size = New-Object System.Drawing.Size(200, 25)
$btnCleanup.Location = New-Object System.Drawing.Point(20, 500)
$form.Controls.Add($btnCleanup)

<#
# Cleanup Status
$lblCleanup = New-Object System.Windows.Forms.Label
$lblCleanup.Text = ""
$lblCleanup.Location = New-Object System.Drawing.Point(150, 440)
$lblCleanup.Size = New-Object System.Drawing.Size(400, 20)
$form.Controls.Add($lblCleanup)
#>

# Test SQL Connection Button
$btnTestSQL = New-Object System.Windows.Forms.Button
$btnTestSQL.Text = "Test SQL Connection"
$btnTestSQL.Size = New-Object System.Drawing.Size(200, 25)
$btnTestSQL.Location = New-Object System.Drawing.Point(20, 460)
$form.Controls.Add($btnTestSQL)

<#
# Test SQL Status
$lblTestSQL = New-Object System.Windows.Forms.Label
$lblTestSQL.Text = ""
$lblTestSQL.Location = New-Object System.Drawing.Point(170, 480)
$lblTestSQL.Size = New-Object System.Drawing.Size(400, 20)
$form.Controls.Add($lblTestSQL)
#>

# Exit Button
$btnExit = New-Object System.Windows.Forms.Button
$btnExit.Text = "Exit"
$btnExit.Size = New-Object System.Drawing.Size(80, 30)
$btnExit.Location = New-Object System.Drawing.Point(400, 500)
$form.Controls.Add($btnExit)

<#
# Exit Status
$lblExit = New-Object System.Windows.Forms.Label
$lblExit.Text = "Closing"
$lblExit.Location = New-Object System.Drawing.Point(150, 440)
$lblExit.Size = New-Object System.Drawing.Size(400, 20)
$form.Controls.Add($lblExit)
#>

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(20, 540)
$txtLog.Size = New-Object System.Drawing.Size(650, 120)
$txtLog.Multiline = $true
$txtLog.ScrollBars = [System.Windows.Forms.ScrollBars]::Both
$txtLog.ReadOnly = $true
$txtLog.Font = New-Object System.Drawing.Font("Consolas", 10)
$form.Controls.Add($txtLog)

function Test-HostReachable {
    param([string]$hostnam)
    try {
        return Test-Connection -ComputerName $hostnam -Count 1 -Quiet -ErrorAction Stop
    } catch {
        return $false
    }
}

function Write-Log {
    param([string]$msg)
    $txtLog.AppendText("[$([DateTime]::Now.ToString('HH:mm:ss'))] $msg`r`n")
    $txtLog.SelectionStart = $txtLog.Text.Length
    $txtLog.ScrollToCaret()
}

# Example: Update all event handlers to use Write-Log for progress
# --- Event Handlers ---
# Add event handler for the button
$btnCopyBinary.Add_Click({
    Import-Module dbatools -ErrorAction SilentlyContinue
    $server = $txtHost.Text
    $remotePath = "D:\SQL\Software"
    $localpath1 = "X:\SQLISO\2022"
    $localpath2 = "X:\SQLISO\CU\2022"
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for copy operation."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text =""
    Write-Log "Starting copy operation to $server ..."
    try {
        Write-Log "Checking/creating remote directory..."
        Invoke-Command -ComputerName $server -ScriptBlock {
            param($remotePath)
            if (-not (Test-Path $remotePath)) {
                New-Item -Path $remotePath -ItemType Directory -Force | Out-Null
            }
        } -ArgumentList $remotePath
        Write-Log "Remote directory ready."
        $remoteUNC = "\\$server\$($remotePath.Substring(0,1))$" + $remotePath.Substring(2)
        Write-Log "Copying files from $localpath1 to $remoteUNC ..."
        $robocopyCmd1 = "robocopy `"$localpath1`" `"$remoteUNC`" /MIR /Z /NP /R:2 /W:5"
        $result1 = Invoke-Expression $robocopyCmd1
        Write-Log "Copying files from $localpath2 to $remoteUNC ..."
        $robocopyCmd2 = "robocopy `"$localpath2`" `"$remoteUNC`" /MIR /Z /NP /R:2 /W:5"
        $result2 = Invoke-Expression $robocopyCmd2
        Write-Log "File copy completed."
		# Calculate total size of files in the target directory
		# List each file and its size in MB
		Get-ChildItem -Path $remoteUNC -Recurse -File | ForEach-Object {
		$fileSizeMB = [math]::Round($_.Length / 1MB, 2)
		Write-Log "File: $($_.FullName) - Size: $fileSizeMB MB"}
    } catch {
        Write-Log "Error during copy: $_"
    }
})

# Example event handler for Copy SSMS button
$btnCopySSMS.Add_Click({
	$server = $txtHost.Text
    $remotePath = "D:\SQL\Software"
    $localpath = "X:\SSMS"
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for copy operation."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text =""
    Write-Log "Starting copy operation to $server ..."
    try {
        Write-Log "Checking/creating remote directory..."
        Invoke-Command -ComputerName $server -ScriptBlock {
            param($remotePath)
            if (-not (Test-Path $remotePath)) {
                New-Item -Path $remotePath -ItemType Directory -Force | Out-Null
            }
        } -ArgumentList $remotePath
        Write-Log "Remote directory ready."
        $remoteUNC = "\\$server\$($remotePath.Substring(0,1))$" + $remotePath.Substring(2)
        Write-Log "Copying files from $localpath to $remoteUNC ..."
        $robocopyCmd = "robocopy `"$localpath`" `"$remoteUNC`" /MIR /Z /NP /R:2 /W:5"
        $result = Invoke-Expression $robocopyCmd
        Write-Log "File copy completed."
		# Calculate total size of files in the target directory
		# List each file and its size in MB
		Get-ChildItem -Path $remoteUNC -Recurse -File | ForEach-Object {
		$fileSizeMB = [math]::Round($_.Length / 1MB, 2)
		Write-Log "File: $($_.FullName) - Size: $fileSizeMB MB"}

    } catch {
        Write-Log "Error during copy: $_"
    }

   })

$btnCheckDrives.Add_Click({
    Import-Module dbatools -ErrorAction SilentlyContinue
    $server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for drive check."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text = ""
    Write-Log "Checking drives on $server ..."
    $driveLetter = Get-DbaDiskSpace $server
    $drives = $driveLetter.Name -join ", "
    $requiredDrives = @('D', 'M', 'L', 'T')
    $hasRequiredDrive = $driveLetter.Name | Where-Object { $_ -in $requiredDrives }
    if (-not $hasRequiredDrive) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Warning: Server does not have any of the required drives: D, M, L, T."
        Write-Log "Server missing all required drives: D, M, L, T."
    } else {
        $lblDrives.ForeColor = [System.Drawing.Color]::Blue
        $lblDrives.Text = "Drives found: $drives"
        Write-Log "Drives found: $drives"
    }
})

$btnApplyPolicy.Add_Click({
	$server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for reboot."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text = ""
    Write-Log "Working.."
	Invoke-Command -ComputerName $server -ScriptBlock {
    $regpath = "HKLM:\Software\Microsoft\Cryptography\Protect\Providers\df9d8cd0-1501-11d1-8c7a-00c04fc297eb"
    $name = "ProtectionPolicy"
    $value = 1
    New-ItemProperty -Path $regpath -Name $name -Value $value -PropertyType DWORD -Force
    Restart-Service -Name CryptSvc -Force
    }
	 Write-Log "cryptographic ProtectionPolicy Applied."
})

$btnReboot.Add_Click({
    $server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for reboot."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text = ""
    Write-Log "Initiating reboot on $server ..."
    try {
        Invoke-Command -ComputerName $server -ScriptBlock {
                       Restart-Computer . -Force
        }
        $lblDrives.Text = "Reboot initiated. Please wait for the server to come back online."
        Write-Log "Reboot initiated."
    } catch {
        Write-Log "Error during reboot: $_"
    }
	
	Import-Module dbatools -ErrorAction Stop
	Start-Sleep -Seconds 300
	$thresholdMinutes = 5      # How recent the reboot should be

	try {
    $osInfo = Get-DbaOperatingSystem -ComputerName $server | Select-Object ComputerName, LastBootTime, LocalDateTime
    if ($null -eq $osInfo) {
        Write-Log "Could not retrieve OS info for $server."
        return
    }

    # Access the .DateTime property for calculations
    #$lastBoot = $osInfo.LastBootTime.DateTime
    #$now = $osInfo.LocalDateTime.DateTime
    #$minutesSinceBoot = ($now - $lastBoot).TotalMinutes
    $lastBoot = [datetime]::Parse($osInfo.LastBootTime.ToString())
    $now = [datetime]::Parse($osInfo.LocalDateTime.ToString())
    $minutesSinceBoot = ($now - $lastBoot).TotalMinutes

    Write-Log "Server: $($osInfo.ComputerName)"
    Write-Log "Last Boot Time: $lastBoot"
    Write-Log "Current Time: $now"
    Write-Log "Minutes since last boot: $([math]::Round($minutesSinceBoot,2))"

    if ($minutesSinceBoot -le $thresholdMinutes) {
        Write-Log "✅ Server $server rebooted successfully within the last $thresholdMinutes minutes."
    } else {
        Write-Log "⚠️ Server $server has been rebooted (last boot was $([math]::Round($minutesSinceBoot,2)) minutes ago)."
    }
} catch {
    Write-Log "❌ Error connecting to $server or retrieving OS info: $_"
}
})

$btnMountISO.Add_Click({
    $server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for Mount."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text = ""
    Write-Log "Checking.."
    try {
        $result = Invoke-Command -ComputerName $server -ScriptBlock {
            $binarypath = "D:\SQL\Software"
            $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO"
            if ($isoImg -ne $null) {
                $isoImg = $isoImg.FullName
                Mount-DiskImage -ImagePath $isoImg
                # Get mounted ISO volume
                $mountvol = (Get-DiskImage -DevicePath \\.\CDROM1 | Get-Volume).DriveLetter
                return "ISO Mounted. SQLServerSetup Drive is: $mountvol"
            } else {
                return "Ensure ISO is copied and exists on the Server"
            }
        }
		 if ($result -eq "Ensure ISO is copied and exists on the Server") {
            $lblDrives.ForeColor = [System.Drawing.Color]::Red
        } else {
            $lblDrives.ForeColor = [System.Drawing.Color]::Blue
        }
        Write-Log $result
        $lblDrives.Text = $result
    } catch {
        Write-Log "Error mounting ISO: $_"
        $lblDrives.Text = "Error mounting ISO."
    }
})


$btnInstallSQL.Add_Click({
    $server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for Install."
        return
    }
    if (-not (Test-HostReachable $server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
        Write-Log "Host $server is unreachable or incorrect."
        return
    }
    $lblDrives.Text = ""
    Write-Log "Checking.."
    $vers = $txtSQLVer.Text
    $namedinstance = $txtInstance.Text
    $mountvol = $txtSetupDrive.Text + ":"
    Import-Module dbatools -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($vers) -or [string]::IsNullOrWhiteSpace($mountvol) -or [string]::IsNullOrWhiteSpace($namedinstance)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Ensure SQL Version or Mount Drive Letter or Instance name is NOT EMPTY."
        return
    }
    try {
        $Instance = Find-DbaInstance -ComputerName $server
        if ($Instance -eq $null -and $namedinstance -eq "1" ) {
            $lblDrives.Text = "Default DB Instance installation started."
            Write-Log "DB installation started. You can cancel\exit if any error or no progress.."
            Install-DbaInstance -ComputerName $server -Version $vers -InstancePath "D:\SQLServer" -Restart -DataPath "M:\SQLDATA" -LogPath "L:\SQLLog" -TempPath "T:\Tempdb" -UpdateSourcePath "D:\SQL\Software" -PerformVolumeMaintenanceTasks -Confirm:$false -ErrorAction Stop
        } else {
            $lblDrives.Text = "DB installation started.You can cancel\exit if any error or no progress.."
            Write-Log "Named DB Instance installation started."
            Install-DbaInstance -ComputerName $server -Version $vers -InstanceName $namedinstance -InstancePath "D:\SQLServer" -Restart -DataPath "M:\SQLData\$namedinstance" -LogPath "L:\SQLLog\$namedinstance" -TempPath "T:\Tempdb\$namedinstance" -UpdateSourcePath "D:\SQL\Software" -PerformVolumeMaintenanceTasks -Confirm:$false -ErrorAction Stop
        }
        $inst = Find-DbaInstance -ComputerName $server
        if ($null -ne $inst) {
            $lblDrives.ForeColor = [System.Drawing.Color]::Blue
            $lblDrives.Text = "SQL installation was successful."
            Write-Log "SQL installation was successful."
        } else {
            $lblDrives.ForeColor = [System.Drawing.Color]::Red
            $lblDrives.Text = "SQL installation could be unsuccessful."
        }
    } catch {
        $errorMsg = $_.Exception.Message
        # Split error message into lines and check for Install-DbaInstance
        $lines = $errorMsg -split "`r?`n"
        foreach ($line in $lines) {
            if ($line.Trim().ToLower().StartsWith("install-dbainstance")) {
                $lblDrives.ForeColor = [System.Drawing.Color]::Red
                $lblDrives.Text = $line
                Write-Log $line
                return
            }
        }
        # Default error reporting if not matched
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Error during SQL Server installation: $errorMsg"
        Write-Log "Error during SQL Server installation: $errorMsg"
    }
})
 
$btnInstallSSMS.Add_Click({
    $server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for SSMS install."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text = ""
    Write-Log "Checking.."
    try {
        $result = Invoke-Command -ComputerName $server -ScriptBlock {
            $filepath = Get-ChildItem -Path D:\SQL\Software -Filter "*SSMS*.exe" | Select-Object -First 1
            if ($null -eq $filepath) {
                return "Ensure SSMS Exe file is copied to Server path." 
            } else {
                $Parms = " /Install /Quiet /Norestart"
                $Prms = $Parms.Split(" ")
                & "$($filepath.FullName)" $Prms | Out-Null
                return "SSMS installation completed successfully."
            }
        }
		if($result -eq "SSMS installation completed successfully." )
		{
        $lblDrives.ForeColor = [System.Drawing.Color]::Green
		}
		else {$lblDrives.ForeColor = [System.Drawing.Color]::Red}
        $lblDrives.Text = $result
        Write-Log $result
    } catch {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Error during SSMS installation."
        Write-Log "Error during SSMS installation: $_"
    }
})

$btnPostBuild.Add_Click({
    Import-Module dbatools -ErrorAction SilentlyContinue
    $server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for Post-Build."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text = ""
    Write-Log "Starting post-build script deployment..."

    try {
        $instance = Find-DbaInstance -ComputerName $server | Select-Object -ExpandProperty SqlInstance
        if ([string]::IsNullOrWhiteSpace($instance)) {
            throw "No SQL instance found on $server."
        }
        $postscripts = Get-ChildItem X:\SQLPostBuild\Deploy -File | Select-Object -ExpandProperty FullName
        if (-not $postscripts) {
            throw "No post-build scripts found in X:\SQLPostBuild\Deploy."
        }
        foreach ($deploy in $postscripts) {
            Write-Log "Deploying script: $deploy"
            try {
                $instance | Invoke-DbaQuery -File $deploy -EnableException -ErrorAction Stop
                Write-Log "Successfully deployed: $deploy"
            } catch {
                Write-Log "Error deploying ${deploy}: $($_.Exception.Message)"
            }
        }
        $lblDrives.ForeColor = [System.Drawing.Color]::Blue
        $lblDrives.Text = "Post-build scripts deployment completed. Check log for details."
        Write-Log "Post-build scripts deployment completed."
    } catch {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Error during post-build deployment: $($_.Exception.Message)"
        Write-Log "Error during post-build deployment: $($_.Exception.Message)"
    }
})

$btnUnmountISO.Add_Click({
    $server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for Unmount."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text = ""
    Write-Log "Checking.."
    try {
        $result = Invoke-Command -ComputerName $server -ScriptBlock {
            $binarypath = "D:\SQL\Software"
            $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO" | Select-Object -First 1
            if ($null -eq $isoImg) {
                return "No ISO image found to unmount."
            }
            try {
                DisMount-DiskImage -ImagePath $isoImg.FullName -ErrorAction Stop
                return "ISO unmounted successfully."
            } catch {
                return "Error unmounting ISO: $($_.Exception.Message)"
            }
        }
        if ($result -eq "ISO unmounted successfully.") {
            $lblDrives.ForeColor = [System.Drawing.Color]::Blue
        } else {
            $lblDrives.ForeColor = [System.Drawing.Color]::Red
        }
        $lblDrives.Text = $result
        Write-Log $result
    } catch {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Error during ISO unmount: $($_.Exception.Message)"
        Write-Log "Error during ISO unmount: $($_.Exception.Message)"
    }
})
$btnCleanup.Add_Click({
    $server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for Cleanup."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text = ""
    Write-Log "Starting cleanup operation..."
    try {
        $result = Invoke-Command -ComputerName $server -ScriptBlock {
            $binarypath = "D:\SQL\Software"
            try {
                $items = Get-ChildItem -Path $binarypath -Recurse -ErrorAction Stop
                if ($items.Count -eq 0) {
                    return "Nothing to cleanup."
                }
                $items | Remove-Item -Force -Recurse -ErrorAction Stop
                return "Software cleanup complete."
            } catch {
                return "Error during cleanup: $($_.Exception.Message)"
            }
        }
        if ($result -eq "Software cleanup complete.") {
            $lblDrives.ForeColor = [System.Drawing.Color]::Blue
        } elseif ($result -eq "Nothing to cleanup.") {
            $lblDrives.ForeColor = [System.Drawing.Color]::Orange
        } else {
            $lblDrives.ForeColor = [System.Drawing.Color]::Red
        }
        $lblDrives.Text = $result
        Write-Log $result
    } catch {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Error during cleanup: $($_.Exception.Message)"
        Write-Log "Error during cleanup: $($_.Exception.Message)"
    }
})

$btnTestSQL.Add_Click({
    Import-Module dbatools -ErrorAction SilentlyContinue
    $server = $txtHost.Text
    if ([string]::IsNullOrWhiteSpace($server)) {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Enter a host name."
        Write-Log "Host name is required for SQL connection test."
        return
    }
	 if (-not (Test-HostReachable $server)) {
     $lblDrives.ForeColor = [System.Drawing.Color]::Red
     $lblDrives.Text = "Host is unreachable or incorrect. Please check the hostname."
     Write-Log "Host $server is unreachable or incorrect."
     return
    }
    $lblDrives.Text = ""
    Write-Log "Starting SQL connection test..."

    try {
        $Ins = Find-DbaInstance -ComputerName $server
        $remoteconnect = Connect-DbaInstance -SqlInstance $Ins -ErrorAction Stop
        if ($remoteconnect -ne $null) {
            $lblDrives.ForeColor = [System.Drawing.Color]::Blue
            $lblDrives.Text = "SQL connection successful! All looks good."
            Write-Log "SQL Server Name and Version: $($remoteconnect.Name), $($remoteconnect.Version)"
            Write-Log "SQL connection test completed successfully."
        } else {
            $lblDrives.ForeColor = [System.Drawing.Color]::Red
            $lblDrives.Text = "SQL connection failed. Check connectivity to the DB server."
            Write-Log "SQL connection failed. No instance returned."
        }
    } catch {
        $lblDrives.ForeColor = [System.Drawing.Color]::Red
        $lblDrives.Text = "Error during SQL connection test: $($_.Exception.Message)"
        Write-Log "Error during SQL connection test: $($_.Exception.Message)"
    }
})

$btnExit.Add_Click({
   
    # Close the form and exit the script
    $form.Close()
    [System.Windows.Forms.Application]::Exit()
})

$form.ShowDialog()

