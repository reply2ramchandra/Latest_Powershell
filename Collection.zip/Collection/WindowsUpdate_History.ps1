﻿#check the Install history, change the KB # as per Release month

#OCT 14th '25 --KB5066584/KB5066836 --2016 and KB5066586 --2019, KB5066782- 2022

$servers=get-content "T:\Test\OS2019.txt"
foreach($server in $servers)
{
Import-Module PSWindowsUpdate
Get-WUHistory -ComputerName $server | Where-Object {$_.Title -match “KB5066586*” } | Select  ComputerName,Date,Result,Title | ft -AutoSize 
}
$servers=get-content "T:\Test\OS2022.txt"
foreach($server in $servers)
{
Import-Module PSWindowsUpdate
Get-WUHistory -ComputerName $server | Where-Object {$_.Title -match “KB5066782*” } | Select  ComputerName,Date,Result,Title | ft -AutoSize  
}

$servers=get-content "T:\Test\OS2016.txt"
foreach($server in $servers)
{
Import-Module PSWindowsUpdate
Get-WUHistory -ComputerName $server | Where-Object {$_.Title -match “KB5066584*” } | Select  ComputerName,Date,Result,Title | ft -AutoSize  
}

##individual Server by maxdate
Import-Module PSWindowsUpdate
Get-WUHistory -ComputerName TPATWSQLSP001 -MaxDate "10/24/2025" | Select ComputerName,Date,Result,Title | FL ##M/DD/YYYY
#Get-WULastResults


Import-Module PSWindowsUpdate
Get-WUHistory -ComputerName TPADWSQLGNXTA01 | Where-Object {$_.Title -match “KB5068787*” } | Select-object ComputerName,Date,Result,Title | ft -AutoSize ##2022
import-Module PSWindowsUpdate
Get-WUHistory -ComputerName TPAPWSQLGNRA01 | Where-Object {$_.Title -match “KB5068791*” } |  Select-object ComputerName,Date,Result,Title | ft -AutoSize ##2019
Get-WUHistory -ComputerName TPAPWSQLGNXTA01 | Where-Object {$_.Title -match “KB5068864*” } | Select-Object ComputerName,Date,Result,Title | ft -AutoSize ##2019

##check OS version
Import-Module dbatools -EA SilentlyContinue
Get-DbaOperatingSystem -ComputerName TPAPWSQLFTPA01 | select ComputerName,OSVersion | FT

##checking Pending Reboot
Import-Module PendingReboot
Test-PendingReboot -ComputerName TPATWSQLQFILE01 -SkipConfigurationManagerClientCheck


<#
##check the HA Server's OS patch history

$hanprod=get-content "T:\Test\HA_Prod.txt"
$count=$hanprod.count
Write-Host 'Total Server Count:'$count
$cnt=0
import-Module PSWindowsUpdate
#change the KB article name according to month
foreach($srv in $hanprod)
{
$cnt=$cnt+1
Get-WUHistory -ComputerName $srv | Where-Object {$_.Title -match “KB5055519*” -or $_.Title -match “KB5055521*”} | Select-Object * | ft
}
write-Host 'Total patch count:'$count-$cnt
#>