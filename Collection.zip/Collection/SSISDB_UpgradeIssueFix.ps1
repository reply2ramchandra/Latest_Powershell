﻿#SSISDB Upgrade issue
#RDP Server and run the command
#NET START MSSQLSERVER /T902
Import-Module dbatools -EA SilentlyContinue 
Get-DbaErrorLog -SqlInstance TPAUWSQLDL001  -LogNumber 1 -Text "LOG"
