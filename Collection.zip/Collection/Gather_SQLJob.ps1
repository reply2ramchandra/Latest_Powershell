﻿clear
get-date
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue
#$instances=get-content "T:\Test\100924.txt" 
$instances = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] WHERE STATUS IN('Y','P','R') and [HostName] NOT IN('PCIPWSQL001') and Category='Prod'"  -TrustServerCertificate 
#foreach($instance in $instances) 
foreach($instance in $instances.SqlInstance)
{
#$OFC=Get-DbaAgentJob -SqlInstance $instance -Job 'Maint - Generate DR Report' | select SqlInstance,Name,LastRunDate,CreateDate
$OFC=Get-DbaAgentJob -SqlInstance $instance | Where-Object Name -Match Generate | Get-DbaAgentJobHistory -OutcomeType Failed 
if($OFC){Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DRReport_613' -InputObject $OFC  -AutoCreateTable -KeepNulls } }
get-Date

