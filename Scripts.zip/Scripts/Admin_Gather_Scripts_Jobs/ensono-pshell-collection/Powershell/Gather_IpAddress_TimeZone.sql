SET NOCOUNT ON 

DECLARE @MachineName VARCHAR(256)
DECLARE @xp VARCHAR(512)
DECLARE @results TABLE ([output] VARCHAR(MAX))

DECLARE @Original_AdvOptions_State SQL_VARIANT;
DECLARE @Original_CmdShell_State SQL_VARIANT;
DECLARE @Current_AdvOptions_State SQL_VARIANT
DECLARE @Current_CmdShell_State SQL_VARIANT;

SET @Original_AdvOptions_State = 0;
SET @Original_CmdShell_State = 0;
SET @Current_AdvOptions_State = 0;
SET @Current_CmdShell_State = 0;


/*  ENABLE XP_CMDSHELL  */
SELECT
	@Original_AdvOptions_State = value_in_use
FROM master.sys.configurations
WHERE name = 'show advanced options'
SELECT
	@Original_CmdShell_State = value_in_use
FROM master.sys.configurations
WHERE name = 'xp_cmdshell'

IF @Original_AdvOptions_State = 0
	 BEGIN
		 EXEC sp_configure 'show advanced options'
						  ,1
		 RECONFIGURE WITH OVERRIDE
	 END

IF @Original_CmdShell_State = 0
	 BEGIN
		 --    PRINT 'Changing xp_cmdshell is off - CHANGING to on'
		 EXEC sp_configure 'xp_cmdshell'
						  ,1
		 RECONFIGURE WITH OVERRIDE
	 END

	 -- // END

-- We are checking Machine Name of SQL Instance Instead of ComputerPhysicalNetBiosName
-- For a Standalone SQL Instance, both Machine and NetBios names are same
-- For FailoverCluster Instance,  Machine Name <=> SQL Virtual Cluster Name, Whereas NetBios is an Active Physical NodeName of Cluster 
SET @MachineName = CAST( SERVERPROPERTY( 'MachineName' ) AS VARCHAR(256) ) 
SET @xp = 'powershell.exe -c " IF (Test-Connection -ComputerName' + SPACE(1) + @MachineName + SPACE(1) +'-Quiet) { Test-Connection -ComputerName'+ SPACE(1) + @MachineName + SPACE(1) + '-Count 1 | Format-List -Property Address,IPV4Address } "'


INSERT INTO @results
EXEC xp_cmdshell @xp

-- Machine TimeZone Offset
INSERT INTO @results
VALUES ('TimeZoneOffset:' + CAST(CURRENT_TIMESTAMP AS VARCHAR(24) ) + SPACE(1) + CAST(DATEDIFF(MINUTE,GETUTCDATE(),CURRENT_TIMESTAMP)/60 AS VARCHAR(2)) + ':' + CAST(DATEDIFF(MINUTE,GETUTCDATE(),CURRENT_TIMESTAMP)%60 AS VARCHAR(2)))
--VALUES ('TimeZoneOffset:' + CAST(SYSDATETIMEOFFSET() AS VARCHAR(35))) /* built-in function does not exist in SQL 2005 */


SELECT
 UPPER(CAST(SERVERPROPERTY('ServerName') AS VARCHAR(256)))					  AS SqlInstance 
,RTRIM( LTRIM( CAST( REPLACE( [T1],'Address     :','' ) AS VARCHAR(256) ) ) ) AS MachineName 
,RTRIM( LTRIM( CAST( REPLACE( [T2],'IPV4Address :','' ) AS VARCHAR(24) ) ) )  AS IPAddress 
,RTRIM( LTRIM( CAST( REPLACE( [T3],'TimeZoneOffset:','' ) AS VARCHAR(64)  ) ) ) AS TimeZoneOffset 
--,RTRIM( LTRIM( CAST( REPLACE( [T3],'TimeZoneOffset:','' ) AS DATETIMEOFFSET(1)  ) ) ) AS TimeZoneOffset  /* built-in function does not exist in SQL 2005 */
FROM (
Select [output],'T' + CAST( ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS CHAR(1))  AS rn  
FROM @results WHERE [output] IS NOT NULL
) AS s
PIVOT (MAX([output]) FOR rn IN ([T1],[T2],[T3]) ) AS p

/* REVERT TO ORIGINAL STATE */
SELECT
	@Current_CmdShell_State = value_in_use
FROM master.sys.configurations
WHERE name = 'xp_cmdshell'

IF @Original_CmdShell_State <> @Current_CmdShell_State
	 BEGIN
		 --PRINT 'Reverting xp_cmdshell state'
		 EXEC sp_configure 'xp_cmdshell'
						  ,0
		 RECONFIGURE WITH OVERRIDE
	 END

SELECT
	@Current_AdvOptions_State = value_in_use
FROM master.sys.configurations
WHERE name = 'show advanced options'

IF @Original_AdvOptions_State <> @Current_AdvOptions_State
	 BEGIN
		 --PRINT 'Reverting show advanced options state'
		 RECONFIGURE WITH OVERRIDE
	 END

/* END */


SET NOCOUNT OFF;