﻿# Ensure TLS 1.2 (older servers)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
# Update PowerShellGet if very old (optional safety)
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Install-Module dbatools -Scope AllUsers -Force