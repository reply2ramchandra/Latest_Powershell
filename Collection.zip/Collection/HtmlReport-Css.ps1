﻿Import-Module dbatools -EA SilentlyContinue
clear
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$css = @"
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid black; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
</style>
"@

$runDateTime = (Get-Date -Format yyyyddMM) 
 $preContent = @"
<h3><font face=verdana color=blue>PROD Server Disk Space Report</font></h3>
<p>This report contains the list of Servers where disk space is less than 10% free space.</p>
"@

$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Please review and take action Required.</font></p>
"@
$diskinfo=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query " SELECT [ComputerName] ,[Name],[Capacity]/1024/1024/1000 [Capacity_GB],cast([Free]/1024/1024/1000.0 as Decimal(10,2)) [Free_GB],[PercentFree] FROM [CMS].[dbo].[DiskSpace] WHERE [PercentFree]<10 order by [ComputerName]; " -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
#$diskinfo | ConvertTo-Html @htmlParams  | Out-File -FilePath \\tpapwmssql002\Reports\DriveSpaceReport$runDateTime.htm

$diskinfo | ConvertTo-Html -Property ComputerName, Name, Capacity_GB,Free_GB,PercentFree -Head $css -Title "PROD Server Disk Space Report" -PreContent $preContent  -PostContent  $postContent | Out-File -FilePath \\tpapwmssql002\Reports\DriveSpaceReport$runDateTime.htm

             if($diskinfo.Count -gt 0)
             {
                  Write-host 'Sending mail of Prod Servers''  drive Info' -ForegroundColor Green
                   
                  $body = Get-Content \\tpapwmssql002\Reports\DriveSpaceReport$runDateTime.htm
                  Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'PROD Server Drive Report | Less than 10 Percent Free space' -SmtpServer smtprelay.healthplan.com -BodyAsHtml:$true -Body "$body" 
                #Invoke-Item \\tpapwmssql002\Reports\backupreport.html
            }
             else
             {
              Write-host 'Not sending mail since we are good' -ForegroundColor Yellow
             }