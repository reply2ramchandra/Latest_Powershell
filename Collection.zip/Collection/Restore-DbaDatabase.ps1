﻿Import-Module dbatools -EA SilentlyContinue 
$BackupDirectory='\\tpadd9300.healthplan.com\SQLBackupsprod\CHG0086467'
$targetInstance='TPAQWSQLDL01' ##BE CAREFULL OF TARGET SERVERNAME
#Restore-DbaDatabase -SqlInstance $targetInstance -Path $BackupDirectory -DatabaseName HPS_STAGE -WithReplace  -Confirm:$true
<#
\\tpadd9300\SQLBackups\TPATWSQL004\HPS_Config\FULL\TPATWSQL004_HPS_Config_FULL_20240822_020026.bak
Import-Module dbatools -EA SilentlyContinue 
$BackupDirectory='\\tpadd9300.healthplan.com\SQLBackupsprod\CHG0086467'
$result = Restore-DbaDatabase -SqlInstance TPAQWSQLDL001 -Path $BackupDirectory -DestinationDataDirectory M:\Stage -OutputScriptOnly
$result | Out-File -Filepath X:\scripts\restore\restore.sql

#>
Import-Module dbatools -EA SilentlyContinue
Restore-DbaDatabase -SqlInstance GCPUWDWSQL005 -DatabaseName HPS_ODS -Path '\\tpadd9300.healthplan.com\SQLBackupsprod\GCPUWDWSQL004\HPS_ODS\FULL\GCPUWDWSQL004_HPS_ODS_FULL_20250515_103309.bak' -DestinationDataDirectory M:\EDW_3Carrier\Datafiles\ -DestinationLogDirectory L:\TPAUWDWSQL005_Logfiles\ -WithReplace -Confirm:$true
Restore-DbaDatabase -SqlInstance GCPUWDWSQL005 -DatabaseName HPS_EDW -Path '\\tpadd9300.healthplan.com\SQLBackupsprod\GCPUWDWSQL004\HPS_STAGE\FULL\GCPUWDWSQL004_HPS_STAGE_FULL_20250515_133231.bak' -DestinationDataDirectory M:\EDW_AllCarrier\ -DestinationLogDirectory L:\LOGS\ -WithReplace -Confirm:$true
