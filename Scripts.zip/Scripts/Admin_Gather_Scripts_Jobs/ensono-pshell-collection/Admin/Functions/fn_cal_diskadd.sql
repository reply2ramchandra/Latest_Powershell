﻿CREATE FUNCTION [Admin].[fn_cal_diskadd] (@currentsize DECIMAL(10,2)
										 ,@currentfree DECIMAL(10,2)
										 ,@targetper   TINYINT = 25)
RETURNS INT
AS
	BEGIN

		DECLARE @targetadd INT

		SET @targetadd = CEILING( (CONVERT( DECIMAL(5,2),((@targetper / 100.0) * @currentsize) - @currentfree ) / (1 - CONVERT( DECIMAL(5,2),(@targetper / 100.0) ))) );

		RETURN (@targetadd);

	END
