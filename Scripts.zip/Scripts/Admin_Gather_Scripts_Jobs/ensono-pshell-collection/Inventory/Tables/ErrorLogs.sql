﻿CREATE TABLE [Inventory].[ErrorLogs]
(
	[DateKey] SMALLDATETIME,
    [SqlInstance] VARCHAR(256) NOT NULL,
    [LogDate]  DATETIME,
    [Source]  VARCHAR(512),
    [Text] NVARCHAR(MAX)
    CONSTRAINT FK_ErrorLogs_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
)

GO

CREATE CLUSTERED INDEX [CX_ErrorLogs_DateKey] ON [Inventory].[ErrorLogs] (DateKey)