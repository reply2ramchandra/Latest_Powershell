﻿Import-Module dbatools -EA SilentlyContinue
Start-ScheduledTask -TaskName "PSWindowsUpdate"
Stop-ScheduledTask -TaskName "PSWindowsUpdate"
Unregister-ScheduledTask -TaskName "PSWindowsUpdate" -Confirm:$false

$Time = New-ScheduledTaskTrigger -At 04:00 -Once
Set-ScheduledTask -TaskName "PSWindowsUpdate" -Trigger $Time

$Time = New-ScheduledTaskTrigger -At 04:00 -Once
$User = "HPS\a-sm58408"
$PS = New-ScheduledTaskAction -Execute "PowerShell.exe"
Register-ScheduledTask -TaskName "PSWindowsUpdate" -Trigger $Time -User $User -Action $PS

$session=New-CimSession -ComputerName TPATWSQLHHB01
Get-ScheduledTask -CimSession $session | where {$_.TaskName -like "*St*" }
