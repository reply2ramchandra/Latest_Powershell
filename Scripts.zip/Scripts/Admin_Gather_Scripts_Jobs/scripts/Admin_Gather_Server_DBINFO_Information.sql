
SET NOCOUNT ON

CREATE TABLE #wDBINFO1  
(db varchar(255),  
dbsize decimal(14,2),  
rem varchar(128))  

CREATE TABLE #wDBINFO2  
(customer varchar(128),  
server varchar(128),
sla char(1),
db varchar(128),
crdate varchar(128),
dbsize decimal(14,2),  
[comments] varchar(128) null,
[updated] varchar(10), 
[by] varchar(16) null)


SET NOCOUNT ON
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear

Declare @customer	varchar(255)
Declare @sla 		char(1)
Declare @server		varchar(128) 
Declare @DBA		varchar(10)

Set @customer	= 'LSC Communications, Inc.'
Set @sla 	= 'P'	-- P=Prod T=Test D=Devl
Set @DBA 	= 'rowens'
Set @server 	= (SELECT CONVERT(sysname, SERVERPROPERTY('ServerName')))


--insert into #wDBINFO1 exec sp_databases
insert into #wDBINFO1
select
        DATABASE_NAME   = db_name(s_mf.database_id),
        DATABASE_SIZE   = SUM(CONVERT(bigint,s_mf.size))*8, -- Convert from 8192 byte pages to Kb
        REMARKS         = CONVERT(varchar(254),null)
    from
        sys.master_files s_mf
    where
        s_mf.state = 0 -- ONLINE
              group by s_mf.database_id
              ORDER BY 1

insert into #wDBINFO2
select @customer, @server as Server,@sla as SLA, db as DBName, 
            convert(varchar(2),datepart(mm,crdate)) + '/' + convert(varchar(4),datepart(yy,crdate)) as 'CreateDate',
            convert(decimal(14,2),dbsize / 1024) as 'Size MB',
	    '', convert(varchar(2),datepart(mm,getdate())) + '/' + convert(varchar(2),datepart(dd,getdate())) + '/' + convert(varchar(4),datepart(yy,getdate())) as 'updated', 		   
	    @DBA
from #wDBINFO1 join master..sysdatabases a on db = name 

where db != 'model' and db != 'tempdb' and db != 'northwind' and db != 'pubs'  and db != 'msdb'  
--and db != 'master' and db != 'DBA'
Update #wDBINFO2
set db = 'System DBs', dbsize = 0 ,sla = '',[comments] = 'SYSTEM Databases'
where db = 'master'
Update #wDBINFO2
set sla = ''
where db = 'DBA'

SELECT
   @Date_Key AS Date_Key,
   * from #wDBINFO2
order by db



