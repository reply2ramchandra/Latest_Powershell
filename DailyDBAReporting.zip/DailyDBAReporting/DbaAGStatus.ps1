<# --- Preflight diagnostics ---
Write-Host "PS Version: $($PSVersionTable.PSVersion)"
Write-Host "64-bit: $([Environment]::Is64BitProcess)"
Write-Host "User: $([Environment]::UserDomainName)\$([Environment]::UserName)"
Write-Host "PSModulePath:`n$($env:PSModulePath -split ';' | ForEach-Object { '  ' + $_ })"

#>
# Module loading (SQL Agent may not load user scope modules)
#Install-Module dbatools -Scope AllUsers -Force
Import-Module dbatools -ErrorAction Stop
Import-Module SQLServer -ErrorAction Stop
# Verify required commands
$required = 'Get-DbaAvailabilityGroup','Get-DbaAgReplica','Write-DbaDataTable','Invoke-DbaQuery'
$missing = $required | Where-Object { -not (Get-Command $_ -ErrorAction SilentlyContinue) }
if ($missing) {
    throw "Missing required dbatools commands: $($missing -join ', ')"
}
# Optional: bypass SSL validation if needed
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }

# SQL connection details
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'

# Drop old table
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "DROP TABLE IF EXISTS [CMS].[dbo].[DbaAGStatus]" -TrustServerCertificate

# Get list of AG servers
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "SELECT [ServerName] FROM [CMS].[dbo].[DbaAGServer] WHERE [PreferredPrimary]='YES'" -TrustServerCertificate

# Collect AG replica status
foreach ($AG in $servers.ServerName) {
    try {
        $primary = Get-DbaAvailabilityGroup -SqlInstance $AG | Select-Object -ExpandProperty PrimaryReplicaServerName
        if ($primary -eq $AG) {
            $AGReplica = Get-DbaAgReplica -SqlInstance $AG
            Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DbaAGStatus' -InputObject $AGReplica -AutoCreateTable -KeepNulls
        }
    } catch {
    Write-Warning ("Failed to collect AG replica info from {0}: {1}" -f $AG, $_.Exception.Message)
    continue
}
}

Start-Sleep -Seconds 2

# HTML styling
$css = @"
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid black; padding: 8px; text-align: left; }
    th { background-color: #D6EEEE; }
    tr:nth-child(even) { background-color: rgba(150, 212, 212, 0.4); }
</style>
"@

# HTML content
$runDateTime = Get-Date -Format "yyyyMMdd"
$reportPath = "\\tpapwmssql002\Reports\AGStatus$runDateTime.html"
$reportPathColored = "\\tpapwmssql002\Reports\AGStatusC$runDateTime.html"

$preContent = @"
<h3><font face='verdana' color='blue'>SQL AG REPLICA - SYNC Status</font></h3>
<p>This report contains the list of AG Server's Sync Status.</p>
"@

$postContent = @"
<p><font face='verdana' color='green'>Generated on $(Get-Date). Please review and take action as required.</font></p>
"@

# Summary table
#$total = $servers.Count
$total=8 #should be changed manually as needed
$tco = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "SELECT COUNT(*) / 2 AS cnt FROM [CMS].[dbo].[DbaAGStatus]" -TrustServerCertificate | Select-Object -ExpandProperty cnt
"<table><tr><th>Total_AOAG_To_Check</th><td bgcolor='#F0FF33'>$total</td><th>Total_AOAG_Checked</th><td bgcolor='#F0FF33'>$tco</td></tr></table>" | Out-File -FilePath $reportPath

# Main report
$rpt = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "SELECT [Replica],[AvailabilityGroup],[Role],[RollupSynchronizationState] FROM [CMS].[dbo].[DbaAGStatus]" -TrustServerCertificate
$rpt | ConvertTo-Html -Property Replica, AvailabilityGroup, Role, RollupSynchronizationState -Head $css -Title "SQL AG REPLICA - SYNC Status" -PreContent $preContent -PostContent $postContent | Out-File -FilePath $reportPath -Append

# Highlight unsynchronized replicas
$nrpt = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -Query "SELECT [Replica],[AvailabilityGroup],[Role],[RollupSynchronizationState] FROM [CMS].[dbo].[DbaAGStatus] WHERE [RollupSynchronizationState] <> 'Synchronized'" -TrustServerCertificate

if ($rpt.Count -gt 0 -or $nrpt.Count -gt 0) {
    Write-Host 'Sending mail' -ForegroundColor Green
    $body = Get-Content $reportPath

    if ($nrpt.Count -gt 0) {
        . "D:\PSScripts\DailyDBAReporting\Set-CellColor.ps1"
        $body | Set-CellColor State Yellow -Filter "RollupSynchronizationState -notlike '*Synchronized*'" | Out-File $reportPathColored
        Send-MailMessage -From 'DBA_Report@Healthplan.com' -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'Alert: SQL AG REPLICA - SYNC Status' -SmtpServer 'smtprelay.healthplan.com' -BodyAsHtml:$true -Body ($body -join "`n")
    } else {
        Send-MailMessage -From 'DBA_Report@Healthplan.com' -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'SQL AG REPLICA - SYNC Status' -SmtpServer 'smtprelay.healthplan.com' -BodyAsHtml:$true -Body ($body -join "`n")
    }
} else {
    Write-Host 'Not sending mail as we don''t have anything' -ForegroundColor Yellow
}


