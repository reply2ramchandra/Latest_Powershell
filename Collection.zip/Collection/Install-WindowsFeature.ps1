﻿Install-WindowsFeature Net-Framework-Core -source C:\tmp\dotnet-sdk-3.1.425-win-x64.exe
Get-WindowsFeature |  Where {$_.Name -Like '*Fail*'}
##Installing Cluster Services 
Install-WindowsFeature –name NET-Framework-Core 
Install-WindowsFeature -Name Failover-Clustering –IncludeManagementTools