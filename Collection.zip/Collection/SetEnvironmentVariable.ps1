﻿$path = [Environment]::GetEnvironmentVariable("Path", "Machine")
$newPath = $path + ";C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn"
[Environment]::SetEnvironmentVariable("Path", $newPath, "Machine")