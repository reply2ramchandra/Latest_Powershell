﻿Add-ADGroupMember -Identity SG-SQLNonProd-Backup -Members ICMInstall
Get-ADGroupMember -Identity SG-SQLProd-Backup | SELECT Name | sort name