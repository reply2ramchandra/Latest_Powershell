﻿$url="http://tpapwsqlssrs-03/Reports/browse/"
# Send a web request to the URL
$response = Invoke-WebRequest -Uri $url -UseBasicParsing

# Check the status code of the response
if ($response.StatusCode -eq 200) {
    Write-Output "The URL is healthy. Status Code: 200"
} else {
    Write-Output "The URL is not healthy. Status Code: $($response.StatusCode)"
}

#path> \\tpapwsqlssrs-03\D$\Program Files\Microsoft SQL Server\MSRS13.MSSQLSERVER\Reporting Services\Logfiles\
 
Get-Service -ComputerName TPAPWSQLSSRS-03 | Where-Object {$_.Name -like '*Report*'}