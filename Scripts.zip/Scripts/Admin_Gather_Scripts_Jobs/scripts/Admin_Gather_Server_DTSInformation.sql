
Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear

DECLARE @ServerName sysname
IF @@VERSION like '%2005%' OR @@VERSION like '%2008%'
BEGIN
SET @ServerName = (select TOP 1 [srvnetname] from master.dbo.sysservers order by srvid ASC)
SELECT TOP 100 PERCENT 
	@Date_Key AS Date_Key,
	@ServerName AS Server_Name, 
	SS.name AS DTS_Package_Name, 
	SS.description AS DTS_Description, 
	SS.createdate AS DTS_Creation_Date
FROM	msdb.dbo.sysdtspackages SS INNER JOIN
	 (SELECT [name], MAX(createdate) AS createdate
	  FROM msdb.dbo.sysdtspackages
	  GROUP BY [name]) S1 ON SS.name = S1.name AND SS.createdate = S1.createdate
ORDER BY SS.name
END


