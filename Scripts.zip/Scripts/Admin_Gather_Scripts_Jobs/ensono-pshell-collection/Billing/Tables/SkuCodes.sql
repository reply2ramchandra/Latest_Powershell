CREATE TABLE Billing.SkuCodes (SupportTier VARCHAR(128)
							  ,SkuName VARCHAR(128))

GO