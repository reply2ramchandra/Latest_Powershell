﻿#SSIS_Extract_dtsx_from_ispac
# Set the directory containing your .ispac files and the output directory
$ispacDir = "C:\Path\To\IspacFiles"
$outputDir = "C:\Path\To\ExtractedDtsx"

# Ensure output directory exists
if (-not (Test-Path $outputDir)) {
    New-Item -Path $outputDir -ItemType Directory | Out-Null
}

# Find all .ispac files (non-recursive; add -Recurse for subfolders)
$ispacFiles = Get-ChildItem -Path $ispacDir -Filter *.ispac

foreach ($ispac in $ispacFiles) {
    $projectName = [System.IO.Path]::GetFileNameWithoutExtension($ispac.Name)
    $projectOutputDir = Join-Path $outputDir $projectName

    if (-not (Test-Path $projectOutputDir)) {
        New-Item -Path $projectOutputDir -ItemType Directory | Out-Null
    }

    # Open the .ispac as a zip archive
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($ispac.FullName)

    foreach ($entry in $zip.Entries) {
        if ($entry.FullName -like "*.dtsx") {
            $destPath = Join-Path $projectOutputDir ([System.IO.Path]::GetFileName($entry.FullName))
            $entryStream = $entry.Open()
            $fileStream = [System.IO.File]::OpenWrite($destPath)
            $entryStream.CopyTo($fileStream)
            $fileStream.Close()
            $entryStream.Close()
            Write-Host "Extracted $($entry.FullName) to $destPath"
        }
    }
    $zip.Dispose()
}