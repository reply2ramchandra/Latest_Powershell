﻿clear
# Load SMO and RegisteredServers assemblies
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Management.SqlManagementObjects") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Management.RegisteredServers") | Out-Null


# Connect to CMS Server
$cmsServerName = "TPAPWMSSQL002"
$serverConnection = New-Object Microsoft.SqlServer.Management.Common.ServerConnection($cmsServerName)
$regServerStore = New-Object Microsoft.SqlServer.Management.RegisteredServers.RegisteredServersStore($serverConnection)

# Recursively update all registered servers
function Update-TrustServerCertificate($serverGroup) {
    foreach ($regServer in $serverGroup.RegisteredServers) {
        $connString = $regServer.ConnectionString
        if ($connString -notmatch "TrustServerCertificate") {
            $connString += ";TrustServerCertificate=True"
            $regServer.ConnectionString = $connString
            $regServer.Alter()  # Persist the change
            Write-Host "Updated: $($regServer.Name)"
        } else {
            Write-Host "Already set: $($regServer.Name)"
        }
    }

    foreach ($subGroup in $serverGroup.ServerGroups) {
        Update-TrustServerCertificate $subGroup
    }
}

# Start from root group
Update-TrustServerCertificate $regServerStore.ServerGroups
