﻿ clear
Import-Module dbatools -ErrorAction SilentlyContinue
 Test-DbaMaxDop -SqlInstance TPAPWDWSQLB05