Import-Module dbatools -EA SilentlyContinue
Update-DbaBuildReference
Update-DbaInstance -ComputerName TPAPWIDESQL001 -KB 5065865 -Restart -Path C:\Patch -Confirm:$false