
SET ARITHIGNORE ON
SET NOCOUNT ON
DECLARE @format tinyint
DECLARE @SQL NVARCHAR(1000)
DECLARE @STRLine VARCHAR(8000)
DECLARE @Drive varchar(500)
DECLARE @TotalSize BIGINT
DECLARE @Freesize BIGINT
DECLARE @VolumeName VARCHAR(64)
DECLARE @command VARCHAR(5000)  
DECLARE @filecheck char(1)

IF EXISTS (SELECT name FROM tempdb..sysobjects WHERE name like '#DrvLetter%')
	DROP TABLE #DrvLetter

CREATE TABLE #DrvLetter (
    Drive VARCHAR(500),
    )
IF EXISTS (SELECT name FROM tempdb..sysobjects WHERE name like '#DrvInfo%')
	DROP TABLE #DrvInfo

CREATE TABLE #DrvInfo (
    Drive VARCHAR(500) null,
    [MB free] BIGINT,
    [MB TotalSize] BIGINT,
    [Volume Name] VARCHAR(64)
    )
IF EXISTS (SELECT name FROM tempdb..sysobjects WHERE name like '#DBInfo2%')
	DROP TABLE #DBInfo2

CREATE TABLE #DBInfo2   
	( ServerName VARCHAR(100),  
	DatabaseName VARCHAR(100),  
	FileSizeMB INT,  
	LogicalFileName sysname,  
	PhysicalFileName NVARCHAR(520),  
	Status sysname,  
	Updateability sysname,  
	RecoveryMode sysname,  
	FreeSpaceMB INT,  
	FreeSpacePct VARCHAR(7),  
	FreeSpacePages INT,  
	PollDate datetime)  

IF EXISTS (SELECT name FROM tempdb..sysobjects WHERE name like '#BackupDrive%')
	DROP TABLE #BackupDrive

CREATE TABLE #BackupDrive   
	( ServerName VARCHAR(100),  
	physical_device_name NVARCHAR(520))  
CREATE TABLE #os_files([filename] varchar(2000))

IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'[tempdb].[dbo].[wCapacityReviewCollection]') ) 
    DROP TABLE [tempdb].[dbo].[wCapacityReviewCollection]

CREATE TABLE #CapacityReviewCollection(
	[Date_Key] [datetime] NOT NULL,
	[ServerName] [nvarchar](128) NOT NULL,
	[FileType] [nvarchar](3) NULL,
	[DatabaseName] [varchar](128) NOT NULL,
	[FileSizeMB] [int] NOT NULL,
	[LogicalFileName] [sysname] NOT NULL,
	[DiskDrive] [varchar](500) NULL,
	[PhysicalFileName] [nvarchar](520) NOT NULL,
	[Status] [sysname] NOT NULL,
	[Updateability] [sysname] NOT NULL,
	[RecoveryMode] [sysname] NOT NULL,
	[FreeSpaceMB] [int] NOT NULL,
	[FreeSpacePct] [varchar](7) NOT NULL,
	[PollDate] [datetime] NOT NULL,
	[Applications] [varchar](256) NULL,
	[FunctionalGroups] [varchar](256) NULL,
	[Owners] [varchar](256) NULL,
	[SortOrder] [int] NOT NULL
)


INSERT INTO #DrvLetter
EXEC xp_cmdshell 'wmic volume where drivetype="3" get caption, freespace, capacity, label'

DELETE
FROM #DrvLetter
WHERE Drive IS NULL OR len(Drive) < 4 OR Drive LIKE '%Capacity%'
	OR Drive LIKE  '%\\%\Volume%'

WHILE EXISTS(SELECT 1 FROM #DrvLetter)
BEGIN
SET ROWCOUNT 1
SELECT @STRLine = Drive FROM #DrvLetter

-- Get TotalSize
SET @TotalSize= CONVERT(BIGINT,CAST(LEFT(@STRLine,CHARINDEX(' ',@STRLine)) AS CHAR(18)))/1024/1024
--SELECT @TotalSize

-- Remove Total Size
SET @STRLine = REPLACE(@STRLine, LEFT(@STRLine,CHARINDEX(' ',@STRLine)),'')
-- Get Drive

SET @Drive = LEFT(LTRIM(@STRLine),CHARINDEX(' ',LTRIM(@STRLine)))
--SELECT @Drive

SET @STRLine = RTRIM(LTRIM(REPLACE(LTRIM(@STRLine), LEFT(LTRIM(@STRLine),CHARINDEX(' ',LTRIM(@STRLine))),'')))

SET @Freesize = CONVERT(BIGINT,CAST(LEFT(LTRIM(@STRLine),CHARINDEX(' ',LTRIM(@STRLine))) AS CHAR(18)))/1024/1024
--SELECT @Freesize/1024/1024

SET @STRLine = RTRIM(LTRIM(REPLACE(LTRIM(@STRLine), LEFT(LTRIM(@STRLine),CHARINDEX(' ',LTRIM(@STRLine))),'')))
SET @VolumeName = @STRLine
-- 

INSERT INTO #DrvInfo
SELECT @Drive, @Freesize , @TotalSize, @VolumeName

DELETE FROM #DrvLetter
END

SET ROWCOUNT 0

-----------------------------------------------------------------------------------------------
-- This logic retrieves the Backup Default location from the Registry
declare @rc int, @BackupDefault nvarchar(4000)

exec @rc = master.dbo.xp_instance_regread
N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\MSSQLServer',N'BackupDirectory', @BackupDefault output, 'no_output'
--Select @BackupDefault
-----------------------------------------------------------------------------------------------


-- POPULATE TEMP TABLE WITH LOGICAL DISKS
-- This is FIX/Workaround for Windows 2003 bug that WMIC doesn't return volume name that is over X number of charactors.
SET @SQL ='wmic /FailFast:ON logicaldisk where (drivetype ="3" and volumename!="RECOVERY" AND volumename!="System Reserved") get deviceid,volumename  /Format:csv'
if object_id('tempdb..#output1') is not null drop table #output1
CREATE TABLE #output1 (col1 VARCHAR(2048))
INSERT INTO #output1
EXEC master..xp_cmdshell @SQL
DELETE #output1 where ltrim(col1) is null or len(col1) = 1 or col1 like 'Node,DeviceID,VolumeName%'


if object_id('tempdb..#logicaldisk') is not null drop table #logicaldisk
CREATE TABLE #logicaldisk (DeviceID varchar(128),VolumeName varchar(256))

DECLARE @NodeName varchar(128)
SET @NodeName = (SELECT TOP 1 LEFT(col1, CHARINDEX(',',col1)) FROM #output1)

-- Clean up server name
UPDATE #output1 SET col1 = REPLACE(col1, @NodeName, '')

INSERT INTO #logicaldisk
SELECT LEFT(col1, CHARINDEX(',',col1)-2),  SUBSTRING(col1, CHARINDEX(',',col1)+1, LEN(col1))
FROM #output1


UPDATE dr
SET dr.[Volume Name] = ld.VolumeName
	FROM #DrvInfo dr RIGHT OUTER JOIN #logicaldisk ld ON left(dr.Drive,1) = ld.DeviceID
WHERE LEN([Volume Name]) = 1


SELECT @command = 'Use [' + '?' + '] SELECT  
	@@servername as ServerName,  
	' + '''' + '?' + '''' + ' AS DatabaseName,  
	CAST(sysfiles.size/128.0 AS int) AS FileSize,  
	sysfiles.name AS LogicalFileName, sysfiles.filename AS PhysicalFileName,  
	CONVERT(sysname,DatabasePropertyEx(''?'',''Status'')) AS Status,  
	CONVERT(sysname,DatabasePropertyEx(''?'',''Updateability'')) AS Updateability,  
	CONVERT(sysname,DatabasePropertyEx(''?'',''Recovery'')) AS RecoveryMode,  
	CAST(sysfiles.size/128.0 - CAST(FILEPROPERTY(sysfiles.name, ' + '''' +  
		   'SpaceUsed' + '''' + ' ) AS int)/128.0 AS int) AS FreeSpaceMB,  
	CAST(100 * (CAST (((sysfiles.size/128.0 -CAST(FILEPROPERTY(sysfiles.name,  
	' + '''' + 'SpaceUsed' + '''' + ' ) AS int)/128.0)/(sysfiles.size/128.0))  
	AS decimal(4,2))) AS varchar(8)) + ' + '''' +  '''' + ' AS FreeSpacePct
	FROM dbo.sysfiles'  
INSERT INTO #DBInfo2  
	   (ServerName,  
	   DatabaseName,  
	   FileSizeMB,  
	   LogicalFileName,  
	   PhysicalFileName,  
	   Status,  
	   Updateability,  
	   RecoveryMode,  
	   FreeSpaceMB,  
	   FreeSpacePct)  
EXEC sp_MSforeachdb @command  

INSERT INTO #BackupDrive
SELECT @@servername as ServerName
      ,UPPER([physical_device_name]) AS physical_device_name
  FROM [msdb].[dbo].[backupmediafamily]
  WHERE LEFT(UPPER([physical_device_name]),3) IN ('Y:\','X:\','W:\')

--SELECT @filecheck = (SELECT DeviceID FROM #logicaldisk WHERE DeviceID = 'N') 
SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='E')
IF @filecheck = 'E'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR E:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR E:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR E:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='F')
IF @filecheck = 'F'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR F:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR F:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR F:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='G')
IF @filecheck = 'G'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR G:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR G:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR G:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='L')
IF @filecheck = 'L'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR L:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR L:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR L:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='M')
IF @filecheck = 'M'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR M:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR M:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR M:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='N')
IF @filecheck = 'N'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR N:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR N:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR N:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='O')
IF @filecheck = 'O'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR O:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR O:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR O:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='P')
IF @filecheck = 'P'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR P:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR P:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR P:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='R')
IF @filecheck = 'R'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR R:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR R:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR R:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='S')
IF @filecheck = 'S'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR S:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR S:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR S:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='T')
IF @filecheck = 'T'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR T:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR T:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR T:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='W')
IF @filecheck = 'W'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR W:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR W:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR W:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='X')
IF @filecheck = 'X'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR X:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR X:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR X:\*.ldf /b /s'
END

SELECT @filecheck = (SELECT DISTINCT LEFT(PhysicalFileName,1) FROM #DBInfo2 WHERE LEFT(PhysicalFileName,1) ='Y')
IF @filecheck = 'Y'
BEGIN
insert into #os_files exec xp_cmdshell 'DIR Y:\*.mdf /b /s'
insert into #os_files exec xp_cmdshell 'DIR Y:\*.ndf /b /s'
insert into #os_files exec xp_cmdshell 'DIR Y:\*.ldf /b /s'
END

Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear


--Clean up Input
delete from #os_files where filename is null
update #os_files set filename=rtrim(filename)

INSERT INTO #CapacityReviewCollection (
	   Date_Key,
	   ServerName,
	   FileType,
	   DatabaseName,
	   FileSizeMB,     
	   LogicalFileName,  
	   DiskDrive,
	   PhysicalFileName,
	   Status,
	   Updateability,  
	   RecoveryMode,  
	   FreeSpaceMB,  
	   FreeSpacePct,
	   PollDate,
       Applications,
       FunctionalGroups,
       Owners,
	   SortOrder)
	SELECT  
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   UPPER(RIGHT(RTRIM(db.PhysicalFileName),3)) AS File_Type,
	   db.DatabaseName AS DBName,
	   db.FileSizeMB AS DBFileSizeMB,     
	   db.LogicalFileName,  
	   Drive AS Drive,
	   db.PhysicalFileName AS DBPhysicalFileName,
	   db.Status AS DBStatus,
	   db.Updateability AS DBUpdateability,  
	   db.RecoveryMode AS DBRecoveryMode,  
	   db.FreeSpaceMB AS DBFreeSpaceMB,  
	   db.FreeSpacePct AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   1 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive))) =  LEFT(RTRIM(dr.Drive),LEN(RTRIM(dr.Drive))) 
	WHERE db.DatabaseName not in (
				SELECT DatabaseName
				FROM #DBInfo2 DB
					JOIN (SELECT Drive FROM #DrvInfo WHERE LEN(Drive) > 3) DR on LEFT(db.PhysicalFileName, LEN(Drive)) = RTRIM(dr.Drive))
	UNION ALL
	SELECT  
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   UPPER(RIGHT(RTRIM(db.PhysicalFileName),3)) AS File_Type,
	   db.DatabaseName,  
	   db.FileSizeMB AS DBFileSizeMB,     
	   db.LogicalFileName,  
	   Drive AS Drive,
	   db.PhysicalFileName,  
	   db.Status AS DBStatus,
	   db.Updateability AS DBUpdateability,  
	   db.RecoveryMode,  
	   db.FreeSpaceMB as DBFreeSpaceMB,  
	   db.FreeSpacePct as DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   1 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(dr.Drive)) =  LEFT(dr.Drive,LEN(dr.Drive))
	WHERE LEN(dr.Drive) > 3 
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize] AS DBFileSizeMB,     
	   'Allocated' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   2 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(dr.Drive)) =  LEFT(dr.Drive,LEN(dr.Drive))
	WHERE LEN(dr.Drive) > 3 
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize] AS DBFileSizeMB,     
	   'Allocated' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   2 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive))) =  LEFT(RTRIM(dr.Drive),LEN(RTRIM(dr.Drive))) 
	WHERE db.DatabaseName not in (
				SELECT DatabaseName
				FROM #DBInfo2 DB
					JOIN (SELECT Drive FROM #DrvInfo WHERE LEN(Drive) > 3) DR on LEFT(db.PhysicalFileName, LEN(Drive)) = RTRIM(dr.Drive))
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize] - dr.[MB free] AS DBFileSizeMB,     
	   'Used' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   3 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(dr.Drive)) =  LEFT(dr.Drive,LEN(dr.Drive))
	WHERE LEN(dr.Drive) > 3 
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize] - dr.[MB free] AS DBFileSizeMB,     
	   'Used' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   3 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive))) =  LEFT(RTRIM(dr.Drive),LEN(RTRIM(dr.Drive))) 
	WHERE db.DatabaseName not in (
				SELECT DatabaseName
				FROM #DBInfo2 DB
					JOIN (SELECT Drive FROM #DrvInfo WHERE LEN(Drive) > 3) DR on LEFT(db.PhysicalFileName, LEN(Drive)) = RTRIM(dr.Drive))
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB free] AS DBFileSizeMB,     
	   'Free Space' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   4 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(dr.Drive)) =  LEFT(dr.Drive,LEN(dr.Drive))
	WHERE LEN(dr.Drive) > 3 
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB free] AS DBFileSizeMB,     
	   'Free Space' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   4 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive))) =  LEFT(RTRIM(dr.Drive),LEN(RTRIM(dr.Drive))) 
	WHERE db.DatabaseName not in (
				SELECT DatabaseName
				FROM #DBInfo2 DB
					JOIN (SELECT Drive FROM #DrvInfo WHERE LEN(Drive) > 3) DR on LEFT(db.PhysicalFileName, LEN(Drive)) = RTRIM(dr.Drive))
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize]*.2 AS DBFileSizeMB,     
	   '20%FreeSpaceThreshold ProActive Measures' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   5 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(dr.Drive)) =  LEFT(dr.Drive,LEN(dr.Drive))
	WHERE LEN(dr.Drive) > 3 
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize]*.2 AS DBFileSizeMB,     
	   '20%FreeSpaceThreshold ProActive Measures' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   5 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive))) =  LEFT(RTRIM(dr.Drive),LEN(RTRIM(dr.Drive))) 
	WHERE db.DatabaseName not in (
				SELECT DatabaseName
				FROM #DBInfo2 DB
					JOIN (SELECT Drive FROM #DrvInfo WHERE LEN(Drive) > 3) DR on LEFT(db.PhysicalFileName, LEN(Drive)) = RTRIM(dr.Drive))
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize]*.1 AS DBFileSizeMB,     
	   '10%FreeSpaceThreshold Sev-3' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   6 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(dr.Drive)) =  LEFT(dr.Drive,LEN(dr.Drive))
	WHERE LEN(dr.Drive) > 3 
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize]*.1 AS DBFileSizeMB,     
	   '10%FreeSpaceThreshold Sev-3' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   6 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive))) =  LEFT(RTRIM(dr.Drive),LEN(RTRIM(dr.Drive))) 
	WHERE db.DatabaseName not in (
				SELECT DatabaseName
				FROM #DBInfo2 DB
					JOIN (SELECT Drive FROM #DrvInfo WHERE LEN(Drive) > 3) DR on LEFT(db.PhysicalFileName, LEN(Drive)) = RTRIM(dr.Drive))
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize]*.05 AS DBFileSizeMB,     
	   '5%FreeSpaceThreshold Sev-1' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   7 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(dr.Drive)) =  LEFT(dr.Drive,LEN(dr.Drive))
	WHERE LEN(dr.Drive) > 3 
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize]*.05 AS DBFileSizeMB,     
	   '5%FreeSpaceThreshold Sev-1' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   7 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive))) =  LEFT(RTRIM(dr.Drive),LEN(RTRIM(dr.Drive))) 
	WHERE db.DatabaseName not in (
				SELECT DatabaseName
				FROM #DBInfo2 DB
					JOIN (SELECT Drive FROM #DrvInfo WHERE LEN(Drive) > 3) DR on LEFT(db.PhysicalFileName, LEN(Drive)) = RTRIM(dr.Drive))
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   	dr.[MB free] AS DBFileSizeMB,     
	   	CASE WHEN dr.[MB free] < dr.[MB TotalSize]*.05 THEN 'Free Disk Space less than  5 percent'
	     WHEN dr.[MB free] < dr.[MB TotalSize]*.10 THEN 'Free Disk Space less than 10 percent'
	     WHEN dr.[MB free] < dr.[MB TotalSize]*.15 THEN 'Free Disk Space less than 15 percent'
	     WHEN dr.[MB free] < dr.[MB TotalSize]*.20 THEN 'Free Disk Space less than 20 percent'
	     ELSE 'Free Disk Space above 20 percent threshold' END AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   8 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(dr.Drive)) =  LEFT(dr.Drive,LEN(dr.Drive))
	WHERE LEN(dr.Drive) > 3 
	UNION ALL
	SELECT DISTINCT
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   	dr.[MB free] AS DBFileSizeMB,     
	   	CASE WHEN dr.[MB free] < dr.[MB TotalSize]*.05 THEN 'Free Disk Space less than  5 percent'
	     WHEN dr.[MB free] < dr.[MB TotalSize]*.10 THEN 'Free Disk Space less than 10 percent'
	     WHEN dr.[MB free] < dr.[MB TotalSize]*.15 THEN 'Free Disk Space less than 15 percent'
	     WHEN dr.[MB free] < dr.[MB TotalSize]*.20 THEN 'Free Disk Space less than 20 percent'
	     ELSE 'Free Disk Space above 20 percent threshold' END AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   8 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive))) =  LEFT(RTRIM(dr.Drive),LEN(RTRIM(dr.Drive))) 
	WHERE db.DatabaseName not in (
				SELECT DatabaseName
				FROM #DBInfo2 DB
					JOIN (SELECT Drive FROM #DrvInfo WHERE LEN(Drive) > 3) DR on LEFT(db.PhysicalFileName, LEN(Drive)) = RTRIM(dr.Drive))
	UNION ALL
	SELECT  
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize] - dr.[MB free] - SUM(db.FileSizeMB) AS DBFileSizeMB,     
	   'Difference Between Database Usage and OS Used' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   9 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(dr.Drive)) =  LEFT(dr.Drive,LEN(dr.Drive))
	WHERE LEN(dr.Drive) > 3
	GROUP BY db.ServerName, Drive, dr.[MB TotalSize], dr.[MB free] 
	UNION ALL
	SELECT  
	   @Date_Key AS Date_Key,
	   db.ServerName,
	   ' ' AS File_Type,
	   ' ' AS DatabaseName,  
	   dr.[MB TotalSize] - dr.[MB free] - SUM(db.FileSizeMB) AS DBFileSizeMB,     
	   'Difference Between Database Usage and OS Used' AS LogicalFileName,  
	   Drive AS Drive,
	   'Totals' AS PhysicalFileName,  
	   ' ' AS DBStatus,
	   ' ' AS DBUpdateability,  
	   ' ' AS RecoveryMode,  
	   ' ' AS DBFreeSpaceMB,  
	   ' ' AS DBFreeSpacePct,
	   @Date_Key AS [PollDate],
       ' ' AS [Applications],
       ' ' AS [FunctionalGroups],
       ' ' AS [Owners],
	   9 AS SortOrder
	FROM #DBInfo2 db
		JOIN #DrvInfo dr ON LEFT(db.PhysicalFileName,LEN(RTRIM(dr.Drive))) =  LEFT(RTRIM(dr.Drive),LEN(RTRIM(dr.Drive))) 
	WHERE db.DatabaseName not in (
				SELECT DatabaseName
				FROM #DBInfo2 DB
					JOIN (SELECT Drive FROM #DrvInfo WHERE LEN(Drive) > 3) DR on LEFT(db.PhysicalFileName, LEN(Drive)) = RTRIM(dr.Drive))
	GROUP BY db.ServerName, Drive, dr.[MB TotalSize], dr.[MB free]

SELECT 
	   Date_Key,
	   ServerName,
	   FileType,
	   DatabaseName,
	   FileSizeMB,     
	   LogicalFileName,  
	   DiskDrive,
	   PhysicalFileName,
	   Status,
	   Updateability,  
	   RecoveryMode,  
	   FreeSpaceMB,  
	   FreeSpacePct,
	   PollDate,
       Applications,
       FunctionalGroups,
       Owners,
	   SortOrder
FROM #CapacityReviewCollection
ORDER BY DiskDrive, SortOrder, DatabaseName

