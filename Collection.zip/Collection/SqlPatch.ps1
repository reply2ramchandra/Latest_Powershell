﻿##https://sqlserverbuilds.blogspot.com/
$targetpatchfolder="D:\patch"
$servers=Get-Content "T:\Test\SqlPatch_2019.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
}

#copy patch file
$patchfile= Get-ChildItem X:\SQLISO\CU -Filter '*5031908*' 
$source=$patchfile.FullName 
$target=$targetpatchfolder -replace ':', '$'
$servers=Get-Content "T:\Test\SqlPatch_2019.txt"
foreach($server in $servers)
{
Copy-item -Path $source -Destination \\$server\$target -ErrorAction Stop -Verbose -Force 
}
<#
In case of n/w share error during file copy , use below step as remediation
#create windows shared folder
$servers=Get-Content "T:\Test\SqlPatch_2019.txt"
foreach($server in $servers)
{
Invoke-Command -ComputerName $server -ScriptBlock {
New-SmbShare -Name "Patch" -Path "D:\patch\" -FullAccess "HPS\a-sm58408" } }

$servers=Get-Content "T:\Test\SqlPatch_2019.txt"
foreach($server in $servers)
{
Copy-item -Path $source -Destination \\$server\Patch -ErrorAction Stop -Verbose -Force 
}
#>

#verify if file exist
$servers=Get-Content "T:\Test\SqlPatch_2019.txt"
foreach($server in $servers)
{
$server
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\patch"
# check if folder exist
$patchfile= Get-ChildItem $targetpatchfolder -Filter '*5031908*'
if($patchfile)
{
Write-Host " Patch file Copied successfully! " -ForegroundColor Green
}
Else { Write-Host " Patch file missing " -ForegroundColor Yellow}
}
}
Import-Module dbatools -DisableNameChecking 
#create temp folder
$folder='CHG0072960'
$targetbackuppath='\\tpadd9300\SQLBackups'
New-Item -ItemType Directory -Path $targetbackuppath\$folder
# Take DB backup
$servers=Get-Content "T:\Test\SqlPatch_2019_instance.txt"
foreach($instance in $servers){
Backup-DbaDatabase -SqlInstance $instance -Path $targetbackuppath\$folder -ExcludeDatabase master,model,msdb  -Type Diff -CompressBackup -CreateFolder}

$servers=Get-Content "T:\Test\SqlPatch_2019.txt"
Update-DbaBuildReference 
foreach($server in $servers)
{
Update-DbaInstance -ComputerName $server -KB 5031908 -Restart -Path $targetpatchfolder -Confirm:$false
Start-Sleep -Seconds 3
}
# -ArgumentList "/SkipRules=RebootRequiredCheck"
# -Version CU24