CREATE PROCEDURE [Admin].[usp_analyze_dbcount] @Server	  VARCHAR(128) = NULL
											  ,@Period	  TINYINT	   = 6
											  ,@StartDate DATE		   = NULL
											  ,@EndDate	  DATE		   = NULL
AS

	/***************************************************************************************************************************************
		
		Purpose: To track the database count per server for a given period of time
		

		History:
		------------------------------------------------------------------------------------------------------------------------------------
		Author                                 Date Created                Comments
		------------------------------------------------------------------------------------------------------------------------------------
		Harsha vasa                              2017-10-12                  Initial draft



	    ------------------------------------------------------------------------------------------------------------------------------------

		Documentation:
		--------------
		Default Period - 6 months 


		Execution Samples:
		------------------
		-- All Servers
		1. EXEC Admin.usp_analyze_dbcount 

		-- Selected server
		2. EXEC Admin.usp_analyze_dbcount @server = 'FWPAXD-SQLVM001'

		-- for last 5 months period 
		3. EXEC Admin.usp_analyze_dbcount @server = 'FWPAXD-SQLVM001' , @Period = 5

    ***************************************************************************************************************************************/
	BEGIN
		SET NOCOUNT ON;
		SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;


		-- // declare variables
		DECLARE @rc BIT;
		DECLARE @iStartDate DATETIME
			   ,@iEndDate DATETIME
			   ,@dMonthString VARCHAR(1000)
			   ,@dMonCoSelectString VARCHAR(8000)
				-- ,@dMonCoAscString	varchar(4000)
				--,@dMonCoDescString   varchar(4000)
			   ,@dServerList VARCHAR(1000)
			   ,@eSql NVARCHAR(MAX);


		-- // temp tables

		IF OBJECT_ID( 'tempdb..#gDate' ) IS NOT NULL
			DROP TABLE #gDate;

		-- Generate Date Keys 

		CREATE TABLE #gDate (DateKeys DATETIME PRIMARY KEY CLUSTERED);

		-- // Server Validation

		IF LTRIM( RTRIM( @Server ) ) IS NOT NULL
		AND NOT EXISTS (
			  SELECT
				  *
			  FROM Inventory.ServerList
			  WHERE SqlInstance = @Server
			  AND (IsActive = 1 AND ConnectionMethod IS NOT NULL)
		)
			 BEGIN
				 RAISERROR ('The server specified %s either doesn''t exist or inactive.',16,1,@Server) WITH NOWAIT;
				 RETURN (1);
			 END;

		BEGIN TRY
			SET @iEndDate = COALESCE( @EndDate,CONVERT( DATE,GETDATE() ) );

			SET @iEndDate = [Admin].fn_endofmonth( @iEndDate );    -- End of Month
			SET @iStartDate = COALESCE( @StartDate,DATEADD( MONTH,DATEDIFF( MONTH,0,@iEndDate ) - (@Period - 1),0 ) )


			-- Populate dates
			;
			WITH C0
			AS (
				  SELECT
					  *
				  FROM (VALUES(0)
							 ,(0)
							 ,(0)
							 ,(0)) X (v)
			),  -- 4 
			C1
			AS (SELECT a.v FROM C0 AS a CROSS JOIN C0 AS b)  -- 16
			,
			CNums
			AS (SELECT ROW_NUMBER() OVER (ORDER BY v) AS n FROM C1)

			INSERT INTO #gDate
			SELECT
				@iStartDate AS dates
			UNION ALL
			SELECT
				DATEADD( MONTH,n,@iStartDate ) AS pcDate
			FROM CNums
			WHERE n <= DATEDIFF( MONTH,@iStartDate,@iEndDate );

			-- //Dynamic Strings of Months
			SELECT
				@dMonthString = STUFF( ((
					  SELECT
						  ',' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' )
			   ,@dMonCoSelectString = +STUFF( ((
					  SELECT
						  ',' + 'COALESCE(' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) ) + ',0) AS ' + QUOTENAME( LEFT( CONVERT( VARCHAR(8),i.DateKeys,112 ),6 ) )
					  FROM #gDate AS i
					  ORDER BY i.DateKeys
					  FOR XML PATH (''),TYPE
				)
				.value( '.','varchar(max)' )),1,1,'' );

			IF @server IS NOT NULL
				 BEGIN
					 SET @dServerList = N'AND [di].[SqlInstance] = N''' + RTRIM( LTRIM( @server ) ) + '''';
				 END;

			SET @eSql = N';WITH dbcnt AS 
(SELECT [di].[DateKey]
			,[di].[SqlInstance]
			,count(DatabaseName) AS dbcount
 FROM [Inventory].[Databases] AS [di]
 WHERE di.[DateKey] BETWEEN @iStartDate AND @iEndDate
 ' + SPACE( 1 ) + COALESCE( @dServerList,'' ) + '
 GROUP BY [di].[SqlInstance],[di].[DateKey])
SELECT [SqlInstance] AS SqlInstance,' + @dMonCoSelectString + ' 
FROM (
      SELECT [SqlInstance],
	         CONVERT(varchar(6),[DateKey],112) AS YYYYMM, 
			 dbcount
	  FROM dbcnt
	  ) AS s
PIVOT (MAX(dbcount) FOR YYYYMM IN (' + @dMonthString + ')) p
OPTION (RECOMPILE);';

			--// print
			--PRINT @eSql;

			-- // execute the statement
			EXEC @rc = sys.sp_executesql @eSql
										,N'@iStartDate DateTime,@iEndDate DateTime'
										,@iStartDate
										,@iEndDate;

			SET @rc = 0;
		END TRY
		BEGIN CATCH

			SET @rc = 1

			EXEC [Admin].usp_error_handler

		END CATCH;

		-- //clear temp tables from cache

		DROP TABLE [#gDate];


		RETURN (@rc);

	END;
	GO
