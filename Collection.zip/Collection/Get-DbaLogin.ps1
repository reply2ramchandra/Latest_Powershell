﻿Import-Module dbatools -EA SilentlyContinue
Get-DbaLogin -SqlInstance TPAPWDWSQLA05 | Out-GridView -Passthru | Copy-DbaLogin -Destination TPAPWDWSQLB05 #-force

#Sync-DbaLoginPermission -Source TPASWSQLDL001 -Destination TPASWSQLDL002 -Login HPS\jt59034