CREATE TABLE [Inventory].[AgBackupNodePreferrence] (
    [SqlInstance]     VARCHAR (256)  NOT NULL,
    [DatabaseName]    VARCHAR (1024) NULL,
    [IsPreferredNode] BIT            NULL,
    CONSTRAINT FK_AgBackupNodePreferrence_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
);


GO

