$Header = @"
<style>
TABLE {border-width: 1px; border-style: solid; border-color: green; border-collapse: collapse;}
TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
</style>
"@



     $backupinfo= Get-DbaLastBackup -SqlInstance tpapwsqlhha01 | Where-Object -FilterScript { $_.LastFullBackup.Date -lt (Get-Date).AddDays(-3) } | select SqlInstance, Database, LastFullBackup
     $backupinfo | ConvertTo-Html -Head $Header | Out-File -FilePath \\tpapwmssql002\Reports\backupreport.html
       

             if($backupinfo.Count -gt 0)
             {
                  Write-host 'Sending mail as we have backups missed for more than 3 days' -ForegroundColor RED
     
                  $body = Get-Content \\tpapwmssql002\Reports\backupreport.html
                  Send-MailMessage -From 'DBCC_Report@Healthplan.com'  -To 'sathiyaneethi.mani@wipro.com' -Subject 'Backup Alerts' -SmtpServer smtp.gmail.com -Body "$body" `-BodyAsHtml

                  Invoke-Item \\tpapwmssql002\Reports\backupreport.html
                 
             }
             else
             {
              Write-host 'Not sending mail as we dont have any backups missed for more than 3 days' -ForegroundColor green
             }