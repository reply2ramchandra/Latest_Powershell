﻿$server='TPAPWSQLIVR01'
Invoke-Command -ComputerName $server -ScriptBlock {
$binarypath="D:\SQL\Software"
 $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO" 
 $isoImg=$isoImg.FullName
 if($isoImg -ne $null){ DisMount-DiskImage -ImagePath $isoImg
 write-Host "UnMounting ISO is Done!" -ForegroundColor Cyan }
 }
 Start-Sleep -Seconds 3
$cleanup = Read-Hostspecial "Want to cleanup the s/w copied . You must enter Y or N to continue:" -promptcolor Cyan
 If ($cleanup -eq "Y" -or $cleanup -eq "y") {
##cleanup software copied
$server=$srv
Invoke-Command -ComputerName $server -ScriptBlock {
$binarypath="D:\SQL\Software"
Get-ChildItem -Path $binarypath -Recurse| Remove-Item -force } }
else { Write-Host "OK. You may cleanup manually later." -ForegroundColor Green}