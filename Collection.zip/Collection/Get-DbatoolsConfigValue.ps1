﻿Import-Module dbatools -EA SilentlyContinue
Get-DbatoolsConfigValue -Name 'assets.sqlbuildreference'
Update-DbaBuildReference -LocalFile "C:\Program Files\WindowsPowerShell\Modules\dbatools\2.1.23\bin\dbatools-buildref-index.json"