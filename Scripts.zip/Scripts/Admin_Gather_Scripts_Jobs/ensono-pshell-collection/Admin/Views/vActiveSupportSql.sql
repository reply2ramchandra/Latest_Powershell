﻿CREATE VIEW [Admin].[vActiveSupportSql]
AS 
SELECT SqlInstance
	   ,Environment
       ,Domain
       ,HasAccess
	   ,SupportGroup
	   ,ConnectionMethod
       ,IPAddress
       ,TimeZoneOffset
FROM Inventory.ServerList 
WHERE IsActive = 1 AND SupportGroup IS NOT NULL
