﻿Get-NetTCPConnection -State Listen,Established
Get-NetTCPConnection -RemotePort 1433