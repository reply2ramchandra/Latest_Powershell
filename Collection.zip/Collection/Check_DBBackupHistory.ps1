﻿$instance='TPAUWSQL001\GNUAT001'
Import-Module dbatools -EA SilentlyContinue 
$count=(Get-DbaDatabase  -SqlInstance $instance  -ExcludeSystem).count
Write-Host "No of User DBs count:$count"  -foregroundcolor Green
$database=Get-DbaDatabase  -SqlInstance $instance -ExcludeSystem | select Name 
foreach( $db in $database.Name){Get-DbaDbBackupHistory -SqlInstance $instance -Database $db -Last -DeviceType Disk}
Import-Module dbatools -EA SilentlyContinue 
$DBBackupHistory=Get-DbaRegServer -SqlInstance TPAPWMSSQL002 -Group PROD | Where-Object  Group -notlike '*PROD\SQL2000*' | Get-DbaDbBackupHistory -DeviceType Disk
$DBBackupHistory

