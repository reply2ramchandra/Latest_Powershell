﻿clear
Get-date
#HPSSQL03 excluded as its HPSSQL03
#Clear-Content \\tpapwmssql002\Reports\backupreport.htm
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue 
Import-Module dbatools -EA SilentlyContinue
Set-DbatoolsInsecureConnection -SessionOnly
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "DROP TABLE IF EXISTS [CMS].[dbo].SQLMaintJobFailed;" -TrustServerCertificate 
$dbscript='X:\SQLPostBuild\SQL_Maint_Job_Failed.sql'
$instances=get-content "T:\Test\100924.txt" # check if all sql servers are active
foreach($instance in $instances)
{
$SQLMaintJobFailed=$instance | Invoke-DbaQuery -File $dbscript
if($SQLMaintJobFailed){Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'SQLMaintJobFailed' -InputObject $SQLMaintJobFailed  -AutoCreateTable -KeepNulls}
}
Get-date
Start-Sleep -Seconds 2
 $css = @"
<style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid black; padding: 8px; text-align: left; }
    th { background-color: #D6EEEE; }
    tr:nth-child(even) {
  background-color: rgba(150, 212, 212, 0.4);}
</style>
"@

$runDateTime = (Get-Date -Format yyyyddMM) 
 $preContent = @"
<h3><font face=verdana color=blue>PROD SQL Maintenance Job Failed in the recent time</font></h3>
<p>This report contains the list of Servers where SQL Maintenance job got Failed.</p>
"@
$postContent = @"
<p><font face=verdana color=green>Generated on $(Get-Date). Please review and take action as Required.</font></p>
"@
$sqljobinfo=Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query "SELECT DISTINCT [Srv],[job_name],max(date_time) as run_date FROM [CMS].[dbo].[SQLMaintJobFailed] Group BY srv,job_name order by [srv]; " -TrustServerCertificate |  Select * -ExcludeProperty ItemArray, Table, RowError, RowState, HasErrors
$sqljobinfo | ConvertTo-Html -Property Srv, Job_name, Run_date -Head $css -Title "MSSQL Server Maintenance Job failure Report" -PreContent $preContent  -PostContent  $postContent  | Out-File -FilePath \\tpapwmssql002\Reports\sqljobfailed$runDateTime.htm 
       

             if($sqljobinfo.Count -gt 0)
             {
                  Write-host 'Sending mail as we have SQL Job failed in Prod' -ForegroundColor Green
     
                  $body = Get-Content \\tpapwmssql002\Reports\sqljobfailed$runDateTime.htm
                  Send-MailMessage -From 'DBA_Report@Healthplan.com'  -To 'WHPS-MSSQL-Admins@wipro.com' -Subject 'MSSQL Maintenance Job Failure Report' -SmtpServer smtprelay.healthplan.com -BodyAsHtml:$true -Body "$body" 

                  #Invoke-Item \\tpapwmssql002\Reports\backupreport.html
                 
             }
             else
             {
              Write-host 'Not sending mail as we dont have SQL Job failed in Prod' -ForegroundColor Yellow
             }
get-date
