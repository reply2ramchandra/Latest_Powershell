﻿Import-Module dbatools 
#Get-DbaAgReplica -SqlInstance tpapwsqleta01 | Out-GridView -Passthru | Set-DbaAgReplica -BackupPriority 5000
Get-DbaAgReplica -SqlInstance TPAPWSQLETA01 | Out-GridView -Passthru | Set-DbaAgReplica -FailoverMode Manual


