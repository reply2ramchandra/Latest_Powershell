
/***************************************************************************************************************************************
    Copyright © 2019 Ensono LP, USA. All rights reserved

	Purpose: Get Backup Report for last 2 days to run against all servers
	

	History:
	---------------------------------------
	Author                       Comments
	---------------------------------------
	Harsha vasa               Initial draft


	Documentation:
	--------------
	/*
	< .. INSERT .. >
UNION ALL
SELECT
	@@servername
   ,[d].[name]
   ,'D'
   ,'1/1/1900'
   ,'N/A'
   ,0
   ,'N/A'
FROM sys.databases AS [d]
WHERE [d].database_id != 2
AND DATABASEPROPERTYEX( [d].[name],'Status' ) = 'ONLINE'
AND DATABASEPROPERTYEX( [d].[name],'IsInStandBY' ) = 0
AND NOT EXISTS
(
	  SELECT
		  *
	  FROM lastbackupdate
	  WHERE [database_name] = [d].[name]
);
*/


	Execution Samples:
	------------------


***************************************************************************************************************************************/


USE [master];

IF OBJECT_ID( 'tempdb..#StageLastBackup' ) IS NOT NULL
	DROP TABLE #StageLastBackup;

CREATE TABLE #StageLastBackup ([server_name]		NVARCHAR(128) NOT NULL
							  ,[database_name]		NVARCHAR(128) NOT NULL
							  ,[backup_type]		CHAR(1)		  NOT NULL
							  ,[backup_finish_date] DATETIME
							  ,[user_name]			NVARCHAR(128)
							  ,[time_taken_seconds] INT)


DECLARE @RunDate DATETIME = GETDATE();

;
WITH lastbackuphistory
AS (
	  SELECT
		  bs.[database_name]
		 ,bs.[type]
		 ,bs.[user_name]
		 ,bs.server_name
		 ,bs.backup_finish_date
		 ,bs.backup_start_date
		 ,DENSE_RANK() OVER (PARTITION BY bs.[database_name],bs.[type] ORDER BY bs.backup_finish_date DESC) AS r
	  FROM msdb.dbo.backupset AS bs
	  WHERE bs.backup_finish_date >= DATEADD( dd,-2,GETDATE() ) -- Databases Not Listed in 2 days == Code Red!!
	  AND (DB_ID( bs.[database_name] ) IS NOT NULL AND DATABASEPROPERTYEX( bs.[database_name],'Status' ) = 'ONLINE' AND DATABASEPROPERTYEX( bs.[database_name],'IsInStandBY' ) = 0)
)

INSERT INTO #StageLastBackup
SELECT
	server_name
   ,bs.[database_name]
   ,[type]
   ,backup_finish_date
   ,[user_name]
   ,DATEDIFF( ss,backup_start_date,backup_finish_date )
FROM lastbackuphistory AS bs
WHERE bs.r = 1
;


/* Insert Valid databases into Target List didn't have an entry in backupset table past 48 hrs */
MERGE
INTO #StageLastBackup AS tgt
USING (
	  SELECT
		  [d].[name]
		 ,t1.backuptype
	  FROM sys.databases AS [d]
	  CROSS APPLY (SELECT 'D' AS backuptype UNION ALL SELECT 'L') AS t1
	  WHERE [d].database_id != 2
	  AND DATABASEPROPERTYEX( [d].[name],'Status' ) = 'ONLINE'
	  AND DATABASEPROPERTYEX( [d].[name],'IsInStandBY' ) = 0
	  AND NOT (t1.backuptype = 'L' AND ([d].recovery_model = 3 OR [d].is_read_only = 1)) --// SIMPLE Recovery Model , Log Backup , ReadOnly Exclusion
) AS src
ON src.[name] = tgt.[database_name] AND src.[backuptype] = tgt.[backup_type]
WHEN NOT MATCHED BY TARGET
	--// Code Red Databases
	THEN INSERT
		VALUES (@@servername
			   ,[src].[name]
			   ,[src].backuptype
			   ,NULL
			   ,NULL
			   ,NULL)
WHEN NOT MATCHED BY SOURCE
	THEN DELETE
;


-- AlwaysOn Availability Group Databases On Non-Preferred Replica
IF SERVERPROPERTY( 'IsHadrEnabled' ) = 1
	 BEGIN

		 MERGE #StageLastBackup AS tgt
		 USING (
			   SELECT
				   [name]														  AS [database_name]
				  ,COALESCE( sys.fn_hadr_backup_is_preferred_replica( name ),-1 ) AS ispreferred
			   FROM sys.databases
			   WHERE database_id > 4
		 ) AS
		 src
		 ON src.[database_name] = tgt.[database_name]
		 WHEN MATCHED
			 AND src.ispreferred = 0
			 THEN DELETE
		 ;
	 END;


-- Final Results to Load into Base Table
SELECT
	@RunDate AS date_key
   ,slb.server_name
   ,slb.[database_name]
   ,slb.backup_type
   ,slb.backup_finish_date
   ,slb.[user_name]
   ,slb.time_taken_seconds
FROM #StageLastBackup AS slb
;


-- Cleanup! Yaay better
DROP TABLE #StageLastBackup;