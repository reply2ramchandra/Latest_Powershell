clear
Import-Module dbatools -EA SilentlyContinue 
Clear-Content "D:\PSScripts\Logs\SQLMemoryMonitor.log"
# Config
Set-DbatoolsInsecureConnection -SessionOnly
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$SqlInstances = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where [Status] in ('Y','R') and HostName Not in('localhost','TPAPWSQLSSRS-03') and Category='PROD' and MajorVersion='SQL Server 2019'"  -TrustServerCertificate 

#$SqlInstances = @("SQL1\INST1", "SQL2", "SQL3\INST2")
$AlertList = @()
$Threshold = 90
$MailFrom = "DBA_Report@Healthplan.com"
$MailTo = "WHPS-MSSQL-Admins@wipro.com"
$SmtpServer = "smtprelay.healthplan.com"
$LogFile = "D:\PSScripts\Logs\SQLMemoryMonitor.log"

$TimeStamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

foreach ($SqlInstance in $SqlInstances.SqlInstance) {
    try {
        $TargetSQLMem = (Get-DbaMemoryUsage -ComputerName $SqlInstance -ErrorAction Stop | Where-Object { $_.Counter -eq "Target Server Memory (KB)" }).Memory
        $TotalSQLMem = (Get-DbaMemoryUsage -ComputerName $SqlInstance -ErrorAction Stop | Where-Object { $_.Counter -eq "Total Server Memory (KB)" }).Memory
        
          # Split by backslash
         <#$parts = $SqlInstance -split '\\'
         $hostname = $parts[0]
         
        # Get total physical memory (in bytes)
        $physicalMemory = (Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $hostname).TotalPhysicalMemory
        
       # Convert values
        $physicalMemGB = [math]::Round($physicalMemory / 1GB, 2)
        $serverMemGB = [math]::Round($TotalSQLMem / 1GB, 2)
		 $percentUsed = [math]::Round(($serverMemGB / $physicalMemGB) * 100, 2)
         #>
        $total = [math]::Round($TotalSQLMem / 1GB,2)
        $target =[math]::Round($TargetSQLMem / 1GB,2) 
        $percentUsed = [math]::Round(($total / $target) * 100, 2)

       

        # Always log to file
        "$TimeStamp - $SqlInstance - SQLServer Memory Usage: $percentUsed% ($total GB / $target GB)" | Out-File -Append -FilePath $LogFile

        if ($percentUsed -ge $Threshold) {
            $AlertList += [PSCustomObject]@{
                Server = $SqlInstance
                PercentUsed = $percentUsed
                TotalSQLUsedMemoryGB = $total
                TotalAllocatedMemoryGB = $target
            }
        }
    }
    catch {
        "$TimeStamp - $SqlInstance - ERROR: $_" | Out-File -Append -FilePath $LogFile
        Write-Warning "Could not check {$SqlInstance}: $_"
    }
}

# If any alerts, send HTML email
if ($AlertList.Count -gt 0) {
    # Build HTML table
    $htmlTable = "<table border='1' cellpadding='5' cellspacing='0' style='border-collapse:collapse;'>"
    $htmlTable += "<tr style='background-color:#f2f2f2;'><th>Server</th><th>Usage %</th><th>Total SQLUsed Memory (GB)</th><th>Total Allocated Memory (GB)</th></tr>"

    foreach ($item in $AlertList) {
        $color = if ($item.PercentUsed -ge 95) { "#ff4d4d" } elseif ($item.PercentUsed -ge 90) { "#ff9933" } else { "#99cc00" }
        $htmlTable += "<tr>"
        $htmlTable += "<td>$($item.Server)</td>"
        $htmlTable += "<td style='background-color:$color;'>$($item.PercentUsed)%</td>"
        $htmlTable += "<td>$($item.TotalSQLUsedMemoryGB)</td>"
        $htmlTable += "<td>$($item.TotalAllocatedMemoryGB)</td>"
        $htmlTable += "</tr>"
    }
    $htmlTable += "</table>"

    $subject = "ALERT: High SQL Server Memory Usage Detected"
    $body = "<html><body><h3>High SQL Server memory usage detected</h3>$htmlTable</body></html>"

    Send-MailMessage -From $MailFrom -To $MailTo -Subject $subject -Body $body -BodyAsHtml -SmtpServer $SmtpServer
    Write-Host "Alert email sent."
}
else {
    Write-Host "No servers exceeded the memory threshold."
}