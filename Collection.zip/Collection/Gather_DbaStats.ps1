﻿clear
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Update-Module dbatools -EA SilentlyContinue
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where Status IN ('Y')" #-TrustServerCertificate
$servers | Select-Object SqlInstance,
  @{n='Length';e={$_.SqlInstance.Length}} |
  Sort-Object Length -Descending
foreach($Instance in $servers.SqlInstance)
{
$DbaStats=Get-DbaDatabase -SqlInstance $Instance -ExcludeSystem | Select @{n='DateKey';e={(Get-Date).GetDateTimeFormats()[46]}},SqlInstance,Name,SizeMB,Compatibility,ServerVersion,Collation,Encrypted,Owner,LastFullBackup,LastGoodCheckDbTime,DatabaseEngineEdition,LastRead,LastWrite,IsUpdateable,AutoClose,AutoShrink,AutoUpdateStatisticsEnabled,AvailabilityDatabaseSynchronizationState,AvailabilityGroupName,State
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'DbaStats' -InputObject $DbaStats  -AutoCreateTable -KeepNulls -Truncate
}
