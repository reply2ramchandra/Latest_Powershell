
--Get Disk space
DECLARE @WMI32Class TABLE (command VARCHAR(MAX));
		DECLARE @Sql VARCHAR(512);
        DECLARE @xpcmdCheck VARCHAR(128);

-- check xp_cmdshell value 
        SET @xpcmdCheck = (SELECT CONVERT( VARCHAR(128),c.[value] ) FROM sys.configurations AS c WHERE c.[name] = 'xp_cmdshell' COLLATE DATABASE_DEFAULT);
        IF @xpcmdCheck = '0' EXEC dbo.usp_configure_options 'xp_cmdshell','1'; -- Turn it on temporarily

        SET @Sql = 'powershell.exe -c "Get-WmiObject -Class Win32_Volume -Filter ''DriveType = 3''| select name,Capacity,freespace | foreach{$_.name+''&''+$_.Capacity/1GB+''#''+$_.freespace/1GB+''@''}"';
INSERT INTO @WMI32Class
		EXEC [master].sys.xp_cmdshell @Sql;

		IF @@error > 0
		OR @@rowcount = 0
			 BEGIN
				 RAISERROR ('Error while executing xp_cmdshell cmd.Check if it is enabled or log entries for additional details',16,1) WITH NOWAIT;
				-- RETURN (1);
			 END;
SELECT
			convert(varchar, getdate(), 120) AS Collectiontime,@@Servername AS Servername
			,base.drive															AS Drive
		   ,CASE
				WHEN COUNT( drive ) OVER (PARTITION BY LEFT( drive,3 )) = 1 THEN 'Physical'
				ELSE 'MountPoint'
			END																	AS VolumeType
		   ,CEILING (base.TotalGB) AS TotalGB
		   ,CEILING (base.FreeGB) AS FreeGB
		   ,ROUND( CAST( base.FreeGB / base.TotalGB * 100 AS DECIMAL(5,2) ),1 ) AS FreePct
		FROM (
			  SELECT
				  RTRIM( LTRIM( SUBSTRING( command,1,CHARINDEX( '&',command,1 ) - 1 ) ) )																	  AS drive
				 ,CAST( RTRIM( LTRIM( SUBSTRING( command,t1.capacity + 1,CHARINDEX( '#',t1.tail,1 ) - 1 ) ) ) AS FLOAT )							  		  AS TotalGB
				 ,CAST( RTRIM( LTRIM( CONVERT( DECIMAL(10,2),SUBSTRING( command,t2.freespace + 1,CHARINDEX( '@',t2.tail,1 ) - 1 ) ) ) ) AS FLOAT )   		  AS FreeGB
			  FROM @WMI32Class
			  CROSS APPLY (
					SELECT
						CHARINDEX( '&',command,0 )						 AS capacity
					   ,STUFF( command,1,CHARINDEX( '&',command,1 ),'' ) AS tail
			  ) t1
			  CROSS APPLY (
					SELECT
						CHARINDEX( '#',command,0 )						 AS freespace
					   ,STUFF( command,1,CHARINDEX( '#',command,1 ),'' ) AS tail
			  ) t2

			  WHERE command LIKE '[D-Z][:]%'  -- Change to C-Z to list all Drives
		) base
		ORDER BY drive;
        
        -- turn xpcmdshell back to original state
        IF @xpcmdCheck = '0' EXEC dbo.usp_configure_options 'xp_cmdshell','0';

	

