﻿$server='TPAPWSQLDL006'
$VSTA= Get-ChildItem "X:\VSTA" -Filter '*2019*.exe' 
$VSTA=$VSTA.FullName  
$target="C:\Patch"
$user =  [Environment]::username
$cred=Get-Credential $user
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $VSTA -Destination $target -ToSession $s -PassThru -Force
Write-Host "VSTA copy completed. " -ForegroundColor Cyan -NoNewline
write-host $server