﻿Import-Module dbatools -EA SilentlyContinue
Resolve-DbaNetworkName -ComputerName TPATWLISTNER01
Resolve-DnsName TPATWLISTNER01 -ErrorAction SilentlyContinue | Select Name, IPAddress, TTL
#ReName-Computer -ComputerName 'TEST-WMSSDGN2-01' -NewName 'TEST-WMSSDGN2-01' -Restart