﻿Test-NetConnection TPAPWSQLGNXTB01
##Restart-Computer TPAPWSQLGNXTB01 -force
Test-NetConnection TPAPWSQLGNXTA01
##Restart-Computer TPAPWSQLGNXTA01 -force

#check Cluster Resource on Node A
Invoke-Command -ComputerName TPAPWSQLGNXTA01 -ScriptBlock {
Get-ClusterResource | FT -AutoSize}

#check Cluster Resource on Node B
Invoke-Command -ComputerName TPAPWSQLGNXTB01 -ScriptBlock {
Get-ClusterResource | FT -AutoSize}

#Get-Service *clusSvc* -ComputerName TPAPWSQLGNXTB01

#Get-Service *jen* -ComputerName TPAPWPEDSQL001 | Start-Service
#Get-Service *TimeBrokerSvc* -ComputerName TPAPWBAS010 | Start-Service
#Check website status
Invoke-Command -ComputerName TPAPWFREDWEB01 -ScriptBlock {
Get-website | FT -AutoSize}
#Tivoli Service
Get-Service *primary* -ComputerName PROD-BECUBICDB1
Get-Service *primary* -ComputerName TPAPWSQLSTEL002 | Start-Service
Get-Service *primary* -ComputerName tpapwsqlgnxtb01
Get-Service *primary* -ComputerName tpapwsqlgnxtb01 | Start-Service 