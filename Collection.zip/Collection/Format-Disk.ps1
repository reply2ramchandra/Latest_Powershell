﻿####BE CAUTIOUS WITH ACTIVITY . DONT EVER TOUCH ALREADY ACTIVE SERVER####
###Use CORRECT SERVER NAME #####
$server='TPAWSQLDL006'
#format the start with "T:" drive for 64kb allocation unit size
$yes=Read-Host "IS IT NEW SERVER , Double Check before Confirm (Y/N)"
$yes=$yes.ToUpper()
if($yes -eq 'Y'){
 invoke-command -computername $server {
Format-Volume -DriveLetter T -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel Tempdb 
Format-Volume -DriveLetter L -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel SQLLog
Format-Volume -DriveLetter M -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel SQLData
#Format-Volume -DriveLetter D -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel SQLRoot 

#64 kb
Get-Volume | Format-List DriveLetter, AllocationUnitSize}
}
Else { break }