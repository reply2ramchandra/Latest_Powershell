﻿CREATE VIEW [Billing].[vNonProdHostInstanceCIs]
AS
	SELECT
		[Billing].format_ci(ServerList.SqlInstance) AS [CI Name]
	FROM Inventory.ServerList
	WHERE (IsActive = 1
	AND SupportGroup IS NOT NULL)
	AND Environment NOT IN ('P', 'R')
	UNION
	SELECT
		Host
	FROM Inventory.ClusterNodeNames
	INNER JOIN Inventory.ServerList
		ON ClusterNodeNames.SqlInstance = ServerList.SqlInstance
	WHERE ServerList.Environment NOT IN ('P', 'R')