﻿#SSIS_Deploy_All_Built_ispac_Files
# Set deployment variables
$targetServer = "YourSqlServerInstance"
$catalogFolder = "YourSSISCatalogFolder" # e.g., "SSISProjects"
$projectPassword = "" # If your project is password protected

# Find all .ispac files
$ispacFiles = Get-ChildItem -Path $ssisPath -Recurse -Filter *.ispac

foreach ($ispac in $ispacFiles) {
    Write-Host "Deploying: $($ispac.FullName)"
    $deployArgs = "/Silent /SourceFile:`"$($ispac.FullName)`" /DestinationServer:$targetServer /DestinationPath:/SSISDB/$catalogFolder"
    if ($projectPassword) {
        $deployArgs += " /ProjectPassword:$projectPassword"
    }
    & "C:\Program Files (x86)\Microsoft SQL Server\160\DTS\Binn\ISDeploymentWizard.exe" $deployArgs
}