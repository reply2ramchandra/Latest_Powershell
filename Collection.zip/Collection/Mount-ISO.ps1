﻿$server='TPAXWSQLET001'
 Invoke-Command -ComputerName $server -ScriptBlock {
 $binarypath="D:\SQL\Software"
 #$binarypath="D:\Patch"
 $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO"
 $isoImg=$isoImg.FullName
 $diskImg = Mount-DiskImage -ImagePath $isoImg 
 # Get mounted ISO volume
 $mountvol = ($diskImg | Get-Volume).DriveLetter
 $mountvol=$mountvol+":\"
 write-Host $mountvol }