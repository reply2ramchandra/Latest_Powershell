﻿ Import-Module dbatools -EA SilentlyContinue
 #Add database via Automatic Seeding, For huge database it would take more time to syncup
 #check if Backup-DbaDatabase nedd to be completed before youa dd db to AG
 $SqlInstance='TPADWSQLMHCA01' 
 $ag=Get-DbaAvailabilityGroup -SqlInstance $SqlInstance
 Get-DbaDatabase -SqlInstance $SqlInstance | Out-GridView -Passthru | Add-DbaAgDatabase -AvailabilityGroup $ag.AvailabilityGroup -SeedingMode Automatic
