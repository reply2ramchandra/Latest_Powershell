﻿Clear-Host
Import-Module dbatools -ErrorAction SilentlyContinue
$Active='TPATWSQLMHCA01'
$Passive='TPATWSQLMHCB01'
# Fetch AG name
$agReplicas = Get-DbaAvailabilityGroup -SqlInstance  $active
$agName = $agReplicas.Name | Select-Object -First 1
#check healthcheck of AG
   $agHealth = Get-DbaAgDatabase -SqlInstance $active
    $unhealthy = $agHealth | Where-Object { $_.SynchronizationState -ne 'Synchronized' }

    if ($unhealthy.Count -gt 0) {
        Write-Warning "Warning: Some AG databases on $Node are not healthy!"
        return
    }
    else{ 
    $isPrimary = $agReplicas.PrimaryReplica -eq $passive

if (-not $isPrimary) {
    Write-Host "Rebooting $passive ...!"
## reboot passive node
Restart-Computer -ComputerName $Passive -Force } else{ return} }

#wait
 Write-Host "Rebooting inprogress..!" 
Start-Sleep -Seconds 300

 #AG Failover
 $maxAttempts = 2
    $attempt = 0
	 while ($attempt -lt $maxAttempts) {
 $ok=Invoke-DbaAgFailover -SqlInstance $Passive -AvailabilityGroup $agName -Confirm:$false

 if($ok){
   Write-Host "Rebooting $Active ...!"
 Restart-Computer -ComputerName $Active -Force
 break
 }
 else {
  Write-Host "Retrying in 5 minutes..!" }
 Start-Sleep -Seconds 300
 $attempt++ }

#wait for server be back online
Start-Sleep -Seconds 300
#AG Failback
 $maxAttempts = 2
    $attempt = 0
	 while ($attempt -lt $maxAttempts) {

 $chk=Get-DbaUptime -SqlInstance $Active

 #AG failback
 if($chk){ 
 
 Invoke-DbaAgFailover -SqlInstance $Active -AvailabilityGroup $agName -Confirm:$false
  Write-Host " Reboot and AG Failover \Failback Completed" -BackgroundColor Cyan
  break
  }
  else {Write-Host "Retrying in 5 minutes..!" }
 Start-Sleep -Seconds 300
 $attempt++}
	 
Write-Host "Check now AG status..!" -BackgroundColor Cyan