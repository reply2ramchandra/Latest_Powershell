﻿#Error/Warning: [Get-DbaBuildReferenceIndex] Index is stale
#Workaround
#add new build # by editing the JSON file name and ALSO Update "Last Updated" with latest date
##file name: dbatools-buildref-index
##path: C:\Program Files\WindowsPowerShell\Modules\dbatools\2.1.23\bin