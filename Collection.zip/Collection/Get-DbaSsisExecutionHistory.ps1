﻿clear
import-module dbatools -EA SilentlyContinue
Get-DbaSsisExecutionHistory -SqlInstance TPASWSQLDL001,TPADWSQLDL001 -Status Failed -Since 2025-03-12

