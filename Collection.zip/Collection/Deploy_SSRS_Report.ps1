# Define variables
$reportServerUrl = "http://<server>/ReportServer/ReportService2010.asmx?wsdl"
$reportFolder = "/MyReports"
$localReportPath = "C:\Reports\SalesReport.rdl"
$reportName = "SalesReport"
$dataSourceName = "SharedSQLDataSource"
$dataSourcePath = "/DataSources/SharedSQLDataSource"
$emailTo = "user@example.com"
$emailSubject = "Scheduled Sales Report"
$renderFormat = "PDF"

# Load SSRS Web Service
$ssrsProxy = New-WebServiceProxy -Uri $reportServerUrl -UseDefaultCredential -Namespace "SSRS"

# Upload the report
$reportDefinition = [System.IO.File]::ReadAllBytes($localReportPath)
$warnings = $null
$ssrsProxy.CreateCatalogItem("Report", $reportName, $reportFolder, $true, $reportDefinition, $null, [ref]$warnings)

# Set the shared data source
$dataSourceRef = New-Object SSRS.DataSourceReference
$dataSourceRef.Reference = $dataSourcePath

$dataSource = New-Object SSRS.DataSource
$dataSource.Item = $dataSourceRef
$dataSource.Name = "DataSource1"

$ssrsProxy.SetItemDataSources("$reportFolder/$reportName", @($dataSource))

# Create a subscription
$extensionSettings = New-Object SSRS.ExtensionSettings
$extensionSettings.Extension = "Report Server Email"
$extensionSettings.ParameterValues = @(
    New-Object SSRS.ParameterValue -Property @{ Name = "TO"; Value = $emailTo },
    New-Object SSRS.ParameterValue -Property @{ Name = "Subject"; Value = $emailSubject },
    New-Object SSRS.ParameterValue -Property @{ Name = "RenderFormat"; Value = $renderFormat }
)

$matchData = "<ScheduleDefinition><StartDateTime>$(Get-Date -Format s)</StartDateTime><WeeklyRecurrence><WeeksInterval>1</WeeksInterval><DaysOfWeek><Monday>True</Monday></DaysOfWeek></WeeklyRecurrence></ScheduleDefinition>"

$ssrsProxy.CreateSubscription(
    "$reportFolder/$reportName",
    $extensionSettings,
    $null,
    "TimedSubscription",
    $matchData,
    $null
)

Write-Host "Report deployed and subscription created successfully."
