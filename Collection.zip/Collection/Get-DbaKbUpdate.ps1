﻿Import-Module dbatools -EA SilentlyContinue
Get-DbaKbUpdate -Name KB5068406,KB5068404,KB5068402,KB5068400 | Save-DbaKbUpdate 
##Later copy it from Q:\