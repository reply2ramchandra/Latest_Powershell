﻿Import-module sqlserver
Import-module sqldbatools
Uninstall-SdtSqlInstance -SQLInstance TPAPWSQLETA01