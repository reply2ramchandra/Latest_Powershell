﻿CREATE TABLE [Stage].[SqlServerProperties] (
    [DateKey]            SMALLDATETIME,
    [SqlInstance]        VARCHAR (256) NOT NULL,
    [Collation]          VARCHAR (256) NULL,
    [Edition]            VARCHAR (256) NULL,
    [HostPlatform]       VARCHAR (16)  NULL,
    [Version]            VARCHAR (256) NULL,
    [IsClustered]        VARCHAR (5)   NULL,
    [IsHadrEnabled]      VARCHAR (5)   NULL,
    [NetName]            VARCHAR (256) NULL,
    [InstanceName]       VARCHAR (256) NULL,
    [ServiceAccount]     VARCHAR (256) NULL,
    [Product]            VARCHAR (256) NULL,
    [ProductLevel]       VARCHAR (4)   NULL,
    [ProductUpdateLevel] VARCHAR (4)   NULL,
    [PhysicalMemory]     INT           NULL,
    [MaxMemoryInMB]      INT           NULL,
    [Processors]         SMALLINT      NULL,
    [MaxDOP]             SMALLINT      NULL,
    [CostThreshold]      SMALLINT      NULL,
    PRIMARY KEY CLUSTERED ([DateKey],[SqlInstance])
);


GO

