USE [master]
GO
/****** Object:  Database [DFIN_ArcReporting_Issue]    Script Date: 2/4/2023 12:32:26 AM ******/
CREATE DATABASE [DFIN_ArcReporting_Issue]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'DFIN_ArcReporting_Issue', FILENAME = N'O:\SQLData\MSSQL10_50.SQL001\MSSQL\Data\DFIN_ArcReporting_Issue.mdf' , SIZE = 307200KB , MAXSIZE = UNLIMITED, FILEGROWTH = 102400KB )
 LOG ON 
( NAME = N'DFIN_ArcReporting_Issue_log', FILENAME = N'O:\SQLLogs\MSSQL10_50.SQL001\MSSQL\Data\DFIN_ArcReporting_Issue_log.ldf' , SIZE = 204800KB , MAXSIZE = 2048GB , FILEGROWTH = 102400KB )
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET COMPATIBILITY_LEVEL = 130
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [DFIN_ArcReporting_Issue].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET ARITHABORT OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET  DISABLE_BROKER 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET RECOVERY FULL 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET  MULTI_USER 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET DB_CHAINING OFF 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET QUERY_STORE = OFF
GO
USE [DFIN_ArcReporting_Issue]
GO
ALTER DATABASE SCOPED CONFIGURATION SET LEGACY_CARDINALITY_ESTIMATION = OFF;
GO
ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 0;
GO
ALTER DATABASE SCOPED CONFIGURATION SET PARAMETER_SNIFFING = ON;
GO
ALTER DATABASE SCOPED CONFIGURATION SET QUERY_OPTIMIZER_HOTFIXES = OFF;
GO
USE [DFIN_ArcReporting_Issue]
GO
/****** Object:  User [FINCOAD\Patrol]    Script Date: 2/4/2023 12:32:27 AM ******/
CREATE USER [FINCOAD\Patrol] FOR LOGIN [FINCOAD\Patrol] WITH DEFAULT_SCHEMA=[FINCOAD\Patrol]
GO
/****** Object:  Schema [FINCOAD\Patrol]    Script Date: 2/4/2023 12:32:27 AM ******/
CREATE SCHEMA [FINCOAD\Patrol]
GO
/****** Object:  Schema [stg]    Script Date: 2/4/2023 12:32:27 AM ******/
CREATE SCHEMA [stg]
GO
/****** Object:  Table [stg].[DbaService]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaService](
	[DateKey] [nvarchar](max) NULL,
	[PSComputerName] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[DisplayName] [nvarchar](max) NULL,
	[ServiceType] [nvarchar](max) NULL,
	[ServiceName] [nvarchar](max) NULL,
	[StartMode] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL,
	[StartName] [nvarchar](max) NULL,
	[ProcessId] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[Vw_DbaService]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Vw_DbaService]
AS
SELECT [DateKey]
      ,[PSComputerName]
      ,[ComputerName]
      ,[DisplayName]
      ,[ServiceType]
      ,[ServiceName]
      ,[StartMode]
      ,[State]
      ,[StartName]
	  , CASE 
	        WHEN [State] <> 'Running' 
			Then 'UnHealthy'
			Else 'Healthy'
        END AS ServerHealthStatus 
  FROM [DFIN_ArcReporting_Issue].[stg].[DbaService] where [ServiceType] IN ('Engine','Agent') 
GO
/****** Object:  Table [stg].[DbaDatabase]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaDatabase](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[ServerVersion] [nvarchar](max) NULL,
	[ID] [int] NULL,
	[Name] [nvarchar](max) NULL,
	[SizeMB] [float] NULL,
	[CreateDate] [datetime2](7) NULL,
	[LastFullBackup] [datetime2](7) NULL,
	[LastDiffBackup] [datetime2](7) NULL,
	[LastLogBackup] [datetime2](7) NULL,
	[DatabaseEngineType] [nvarchar](max) NULL,
	[DatabaseEngineEdition] [nvarchar](max) NULL,
	[AutoClose] [bit] NULL,
	[AutoShrink] [bit] NULL,
	[BrokerEnabled] [bit] NULL,
	[Collation] [nvarchar](max) NULL,
	[CompatibilityLevel] [nvarchar](max) NULL,
	[DataSpaceUsage] [float] NULL,
	[EncryptionEnabled] [bit] NULL,
	[LastGoodCheckDbTime] [datetime2](7) NULL,
	[LogReuseWaitStatus] [nvarchar](max) NULL,
	[Owner] [nvarchar](max) NULL,
	[RecoveryModel] [nvarchar](max) NULL,
	[Size] [float] NULL,
	[SpaceAvailable] [float] NULL,
	[Status] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[Vw_DbaDatabase]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[Vw_DbaDatabase]
AS
SELECT [ComputerName],[Datekey],
       [SqlInstance],
	   [Name],[SizeMB],
	   [CreateDate],
	   [LastFullBackup],
	   [LastDiffBackup],
	   [LastLogBackup],
	   [LastGoodCheckDbTime],
	   [LogReuseWaitStatus],
	   [RecoveryModel],
	   [Status],
	   [State]
       ,CASE 
	       WHEN [LogReuseWaitStatus] <> 'Nothing' or [Status] <> 'Normal' 
		   Then 'UnHealthy' 
		   Else 'Healthy' 
		 END AS DatabaseHealthStatus
FROM [DFIN_ArcReporting_Issue].[stg].[DbaDatabase] 
where Name not in ('master','model','tempdb','msdb','DBA') 
GO
/****** Object:  Table [stg].[DbaDbLogSpace]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaDbLogSpace](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[LogSize] [bigint] NULL,
	[LogSpaceUsed] [bigint] NULL,
	[LogSpaceUsedPercent] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[Vw_DbaDbLogSpace]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Vw_DbaDbLogSpace]
AS
SELECT [DateKey]
      ,[ComputerName]
      ,[SqlInstance]
      ,[Database]
      ,[LogSize]
      ,[LogSpaceUsed]
      ,[LogSpaceUsedPercent]
	  ,CASE 
	   WHEN  [LogSpaceUsedPercent] > 95.000
	   Then 'UnHealthy'
	   Else 'Healthy'
	   END AS DbaDbLogSpaceStatus
  FROM [DFIN_ArcReporting_Issue].[stg].[DbaDbLogSpace];
GO
/****** Object:  Table [stg].[DbaDiskSpace]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaDiskSpace](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Label] [nvarchar](max) NULL,
	[Capacity] [bigint] NULL,
	[Free] [bigint] NULL,
	[PercentFree] [float] NULL,
	[BlockSize] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[Vw_DbaDiskSpace]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[Vw_DbaDiskSpace]
AS
SELECT [DateKey]
      ,[ComputerName]
      ,[Name]
      ,[Label]
      ,[Capacity]
      ,[Free]
      ,[PercentFree]
      ,CASE 
	     WHEN [PercentFree] < 10.00
		 Then 'UnHealthy'
		 Else 'Healthy'
	   END AS DbaDiskSpaceStatus
  FROM [DFIN_ArcReporting_Issue].[stg].[DbaDiskSpace];
GO
/****** Object:  Table [stg].[DbaCpuRingBuffer]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaCpuRingBuffer](
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[RecordId] [int] NULL,
	[SQLProcessUtilization] [int] NULL,
	[OtherProcessUtilization] [int] NULL,
	[SystemIdle] [int] NULL,
	[EventTime] [datetime2](7) NULL,
	[DateKey] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[Vw_DbaCpuRingBuffer]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Vw_DbaCpuRingBuffer]
AS
SELECT [ComputerName]
      ,[SqlInstance]
      ,[RecordId]
      ,[SQLProcessUtilization]
      ,[OtherProcessUtilization]
      ,[SystemIdle]
      ,[EventTime]
      ,[DateKey]
	  , CASE 
	         WHEN [SQLProcessUtilization] > 95 or [OtherProcessUtilization] > 95 or [SystemIdle] < 10
			 Then 'Unhealthy'
			 ELse 'Healthy'
		END AS ServerHealthStatus
  FROM [DFIN_ArcReporting_Issue].[stg].[DbaCpuRingBuffer];
GO
/****** Object:  Table [stg].[DbaSPWhoisactive]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaSPWhoisactive](
	[dd hh:mm:ss.mss] [nvarchar](max) NULL,
	[session_id] [smallint] NULL,
	[sql_text] [nvarchar](max) NULL,
	[login_name] [nvarchar](max) NULL,
	[wait_info] [nvarchar](max) NULL,
	[CPU] [nvarchar](max) NULL,
	[tempdb_allocations] [nvarchar](max) NULL,
	[tempdb_current] [nvarchar](max) NULL,
	[blocking_session_id] [smallint] NULL,
	[reads] [nvarchar](max) NULL,
	[writes] [nvarchar](max) NULL,
	[physical_reads] [nvarchar](max) NULL,
	[used_memory] [nvarchar](max) NULL,
	[status] [nvarchar](max) NULL,
	[open_tran_count] [nvarchar](max) NULL,
	[percent_complete] [nvarchar](max) NULL,
	[host_name] [nvarchar](max) NULL,
	[database_name] [nvarchar](max) NULL,
	[program_name] [nvarchar](max) NULL,
	[start_time] [datetime2](7) NULL,
	[login_time] [datetime2](7) NULL,
	[request_id] [int] NULL,
	[server_name] [nvarchar](max) NULL,
	[collection_time] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[Vw_DbaSPWhoisactive]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Vw_DbaSPWhoisactive]
AS
SELECT [server_name]
      ,[dd hh:mm:ss.mss]
      ,[session_id]
      ,[sql_text]
      ,[login_name]
      ,[wait_info]
      ,[blocking_session_id]
      ,[status]
      ,[open_tran_count]
      ,[percent_complete]
      ,[host_name]
      ,[database_name]
      ,[program_name]
      ,[start_time]
      ,[login_time]
      ,[collection_time]
      , CASE
	    WHEN [blocking_session_id] > 1 or [dd hh:mm:ss.mss] > '00 02:00:11.116'
		Then 'Unhealthy'
	    ELse 'Healthy'
		END AS DbaSPWhoisactiveStatus
FROM [DFIN_ArcReporting_Issue].[stg].[DbaSPWhoisactive]; 
GO
/****** Object:  Table [stg].[DbaMemoryCondition]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaMemoryCondition](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Runtime] [nvarchar](max) NULL,
	[NotificationTime] [datetime2](7) NULL,
	[NotificationType] [nvarchar](max) NULL,
	[MemoryUtilizationPercent] [bigint] NULL,
	[TotalPhysicalMemory] [bigint] NULL,
	[AvailablePhysicalMemory] [bigint] NULL,
	[TotalPageFile] [bigint] NULL,
	[AvailablePageFile] [bigint] NULL,
	[TotalVirtualAddressSpace] [bigint] NULL,
	[AvailableVirtualAddressSpace] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[Vw_DbaMemoryCondition]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Vw_DbaMemoryCondition]
AS
SELECT [DateKey]
      ,[ComputerName]
      ,[SqlInstance]
      ,[Runtime]
      ,[NotificationTime]
      ,[NotificationType]
      ,[MemoryUtilizationPercent]
      ,[TotalPhysicalMemory]/(1024*1024*1024) AS [TotalPhysicalMemoryGB]
      ,[AvailablePhysicalMemory]/(1024*1024*1024) AS [AvailablePhysicalMemoryGB]
	  , CASE 
	        WHEN [MemoryUtilizationPercent] > 95 
			Then 'UnHealthy'
			Else 'Healthy'
        END AS ServerHealthStatus
  FROM [DFIN_ArcReporting_Issue].[stg].[DbaMemoryCondition] where [NotificationTime] > Getdate()-1
GO
/****** Object:  Table [stg].[DbaDbSpace]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DbaDbSpace](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[FileName] [nvarchar](max) NULL,
	[PhysicalName] [nvarchar](max) NULL,
	[FileType] [nvarchar](max) NULL,
	[UsedSpace] [bigint] NULL,
	[FreeSpace] [bigint] NULL,
	[FileSize] [bigint] NULL,
	[PercentUsed] [float] NULL,
	[AutoGrowth] [bigint] NULL,
	[AutoGrowType] [nvarchar](max) NULL,
	[SpaceUntilMaxSize] [bigint] NULL,
	[AutoGrowthPossible] [bigint] NULL,
	[UnusableSpace] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  View [dbo].[Vw_DbaDbSpace]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Vw_DbaDbSpace]
AS
SELECT [DateKey]
      ,[ComputerName]
      ,[SqlInstance]
      ,[Database]
      ,[FileName]
      ,[PhysicalName]
      ,[FileType]
      ,[UsedSpace]
      ,[FreeSpace]
      ,[FileSize]
      ,[PercentUsed]
	  ,CASE 
	     WHEN [PercentUsed] > 95
		 THEN 'UnHealthy'
		 ELse 'Healthy'
		 END AS DbaDbSpaceStatus 
FROM [DFIN_ArcReporting_Issue].[stg].[DbaDbSpace]
GO
/****** Object:  Table [dbo].[commandlog]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[commandlog](
	[Description] [nvarchar](1000) NULL,
	[Status] [nchar](1000) NULL,
	[Collectiontime] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaCpuRingBuffer]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaCpuRingBuffer](
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[RecordId] [int] NULL,
	[SQLProcessUtilization] [int] NULL,
	[OtherProcessUtilization] [int] NULL,
	[SystemIdle] [int] NULL,
	[EventTime] [datetime2](7) NULL,
	[DateKey] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaDatabase]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaDatabase](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[ServerVersion] [nvarchar](max) NULL,
	[ID] [int] NULL,
	[Name] [nvarchar](max) NULL,
	[SizeMB] [float] NULL,
	[CreateDate] [datetime2](7) NULL,
	[LastFullBackup] [datetime2](7) NULL,
	[LastDiffBackup] [datetime2](7) NULL,
	[LastLogBackup] [datetime2](7) NULL,
	[DatabaseEngineType] [nvarchar](max) NULL,
	[DatabaseEngineEdition] [nvarchar](max) NULL,
	[AutoClose] [bit] NULL,
	[AutoShrink] [bit] NULL,
	[BrokerEnabled] [bit] NULL,
	[Collation] [nvarchar](max) NULL,
	[CompatibilityLevel] [nvarchar](max) NULL,
	[DataSpaceUsage] [float] NULL,
	[EncryptionEnabled] [bit] NULL,
	[LastGoodCheckDbTime] [datetime2](7) NULL,
	[LogReuseWaitStatus] [nvarchar](max) NULL,
	[Owner] [nvarchar](max) NULL,
	[RecoveryModel] [nvarchar](max) NULL,
	[Size] [float] NULL,
	[SpaceAvailable] [float] NULL,
	[Status] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaDbLogSpace]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaDbLogSpace](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[LogSize] [bigint] NULL,
	[LogSpaceUsed] [bigint] NULL,
	[LogSpaceUsedPercent] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaDbSpace]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaDbSpace](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Database] [nvarchar](max) NULL,
	[FileName] [nvarchar](max) NULL,
	[PhysicalName] [nvarchar](max) NULL,
	[FileType] [nvarchar](max) NULL,
	[UsedSpace] [bigint] NULL,
	[FreeSpace] [bigint] NULL,
	[FileSize] [bigint] NULL,
	[PercentUsed] [float] NULL,
	[AutoGrowth] [bigint] NULL,
	[AutoGrowType] [nvarchar](max) NULL,
	[SpaceUntilMaxSize] [bigint] NULL,
	[AutoGrowthPossible] [bigint] NULL,
	[UnusableSpace] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaDiskSpace]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaDiskSpace](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Label] [nvarchar](max) NULL,
	[Capacity] [bigint] NULL,
	[Free] [bigint] NULL,
	[PercentFree] [float] NULL,
	[BlockSize] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaMemoryCondition]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaMemoryCondition](
	[DateKey] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[SqlInstance] [nvarchar](max) NULL,
	[Runtime] [nvarchar](max) NULL,
	[NotificationTime] [datetime2](7) NULL,
	[NotificationType] [nvarchar](max) NULL,
	[MemoryUtilizationPercent] [bigint] NULL,
	[TotalPhysicalMemory] [bigint] NULL,
	[AvailablePhysicalMemory] [bigint] NULL,
	[TotalPageFile] [bigint] NULL,
	[AvailablePageFile] [bigint] NULL,
	[TotalVirtualAddressSpace] [bigint] NULL,
	[AvailableVirtualAddressSpace] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaService]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaService](
	[DateKey] [nvarchar](max) NULL,
	[PSComputerName] [nvarchar](max) NULL,
	[ComputerName] [nvarchar](max) NULL,
	[DisplayName] [nvarchar](max) NULL,
	[ServiceType] [nvarchar](max) NULL,
	[ServiceName] [nvarchar](max) NULL,
	[StartMode] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL,
	[StartName] [nvarchar](max) NULL,
	[ProcessId] [bigint] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DbaSPWhoisactive]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DbaSPWhoisactive](
	[dd hh:mm:ss.mss] [nvarchar](max) NULL,
	[session_id] [smallint] NULL,
	[sql_text] [nvarchar](max) NULL,
	[login_name] [nvarchar](max) NULL,
	[wait_info] [nvarchar](max) NULL,
	[CPU] [nvarchar](max) NULL,
	[tempdb_allocations] [nvarchar](max) NULL,
	[tempdb_current] [nvarchar](max) NULL,
	[blocking_session_id] [smallint] NULL,
	[reads] [nvarchar](max) NULL,
	[writes] [nvarchar](max) NULL,
	[physical_reads] [nvarchar](max) NULL,
	[used_memory] [nvarchar](max) NULL,
	[status] [nvarchar](max) NULL,
	[open_tran_count] [nvarchar](max) NULL,
	[percent_complete] [nvarchar](max) NULL,
	[host_name] [nvarchar](max) NULL,
	[database_name] [nvarchar](max) NULL,
	[program_name] [nvarchar](max) NULL,
	[start_time] [datetime2](7) NULL,
	[login_time] [datetime2](7) NULL,
	[request_id] [int] NULL,
	[server_name] [nvarchar](max) NULL,
	[collection_time] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DFIN_HealthReport]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DFIN_HealthReport](
	[Description] [nvarchar](1000) NULL,
	[Collectiontime] [datetime] NULL,
	[Healthy] [int] NULL,
	[UnHealthy] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ServerList]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ServerList](
	[SqlInstance] [varchar](256) NOT NULL,
	[MachineName] [varchar](256) NULL,
	[Status] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [stg].[DFIN_HealthReport]    Script Date: 2/4/2023 12:32:27 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [stg].[DFIN_HealthReport](
	[Description] [nvarchar](1000) NULL,
	[Collectiontime] [datetime] NULL,
	[Healthy] [int] NULL,
	[UnHealthy] [int] NULL
) ON [PRIMARY]
GO
USE [master]
GO
ALTER DATABASE [DFIN_ArcReporting_Issue] SET  READ_WRITE 
GO
