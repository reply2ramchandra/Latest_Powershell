﻿Import-Module dbatools -EA SilentlyContinue
 $server='TPAPWPEDSQL001'
  #check drive allocation Unit
 Get-DbaDiskSpace $server | where {$_.Name -eq "M:\"}
  $srv='TPAPWSQLDL005'
   #Get-DbaDiskSpace $srv 
  #check drive allocation Unit
 Get-DbaDiskSpace $srv | where {$_.Name -eq "D:\"}
 get-date | select DateTime

