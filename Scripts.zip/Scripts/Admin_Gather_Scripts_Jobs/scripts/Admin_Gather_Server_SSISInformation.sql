
set nocount on
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wDrives') ) 
    DROP TABLE #wDrives
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#Files') ) 
    DROP TABLE #Files    
IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wSSIS_Information') ) 
    DROP TABLE #wSSIS_Information    
CREATE TABLE #wSSIS_Information(
	[Date_Key] [datetime] NULL,
	[Server_Name] [sysname] NULL,
	[FileType] [varchar](10) NULL,
	[MountPoint] [varchar](60) NULL,
	[SSIS_Package_Name] [varchar](500) NOT NULL,
	[FileSizeInMB] [decimal](18, 2) NULL,
	[FileSizeInGB] [decimal](18, 2) NULL
)
CREATE TABLE #wDrives (DriveLetter char(1), MBFree int)
INSERT INTO #wDrives
EXEC master..xp_fixeddrives
-- DECLARE VARIABLES
DECLARE @CurrentDriveLetter char(1), @MaxDriveLetter varchar(1), @EXECSTR varchar(1024)
-- FIND THE FIRST AND LAST DRIVES FOR THE LOOP
SELECT @CurrentDriveLetter = Min(DriveLetter), @MaxDriveLetter = Max(DriveLetter) from #wDrives
-- CREATE THE TABLE TO HOST THE LIST OF FILES
CREATE TABLE #Files (autono_id int NOT NULL IDENTITY (1, 1), RawData varchar(255), FilePath varchar(255), DriveLetter char(1), [FileName] varchar(255), FileSize varchar(17), FileSizeInMB decimal(18,2), FileSizeInGB decimal(18,2), FileType varchar(10))
WHILE @CurrentDriveLetter <= @MaxDriveLetter
BEGIN
      -- STORE THE FILES WE ARE LOOKING FOR IN THE #FILES TABLE
    -- PRINT STR('dir ' + STR(@CurrentDriveLetter) + ':\*.mdf;*.ndf;*.ldf /s')
      SELECT @EXECSTR = 'dir ' + CONVERT(NVARCHAR(1),@CurrentDriveLetter) + ':\*.dtsx /s' -- string in the drive letter later
      INSERT INTO #Files (RawData)
      EXEC master..xp_cmdshell @EXECSTR
    -- PRINT @EXECSTR
      select @CurrentDriveLetter = MIN(DriveLetter) from #wDrives where DriveLetter > @CurrentDriveLetter
END
-- CLEAN UP ##_Files
update #Files
   set FilePath = REPLACE(RawData,'Directory of ','')
 where RawData like '%Directory of %:%'
update #Files
   set FilePath = SubString(FilePath, 2, 255)
 where FilePath is not null
delete from #Files
 where RawData is NULL
      or RawData = 'File Not Found'
      or RawData like '%Volume%'
      or RawData like '%File(s)%'
      or RawData like '%Dir(s)%'
      or RawData like '%Total Files Listed:%'
update #Files set [FileName] = substring (RawData, 40, 255) where FilePath is NULL
update #Files set FileSize = substring (RawData, 22, 17) where FilePath is NULL
update #Files set FileSize = replace(substring (RawData, 22, 17),',','') where FilePath is NULL
update #Files set FileType = UPPER(right(substring (RawData, 40, 255), 4)) where FilePath is NULL
update #Files
   set FileSizeInMB = CONVERT(decimal(18,2), FileSize) / 1024 / 1024,
         FileSizeInGB = CONVERT(decimal(18,2), FileSize) / 1024 / 1024 / 1024
DECLARE @autono_id int, @fp varchar(255), @drive char(1)
select top 1 @autono_id = autono_id, @fp = [FilePath], @drive = DriveLetter
  from #Files F1
 where FilePath is not null
   and autono_id < (select max(autono_id) from #Files where FilePath is NULL)
 order by autono_id desc
WHILE @autono_id IS NOT NULL
BEGIN
      update #Files
         set [FilePath] = @fp, DriveLetter = @drive
       where autono_id > @autono_id and [FilePath] is NULL
      DELETE from #Files where [FileName] is null AND DriveLetter = @drive AND autono_id > @autono_id
      SELECT @autono_id = NULL, @fp = NULL, @drive = NULL -- RESET FLAGS
      select top 1 @autono_id = autono_id, @fp = [FilePath], @drive = DriveLetter
        from #Files F1
       where FilePath is not null
         and autono_id < (select max(autono_id) from #Files where FilePath is NULL)
       order by autono_id desc
END
delete from #Files where FileName is NULL or FilePath like '%i386%' or FilePath like '%ia64%'

Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear

-- @@VERSION like '%2000%' is excluded in the intital search for environments to scan
IF @@VERSION like '%2005%'
BEGIN
INSERT INTO #wSSIS_Information(
	[Date_Key],
	[Server_Name],
	[FileType],
	[MountPoint],
	[SSIS_Package_Name],
	[FileSizeInMB],
	[FileSizeInGB])
select 
	@Date_Key as Date_Key, 
	@@servername as Server_Name, 
	FileType, 
	DriveLetter AS MountPoint,
	'SSIS_Package_Name' = CONVERT(VARCHAR(500), REPLACE(FilePath + '\' + [FileName], ':\\', ':\')), 
	FileSizeInMB, 
	FileSizeInGB
from #Files
where --FilePath + '\' + FileName not in (select filename from master.dbo.sysaltfiles) and
    FileType = 'dtsx'
   and FileSizeInMB > 0 
   and FilePath NOT Like '%RECYCLE%'
   and FilePath NOT Like '%Symantec%'
   and FilePath NOT Like '%Documents and Settings%'
   and FilePath NOT Like '%C:\WINDOWS%'
   and FilePath NOT Like '%C:\Users%'
END
ELSE
BEGIN
INSERT INTO #wSSIS_Information(
	[Date_Key],
	[Server_Name],
	[FileType],
	[MountPoint],
	[SSIS_Package_Name],
	[FileSizeInMB],
	[FileSizeInGB])
select 
	@Date_Key as Date_Key, 
	@@servername as Server_Name, 
	FileType, 
	DriveLetter AS MountPoint,
	'SSIS_Package_Name' = CONVERT(VARCHAR(500), REPLACE(FilePath + '\' + [FileName], ':\\', ':\')), 
	FileSizeInMB, 
	FileSizeInGB
from #Files
where --FilePath + '\' + FileName not in (select filename from master.dbo.sysaltfiles) and
    FileType = 'dtsx'
   and FileSizeInMB > 0 
   and FilePath NOT Like '%RECYCLE%'
   and FilePath NOT Like '%Symantec%'
   and FilePath NOT Like '%Documents and Settings%'
   and FilePath NOT Like '%C:\WINDOWS%'
   and FilePath NOT Like '%C:\Users%'
UNION
SELECT TOP 100 PERCENT 
  	@Date_Key as Date_Key,
	@@ServerName AS Server_Name, 
	'SQL Server' AS FileType,
	'MSDB' AS MountPoint,
	CONVERT(VARCHAR(500), SS.name) AS SSIS_Package_Name,
	0.00 AS FileSizeInMB,
	0.00 AS FileSizeInGB
FROM	msdb.dbo.sysssispackages SS INNER JOIN
	 (SELECT [name], MAX(createdate) AS createdate
	  FROM msdb.dbo.sysssispackages
	  GROUP BY [name]) S1 ON SS.name = S1.name AND SS.createdate = S1.createdate
END


SELECT 
	[Date_Key],
	[Server_Name],
	[FileType],
	[MountPoint],
	[SSIS_Package_Name],
	[FileSizeInMB],
	[FileSizeInGB]
FROM #wSSIS_Information
