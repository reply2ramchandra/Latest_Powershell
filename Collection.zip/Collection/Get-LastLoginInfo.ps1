﻿clear
Get-LastLoginInfo -ComputerName localhost -LoginEvent Logoff -DaysFromToday 2