﻿Import-Module dbatools -DisableNameChecking 
$SecurePW = Read-Host "SSISHHPa**w03d" -AsSecureString
#Copy-DbaSsisCatalog -Source TPAPWHHSQL004 -Destination TPAPWSQLHH004 -CreateCatalogPassword $SecurePW
$ISNamespace = "Microsoft.SqlServer.Management.IntegrationServices"
#Copy-DbaSsisCatalog -Source TPAPWHHSQL004 -Destination TPAPWSQLHH004 -Folder SSIS_Harrington -Force
Copy-DbaSsisCatalog -Source TPATWSQL004 -Destination TPADWSQLDL001 #-Folder UCCEETL -Force

New-DbaSsisCatalog -SqlInstance TPADWSQLDL001 -Credential HPS\sm58408 DLPa**w03d


<#
create a SSIS catalog on target amnually
run the below command 2 times
Copy-DbaSsisCatalog -Source TPATWSQL004 -Destination TPADWSQLDL001
#>