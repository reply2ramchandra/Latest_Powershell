﻿ $server='TPAUWSQLDL001'
 Invoke-Command -ComputerName $server -ScriptBlock {
# Function to check if a service is running
function Check-ServiceStatus {
    param (
        [string]$serviceName
    )

    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($null -eq $service) {
        Write-Output "Service '$serviceName' not found."
    } else {
        if ($service.Status -eq 'Running') {
            Write-Output "Service '$serviceName' is running."
        } else {
            Write-Output "Service '$serviceName' is not running."
        }
    }
}
clear
# Check Tanium Service
Check-ServiceStatus -serviceName 'Tanium Client'

# Check Splunk Service
Check-ServiceStatus -serviceName 'SplunkForwarder'

# Check Qualys Service
Check-ServiceStatus -serviceName 'QualysAgent'

# Check Cortex Service
Check-ServiceStatus -serviceName 'cyserver'

# Get default user accounts and their status
$defaultUsers = @("Lcl_admin", "EmergencyAdmin", "DefaultAccount", "WDAGUtilityAccount" )
foreach ($user in $defaultUsers) {
    $userAccount = Get-LocalUser -Name $user -ErrorAction SilentlyContinue
    if ($null -eq $userAccount) {
        Write-Output "User account '$user' not found."
    } else {
        Write-Output "User account '$user': Enabled = $($userAccount.Enabled)"
    }
}

# Get hostname
$hostname = (Get-WmiObject Win32_ComputerSystem).Name
Write-Output "Hostname: $hostname"

# Get IP address
$ipAddresses = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notmatch '^(169\.254\.)' } | Select-Object -ExpandProperty IPAddress
Write-Output "IP Addresses: $($ipAddresses -join ', ')"
}
