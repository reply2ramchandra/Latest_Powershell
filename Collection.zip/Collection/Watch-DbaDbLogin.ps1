﻿CLEAR
import-module dbatools -EA SilentlyContinue
Watch-DbaDbLogin -SqlInstance localhost -Database CentralAudit -ServersFromFile T:\test\1024.txt
<#
CLEAR
import-module dbatools -EA SilentlyContinue
$instance1 = Connect-DbaInstance -SqlInstance TPAPWSQLSTEL003
$instance2 = Connect-DbaInstance -SqlInstance TPAPWAIRSQL001
$instance1, $instance2 | Watch-DbaDbLogin -SqlInstance localhost -Database CMS -Table WatchDbLogins
#$inst1 | Watch-DbaDbLogin -SqlInstance localhost -Database CMS -Table WatchDbLogins
#>
