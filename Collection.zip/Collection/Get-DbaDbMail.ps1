﻿clear
Import-Module dbatools -EA SilentlyContinue
Get-DbaDbMail -SqlInstance tpapwsqldl001
