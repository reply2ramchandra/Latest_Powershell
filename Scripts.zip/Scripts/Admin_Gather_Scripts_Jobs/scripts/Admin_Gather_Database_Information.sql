SET NOCOUNT ON

IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'[tempdb].[dbo].[wDBInformation]') ) 
    DROP TABLE [tempdb].[dbo].[wDBInformation]  

--Recreate it

CREATE TABLE [tempdb].[dbo].[wDBInformation]  
( ServerName NVARCHAR(128),  
DatabaseName VARCHAR(128),  
FileSizeMB INT,  
LogicalFileName sysname,  
PhysicalFileName NVARCHAR(520),  
Status sysname,  
Updateability sysname,  
RecoveryMode sysname,  
FreeSpaceMB INT,  
FreeSpacePct VARCHAR(7),  
FreeSpacePages INT,  
PollDate datetime,
Applications VARCHAR(256),
FunctionalGroups VARCHAR (256),
Owners VARCHAR (256)
)  

DECLARE @command VARCHAR(5000)  
IF @@VERSION LIKE '%2000%' 
BEGIN
SELECT @command = 'Use [' + '?' + '] SELECT  
CONVERT(sysname,SERVERPROPERTY(''ServerName'')) AS ServerName,  
' + '''' + '?' + '''' + ' AS DatabaseName,  
CAST(sysfiles.size/128.0 AS int) AS FileSize,  
sysfiles.name AS LogicalFileName, sysfiles.filename AS PhysicalFileName,  
CONVERT(sysname,DatabasePropertyEx(''?'',''Status'')) AS Status,  
CONVERT(sysname,DatabasePropertyEx(''?'',''Updateability'')) AS Updateability,  
CONVERT(sysname,DatabasePropertyEx(''?'',''Recovery'')) AS RecoveryMode,  
CAST(sysfiles.size/128.0 - CAST(FILEPROPERTY(sysfiles.name, ' + '''' +  
       'SpaceUsed' + '''' + ' ) AS int)/128.0 AS int) AS FreeSpaceMB,  
CAST(100 * (CAST (((sysfiles.size/128.0 -CAST(FILEPROPERTY(sysfiles.name,  
' + '''' + 'SpaceUsed' + '''' + ' ) AS int)/128.0)/(sysfiles.size/128.0))  
AS decimal(4,2))) AS varchar(8)) + ' + '''' + '%' + '''' + ' AS FreeSpacePct,  
GETDATE() as PollDate,
(SELECT cast([value] AS VARCHAR(256)) FROM dbo.sysproperties where [name] = ''Applications'') AS Appliciations, 
(SELECT cast([value] AS VARCHAR(256)) FROM dbo.sysproperties where [name] = ''FunctionalGroups'') AS FunctionGroups,
(SELECT cast([value] AS VARCHAR(256)) FROM dbo.sysproperties where [name] = ''Owners'') AS Owners
FROM dbo.sysfiles'  
END
ELSE
BEGIN
SELECT @command = 'Use [' + '?' + '] SELECT  
CONVERT(sysname,SERVERPROPERTY(''ServerName'')) AS ServerName,  
' + '''' + '?' + '''' + ' AS DatabaseName,  
CAST(sysfiles.size/128.0 AS int) AS FileSize,  
sysfiles.name AS LogicalFileName, sysfiles.filename AS PhysicalFileName,  
CONVERT(sysname,DatabasePropertyEx(''?'',''Status'')) AS Status,  
CONVERT(sysname,DatabasePropertyEx(''?'',''Updateability'')) AS Updateability,  
CONVERT(sysname,DatabasePropertyEx(''?'',''Recovery'')) AS RecoveryMode,  
CAST(sysfiles.size/128.0 - CAST(FILEPROPERTY(sysfiles.name, ' + '''' +  
       'SpaceUsed' + '''' + ' ) AS int)/128.0 AS int) AS FreeSpaceMB,  
CAST(100 * (CAST (((sysfiles.size/128.0 -CAST(FILEPROPERTY(sysfiles.name,  
' + '''' + 'SpaceUsed' + '''' + ' ) AS int)/128.0)/(sysfiles.size/128.0))  
AS decimal(4,2))) AS varchar(8)) + ' + '''' + '%' + '''' + ' AS FreeSpacePct,  
GETDATE() as PollDate,
(SELECT cast([value] AS VARCHAR(256)) FROM [sys].[extended_properties] where [name] = ''Applications'') AS Appliciations, 
(SELECT cast([value] AS VARCHAR(256)) FROM [sys].[extended_properties] where [name] = ''FunctionalGroups'') AS FunctionGroups,
(SELECT cast([value] AS VARCHAR(256)) FROM [sys].[extended_properties] where [name] = ''Owners'') AS Owners
FROM [sys].[sysfiles]'  
END

INSERT INTO [tempdb].[dbo].[wDBInformation]  
   (ServerName,  
   DatabaseName,  
   FileSizeMB,  
   LogicalFileName,  
   PhysicalFileName,  
   Status,  
   Updateability,  
   RecoveryMode,  
   FreeSpaceMB,  
   FreeSpacePct,  
   PollDate,
   Applications,
   FunctionalGroups,
   Owners)  
EXEC sp_MSforeachdb @command  

Declare @Date_Key  datetime
Declare @DateYear  char(4)
Declare @DateMonth char(2)
Declare @DateDay   char(2)
Select  @Date_Key = GETDATE()
Select  @DateYear  = DATEPART(Year, @Date_Key)
Select  @DateMonth = DATEPART(Month, @Date_Key)
Select  @DateDay   = DATEPART(Day, @Date_Key)

Select @Date_Key = @DateMonth + '/' + @DateDay + '/' + @DateYear

SELECT
   @Date_Key AS Date_Key,
   ServerName,  
   DatabaseName,  
   FileSizeMB,  
   LogicalFileName,  
   PhysicalFileName,  
   Status,  
   Updateability,  
   RecoveryMode,  
   FreeSpaceMB,  
   FreeSpacePct,  
   PollDate,
   Applications,
   FunctionalGroups,
   Owners
FROM [tempdb].[dbo].[wDBInformation]  
ORDER BY  
   ServerName,  
   DatabaseName  

IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'[tempdb].[dbo].[wDBInformation]') ) 
    DROP TABLE [tempdb].[dbo].[wDBInformation]  
