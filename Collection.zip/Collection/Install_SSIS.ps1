﻿$server='TPADWSQLDL001'
 Invoke-Command -ComputerName $server -ScriptBlock {
 $binarypath="D:\SQL\Software"
 $isoImg = Get-ChildItem -Path $binarypath -Recurse -Filter "*.ISO"
 $isoImg=$isoImg.FullName
 $diskImg = Mount-DiskImage -ImagePath $isoImg 
 # Get mounted ISO volume
 $mountvol = ($diskImg | Get-Volume).DriveLetter
 $mountvol=$mountvol+":\"
 write-Host $mountvol }
 Import-Module dbatools -WarningAction SilentlyContinue 
#Setup Drive Letter Manually
$server='TPAPWSQLGNXTB02'
Set-DbatoolsConfig -Name Path.SQLServerSetup -Value E:\
Install-DbaInstance -ComputerName $server -Version 2022 -Restart -Feature IntegrationServices -Confirm:$false