﻿$server='TPAPWSP16SQL001'
Invoke-Command -ComputerName $server -ScriptBlock {
$targetpatchfolder="D:\patch"
# check if folder exist
if(Test-Path $targetpatchfolder)
{
Write-Host " Folder Exist " -ForegroundColor Green
}
Else { New-Item -ItemType Directory -Path $targetpatchfolder 
Write-Host " Folder Created " -ForegroundColor Yellow}
}
#copy patch file
$patchfile= Get-ChildItem X:\SQLISO\CU -Filter '*2014*' 
$source=$patchfile.FullName  
$target="D:\patch"
$cred=Get-Credential HPS\a-sm58408
$s = New-PSSession -ComputerName $server -Credential $cred
Copy-Item -Path $source -Destination $target -ToSession $s


 