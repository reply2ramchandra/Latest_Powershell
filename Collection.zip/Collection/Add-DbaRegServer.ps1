﻿Import-Module dbatools -EA SilentlyContinue

Import-DbaRegServer -SqlInstance TPAPWMSSQL002 -Path C:\Users\a-sm58408\Documents\DbatoolsExport\TPAPWMSSQL002-reggroup-DatabaseEngineServerGroup-20250707060620.xml

Remove-DbaRegServer -SqlInstance TPAPWMSSQL002


Export-DbaRegServer -SqlInstance TPAPWMSSQL002 -Group Prod


Get-DbaRegServer -SqlInstance TPAPWMSSQL002
Add-DbaRegServerGroup -SqlInstance TPAPWMSSQL002 -Name TelePhony
#Add-DbaRegServerGroup -SqlInstance TPATWSQLMHCB01 -Name NonProdAll
#Add-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName GCPUWUCCE01 -Group NonProd -Description "Telephony in PCI"
#Remove-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName TPAPWSQLSSRS-03 -Confirm:$false -Group ProdAll, Accounting
#Remove-DbaRegServerGroup -SqlInstance TPATWSQLMHCA01 -Group NonProdAll -Confirm:$false
Import-Module dbatools -EA SilentlyContinue 
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
#$instances = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where [Status]='Y' and [Category]='PROD' and [SqlInstance] NOT IN ('localhost','TPAPWSQLSSRS-03')" 
#$instances = 
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] Where [Status]='Y' and [Category]='PROD' and HostName<>'TPAPWSQLSSRS-03'" -TrustServerCertificate | Out-File -FilePath D:\PSScripts\activeinstance.txt
#$incms=
Get-DbaRegServer -SqlInstance TPAPWMSSQL002 -Group ProdAll | Select-Object Name | Out-File -FilePath D:\PSScripts\reginstance.txt
#$activeins=$instances.SqlInstance
$addreg=compare-object (Get-Content "D:\PSScripts\activeinstance.txt") (Get-Content "D:\PSScripts\reginstance.txt")

foreach($instance in $instances.Name)
{
Add-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName BLDPWHDS11 -Group PROD\SQL2014
#Add-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName $instance -Group NonProdAll
}
<#
Import-Module dbatools -EA SilentlyContinue 
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$instances = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] from [CMS].[dbo].[DBServer]  where Status in ('Y','P') AND Application like '%tele%'  order by HostName" -TrustServerCertificate
foreach($instance in $instances.SqlInstance)
{
Add-DbaRegServer -SqlInstance TPAPWMSSQL002 -ServerName $instance -Group TelePhony
}
#>


