SET NOCOUNT ON
Declare @Date_Key  datetime

Select @Date_Key = DATEADD(dd,DATEDIFF(dd,0,getdate()),0)
DECLARE @ServerName varchar(128)
SELECT @ServerName = CONVERT(varchar(128), SERVERPROPERTY('ServerName'))

SELECT    
	@Date_Key AS Date_Key,
  	@ServerName AS [Server], 
	name AS 'Login Name', 
	dbname AS 'Default Database', 
	[createdate] AS 'CreateDate',
	[updatedate] AS 'UpdateDate',
	[accdate] AS 'AccDate',
	isntname AS 'NT Name', 
	isntgroup AS 'NT Grp', 
	isntuser AS 'NT User', 
	sysadmin AS 'Sys Adm', 
	securityadmin AS 'Sec Adm', 
	serveradmin AS 'Srvr Adm', 
	setupadmin AS 'Setup Adm', 
	processadmin AS 'Proc Adm', 
	diskadmin AS 'Disk Adm', 
	dbcreator AS 'DB Creator', 
	bulkadmin AS 'Bulk Adm'
FROM	master.dbo.syslogins
ORDER BY name