﻿Install-Module -Name PSWindowsUpdate -Force
Get-Command–module PSWindowsUpdate
#check the Install history
import-Module PSWindowsUpdate
Get-WUHistory -ComputerName localhost -MaxDate "8/23/2024" | Select ComputerName,Title, Date,Result | FL ##M/D/YYYY
Get-WUJob -ComputerName TPAPWSQLMHB001
#Remove-WindowsUpdate -ComputerName TPATWSQL004 -KBArticleID KB5043050
$HideList = “KB5017308”
Get-WindowsUpdate -KBArticleID $HideList –Hide
#Show-WindowsUpdate -KBArticleID $HideList
#Get-WULastResults
Get-WUHistory| Where-Object {$_.Title -match “KB5036335*”} | Select-Object * | ft
Get-WindowsUpdate –Computername TPATWSQLHHA01
Get-WUList -MicrosoftUpdate -ComputerName localhost -Category "Security Updates"
#Get-WUList -MicrosoftUpdate -ComputerName TPAPWSQLBMC001 -Category "Critical Updates"
Get-WUList –Computername TPAPWSQLHHA01 
#Install-WindowsUpdate –Computername TPATWSQLHHB01 –AcceptAll -KBArticleID KB5058383 –IgnoreReboot -SendReport 

#Invoke-WUJob -ComputerName server1, server2, server3 -Script {ipmo PSWindowsUpdate; Get-WUInstall -AcceptAll -AutoReboot | Out-File C:\Windows\PSWindowsUpdate.log } -Confirm:$false -Verbose –RunNow