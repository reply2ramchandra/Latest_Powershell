﻿<#
Import-Module dbatools -EA SilentlyContinue 
$servers=Get-Content "T:\Test\remove_login.txt"
foreach($server in $servers)
{
Remove-DbaLogin -SqlInstance $server -Login HPS\a-sm42933 -Confirm:$false}
#>
Import-Module dbatools -EA SilentlyContinue
#Remove-DbaLogin -SqlInstance TPASWSQLDL002 -Login HPS\svc_Aria_SQL -Confirm:$false
