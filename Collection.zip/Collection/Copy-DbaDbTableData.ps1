﻿clear
Import-Module dbatools -ErrorAction SilentlyContinue
Copy-DbaDbTableData -SqlInstance TPAPWDWSQL004 -Destination TPAPWDWSQLA05 -Database HPS_ODS -DestinationDatabase HPS_ODS -Table [dbo].[FACT_SLA_RECONCILATION_FILE_MANAGEMENT] -KeepIdentity -Truncate
#Copy-DbaDbTableData -SqlInstance TPADWSQLARCH01 -Destination TPAPWMSSQL002 -Database LPUMLE -DestinationDatabase SQLSentry -Table [dbo].[RptClaimMember] -KeepIdentity -Truncate -AutoCreateTable
#Copy-DbaDbTableData -SqlInstance TPAPWDWSQL004 -Destination TPAPWDWSQLA05 -Database HPS_ODS -DestinationDatabase HPS_ODS -Table [dbo].[FACT_SLA_OVERPAYMENT_TIMELINESS] -KeepIdentity -Truncate
#Copy data one to another using Query
$params = @{
 SqlInstance = 'PRODWMSSPGN2-01\IHGN2P01'
 Destination = 'TPAPWSQLARCH01'
 Database = 'GetNext'
 DestinationDatabase = 'GetNext'
 DestinationTable = '[GetNext].[DBO].[FLOWDATAtblTriggers]'
 BatchSize = 10000
 Table = '[GetNext].[DBO].[FLOWDATAtblTriggers]'
 Query = " SELECT *
	 FROM [GetNext].[dbo].[FLOWDATAtblTriggers](nolock) where PackageGUID in
(select P.PackageGUID from FLOWDATAtblPackages P INNER JOIN FLOWDATAtblFieldData FD0 WITH(NOLOCK)
ON FD0.PackageGUID = P.PackageGUID INNER JOIN FLOWDEFtblFields FDF0 WITH(NOLOCK) ON FDF0.FieldDefGUID=FD0.FieldDefGUID
AND FDF0.CustomID='Source' AND FD0.FieldValue in ('RCNO') AND P.Status = 'Finished'
AND P.CreatedTimestamp  BETWEEN '2020-02-06 00:00:00' AND '2020-05-31 23:59:59'
AND P.WorkflowDefGUID in('434274DE-A98E-4B5C-88BB-7ADAAB6AA284'--HCSC
))"
KeepIdentity=$true }

Copy-DbaDbTableData @params




#Copies data from one table to another in the same instance
#Get-DbaDbTable -SqlInstance TPAPWMSSQL002 -Database SQL_Health_Check -Table STG_DiskSpace1 | Copy-DbaDbTableData -DestinationTable STG_DiskSpace
#Copies data from one instance to another for same Db
#Get-DbaDbTable -SqlInstance TPAQWDWSQL00 -Database HPS_Loading -Table tb1, tb2 | Copy-DbaDbTableData -Destination TPAQWSQLDL001


