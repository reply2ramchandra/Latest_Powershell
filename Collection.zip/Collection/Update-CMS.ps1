﻿##MSSQL Edition update in CMS
Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] WHERE Status IN('Y') and Application='Mountain Health';" #-TrustServerCertificate
foreach($SQL in $servers.SqlInstance)
{
$data = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT CONVERT(varchar(50), SERVERPROPERTY('Edition')) as Edition" -As SingleValue
$data
Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "Update dbo.DBServer SET Edition='$data' where SqlInstance='$SQL'" 
}

##Gather current build version

clear
Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] WHERE Status IN('Y','P','R') and HostName NOT in('PCIPWSQL001','TPAPWSQLSSRS-03','Localhost');" -TrustServerCertificate
foreach($SQL in $servers.SqlInstance)
{
Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT @@serverName as Srv, CONVERT(varchar(9), SERVERPROPERTY('productversion')) as BuildNumber,CONVERT(varchar(9), SERVERPROPERTY('productlevel')) as SPLevel, CONVERT(varchar(9), SERVERPROPERTY('ProductUpdateLevel')) as CULevel" | Format-Table -AutoSize
}

##MSSQL BuildNumber update in CMS
Import-Module dbatools -EA SilentlyContinue 
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where BuildNumber IS NULL and Status='Y' and HostName<>'TPAPWSQLSSRS-03';" -TrustServerCertificate
foreach($SQL in $servers.SqlInstance)
{
$data = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT CONVERT(varchar(9), SERVERPROPERTY('productversion')) as BuildNumber" -As SingleValue
$data
Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "Update dbo.DBServer SET BuildNumber='$data' where SqlInstance='$SQL'" 
}

##MSSQL IPADDRESS CMS update

$instance  = 'TPAPWMSSQL002'
$database  = 'CMS'
$hostnames = Invoke-Sqlcmd -ServerInstance $instance -Database $database -Query @"
SELECT HostName FROM [CMS].[dbo].[DBServer]WHERE IpAddress IS NULL AND Status = 'Y';
"@ | Select-Object -ExpandProperty HostName

$updateSql = @'
UPDATE [CMS].[dbo].[DBServer] SET IpAddress = '$(IPADDR)' WHERE HostName = '$(HOSTNAME)';
'@

foreach ($h in $hostnames) {
    $hostClean = $h.Trim()
    $ip = try {
        ([System.Net.Dns]::GetHostAddresses($hostClean) |
          Where-Object AddressFamily -eq InterNetwork |
          Select-Object -First 1).IPAddressToString
    } catch { $null }

    if (-not $ip) { continue }

    $ipEsc    = $ip       -replace "'", "''"
    $hostEsc  = $hostClean -replace "'", "''"

    Invoke-Sqlcmd -ServerInstance $instance -Database $database -Query $updateSql `
        -Variable IPADDR=$ipEsc, HOSTNAME=$hostEsc
}
##MSSQL IPADDRESS CMS update
Import-Module dbatools -EA SilentlyContinue 
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [HostName] FROM [CMS].[dbo].[DBServer] where IpAddress IS NULL and Status='Y';" -TrustServerCertificate
foreach($h in $servers.HostName)
{
$IP=Test-NetConnection $h | select -Expand RemoteAddress
if($IP){Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "Update [CMS].[dbo].[DBServer] SET IpAddress='$IP' where HostName='$h'" }
}


##mysql IPADDRESS CMS update
Import-Module dbatools -EA SilentlyContinue 
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [ServerName] FROM [CMS].[dbo].[MySQLMaster] Where [Status]='Y';" -TrustServerCertificate
foreach($mysql in $servers.ServerName)
{
$IP=Test-NetConnection $mysql | select -Expand RemoteAddress
if($IP){Invoke-DbaQuery -SqlInstance TPAPWMSSQL002 -Database CMS -Query "Update [dbo].[MySQLMaster] SET IpAddress='$IP' where ServerName='$mysql'" }
}



##MSSQL BuildNumber and CU update in CMS, SQL Version Wise
##change the input query to select sql instance as required
Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] WHERE Status IN ('Y','P') and category='NonProd' and HA=0;" -TrustServerCertificate
foreach($SQL in $servers.SqlInstance)
{
$patch = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT CONVERT(varchar(9), SERVERPROPERTY('productversion')) as BuildNumber,CONVERT(varchar(9), SERVERPROPERTY('productlevel')) as SPLevel, CONVERT(varchar(9), SERVERPROPERTY('ProductUpdateLevel')) as CULevel" 
$build=$patch.BuildNumber
$sp=$patch.SPLevel
$cu=$patch.CULevel
Invoke-DbaQuery -SqlInstance $collectionSql -Database $collectionDb -Query "Update dbo.DBServer SET BuildNumber='$build',SPLevel='$sp', CULevel='$cu' where SqlInstance='$SQL'" 
}
##for all
Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where  Status IN('Y','R') and  MajorVersion='SQL Server 2022'  and category='NonProd' and HA=1" -TrustServerCertificate
foreach($SQL in $servers.SqlInstance)
{
$patch = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT CONVERT(varchar(9), SERVERPROPERTY('productversion')) as BuildNumber,CONVERT(varchar(9), SERVERPROPERTY('productlevel')) as SPLevel, CONVERT(varchar(9), SERVERPROPERTY('ProductUpdateLevel')) as CULevel" 
$build=$patch.BuildNumber
$sp=$patch.SPLevel
$cu=$patch.CULevel
Invoke-DbaQuery -SqlInstance $collectionSql -Database $collectionDb -Query "Update dbo.DBServer SET BuildNumber='$build',SPLevel='$sp', CULevel='$cu' where SqlInstance='$SQL'" 
}
#SQL 2019
Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] FROM [CMS].[dbo].[DBServer] where Status IN ('Y','P') and MajorVersion='SQL Server 2019' and HostName<>'PCIPWSQL001';" -TrustServerCertificate
foreach($SQL in $servers.SqlInstance)
{
$patch = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT CONVERT(varchar(9), SERVERPROPERTY('productversion')) as BuildNumber,CONVERT(varchar(9), SERVERPROPERTY('productlevel')) as SPLevel, CONVERT(varchar(9), SERVERPROPERTY('ProductUpdateLevel')) as CULevel" 
$build=$patch.BuildNumber
$sp=$patch.SPLevel
$cu=$patch.CULevel
Invoke-DbaQuery -SqlInstance $collectionSql -Database $collectionDb -Query "Update dbo.DBServer SET BuildNumber='$build',SPLevel='$sp', CULevel='$cu' where SqlInstance='$SQL'" 
}

##service account update
Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [SqlInstance] from [CMS].[dbo].[DBServer] where Status IN('Y','R') and  MajorVersion='SQL Server 2022'  and BuildNumber='16.0.4205';" -TrustServerCertificate
foreach($SQL in $servers.SqlInstance)
{
$serviceaccount = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "select service_account from sys.dm_server_services where servicename like 'SQL Server (%';" 
$srcaccount=$serviceaccount.service_account
if($srcaccount){
Invoke-DbaQuery -SqlInstance $collectionSql -Database $collectionDb -Query "Update dbo.DBServer SET ServiceAccount='$srcaccount' where SqlInstance='$SQL'" }
}


##individual SQL instance build Number update
import-module dbatools -EA SilentlyContinue
$SQL="BLDPWVSQL001"
$patch = Invoke-DbaQuery -SqlInstance $SQL -Database master -Query "SELECT CONVERT(varchar(9), SERVERPROPERTY('productversion')) as BuildNumber,CONVERT(varchar(9), SERVERPROPERTY('productlevel')) as SPLevel, CONVERT(varchar(9), SERVERPROPERTY('ProductUpdateLevel')) as CULevel" 
$build=$patch.BuildNumber
$sp=$patch.SPLevel
$cu=$patch.CULevel
Invoke-DbaQuery -SqlInstance tpapwmssql002 -Database cms -Query "Update dbo.DBServer SET BuildNumber='$build',SPLevel='$sp', CULevel='$cu' where SqlInstance='$SQL'" 

##Update ListnerName
import-module dbatools -EA SilentlyContinue
$mysql=get-Content "T:\Test\5724.txt"
foreach($server in $mysql)
{
$SQL=$server.replace('L01','A01')
$list=Test-NetConnection $server | select ComputerName,RemoteAddress
$listname=$list.ComputerName
$listip=$list.RemoteAddress
Invoke-DbaQuery -SqlInstance tpapwmssql002 -Database cms -Query "Update dbo.DbaAGServer SET ListenerName='$listname',ListenerIP='$listip' where ServerName='$SQL'" 
}

##update OSversion Table

Import-Module dbatools -EA SilentlyContinue
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
$servers = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [ComputerName] from [CMS].[dbo].[OSVersion]" -TrustServerCertificate
foreach($srv in $servers.ComputerName )
{
$hst=$srv.replace('.HPS.HPH.AD','')
Invoke-DbaQuery -SqlInstance tpapwmssql002 -Database cms -Query "Update dbo.OSVersion SET [HostName]='$hst' where ComputerName='$srv'" 
}