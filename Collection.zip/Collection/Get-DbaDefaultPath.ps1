﻿Import-Module dbatools -DisableNameChecking 
Get-DbaDefaultPath -SqlInstance PRODWMSSPGN2-01\IHGN2P01
