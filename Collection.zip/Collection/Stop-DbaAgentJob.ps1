﻿Import-Module dbatools -DisableNameChecking
#Get-DbaAgentJob -SqlInstance sql2016 -Job cdc.DBWithCDC_capture | Stop-DbaAgentJob
Get-DbaAgentJob -SqlInstance tpapwdwsqlB05 | Get-DbaRunningJob | Stop-DbaAgentJob