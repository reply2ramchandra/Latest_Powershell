﻿CREATE FUNCTION [Admin].[fn_format_sqlci] (@SqlInstance VARCHAR(256))
RETURNS VARCHAR(256)
AS
/***************************************************************************************************************************************
	Copyright © 2021 Ensono LP, USA. All rights reserved

	Purpose: To format the SQL instance CIs to sync with CMDB CI naming convention
	

	History:
	------------------------------------------------------------------------------------------------------------------------------------
	Author                                 Date Created                Comments
	------------------------------------------------------------------------------------------------------------------------------------
	Harsha vasa                              2021-10-18                  Initial draft



    ------------------------------------------------------------------------------------------------------------------------------------

	Documentation:
	--------------
            ASCII(169) - ©


	Execution Samples:
	------------------
	#1: Named Instance

	SELECT Admin.fn_format_sqlci('ServerName\Instance')

	Output:
	-------
	ServerName:Instance
	-------

	#2: Default Instance

	SELECT Admin.fn_format_sqlci('ServerName')

	Output:
	-------
	ServerName:DEFAULT
	-------

***************************************************************************************************************************************/

	BEGIN
		DECLARE @ci_format VARCHAR(256);

		SET @SqlInstance = LTRIM(RTRIM(@SqlInstance));
		SELECT
			@ci_format = CASE
				WHEN CHARINDEX( '\',@SqlInstance ) = 0 THEN @SqlInstance + ':' + 'DEFAULT'
				ELSE REPLACE( @SqlInstance,'\',':' )
			END;

		RETURN @ci_format;
	END;
