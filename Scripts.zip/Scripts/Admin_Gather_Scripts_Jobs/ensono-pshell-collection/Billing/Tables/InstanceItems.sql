﻿CREATE TABLE [Billing].[InstanceItems]
(
	[SqlInstance] VARCHAR(256) NOT NULL
)
