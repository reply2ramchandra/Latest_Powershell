﻿$TargetServer='tpapwidesql001'
$service= Get-Service -ComputerName $TargetServer | Where-Object Name -like '*SQLdm*' | select-Object Name,DisplayName,Status 
$service
 ##Get-DbaService $TargetServer | Select-Object ComputerName,ServiceName,StartName,State

Get-Service -ComputerName tpapwidesql001 | Where-Object Name -like '*SQLdm*' | Start-Service -Verbose


#Get-Service -ComputerName tpapwidesql001 | Where-Object Name -like '*SQLdm*' | Stop-Service -Verbose
#Get-Service -ComputerName tpapwpedsql001 | Where-Object Name -like '*jenk*' | Start-Service -Verbose
#Get-Service -ComputerName tpapwsqlgnxtb01 | Where-Object Name -like '*Clus*' 