﻿clear-host
$server='TPAPWSQLDLR006'
$bckpath="D:\MSSQL16.MSSQLSERVER\MSSQL\Backup\"
 Invoke-Command -ComputerName $server -ScriptBlock { param($bckpath)
$acl = Get-Acl -path $bckPath
$permission = "HPS\svc_datalinksql","FullControl","Allow"
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule $permission
$acl.SetAccessRule($rule)
Set-Acl $bckpath $acl} -ArgumentList $bckpath