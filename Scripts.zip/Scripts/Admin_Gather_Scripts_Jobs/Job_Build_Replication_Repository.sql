USE [msdb]
GO

/****** Object:  Job [ACXJOB_Build_Replication_Repository]    Script Date: 2/9/2023 12:13:28 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Ensono-Maintenance]    Script Date: 2/9/2023 12:13:28 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Ensono-Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Ensono-Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ACXJOB_Build_Replication_Repository', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'this job runs every week to build a replication repository for the servers involved in the replication topology. output is saved to default backup path under uRepository dir.', 
		@category_name=N'Ensono-Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Step@1 - Create Repo subfolder]    Script Date: 2/9/2023 12:13:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Step@1 - Create Repo subfolder', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @oDefaultBackupdir Nvarchar(512)
DECLARE @CreateSubFolder Nvarchar(512)
DECLARE @tSubDirectories TABLE (dir Varchar(8000));

                EXEC  [master].dbo.xp_instance_regread	N''HKEY_LOCAL_MACHINE''
					               ,N''SOFTWARE\Microsoft\MSSQLServer\MSSQLServer''
					               ,N''BackupDirectory''
					               ,@oDefaultBackupdir OUTPUT;

				-- exit if subfolder creation fails

				IF @oDefaultBackupdir IS NULL
					BEGIN
						RAISERROR (N''Could find default backup directory.Returned as NULL.Check the settings and rerun'', 11, 1) WITH NOWAIT;
					END;

				INSERT INTO @tSubDirectories
				EXEC [master].dbo.xp_subdirs @oDefaultBackupdir;

				-- construct string to create sub folder urefresh
				SET @CreateSubFolder = @oDefaultBackupdir + ''\uRepository'';

				-- create folder if not exists

				IF NOT EXISTS
				(
					SELECT
						1
					FROM @tSubDirectories
					WHERE dir = ''uRepository''
				)

                 EXEC [master].sys.xp_create_subdir @CreateSubFolder;', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Step@2 - Run Drop Repl]    Script Date: 2/9/2023 12:13:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Step@2 - Run Drop Repl', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d DBA -Q "EXEC dbo.usp_repo_gen_drop_replication" -o Y:\SQLBackups\MSSQL11.SQLHV1\MSSQL\Backup\uRepository\ACWIN-SQLPRHUB_SQLHV1_dropREPL_$(ESCAPE_SQUOTE(STRTDT)).sql -y 0 -b', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Step@3 - Run Create Distributor]    Script Date: 2/9/2023 12:13:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Step@3 - Run Create Distributor', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=3, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d DBA -Q "EXEC dbo.usp_repo_gen_create_dist" -o Y:\SQLBackups\MSSQL11.SQLHV1\MSSQL\Backup\uRepository\ACWIN-SQLPRHUB_SQLHV1_createREPLdist_$(ESCAPE_SQUOTE(STRTDT)).sql -y 0 -b', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Step@4 - Run Create Publication]    Script Date: 2/9/2023 12:13:28 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Step@4 - Run Create Publication', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d DBA -Q "EXEC dbo.usp_repo_gen_create_pub" -o Y:\SQLBackups\MSSQL11.SQLHV1\MSSQL\Backup\uRepository\ACWIN-SQLPRHUB_SQLHV1_createREPLpubs_$(ESCAPE_SQUOTE(STRTDT)).sql -y 0 -b', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Weekly @ Sunday', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160719, 
		@active_end_date=99991231, 
		@active_start_time=30000, 
		@active_end_time=235959, 
		@schedule_uid=N'8fd9724d-a457-438f-8aae-2f92c7c9117a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


