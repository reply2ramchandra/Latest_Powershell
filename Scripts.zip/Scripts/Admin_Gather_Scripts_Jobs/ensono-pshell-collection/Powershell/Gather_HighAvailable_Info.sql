
DECLARE @LogShip  VARCHAR(5)
	   ,@DbMirror VARCHAR(5)
	   ,@Repl	  VARCHAR(5)


IF (EXISTS (SELECT 1 FROM [msdb].[dbo].[log_shipping_primary_databases])
OR EXISTS (SELECT 1 FROM [msdb].[dbo].[log_shipping_secondary_databases])
)
	SET @LogShip = 'True'

IF EXISTS (SELECT 1 FROM sys.databases WHERE is_distributor = 1 OR is_published = 1 OR is_subscribed = 1)
	SET @Repl = 'True';

IF EXISTS (SELECT 1 FROM sys.database_mirroring WHERE mirroring_role IS NOT NULL)
	SET @DbMirror = 'True'

SELECT
	UPPER( CAST( SERVERPROPERTY( 'ServerName' ) AS VARCHAR(256) ) ) AS SqlInstance
   ,@LogShip										AS LogShippingEnabled
   ,@DbMirror										AS DbMirrorEnabled
   ,@Repl											AS ReplicationEnabled