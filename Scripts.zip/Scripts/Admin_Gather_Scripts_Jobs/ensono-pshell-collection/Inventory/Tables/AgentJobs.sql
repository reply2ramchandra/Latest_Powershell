﻿CREATE TABLE [Inventory].[AgentJobs]
(
	[DateKey] SMALLDATETIME,
    [SqlInstance] VARCHAR(256) NOT NULL,
	[Name] VARCHAR(256) NULL, 
    [DateCreated] DATETIME NULL, 
    [Category] VARCHAR(128) NULL, 
    [OwnerLoginName] VARCHAR(256) NULL, 
    [IsEnabled] BIT NULL, 
    [LastRunDate] DATETIME2(1) NULL, 
    [LastRunOutcome] VARCHAR(128) NULL, 
    CONSTRAINT FK_AgentJobs_SqlInstance FOREIGN KEY ([SqlInstance]) REFERENCES [Inventory].[ServerList] ([SqlInstance]) ON DELETE CASCADE
)

GO 

CREATE CLUSTERED INDEX [CX_AgentJobs_SqlInstance] ON [Inventory].[AgentJobs] (SqlInstance)