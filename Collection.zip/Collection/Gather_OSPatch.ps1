﻿clear-host
get-date
#change the KB article # for each month patch accordingly
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue 
import-Module PSWindowsUpdate
<##KB5052108
$os2012 = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [HostName] FROM [CMS].[dbo].[DBServer] where [OSVersion] like '%2012%' and DC<>'GCP' and HA=0 AND [STATUS]='Y'"  -TrustServerCertificate 
foreach($2012 in $os2012.HostName)
{
$OSPatch2012=Get-WUHistory -ComputerName $2012 | Where-Object {$_.Title -match “KB5052108*”} | Select ComputerName,Date,Title,Result,KB 
Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'OSPatch2012' -InputObject $OSPatch2012  -AutoCreateTable -KeepNulls
}
#>



#change the KB article # for each month patch accordingly
$collectionSql = 'tpapwmssql002'
$collectionDb = 'CMS'
Import-Module dbatools -EA SilentlyContinue 
import-Module PSWindowsUpdate
Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "IF OBJECT_ID('CMS..OSPatch2016') IS NOT NULL DROP TABLE OSPatch2016;IF OBJECT_ID('CMS..OSPatch2019') IS NOT NULL DROP TABLE OSPatch2019;IF OBJECT_ID('CMS..OSPatch2022') IS NOT NULL DROP TABLE OSPatch2022;"  -TrustServerCertificate 
##KB5052108
<#$os2016 = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [HostName] FROM [CMS].[dbo].[DBServer] where [OSVersion] like '%2016%' and DC<>'GCP' and HA=0 AND STATUS IN('Y','P')"  -TrustServerCertificate 
foreach($2016 in $os2016.HostName)
{
$OSPatch2016=Get-WUHistory -ComputerName $2016 | Where-Object {$_.Title -match “KB5058524*” -OR $_.Title -match “KB5058383*” } | Select ComputerName,Date,Title,Result,KB 
if($OSPatch2016){Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'OSPatch2016' -InputObject $OSPatch2016  -AutoCreateTable -KeepNulls}
}
#>

$os2019 = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [HostName] FROM [CMS].[dbo].[DBServer] where [OSVersion] like '%2019%' and DC<>'GCP' and HA=0 AND STATUS IN('Y','P')"  -TrustServerCertificate 
import-Module PSWindowsUpdate
foreach($2019 in $os2019.HostName)
{
$OSPatch2019=Get-WUHistory -ComputerName $2019 | Where-Object {$_.Title -match “KB5058392*”} | Select ComputerName,Date,Title,Result,KB
if($OSPatch2019){Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'OSPatch2019' -InputObject $OSPatch2019  -AutoCreateTable -KeepNulls }
}

$os2022 = Invoke-Sqlcmd -ServerInstance $collectionSql -Database $collectionDb -query  "SELECT [HostName] FROM [CMS].[dbo].[DBServer] where [OSVersion] like '%2022%' and DC<>'GCP' and HA=0 AND STATUS IN('Y','P')"  -TrustServerCertificate 
import-Module PSWindowsUpdate
foreach($2022 in $os2022.HostName)
{
$OSPatch2022=Get-WUHistory -ComputerName $2022 | Where-Object {$_.Title -match “KB5058385*”} | Select ComputerName,Date,Title,Result,KB
if($OSPatch2022){Write-DbaDataTable -SqlInstance $collectionSql -Database $collectionDb -Schema 'dbo' -Table 'OSPatch2022' -InputObject $OSPatch2022  -AutoCreateTable -KeepNulls }
}
get-date
#import-Module PSWindowsUpdate; Get-WUHistory -ComputerName TPATWSQLQFILE01 | Where-Object {$_.Title -match “KB5048671*”} | Select ComputerName,Date,Title,Result,KB 