﻿Get-PackageSource
Register-PackageSource -Name "nuget.org" -Location "https://api.nuget.org/v3/index.json" -ProviderName "NuGet"

Install-Package -Name MimeKit -Source nuget.org
Install-Package -Name MailKit -Source nuget.org
nuget locals all -clear
Get-PackageSource | Where-Object { $_.Name -eq 'nuget.org' } | Set-PackageSource -Trusted -Force
Install-Package -Name MailKit -Source nuget.org

nuget install MailKit