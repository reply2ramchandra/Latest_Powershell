﻿$server='TPAQWSQLDL001'
Invoke-Command -ComputerName $server -ScriptBlock {
Write-host "***Inprogress***"
powershell.exe -command "& C:\Patch\ServiceNow-ODBC-64-bit_1.0.13.exe /quiet IACCEPTMSLICENSETERMS=YES"}