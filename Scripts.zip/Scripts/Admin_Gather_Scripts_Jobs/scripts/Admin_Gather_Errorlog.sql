IF EXISTS (SELECT name FROM tempdb..sysobjects WHERE name like '#TempLog%')
	DROP TABLE #TempLog

IF EXISTS (SELECT name FROM tempdb..sysobjects WHERE name like '#TempLog2000%')
	DROP TABLE #TempLog2000

IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wErrorLog') ) 
    DROP TABLE #wErrorLog  


CREATE TABLE #TempLog (
      LogDate     DATETIME,
      ProcessInfo NVARCHAR(50),
      [Text] NVARCHAR(3000)
)
CREATE TABLE #TempLog2000 (
      [Text] NVARCHAR(3000),
      [ContinuationInfo] NVARCHAR(50)
)
CREATE TABLE #wErrorLog (
      LogDate     DATETIME,
      ProcessInfo NVARCHAR(50),
      [Text] NVARCHAR(3000),
      [Server] sysname
)

 
IF @@Version not like '%2000%'
BEGIN
      INSERT INTO #TempLog
      EXEC sp_readerrorlog 0
END

IF @@Version like '%2000%'
BEGIN
      INSERT INTO #TempLog2000
      EXEC sp_readerrorlog 0
END


--Find Information.

INSERT INTO #wErrorLog
SELECT LogDate, ProcessInfo, Text, CONVERT(sysname, SERVERPROPERTY('Servername')) AS [Server]
FROM #TempLog
WHERE 	DATEDIFF(HH, LogDate, GETDATE()) < 36 AND
	Text NOT LIKE '%Log was backed up%' AND 
	Text NOT LIKE '%Log backed up%' AND 
	Text NOT LIKE '%Database backed up%' AND 
	Text NOT LIKE '%Login succeeded%' AND
	Text NOT LIKE '%differential changes were backed up%'
UNION
SELECT CONVERT(DATETIME,REPLACE(LEFT(Text ,22), ' ', 'T')) AS LogDate, 'Login' AS ProcessInfo, Text, CONVERT(sysname, SERVERPROPERTY('Servername')) AS [Server]
FROM #TempLog2000
WHERE	ISNUMERIC(LEFT(Text,4)) = 1 AND 
		ISNUMERIC(SUBSTRING(Text,6, 2)) = 1 AND
		ISNUMERIC(SUBSTRING(Text,9, 2)) = 1 AND
		ISNUMERIC(SUBSTRING(Text,12, 2)) = 1 AND
		ISNUMERIC(SUBSTRING(Text,15, 2)) = 1 AND
		ISNUMERIC(SUBSTRING(Text,18, 2)) = 1 AND
		ISNUMERIC(SUBSTRING(Text,21, 2)) = 1 AND
		Text NOT LIKE '%Log was backed up%' AND
		Text NOT LIKE '%Log backed up%' AND
		Text NOT LIKE '%Database backed up%' AND
		Text NOT LIKE '%Login succeeded%' AND
		Text NOT LIKE '%differential changes were backed up%' AND
		DATEDIFF(HH,CONVERT(DATETIME,REPLACE(LEFT(Text ,22), ' ', 'T')),GETDATE())<36

SELECT [LogDate]
      ,[ProcessInfo]
      ,[Text]
      ,[Server]
  FROM #wErrorLog




IF EXISTS (SELECT name FROM tempdb..sysobjects WHERE name like '#TempLog%')
	DROP TABLE #TempLog

IF EXISTS (SELECT name FROM tempdb..sysobjects WHERE name like '#TempLog2000%')
	DROP TABLE #TempLog2000

IF EXISTS ( SELECT  *
            FROM    tempdb.dbo.sysobjects
            WHERE   id = OBJECT_ID(N'#wErrorLog') ) 
    DROP TABLE #wErrorLog  
